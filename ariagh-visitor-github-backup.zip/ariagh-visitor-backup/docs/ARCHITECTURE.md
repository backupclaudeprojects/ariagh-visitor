# معماری ARIAGH.VISITOR

نمودارها با Mermaid کشیده شده‌اند و GitHub آن‌ها را خودکار نمایش می‌دهد. مسیر فایل‌ها نسبت به پوشه `ariagh-visitor/` است.

## ۱. نمای کلی اجزا

```mermaid
flowchart TB
  subgraph Browser["مرورگر"]
    CP["پنل مشتری<br/>assets/js/customer-panel.js"]
    VP["پنل ویزیتور / مدیر<br/>assets/js/visitor-panel.js"]
    AJ["صفحات تنظیمات wp-admin<br/>assets/js/admin.js"]
    CORE["هسته UI و API مشترک<br/>assets/js/bws-core.js (window.BWSU)"]
    CP --> CORE
    VP --> CORE
  end

  subgraph WP["وردپرس + ووکامرس"]
    MAIN["ariagh-visitor.php<br/>نقطه ورود و require"]
    REST["includes/class-rest.php<br/>REST bws/v1"]
    AUTH["class-auth.php<br/>توکن مشتری · OTP"]
    PERM["class-perms.php<br/>دسترسی ویزیتور"]
    CUST["class-customers.php"]
    ORD["class-orders.php"]
    LED["class-ledger.php<br/>دفتر اعتبار"]
    PROD["class-products.php"]
    SMS["class-sms.php<br/>+ sms/class-sms-drivers.php"]
    RET["returns/class-returns.php<br/>مرجوعی"]
    FILES["returns/class-return-files.php"]
    BOT["returns/class-bot.php"]
    MSG["returns/class-messenger.php"]
    GD["returns/class-gdrive.php"]
    ADM["admin/class-admin*.php"]
    SPP["gateways/class-snapppay-*.php"]
    OPT[("option: bws_settings")]
    DB[("جداول wp_bws_*")]
  end

  subgraph Ext["سرویس‌های بیرونی"]
    TG["Telegram Bot API"]
    BL["Bale Bot API"]
    GDR["Google Drive v3"]
    SMSP["پنل‌های پیامک ایرانی"]
    SNP["SnappPay"]
  end

  CORE -- "fetch / XHR + X-BWS-Token یا X-WP-Nonce" --> REST
  AJ --> REST
  REST --> AUTH & PERM
  REST --> CUST & ORD & LED & PROD & SMS & RET
  ADM --> OPT
  RET --> FILES & BOT & SMS & LED & ORD
  BOT --> MSG --> TG & BL
  FILES --> GD --> GDR
  SMS --> SMSP
  SPP --> SNP
  TG -- "وب‌هوک /bws/v1/bot/telegram/{secret}" --> BOT
  BL -- "وب‌هوک /bws/v1/bot/bale/{secret}" --> BOT
  CUST & ORD & LED & RET & FILES --> DB
  MAIN --> REST & ADM
```

## ۲. چرخه کامل یک مرجوعی

```mermaid
sequenceDiagram
  autonumber
  actor C as مشتری / ویزیتور
  participant JS as bws-core.js<br/>U.returnForm + U.upload
  participant API as BWS_Returns::rest_*_create
  participant R as BWS_Returns
  participant F as BWS_Return_Files
  participant B as BWS_Bot
  participant M as BWS_Messenger
  participant G as BWS_GDrive
  actor T as گیرندگان تلگرام/بله

  C->>JS: سفارش، کالا و تعداد، دلیل، توضیح، عکس
  JS->>JS: compressImage (۱۶۰۰px)
  JS->>API: multipart (photos[]) با نوار پیشرفت
  API->>R: create(): قفل ret_c{id}، اعتبارسنجی تعداد ≤ باقیمانده
  R->>F: validate + store (بازسازی JPEG، نام تصادفی)
  R-->>JS: کد R-xxxx (پاسخ فوری)
  Note over R: defer('new') → shutdown + fastcgi_finish_request
  R->>R: process(): پیامک یک‌بار
  R->>B: deliver(r,'new',$st)
  loop هر گیرنده فعال در محدوده
    B->>M: send_view: عکس+زیرنویس / آلبوم / جایگزین متنی
    M->>T: sendPhoto | sendMediaGroup | sendMessage
    B->>B: ذخیره root[p|chat] = message_id
  end
  R->>F: push_to_drive (gdrive/both)
  F->>G: upload (Resumable) + تطبیق MD5
  Note over R: خطای موقت → bws_returns_retry (کران هر ۵ دقیقه)

  T->>B: دکمه تأیید (callback a:ID → ar:ID:credit)
  B->>R: decide() به‌عنوان کاربر متصل (همان دسترسی‌ها)
  R->>R: دفتر اعتبار / سفارش جایگزین / دستی + پیامک به مشتری
  R->>B: deliver(r,'decision')
  B->>M: send_update = Reply روی root هر چت
  M->>T: «✅ تأیید شد توسط …»
```

## ۳. جداول دیتابیس

```mermaid
erDiagram
  bws_customers ||--o{ bws_ledger : "بدهی/پرداخت"
  bws_customers ||--o{ bws_orders : "سفارش‌ها"
  bws_customers ||--o{ bws_visits : "ویزیت"
  bws_customers ||--o{ bws_returns : "مرجوعی"
  bws_returns ||--|{ bws_return_items : "اقلام"
  bws_returns ||--o{ bws_return_files : "عکس‌ها"
  bws_orders }o--|| wc_orders : "order_id"
  bws_customers {
    bigint id
    varchar code
    bigint visitor_id
    decimal credit_limit
    decimal balance
    varchar status
  }
  bws_ledger {
    bigint id
    varchar type "purchase|payment|return|reversal|..."
    decimal amount "+بدهی -پرداخت"
    decimal balance_after
  }
  bws_orders {
    bigint order_id
    varchar kind "order|settlement|replacement"
    varchar status
    decimal total
  }
  bws_returns {
    bigint id
    varchar code "R-1000+id"
    varchar status "pending|approved|rejected|cancelled"
    varchar resolution "credit|replacement|manual"
    varchar storage "host|gdrive|both"
    longtext notify_state "JSON"
    int attempts
  }
  bws_return_items {
    bigint order_item_id
    int qty
    int approved_qty
    decimal unit_price
  }
  bws_return_files {
    varchar path "خالی=حذف از هاست"
    varchar drive_id
    varchar state "local|uploaded|pending|purged"
    varchar md5
  }
```

بقیه جداول: `bws_products` (قیمت عمده هر محصول)، `bws_sms_log`، `bws_activity` (گزارش فعالیت). تعریف همه در `includes/class-install.php:79`.

## ۴. دسترسی‌ها

```mermaid
flowchart LR
  REQ["درخواست REST"] --> P{"permission_callback"}
  P -- open --> X1["ورود مشتری / OTP"]
  P -- is_customer --> X2["فقط داده همان مشتری (توکن HMAC)"]
  P -- is_staff --> S{"BWS_Perms::scope_allows"}
  P -- is_manager --> X3["همه چیز (cap: bws_manage)"]
  S -- all --> OK1["همه مشتریان"]
  S -- own --> OK2["فقط مشتریانی که visitor_id = کاربر"]
  S -- none --> NO["403"]
```

مجوزها در `class-perms.php:12` (`schema`) تعریف شده‌اند. پیش‌فرض همه ویزیتورها در تنظیمات (`visitor_perms`) است و برای هر ویزیتور هم دسترسی اختصاصی دارد (`bws_perm_mode=custom` + `bws_perms` در user meta). مرجوعی: `returns_view`، `returns_create`، `returns_decide` (own/all/none)، `returns_credit`، `returns_replace`.

## ۵. ربات تعاملی

```mermaid
flowchart TD
  U["آپدیت تلگرام/بله"] -->|"وب‌هوک یا poll() هر دقیقه"| H["BWS_Bot::handle_update<br/>حذف تکراری با update_id"]
  H --> M{"message یا callback_query؟"}
  M -- "/start" --> W["welcome: گیرنده → خوش‌آمد + دکمه منو<br/>ناشناس → اعلام شناسه عددی"]
  M -- "📋 مرجوعی‌های باز یا /open" --> L["open_list: pending در محدوده گیرنده<br/>+ دکمه v:ID"]
  M -- "متن در حالت انتظار دلیل" --> RJ["finish_reject → decide(reject)"]
  M -- "v:ID" --> V["send_view (Reply روی لیست)"]
  M -- "a:ID" --> A["actor(): گیرنده با decide + کاربر متصل + scope<br/>→ دکمه‌های نوع رسیدگی مجاز"]
  M -- "ar:ID:res" --> AP["decide(approve)"]
  M -- "r:ID" --> RS["transient انتظار دلیل + force_reply"]
  AP & RJ --> D["defer('decision') → Reply به همه گیرندگان"]
```

## ۶. مسیر فایل‌های عکس

| حالت (`return_storage`) | بعد از ثبت | بعد از ارسال ربات‌ها | نمایش در پنل |
|---|---|---|---|
| `host` | هاست | هاست | لینک امضاشده ۲ ساعته (`?bws_rfile=`) |
| `gdrive` | هاست موقت → درایو | نسخه هاست حذف می‌شود | کلیک: درایو؛ تصویر کوچک از طریق سایت (`serve` → `download`) |
| `both` | هاست + درایو | هر دو می‌مانند | هاست + نشان لینک درایو |

پاک‌سازی (`cleanup_run`) فقط نسخه هاست را حذف می‌کند و فایل‌هایی که هنوز در صف درایو هستند را هرگز حذف نمی‌کند.
