# ARIAGH.VISITOR — ویزیتور

افزونه وردپرس/ووکامرس برای **فروش عمده و ویزیتوری**. سه پنل دارد: مدیر، ویزیتور و مشتری عمده. امکانات اصلی:
- اعتبار و دفتر حساب
- پیامک با ۲۶ پنل ایرانی
- درگاه اسنپ‌پی
- **ثبت مرجوعی کالا** با ربات تلگرام و بله و ذخیره عکس در گوگل‌درایو

**نسخه فعلی: 2.3.1** · PHP 7.4+ · WordPress 6+ · WooCommerce 7+ (HPOS)

## ساختار مخزن
```
.
├── PROJECT_MAP.md          ← نقطه شروع: نقشه کامل پروژه برای ادامه کار (حتماً اول این را بخوانید)
├── NEW_CHAT_PROMPT.md      ← متن آماده برای شروع چت جدید با Claude
├── ariagh-visitor/         ← سورس کامل افزونه (آخرین نسخه)
│   ├── ariagh-visitor.php  ← نقطه ورود
│   ├── includes/           ← کلاس‌های PHP (هسته، returns/، admin/، sms/، gateways/، elementor/)
│   ├── assets/             ← js/ (هسته UI + پنل‌ها)، css/، img/، fonts/
│   ├── templates/          ← قالب تمام‌صفحه پنل
│   ├── readme.txt          ← توضیحات افزونه + Changelog
│   └── uninstall.php
├── docs/
│   ├── ARCHITECTURE.md     ← نمودارها (اجزا، چرخه مرجوعی، دیتابیس، دسترسی، ربات)
│   ├── diagrams/*.svg      ← همان نمودارها به‌صورت تصویر
│   ├── CHANGELOG.md        ← تاریخچه همه نسخه‌ها
│   ├── LESSONS.md          ← باگ‌های رفع‌شده و اشتباهاتی که نباید تکرار شوند
│   ├── TESTING.md          ← روش تست و بازسازی محیط تست
│   └── CHAT_HISTORY.md     ← متن گفتگوهای ساخت پروژه با Claude
├── releases/               ← فایل‌های zip همه نسخه‌ها (benli 1.1.0 تا 2.3.1)
└── tests/                  ← تست واحد ارسال ربات (بدون نیاز به وردپرس)
```

## نصب
فایل `releases/ariagh-visitor-2.3.1.zip` را در «افزونه‌ها ← افزودن ← بارگذاری» نصب کنید. بعد از هر به‌روزرسانی، کش سایت و CDN را یک‌بار پاک کنید.

## ساخت فایل نصب از سورس
```bash
# بررسی سینتکس
find ariagh-visitor -name "*.php" -exec php -l {} \; | grep -v "No syntax"
# فشرده‌سازی JS/CSS (فقط بعد از تغییر فایل‌های اصلی)
for f in bws-core customer-panel visitor-panel admin; do
  npx esbuild ariagh-visitor/assets/js/$f.js --minify --charset=utf8 --target=es2017 --outfile=ariagh-visitor/assets/js/$f.min.js
done
npx esbuild ariagh-visitor/assets/css/bws.css --minify --charset=utf8 --outfile=ariagh-visitor/assets/css/bws.min.css
# بسته
zip -r ariagh-visitor-X.Y.Z.zip ariagh-visitor
```

## امنیت مخزن
هیچ توکن، رمز یا کلیدی در این مخزن نیست. کلیدهای پیامک، ربات و گوگل فقط در تنظیمات هر سایت (رمزنگاری‌شده) ذخیره می‌شوند. اگر مخزن عمومی است، مطمئن شوید فایل یا اسکرین‌شاتی حاوی کلید به آن اضافه نکرده‌اید.
