<?php
define( 'ABSPATH', '/tmp/' ); define( 'BWS_VERSION', 't' ); define( 'MB_IN_BYTES', 1048576 );
$GLOBALS['S'] = array( 'tg_enabled' => 1, 'tg_token' => '1:TGTOKENaaaaaaaaaa', 'bale_enabled' => 1, 'bale_token' => '2:BLTOKENaaaaaaaaaa', 'bot_photos' => 1, 'company_name' => 'شرکت' );
function bws_opt( $k, $d = null ) { return array_key_exists( $k, $GLOBALS['S'] ) ? $GLOBALS['S'][ $k ] : $d; }
function bws_decrypt( $v ) { return $v; }
function esc_url_raw( $u ) { return $u; }
function untrailingslashit( $s ) { return rtrim( $s, '/' ); }
function wp_json_encode( $d, $o = 0 ) { return json_encode( $d, $o ); }
function is_wp_error( $x ) { return $x instanceof WP_Error; }
class WP_Error { public $m; function __construct( $c = '', $m = '' ) { $this->m = $m; } function get_error_message() { return $this->m; } }
function esc_html( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES ); }
function wp_strip_all_tags( $s ) { return strip_tags( $s ); }
function wp_parse_url( $u, $c = -1 ) { return parse_url( $u, $c ); }
function bws_en_digits( $s ) { return $s; }
function bws_fa_digits( $s ) { return (string) $s; }
function bws_money_text( $n ) { return number_format( (float) $n ) . ' تومان'; }
function bws_jdate( $d, $t = true ) { return '1405/08/16'; }
function bws_user_name( $id ) { return 'کاربر' . $id; }
function bws_is_manager( $u = null ) { return 1 === (int) $u; }
function bws_visitor_panel_url() { return 'https://site.ir/visitor-panel/'; }
function get_user_meta() { return ''; }
function random_str() { return 'x'; }
function wp_remote_retrieve_body( $r ) { return $r['body']; }
function wp_remote_retrieve_response_code( $r ) { return $r['response']['code']; }
$GLOBALS['calls'] = array(); $GLOBALS['mid'] = 10; $GLOBALS['plan'] = array();
function wp_remote_post( $url, $args ) {
	preg_match( '#/bot[^/]+/(\w+)$#', $url, $m ); $method = $m[1];
	$plat = false !== strpos( $url, 'BLTOKEN' ) ? 'bale' : 'telegram';
	$GLOBALS['calls'][] = array( $plat, $method, $args );
	$key = $plat . ':' . $method . ( false !== strpos( (string) $args['body'], 'reply_markup' ) ? ':kb' : '' );
	$rule = isset( $GLOBALS['plan'][ $key ] ) ? $GLOBALS['plan'][ $key ] : ( isset( $GLOBALS['plan'][ $plat . ':' . $method ] ) ? $GLOBALS['plan'][ $plat . ':' . $method ] : 'ok' );
	if ( 'net' === $rule ) return new WP_Error( 'x', 'timeout' );
	if ( is_int( $rule ) ) return array( 'body' => json_encode( array( 'ok' => false, 'error_code' => $rule, 'description' => 'Bad Request: test ' . $rule ) ), 'response' => array( 'code' => $rule ) );
	if ( 'sendMediaGroup' === $method ) return array( 'body' => json_encode( array( 'ok' => true, 'result' => array( array( 'message_id' => ++$GLOBALS['mid'] ), array( 'message_id' => ++$GLOBALS['mid'] ) ) ) ), 'response' => array( 'code' => 200 ) );
	return array( 'body' => json_encode( array( 'ok' => true, 'result' => array( 'message_id' => ++$GLOBALS['mid'] ) ) ), 'response' => array( 'code' => 200 ) );
}
class BWS_Returns { public static $statuses = array( 'pending' => 'در انتظار بررسی', 'approved' => 'تأیید شد', 'rejected' => 'رد شد', 'cancelled' => 'لغو' ); public static $resolutions = array( 'credit' => 'اعتبار', 'replacement' => 'جایگزین', 'manual' => 'دستی' );
	static function items( $id ) { return array( (object) array( 'name' => 'ماست', 'qty' => 2, 'approved_qty' => 0, 'unit_price' => 1000 ) ); }
	static function panel_link( $r ) { return 'https://site.ir/wp-admin/admin.php?page=bws-customers&tab=returns#r' . $r->id; } }
class BWS_Customers { static function get( $id ) { return (object) array( 'id' => 1, 'code' => 'C1', 'shop_name' => 'فروشگاه', 'mobile' => '0912', 'phone' => '', 'province' => '', 'city' => 'تهران', 'address' => 'خیابان', 'postal_code' => '', 'lat' => null, 'lng' => null, 'visitor_id' => 5, 'first_name' => 'علی', 'last_name' => 'رضایی' ); } static function full_name( $c ) { return $c->first_name . ' ' . $c->last_name; } }
class BWS_Return_Files { static function for_return( $id ) { return array(); } }
require __DIR__ . '/../ariagh-visitor/includes/returns/class-http-multipart.php';
require __DIR__ . '/../ariagh-visitor/includes/returns/class-messenger.php';
require __DIR__ . '/../ariagh-visitor/includes/returns/class-bot.php';
$ok = 0; $fail = 0;
function check( $l, $c ) { global $ok, $fail; if ( $c ) $ok++; else { $fail++; echo "FAIL: $l\n"; } }
$img = function () { $f = tempnam( '/tmp', 'p' ); $im = imagecreatetruecolor( 20, 20 ); imagejpeg( $im, $f ); return array( $f, 'p.jpg', 'image/jpeg', false ); };
$r = (object) array( 'id' => 7, 'code' => 'R-1007', 'status' => 'pending', 'customer_id' => 1, 'order_id' => 50, 'created_at' => '', 'amount' => 2000, 'reason' => 'کپک‌زدگی محصول', 'description' => 'توضیح', 'created_by_type' => 'customer', 'created_by' => 0, 'resolution' => '', 'approved_amount' => 0, 'replacement_order_id' => 0, 'decision_note' => '', 'decided_by' => 0, 'decided_at' => '' );
$rec = function ( $p, $decide = 1 ) { return array( 'id' => 'r1', 'p' => $p, 'chat' => '900', 'name' => 'مدیر', 'user' => 1, 'scope' => 'all', 'ev' => array( 'new' ), 'photos' => 1, 'list' => 1, 'decide' => $decide, 'on' => 1 ); };
$m = function ( $plat, $method ) { return array_values( array_filter( $GLOBALS['calls'], function ( $c ) use ( $plat, $method ) { return $c[0] === $plat && $c[1] === $method; } ) ); };

// A. Bale rejects album and photo → full text with buttons, photos follow.
$GLOBALS['calls'] = array(); $GLOBALS['plan'] = array( 'bale:sendMediaGroup' => 400, 'bale:sendPhoto' => 400 ); $st = array();
$res = BWS_Bot::send_view( $rec( 'bale' ), $r, $st, array( $img(), $img() ) );
$txt = $m( 'bale', 'sendMessage' );
check( 'A ok via text fallback', $res['ok'] && 1 === count( $txt ) );
$b = json_decode( $txt[0][2]['body'], true );
check( 'A text has info + buttons', false !== strpos( $b['text'], 'R-1007' ) && false !== strpos( $b['text'], 'علی رضایی' ) && 'a:7' === $b['reply_markup']['inline_keyboard'][0][0]['callback_data'] );
check( 'A root = text message, photo_error saved', $st['root']['bale|900'] === BWS_Messenger::message_id( $res ) && ! empty( $st['photo_error']['bale|900'] ) && $st['kb']['bale|900'][0] === $st['root']['bale|900'] );
// B. Telegram album fine → caption + buttons reply.
$GLOBALS['calls'] = array(); $GLOBALS['plan'] = array(); $st = array();
$res = BWS_Bot::send_view( $rec( 'telegram' ), $r, $st, array( $img(), $img() ) );
check( 'B album with caption', $res['ok'] && 1 === count( $m( 'telegram', 'sendMediaGroup' ) ) && false !== strpos( $m( 'telegram', 'sendMediaGroup' )[0][2]['body'], '"caption"' ) );
$kb = $m( 'telegram', 'sendMessage' );
check( 'B buttons reply under album', 1 === count( $kb ) && isset( json_decode( $kb[0][2]['body'], true )['reply_parameters'] ) );
// C. single photo: buttons refused → photo+caption without kb, then kb reply.
$GLOBALS['calls'] = array(); $GLOBALS['plan'] = array( 'telegram:sendPhoto:kb' => 400 ); $st = array();
$res = BWS_Bot::send_view( $rec( 'telegram' ), $r, $st, array( $img() ) );
check( 'C photo resent without kb + kb reply', $res['ok'] && 2 === count( $m( 'telegram', 'sendPhoto' ) ) && 1 === count( $m( 'telegram', 'sendMessage' ) ) && ! empty( $st['kb']['telegram|900'] ) );
// D. 403 → no fallback spam.
$GLOBALS['calls'] = array(); $GLOBALS['plan'] = array( 'telegram:sendMediaGroup' => 403 ); $st = array();
$res = BWS_Bot::send_view( $rec( 'telegram' ), $r, $st, array( $img(), $img() ) );
check( 'D 403 no fallback', ! $res['ok'] && 403 === (int) $res['code'] && 1 === count( $GLOBALS['calls'] ) );
// E. network → failed (will be retried by queue), no fallback.
$GLOBALS['calls'] = array(); $GLOBALS['plan'] = array( 'telegram:sendMediaGroup' => 'net' ); $st = array();
$res = BWS_Bot::send_view( $rec( 'telegram' ), $r, $st, array( $img(), $img() ) );
check( 'E net no fallback', ! $res['ok'] && ! empty( $res['net'] ) && 1 === count( $GLOBALS['calls'] ) );
// F. no photos → text.
$GLOBALS['calls'] = array(); $GLOBALS['plan'] = array(); $st = array();
$res = BWS_Bot::send_view( $rec( 'telegram', 0 ), $r, $st, array() );
check( 'F text only, url button', $res['ok'] && 1 === count( $GLOBALS['calls'] ) && 'sendMessage' === $GLOBALS['calls'][0][1] );
// G. album 400 but first photo fine → photo w/ caption + others as replies + kb reply.
$GLOBALS['calls'] = array(); $GLOBALS['plan'] = array( 'telegram:sendMediaGroup' => 400 ); $st = array();
$res = BWS_Bot::send_view( $rec( 'telegram' ), $r, $st, array( $img(), $img(), $img() ) );
check( 'G album fallback', $res['ok'] && 3 === count( $m( 'telegram', 'sendPhoto' ) ) && 1 === count( $m( 'telegram', 'sendMessage' ) ) );
echo "OK $ok FAIL $fail\n";
