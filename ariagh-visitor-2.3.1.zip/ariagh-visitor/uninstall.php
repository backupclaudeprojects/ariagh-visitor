<?php
/**
 * Uninstall ARIAGH.VISITOR. Data is removed ONLY when "delete data on uninstall" is enabled in
 * Settings → Data. Deactivating the plugin never removes anything.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$bws_settings = get_option( 'bws_settings', array() );
if ( empty( $bws_settings['delete_data_on_uninstall'] ) ) {
	return;
}

global $wpdb;
foreach ( array( 'customers', 'ledger', 'orders', 'products', 'sms_log', 'activity', 'visits', 'returns', 'return_items', 'return_files' ) as $bws_t ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'bws_' . $bws_t ); // phpcs:ignore
}
foreach ( array( 'bws_settings', 'bws_db_version', 'bws_last_sync', 'bws_catalog_ver', 'bws_stats_ver', 'woocommerce_bws_snapppay_settings', 'bws_returns_retry', 'bws_gd_folders', 'bws_bot_seen_telegram', 'bws_bot_seen_bale', 'bws_bot_offset_telegram', 'bws_bot_offset_bale' ) as $bws_o ) {
	delete_option( $bws_o );
}
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_bws\\_%' OR option_name LIKE '\\_transient\\_timeout\\_bws\\_%'" ); // phpcs:ignore
$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'bws\\_%'" ); // phpcs:ignore
wp_clear_scheduled_hook( 'bws_daily' );
wp_clear_scheduled_hook( 'bws_snapppay_reconcile' );
wp_clear_scheduled_hook( 'bws_returns_retry' );
wp_clear_scheduled_hook( 'bws_bot_poll' );
// Private return photos.
$bws_up  = wp_upload_dir();
$bws_dir = trailingslashit( $bws_up['basedir'] ) . 'ariagh-visitor-private';
if ( is_dir( $bws_dir ) ) {
	$bws_it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $bws_dir, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
	foreach ( $bws_it as $bws_f ) {
		$bws_f->isDir() ? @rmdir( $bws_f->getPathname() ) : @unlink( $bws_f->getPathname() ); // phpcs:ignore
	}
	@rmdir( $bws_dir ); // phpcs:ignore
}
remove_role( 'bws_visitor' );
foreach ( array( 'administrator', 'shop_manager' ) as $bws_r ) {
	$bws_role = get_role( $bws_r );
	if ( $bws_role ) {
		$bws_role->remove_cap( 'bws_manage' );
	}
}
