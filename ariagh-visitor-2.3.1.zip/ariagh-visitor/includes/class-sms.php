<?php
defined( 'ABSPATH' ) || exit;

/**
 * SMS service: driver registry, event sending (plain text or provider pattern/template), bulk sending and logs.
 */
class BWS_SMS {

	protected static $drivers = null;

	public static $families = array(
		'main'     => 'سامانه‌های اصلی (REST)',
		'reseller' => 'سایر سامانه‌ها و نمایندگی‌ها',
		'soap'     => 'سامانه‌های مبتنی بر SOAP / وب‌سرویس قدیمی',
		'custom'   => 'اتصال دستی',
	);

	public static function contexts() {
		$out = array();
		foreach ( BWS_Events::all() as $k => $e ) {
			$out[ $k ] = $e['label'];
		}
		$out['custom'] = 'پیام دلخواه';
		$out['bulk']   = 'پیامک گروهی';
		$out['bulk_visitors'] = 'پیامک گروهی به ویزیتورها';
		$out['test']   = 'تست';
		return $out;
	}

	public static function context_label( $k ) {
		$c = self::contexts();
		return isset( $c[ $k ] ) ? $c[ $k ] : $k;
	}

	public static function drivers() {
		if ( null === self::$drivers ) {
			$classes = array(
				'Smsir', 'IPPanel', 'Faraz', 'Kavenegar', 'Melipayamak', 'Melipayamak_Console', 'Ghasedak', 'Magfa', 'IPPanel_Legacy',
				'Trez', 'Sabanovin', 'Asanak', 'Payamresan', 'Sms18', 'Sunway', 'Isms', 'Logistic',
				'PayamakPanel_Soap', 'IPPanel_Soap', 'SendSmsAsmx', 'SmsServicePhp', 'HiroSoap', 'ParsGreen', '0098', 'Candoo',
				'Generic',
			);
			$list = array();
			foreach ( $classes as $c ) {
				$cls = 'BWS_SMS_Driver_' . $c;
				if ( class_exists( $cls ) ) {
					$list[] = new $cls();
				}
			}
			$list          = apply_filters( 'bws_sms_drivers', $list );
			self::$drivers = array();
			foreach ( $list as $d ) {
				if ( $d instanceof BWS_SMS_Driver ) {
					self::$drivers[ $d->id ] = $d;
				}
			}
		}
		return self::$drivers;
	}

	public static function driver( $id = null ) {
		$d  = self::drivers();
		$id = $id ? $id : bws_opt( 'sms_provider', 'smsir' );
		return isset( $d[ $id ] ) ? $d[ $id ] : $d['smsir'];
	}

	/** Provider config with secrets decrypted (only in memory, never sent to the browser). */
	public static function driver_cfg( $id = null ) {
		$id  = $id ? $id : self::driver()->id;
		$all = (array) bws_opt( 'sms_providers', array() );
		$cfg = isset( $all[ $id ] ) && is_array( $all[ $id ] ) ? $all[ $id ] : array();
		$drv = self::driver( $id );
		foreach ( $drv->fields() as $k => $f ) {
			if ( isset( $cfg[ $k ] ) && 'password' === $f[1] ) {
				$cfg[ $k ] = bws_decrypt( $cfg[ $k ] );
			}
		}
		return $cfg;
	}

	public static function mode() {
		if ( ! bws_opt( 'sms_enabled' ) ) {
			return 'disabled';
		}
		return bws_opt( 'sms_test_mode' ) ? 'test' : 'live';
	}

	/**
	 * Send a list of messages.
	 *
	 * @param array  $messages [ [ mobile, text, customer_id, pattern => [ code, params ] (optional) ] ]
	 * @param string $context  event key / custom / bulk / test.
	 * @return array [ sent, failed, response ]
	 */
	public static function send_many( array $messages, $context = 'custom' ) {
		global $wpdb;
		$sent   = 0;
		$failed = 0;
		$last   = '';
		$valid  = array();
		foreach ( $messages as $m ) {
			$mobile = bws_normalize_mobile( isset( $m['mobile'] ) ? $m['mobile'] : '' );
			$text   = isset( $m['text'] ) ? (string) $m['text'] : '';
			if ( $mobile && ( '' !== trim( $text ) || ! empty( $m['pattern'] ) ) ) {
				$m['mobile'] = $mobile;
				$m['text']   = $text;
				$valid[]     = $m;
			} else {
				$failed++;
			}
		}
		if ( ! $valid ) {
			return array( 'sent' => 0, 'failed' => $failed, 'response' => 'شماره موبایل یا متن پیامک معتبر نیست.' );
		}
		$mode   = self::mode();
		$driver = self::driver();
		$cfg    = self::driver_cfg( $driver->id );

		// Split: pattern messages go one by one; text messages go in provider-size batches.
		$pattern = array();
		$plain   = array();
		foreach ( $valid as $m ) {
			if ( ! empty( $m['pattern']['code'] ) && $driver->pattern ) {
				$pattern[] = $m;
			} else {
				$plain[] = $m;
			}
		}
		$jobs = array();
		foreach ( array_chunk( $plain, max( 1, $driver->batch_size() ) ) as $chunk ) {
			$jobs[] = array( 'type' => 'text', 'items' => $chunk );
		}
		foreach ( $pattern as $m ) {
			$jobs[] = array( 'type' => 'pattern', 'items' => array( $m ) );
		}

		foreach ( $jobs as $job ) {
			$chunk  = $job['items'];
			$status = null;
			if ( 'live' !== $mode ) {
				$results = array_fill( 0, count( $chunk ), array( 'ok' => true, 'response' => 'test' === $mode ? 'حالت تست — پیامک واقعی ارسال نشد' : 'ارسال پیامک غیرفعال است' ) );
				$status  = $mode;
			} else {
				try {
					if ( 'pattern' === $job['type'] ) {
						$m       = $chunk[0];
						$results = array( $driver->send_pattern( $m['mobile'], (string) $m['pattern']['code'], (array) $m['pattern']['params'], $cfg ) );
					} else {
						$results = $driver->send( $chunk, $cfg );
					}
				} catch ( Throwable $e ) {
					$results = array_fill( 0, count( $chunk ), array( 'ok' => false, 'response' => $e->getMessage() ) );
				}
			}
			foreach ( $chunk as $i => $m ) {
				$r  = isset( $results[ $i ] ) ? $results[ $i ] : array( 'ok' => false, 'response' => 'پاسخی از سامانه دریافت نشد' );
				$st = $status ? $status : ( $r['ok'] ? 'sent' : 'failed' );
				if ( $r['ok'] ) {
					$sent++;
				} else {
					$failed++;
				}
				$last = (string) $r['response'];
				$msg  = $m['text'];
				if ( 'pattern' === $job['type'] ) {
					$pairs = array();
					foreach ( (array) $m['pattern']['params'] as $k => $v ) {
						$pairs[] = $k . '=' . $v;
					}
					$msg = '[الگو ' . $m['pattern']['code'] . '] ' . implode( ' | ', $pairs );
				}
				$wpdb->insert( BWS_Install::table( 'sms_log' ), array(
					'customer_id' => isset( $m['customer_id'] ) ? (int) $m['customer_id'] : 0,
					'mobile'      => $m['mobile'],
					'message'     => $msg,
					'context'     => $context,
					'provider'    => $driver->id,
					'status'      => $st,
					'response'    => mb_substr( $last, 0, 2000 ),
					'created_by'  => get_current_user_id(),
					'created_at'  => bws_now(),
				) );
			}
		}
		return array( 'sent' => $sent, 'failed' => $failed, 'response' => $last );
	}

	/** Variables for a customer (+ general + extra). */
	public static function vars_for( $customer, $extra = array() ) {
		$vars = self::general_vars();
		if ( $customer ) {
			$vars = array_merge( $vars, BWS_Customers::template_vars( $customer ) );
		}
		return array_merge( $vars, $extra );
	}

	public static function general_vars() {
		return array(
			'company'       => bws_opt( 'company_name' ),
			'company_phone' => bws_opt( 'company_phone' ),
			'site_url'      => home_url( '/' ),
			'date'          => bws_jdate( bws_now(), false ),
			'time'          => bws_fa_digits( current_time( 'H:i' ) ),
		);
	}

	public static function render_for( $customer, $template, $extra = array() ) {
		return bws_render_template( $template, self::vars_for( $customer, $extra ) );
	}

	public static function event_enabled( $event ) {
		$e = BWS_Events::get( $event );
		if ( ! $e ) {
			return false;
		}
		return ! $e['toggle'] || (bool) bws_opt( $e['toggle'] );
	}

	/** Build one message (text + optional pattern) for an event. */
	public static function build( $event, $vars, $mobile, $customer_id = 0 ) {
		$text = bws_render_template( bws_opt( 'tpl_' . $event, '' ), $vars );
		$msg  = array( 'mobile' => $mobile, 'text' => $text, 'customer_id' => (int) $customer_id );
		if ( 'pattern' === bws_opt( 'tpl_' . $event . '_mode' ) && '' !== trim( (string) bws_opt( 'tpl_' . $event . '_code' ) ) ) {
			$params = array();
			foreach ( BWS_Events::parse_params( bws_opt( 'tpl_' . $event . '_params' ) ) as $k => $tpl ) {
				$v            = bws_render_template( $tpl, $vars );
				$params[ $k ] = '' === $v ? '-' : $v; // Providers reject empty parameters.
			}
			$msg['pattern'] = array( 'code' => trim( (string) bws_opt( 'tpl_' . $event . '_code' ) ), 'params' => $params );
		}
		return $msg;
	}

	/**
	 * Send an event message.
	 *
	 * @param string      $event    Event key from BWS_Events.
	 * @param object|null $customer Customer row (when the event is about a customer).
	 * @param array       $extra    Extra variables.
	 * @param array       $opts     force (ignore on/off toggle), to (mobile override for visitor/admin events).
	 */
	public static function send_event( $event, $customer = null, $extra = array(), $opts = array() ) {
		$e = BWS_Events::get( $event );
		if ( ! $e ) {
			return array( 'sent' => 0, 'failed' => 0, 'response' => 'unknown event' );
		}
		if ( empty( $opts['force'] ) && ! self::event_enabled( $event ) ) {
			return array( 'sent' => 0, 'failed' => 0, 'response' => 'off' );
		}
		$vars = self::vars_for( $customer, $extra );
		$msgs = array();
		if ( 'admins' === $e['to'] ) {
			foreach ( self::admin_mobiles() as $m ) {
				$msgs[] = self::build( $event, $vars, $m, 0 );
			}
		} elseif ( 'visitor' === $e['to'] ) {
			if ( ! empty( $opts['to'] ) ) {
				$msgs[] = self::build( $event, $vars, $opts['to'], 0 );
			}
		} elseif ( $customer ) {
			$msgs[] = self::build( $event, $vars, ! empty( $opts['to'] ) ? $opts['to'] : $customer->mobile, $customer->id );
		}
		if ( ! $msgs ) {
			return array( 'sent' => 0, 'failed' => 0, 'response' => 'no recipient' );
		}
		$r = self::send_many( $msgs, $event );
		do_action( 'bws_sms_event_sent', $event, $customer, $r );
		return $r;
	}

	public static function admin_mobiles() {
		return array_values( array_unique( array_filter( array_map( 'bws_normalize_mobile', preg_split( '/[\s,،]+/', (string) bws_opt( 'admin_mobiles' ) ) ) ) ) );
	}

	/** Custom (free) text to a customer – variables are replaced. */
	public static function send_text( $customer, $text, $context = 'custom' ) {
		return self::send_many( array( array( 'mobile' => $customer->mobile, 'text' => self::render_for( $customer, $text ), 'customer_id' => $customer->id ) ), $context );
	}

	/**
	 * Resolve target customer IDs for a bulk send.
	 * filter: all | visitor:{id} | debtors | no_order | inactive_30 | inactive_60 | province:{name} | ids
	 */
	public static function bulk_target_ids( $filter, $restrict_visitor = 0, $ids = array() ) {
		global $wpdb;
		$t     = BWS_Customers::table();
		$where = array( "status = 'active'" );
		$vals  = array();
		if ( $restrict_visitor ) {
			$where[] = 'visitor_id = %d';
			$vals[]  = (int) $restrict_visitor;
		}
		if ( 0 === strpos( $filter, 'visitor:' ) ) {
			$where[] = 'visitor_id = %d';
			$vals[]  = (int) substr( $filter, 8 );
		} elseif ( 0 === strpos( $filter, 'province:' ) ) {
			$where[] = 'province = %s';
			$vals[]  = sanitize_text_field( substr( $filter, 9 ) );
		} elseif ( 'debtors' === $filter ) {
			$where[] = 'balance > 0';
		} elseif ( 'no_order' === $filter ) {
			$where[] = 'last_order_at IS NULL';
		} elseif ( in_array( $filter, array( 'inactive_30', 'inactive_60' ), true ) ) {
			$where[] = '(last_order_at IS NULL OR last_order_at < %s)';
			$vals[]  = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - ( 'inactive_60' === $filter ? 60 : 30 ) * DAY_IN_SECONDS );
		} elseif ( 'ids' === $filter ) {
			$ids     = array_filter( array_map( 'absint', is_array( $ids ) ? $ids : explode( ',', (string) $ids ) ) );
			$where[] = 'id IN (' . ( $ids ? implode( ',', $ids ) : '0' ) . ')';
		}
		$sql = "SELECT id FROM $t WHERE " . implode( ' AND ', $where ) . ' ORDER BY id ASC';
		return array_map( 'intval', $vals ? $wpdb->get_col( $wpdb->prepare( $sql, $vals ) ) : $wpdb->get_col( $sql ) );
	}

	/**
	 * One batch of a bulk send. The browser calls this repeatedly with an increasing offset so
	 * thousands of personalised messages are sent without PHP timeouts.
	 * $event (optional) = send this event's saved template (text or pattern) instead of $template.
	 */
	public static function bulk_batch( $ids, $template, $offset, $event = '' ) {
		$size  = max( 1, min( 200, (int) bws_opt( 'sms_batch_size', 25 ) ) );
		$slice = array_slice( $ids, $offset, $size );
		$msgs  = array();
		foreach ( $slice as $id ) {
			$c = BWS_Customers::get( $id );
			if ( ! $c ) {
				continue;
			}
			if ( $event && BWS_Events::get( $event ) ) {
				$msgs[] = self::build( $event, self::vars_for( $c ), $c->mobile, $c->id );
			} else {
				$msgs[] = array( 'mobile' => $c->mobile, 'text' => self::render_for( $c, $template ), 'customer_id' => $c->id );
			}
		}
		$res = $msgs ? self::send_many( $msgs, $event ? $event : 'bulk' ) : array( 'sent' => 0, 'failed' => 0 );
		return array(
			'sent'   => $res['sent'],
			'failed' => $res['failed'],
			'next'   => $offset + count( $slice ),
			'total'  => count( $ids ),
			'done'   => ( $offset + count( $slice ) ) >= count( $ids ),
			'mode'   => self::mode(),
		);
	}

	/** Visitor recipients: "visitors" = all active visitors with a mobile, "visitor_user:ID" = one visitor. */
	public static function visitor_target_ids( $filter ) {
		$ids = array();
		if ( 0 === strpos( $filter, 'visitor_user:' ) ) {
			$uid = (int) substr( $filter, 13 );
			return bws_is_visitor( $uid ) && bws_normalize_mobile( get_user_meta( $uid, 'bws_mobile', true ) ) ? array( $uid ) : array();
		}
		foreach ( BWS_Auth::visitors( true ) as $u ) {
			if ( bws_normalize_mobile( get_user_meta( $u->ID, 'bws_mobile', true ) ) ) {
				$ids[] = (int) $u->ID;
			}
		}
		return $ids;
	}

	/** Template variables for a visitor message. */
	public static function visitor_vars( $uid ) {
		$u     = get_userdata( $uid );
		$month = BWS_Stats::visitor_period( $uid, 'month' );
		return array_merge( self::general_vars(), array(
			'visitor_name'      => bws_user_name( $uid ),
			'name'              => $u && $u->first_name ? $u->first_name : bws_user_name( $uid ),
			'username'          => $u ? $u->user_login : '',
			'mobile'            => (string) get_user_meta( $uid, 'bws_mobile', true ),
			'visitor_panel_url' => bws_visitor_panel_url(),
			'month_sales'       => bws_money_text( $month['sales'] ),
			'month_orders'      => bws_fa_digits( $month['orders'] ),
		) );
	}

	public static function bulk_visitors_batch( $ids, $template, $offset ) {
		$size  = max( 1, min( 200, (int) bws_opt( 'sms_batch_size', 25 ) ) );
		$slice = array_slice( $ids, $offset, $size );
		$msgs  = array();
		foreach ( $slice as $uid ) {
			$msgs[] = array( 'mobile' => get_user_meta( $uid, 'bws_mobile', true ), 'text' => bws_render_template( $template, self::visitor_vars( $uid ) ), 'customer_id' => 0 );
		}
		$res = $msgs ? self::send_many( $msgs, 'bulk_visitors' ) : array( 'sent' => 0, 'failed' => 0 );
		return array(
			'sent'   => $res['sent'],
			'failed' => $res['failed'],
			'next'   => $offset + count( $slice ),
			'total'  => count( $ids ),
			'done'   => ( $offset + count( $slice ) ) >= count( $ids ),
			'mode'   => self::mode(),
		);
	}

	public static function log_query( $args = array() ) {
		global $wpdb;
		$t     = BWS_Install::table( 'sms_log' );
		$where = array( '1=1' );
		$vals  = array();
		if ( ! empty( $args['customer_id'] ) ) {
			$where[] = 'customer_id = %d';
			$vals[]  = (int) $args['customer_id'];
		}
		if ( ! empty( $args['search'] ) ) {
			$where[] = '(mobile LIKE %s OR message LIKE %s)';
			$s       = '%' . $wpdb->esc_like( bws_en_digits( $args['search'] ) ) . '%';
			array_push( $vals, $s, $s );
		}
		if ( ! empty( $args['status'] ) ) {
			$where[] = 'status = %s';
			$vals[]  = $args['status'];
		}
		if ( ! empty( $args['context'] ) ) {
			$where[] = 'context = %s';
			$vals[]  = $args['context'];
		}
		$per    = isset( $args['per_page'] ) ? max( 1, min( 500, (int) $args['per_page'] ) ) : 50;
		$page   = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
		$offset = ( $page - 1 ) * $per;
		$w      = implode( ' AND ', $where );
		$sql    = "SELECT * FROM $t WHERE $w ORDER BY id DESC LIMIT $offset, $per";
		$csql   = "SELECT COUNT(*) FROM $t WHERE $w";
		return array(
			'items' => $vals ? $wpdb->get_results( $wpdb->prepare( $sql, $vals ) ) : $wpdb->get_results( $sql ),
			'total' => (int) ( $vals ? $wpdb->get_var( $wpdb->prepare( $csql, $vals ) ) : $wpdb->get_var( $csql ) ),
		);
	}

	/** Remove log rows older than N days (keeps the table small). */
	public static function prune( $days = 180 ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . BWS_Install::table( 'sms_log' ) . ' WHERE created_at < %s', gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $days * DAY_IN_SECONDS ) ) );
	}
}
