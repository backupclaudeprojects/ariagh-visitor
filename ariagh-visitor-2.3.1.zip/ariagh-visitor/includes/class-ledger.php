<?php
defined( 'ABSPATH' ) || exit;

/**
 * Credit ledger. Positive amount = debt increases (credit used), negative = payment / reversal.
 * balance (customer debt) = SUM(amount).  available = max(0, credit_limit - balance).
 */
class BWS_Ledger {

	public static $types = array(
		'purchase' => 'خرید از اعتبار',
		'cash_due' => 'مازاد سفارش (پرداخت حضوری)',
		'payment'  => 'پرداخت / تسویه',
		'reversal' => 'برگشت (لغو سفارش)',
		'adjust'   => 'اصلاح دستی حساب',
		'return'   => 'برگشت مرجوعی',
		'opening'  => 'مانده اول دوره',
	);

	public static $methods = array(
		'online'   => 'درگاه آنلاین',
		'cash'     => 'نقدی',
		'card'     => 'کارت‌به‌کارت',
		'transfer' => 'واریز/حواله بانکی',
		'cheque'   => 'چک',
		'pos'      => 'کارتخوان',
		'credit'   => 'اعتبار',
		'other'    => 'سایر',
	);

	public static function table() {
		return BWS_Install::table( 'ledger' );
	}

	public static function summary( $c ) {
		$limit     = (float) $c->credit_limit;
		$debt      = (float) $c->balance;
		$available = max( 0, $limit - max( 0, $debt ) );
		return array(
			'limit'          => $limit,
			'debt'           => $debt,
			'available'      => $available,
			'limit_text'     => bws_money_text( $limit ),
			'debt_text'      => bws_money_text( max( 0, $debt ) ),
			'available_text' => bws_money_text( $available ),
			'credit_text'    => $debt < 0 ? bws_money_text( abs( $debt ) ) : '',
			'percent_used'   => $limit > 0 ? min( 100, round( max( 0, $debt ) / $limit * 100 ) ) : 0,
		);
	}

	/**
	 * Add a ledger entry and refresh cached balance. Caller should hold the customer lock for purchases.
	 */
	public static function add( $customer_id, $type, $amount, $args = array() ) {
		global $wpdb;
		$amount = round( (float) $amount, 2 );
		if ( 0.0 === $amount && 'opening' !== $type ) {
			return 0;
		}
		$current = (float) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(amount),0) FROM ' . self::table() . ' WHERE customer_id = %d', $customer_id ) );
		$after   = $current + $amount;
		$wpdb->insert( self::table(), array(
			'customer_id'   => (int) $customer_id,
			'type'          => $type,
			'amount'        => $amount,
			'balance_after' => $after,
			'order_id'      => isset( $args['order_id'] ) ? (int) $args['order_id'] : 0,
			'method'        => isset( $args['method'] ) ? sanitize_key( $args['method'] ) : '',
			'reference'     => isset( $args['reference'] ) ? sanitize_text_field( $args['reference'] ) : '',
			'note'          => isset( $args['note'] ) ? sanitize_textarea_field( $args['note'] ) : '',
			'created_by'    => isset( $args['created_by'] ) ? (int) $args['created_by'] : get_current_user_id(),
			'created_at'    => isset( $args['date'] ) && $args['date'] ? $args['date'] : bws_now(),
		) );
		$id = (int) $wpdb->insert_id;
		self::recalc( $customer_id );
		do_action( 'bws_ledger_added', $id, $customer_id, $type, $amount, $args );
		return $id;
	}

	public static function recalc( $customer_id ) {
		global $wpdb;
		$sum = (float) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(amount),0) FROM ' . self::table() . ' WHERE customer_id = %d', $customer_id ) );
		$wpdb->update( BWS_Customers::table(), array( 'balance' => $sum ), array( 'id' => $customer_id ) );
		return $sum;
	}

	/**
	 * Record a payment (settlement) from customer.
	 */
	public static function record_payment( $customer_id, $amount, $method = 'cash', $reference = '', $note = '', $notify = true ) {
		$amount = abs( (float) $amount );
		if ( $amount <= 0 ) {
			return new WP_Error( 'bws_amount', 'مبلغ پرداخت معتبر نیست.' );
		}
		if ( ! isset( self::$methods[ $method ] ) ) {
			$method = 'other';
		}
		$id = self::add( $customer_id, 'payment', -$amount, array( 'method' => $method, 'reference' => $reference, 'note' => $note ) );
		BWS_Log::add( 'ledger_payment', 'customer', $customer_id, array( 'amount' => $amount, 'method' => $method, 'ref' => $reference ) );
		if ( $notify ) {
			BWS_SMS::send_event( 'payment', BWS_Customers::get( $customer_id ), array(
				'amount'    => bws_money_text( $amount ),
				'method'    => self::$methods[ $method ],
				'reference' => $reference,
			) );
		}
		return $id;
	}

	public static function adjust( $customer_id, $amount, $note = '' ) {
		$id = self::add( $customer_id, 'adjust', (float) $amount, array( 'note' => $note ) );
		BWS_Log::add( 'ledger_adjust', 'customer', $customer_id, array( 'amount' => $amount, 'note' => $note ) );
		return $id;
	}

	public static function entries( $args = array() ) {
		global $wpdb;
		$t     = self::table();
		$where = array( '1=1' );
		$vals  = array();
		if ( ! empty( $args['customer_id'] ) ) {
			$where[] = 'l.customer_id = %d';
			$vals[]  = (int) $args['customer_id'];
		}
		if ( ! empty( $args['type'] ) ) {
			$where[] = 'l.type = %s';
			$vals[]  = $args['type'];
		}
		if ( ! empty( $args['visitor_id'] ) ) {
			$where[] = 'c.visitor_id = %d';
			$vals[]  = (int) $args['visitor_id'];
		}
		if ( ! empty( $args['from'] ) ) {
			$where[] = 'l.created_at >= %s';
			$vals[]  = $args['from'];
		}
		if ( ! empty( $args['to'] ) ) {
			$where[] = 'l.created_at <= %s';
			$vals[]  = $args['to'];
		}
		$per    = isset( $args['per_page'] ) ? max( 1, (int) $args['per_page'] ) : 50;
		$page   = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
		$offset = ( $page - 1 ) * $per;
		$ct     = BWS_Customers::table();
		$w      = implode( ' AND ', $where );
		$sql    = "SELECT l.*, c.first_name, c.last_name, c.code, c.visitor_id FROM $t l LEFT JOIN $ct c ON c.id = l.customer_id WHERE $w ORDER BY l.id DESC LIMIT $offset, $per";
		$csql   = "SELECT COUNT(*) FROM $t l LEFT JOIN $ct c ON c.id = l.customer_id WHERE $w";
		return array(
			'items' => $vals ? $wpdb->get_results( $wpdb->prepare( $sql, $vals ) ) : $wpdb->get_results( $sql ),
			'total' => (int) ( $vals ? $wpdb->get_var( $wpdb->prepare( $csql, $vals ) ) : $wpdb->get_var( $csql ) ),
		);
	}

	public static function entry_to_array( $e ) {
		$amount = (float) $e->amount;
		return array(
			'id'           => (int) $e->id,
			'type'         => $e->type,
			'type_label'   => isset( self::$types[ $e->type ] ) ? self::$types[ $e->type ] : $e->type,
			'amount'       => $amount,
			'amount_text'  => bws_money_text( abs( $amount ) ),
			'direction'    => $amount >= 0 ? 'debit' : 'credit',
			'balance'      => (float) $e->balance_after,
			'balance_text' => bws_money_text( $e->balance_after ),
			'order_id'     => (int) $e->order_id,
			'method'       => $e->method ? ( isset( self::$methods[ $e->method ] ) ? self::$methods[ $e->method ] : $e->method ) : '',
			'reference'    => $e->reference,
			'note'         => $e->note,
			'by'           => $e->created_by ? bws_user_name( $e->created_by ) : 'مشتری / سیستم',
			'date'         => bws_jdate( $e->created_at ),
		);
	}

	/** Totals for dashboard. */
	public static function totals() {
		global $wpdb;
		$ct = BWS_Customers::table();
		return array(
			'outstanding' => (float) $wpdb->get_var( "SELECT COALESCE(SUM(balance),0) FROM $ct WHERE balance > 0" ),
			'debtors'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct WHERE balance > 0" ),
			'limit_total' => (float) $wpdb->get_var( "SELECT COALESCE(SUM(credit_limit),0) FROM $ct WHERE status = 'active'" ),
		);
	}

	/**
	 * Is the customer's debt older than the payment terms (settings → payment_terms_days)?
	 */
	public static function is_overdue( $c ) {
		static $cache = array();
		$days = (int) bws_opt( 'payment_terms_days', 30 );
		if ( $days <= 0 || (float) $c->balance <= 0 ) {
			return false;
		}
		if ( ! isset( $cache[ $c->id ] ) ) {
			$oldest             = self::oldest_unpaid_date( $c->id );
			$cache[ $c->id ] = $oldest && strtotime( $oldest ) < current_time( 'timestamp' ) - $days * DAY_IN_SECONDS;
		}
		return $cache[ $c->id ];
	}

	/** Date of the oldest unsettled debit (FIFO), used for overdue reminders. */
	public static function oldest_unpaid_date( $customer_id ) {
		global $wpdb;
		$rows    = $wpdb->get_results( $wpdb->prepare( 'SELECT amount, created_at FROM ' . self::table() . ' WHERE customer_id = %d ORDER BY id ASC', $customer_id ) );
		$credits = 0;
		foreach ( $rows as $r ) {
			if ( (float) $r->amount < 0 ) {
				$credits += abs( (float) $r->amount );
			}
		}
		foreach ( $rows as $r ) {
			if ( (float) $r->amount > 0 ) {
				if ( $credits >= (float) $r->amount ) {
					$credits -= (float) $r->amount;
				} else {
					return $r->created_at;
				}
			}
		}
		return null;
	}
}
