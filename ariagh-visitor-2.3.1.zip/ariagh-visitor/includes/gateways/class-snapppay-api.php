<?php
defined( 'ABSPATH' ) || exit;

/**
 * SnappPay (اسنپ‌پی) merchant API client — "self-CMS" contract v2.1 (academy.snapppay.ir/self-cms).
 *
 *  OAuth   POST /api/online/v1/oauth/token          Basic client_id:client_secret, form: grant_type=password, scope=online-merchant, username, password
 *  Eligible GET /api/online/offer/v1/eligible        ?amount=<IRR>
 *  Token   POST /api/online/payment/v1/token         { amount, mobile(+98…), paymentMethodTypeDto: INSTALLMENT, transactionId, returnURL, discountAmount, externalSourceAmount, cartList[] }
 *  Verify  POST /api/online/payment/v1/verify        { paymentToken }
 *  Settle  POST /api/online/payment/v1/settle        { paymentToken }
 *  Revert  POST /api/online/payment/v1/revert        { paymentToken }
 *  Status  GET  /api/online/payment/v1/status        ?paymentToken=…
 *  Cancel  POST /api/online/payment/v1/cancel        { paymentToken }
 *  Update  POST /api/online/payment/v1/update        { paymentToken, amount, discountAmount, externalSourceAmount, paymentMethodTypeDto, cartList[] }
 *
 * Every response (except OAuth) is { successful: bool, response: {...}, errorData: { errorCode, message } }.
 * A fresh OAuth token is requested for every operation (the documentation asks merchants not to keep tokens).
 */
class BWS_SnappPay_API {

	const SANDBOX = 'https://fms-gateway-staging.apps.public.teh-1.snappcloud.io';

	protected $base;
	protected $client_id;
	protected $client_secret;
	protected $username;
	protected $password;
	protected $logger;

	public function __construct( array $cfg, $logger = null ) {
		$this->base          = untrailingslashit( trim( (string) ( isset( $cfg['base_url'] ) ? $cfg['base_url'] : '' ) ) );
		$this->client_id     = trim( (string) ( isset( $cfg['client_id'] ) ? $cfg['client_id'] : '' ) );
		$this->client_secret = trim( (string) ( isset( $cfg['client_secret'] ) ? $cfg['client_secret'] : '' ) );
		$this->username      = trim( (string) ( isset( $cfg['username'] ) ? $cfg['username'] : '' ) );
		$this->password      = (string) ( isset( $cfg['password'] ) ? $cfg['password'] : '' );
		$this->logger        = $logger;
	}

	public function configured() {
		return $this->base && $this->client_id && $this->client_secret && $this->username && '' !== $this->password;
	}

	/** Only HTTPS (http is allowed for a local test server only). */
	protected function base_ok() {
		$p = wp_parse_url( $this->base );
		if ( empty( $p['host'] ) || empty( $p['scheme'] ) ) {
			return false;
		}
		if ( 'https' === $p['scheme'] ) {
			return true;
		}
		return 'http' === $p['scheme'] && in_array( $p['host'], array( 'localhost', '127.0.0.1' ), true );
	}

	protected function log( $msg ) {
		if ( $this->logger ) {
			call_user_func( $this->logger, $msg );
		}
	}

	protected function http( $method, $path, $args ) {
		if ( ! $this->base_ok() ) {
			return new WP_Error( 'spp_url', 'آدرس سرور اسنپ‌پی معتبر نیست (باید با https شروع شود).' );
		}
		$args = wp_parse_args( $args, array(
			'method'      => $method,
			'timeout'     => 30,
			'redirection' => 0,
			'sslverify'   => true,
			'user-agent'  => 'ARIAGH.VISITOR/' . ( defined( 'BWS_VERSION' ) ? BWS_VERSION : '2' ) . ' WooCommerce',
		) );
		$res = wp_remote_request( $this->base . $path, $args );
		if ( is_wp_error( $res ) ) {
			$this->log( $method . ' ' . $path . ' → connection error: ' . $res->get_error_message() );
			return new WP_Error( 'spp_http', 'خطای ارتباط با اسنپ‌پی: ' . $res->get_error_message(), array( 'timeout' => true ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$body = (string) wp_remote_retrieve_body( $res );
		$json = json_decode( $body, true );
		$this->log( $method . ' ' . $path . ' → HTTP ' . $code . ' ' . mb_substr( preg_replace( '/"(access_token|paymentToken|paymentPageUrl|mobile)"\s*:\s*"[^"]*"/', '"$1":"***"', $body ), 0, 600 ) );
		return array( 'code' => $code, 'json' => is_array( $json ) ? $json : null, 'body' => $body );
	}

	/** OAuth2 password grant. */
	public function access_token() {
		$r = $this->http( 'POST', '/api/online/v1/oauth/token', array(
			'timeout' => 15,
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode( $this->client_id . ':' . $this->client_secret ),
				'Content-Type'  => 'application/x-www-form-urlencoded',
				'Accept'        => 'application/json',
			),
			'body'    => array(
				'grant_type' => 'password',
				'scope'      => 'online-merchant',
				'username'   => $this->username,
				'password'   => $this->password,
			),
		) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( 200 !== $r['code'] || empty( $r['json']['access_token'] ) ) {
			return new WP_Error( 'spp_auth', 'احراز هویت اسنپ‌پی ناموفق بود؛ Client ID / Client Secret / نام کاربری / رمز را بررسی کنید.' );
		}
		return (string) $r['json']['access_token'];
	}

	/** Authenticated call; returns the "response" object or WP_Error. */
	protected function call( $method, $path, $data = array() ) {
		$token = $this->access_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}
		$args = array( 'headers' => array( 'Authorization' => 'Bearer ' . $token, 'Accept' => 'application/json' ) );
		if ( 'GET' === $method ) {
			$path .= $data ? '?' . http_build_query( $data ) : '';
		} else {
			$args['headers']['Content-Type'] = 'application/json';
			$args['body']                    = wp_json_encode( $data, JSON_UNESCAPED_UNICODE );
		}
		$r = $this->http( $method, $path, $args );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$j = $r['json'];
		if ( 200 === $r['code'] && is_array( $j ) && isset( $j['successful'] ) && true === $j['successful'] ) {
			return isset( $j['response'] ) && is_array( $j['response'] ) ? $j['response'] : array();
		}
		$msg  = isset( $j['errorData']['message'] ) ? (string) $j['errorData']['message'] : 'پاسخ نامعتبر از اسنپ‌پی (HTTP ' . $r['code'] . ')';
		$code = isset( $j['errorData']['errorCode'] ) ? (string) $j['errorData']['errorCode'] : (string) $r['code'];
		return new WP_Error( 'spp_api', $msg, array( 'errorCode' => $code, 'http' => $r['code'] ) );
	}

	public function eligible( $amount_irr ) {
		return $this->call( 'GET', '/api/online/offer/v1/eligible', array( 'amount' => (int) $amount_irr ) );
	}

	public function token( array $payload ) {
		return $this->call( 'POST', '/api/online/payment/v1/token', $payload );
	}

	public function verify( $payment_token ) {
		return $this->call( 'POST', '/api/online/payment/v1/verify', array( 'paymentToken' => (string) $payment_token ) );
	}

	public function settle( $payment_token ) {
		return $this->call( 'POST', '/api/online/payment/v1/settle', array( 'paymentToken' => (string) $payment_token ) );
	}

	public function revert( $payment_token ) {
		return $this->call( 'POST', '/api/online/payment/v1/revert', array( 'paymentToken' => (string) $payment_token ) );
	}

	public function status( $payment_token ) {
		return $this->call( 'GET', '/api/online/payment/v1/status', array( 'paymentToken' => (string) $payment_token ) );
	}

	public function cancel( $payment_token ) {
		return $this->call( 'POST', '/api/online/payment/v1/cancel', array( 'paymentToken' => (string) $payment_token ) );
	}

	public function update( array $payload ) {
		return $this->call( 'POST', '/api/online/payment/v1/update', $payload );
	}
}
