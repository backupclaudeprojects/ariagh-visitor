<?php
defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/** SnappPay in the block-based (Gutenberg) checkout. */
final class BWS_SnappPay_Blocks extends AbstractPaymentMethodType {

	protected $name = 'bws_snapppay';

	public function initialize() {
		$this->settings = get_option( 'woocommerce_bws_snapppay_settings', array() );
	}

	public function is_active() {
		$gws = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();
		return isset( $gws['bws_snapppay'] ) && $gws['bws_snapppay']->is_available();
	}

	public function get_payment_method_script_handles() {
		wp_register_script( 'bws-snapppay-blocks', BWS_Frontend::js( 'snapppay-blocks' ), array( 'wc-blocks-registry', 'wp-element', 'wp-html-entities' ), BWS_VERSION, true );
		return array( 'bws-snapppay-blocks' );
	}

	public function get_payment_method_data() {
		$total = WC()->cart ? (float) WC()->cart->get_total( 'edit' ) : 0;
		$e     = $total > 0 ? BWS_Gateway_SnappPay::eligibility( $total ) : array( 'title' => '', 'description' => '' );
		return array(
			'title'       => isset( $this->settings['title'] ) ? $this->settings['title'] : 'خرید اقساطی با اسنپ‌پی',
			'description' => isset( $this->settings['description'] ) ? $this->settings['description'] : '',
			'offer'       => trim( $e['title'] . ' ' . $e['description'] ),
			'icon'        => BWS_URL . 'assets/img/snapppay.svg',
			'supports'    => array( 'products', 'refunds' ),
		);
	}
}
