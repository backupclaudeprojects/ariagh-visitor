<?php
defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce payment gateway: SnappPay (اسنپ‌پی) — buy now, pay in installments.
 *
 * Flow (per SnappPay self-CMS v2.1):
 *  1. process_payment  → OAuth → POST token (unique transactionId, IRR amount, +98 mobile, itemized cartList) → redirect to paymentPageUrl.
 *  2. Customer pays on SnappPay → SnappPay POSTs transactionId / state / amount to our returnURL.
 *  3. Callback is only a trigger: we match order, transactionId and amount, then VERIFY → SETTLE
 *     (with status inquiry recovery on timeouts), and only after SETTLE mark the order paid.
 *  4. Refunds: full = cancel, partial = update with the reduced cart. Admin can inquire status any time.
 *  5. Hourly reconciliation settles payments whose callback was lost.
 */
class BWS_Gateway_SnappPay extends WC_Payment_Gateway {

	const ID = 'bws_snapppay';

	/** @var array */
	protected static $instance_settings = null;

	public function __construct() {
		$this->id                 = self::ID;
		$this->method_title       = 'اسنپ‌پی (خرید اقساطی) — ARIAGH.VISITOR';
		$this->method_description = 'پرداخت اقساطی با حساب اسنپ‌پی؛ مطابق مستندات فنی اسنپ‌پی (self-CMS نسخه ۲٫۱): تأیید (verify) و تسویه (settle) خودکار، استعلام وضعیت، بازیابی تراکنش‌های ناتمام و استرداد کامل/جزئی از داخل ووکامرس. راهنمای کامل: ویزیتور ← راهنما ← اسنپ‌پی.';
		$this->has_fields         = true;
		$this->supports           = array( 'products', 'refunds' );
		$this->icon               = BWS_URL . 'assets/img/snapppay.svg';

		$this->init_form_fields();
		$this->init_settings();
		$this->title       = $this->get_option( 'title' );
		$this->description = $this->get_option( 'description' );
		$this->enabled     = $this->get_option( 'enabled' );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Static wiring                                                       */
	/* ------------------------------------------------------------------ */

	public static function hooks() {
		add_action( 'woocommerce_api_bws_snapppay', array( __CLASS__, 'callback' ) );
		add_action( 'bws_snapppay_reconcile', array( __CLASS__, 'reconcile' ) );
		if ( ! wp_next_scheduled( 'bws_snapppay_reconcile' ) ) {
			wp_schedule_event( time() + 900, 'hourly', 'bws_snapppay_reconcile' );
		}
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( __CLASS__, 'admin_box' ) );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'product_badge' ), 25 );
		add_action( 'woocommerce_blocks_payment_method_type_registration', array( __CLASS__, 'register_blocks' ) );
	}

	public static function opts() {
		if ( null === self::$instance_settings ) {
			$s                       = get_option( 'woocommerce_' . self::ID . '_settings', array() );
			self::$instance_settings = is_array( $s ) ? $s : array();
		}
		return self::$instance_settings;
	}

	protected static function opt( $k, $d = '' ) {
		$s = self::opts();
		return isset( $s[ $k ] ) && '' !== $s[ $k ] ? $s[ $k ] : $d;
	}

	public static function api() {
		$debug = 'yes' === self::opt( 'debug', 'no' );
		return new BWS_SnappPay_API(
			array(
				'base_url'      => 'production' === self::opt( 'environment', 'sandbox' ) ? self::opt( 'base_url' ) : self::opt( 'sandbox_url', BWS_SnappPay_API::SANDBOX ),
				'client_id'     => self::opt( 'client_id' ),
				'client_secret' => bws_decrypt( self::opt( 'client_secret' ) ),
				'username'      => self::opt( 'username' ),
				'password'      => bws_decrypt( self::opt( 'password' ) ),
			),
			$debug && function_exists( 'wc_get_logger' ) ? function ( $m ) {
				wc_get_logger()->debug( $m, array( 'source' => 'bws-snapppay' ) );
			} : null
		);
	}

	public static function is_ready() {
		return 'yes' === self::opt( 'enabled', 'no' ) && self::api()->configured() && self::currency_factor() > 0;
	}

	/** Store currency → Rial multiplier (SnappPay always works in IRR). */
	public static function currency_factor() {
		$map = array( 'IRR' => 1, 'IRT' => 10, 'IRHR' => 1000, 'IRHT' => 10000 );
		$c   = get_woocommerce_currency();
		return isset( $map[ $c ] ) ? $map[ $c ] : 0;
	}

	public static function to_irr( $amount ) {
		return (int) round( (float) $amount * self::currency_factor() );
	}

	/**
	 * Eligibility for an amount (store currency). Cached so product/cart pages stay fast.
	 * Returns [ eligible, title, description ].
	 */
	public static function eligibility( $amount ) {
		$irr = self::to_irr( $amount );
		if ( $irr <= 0 || ! self::api()->configured() ) {
			return array( 'eligible' => false, 'title' => '', 'description' => '' );
		}
		$key = 'bws_spp_el_' . $irr . '_' . md5( self::opt( 'environment' ) . self::opt( 'client_id' ) );
		$c   = get_transient( $key );
		if ( is_array( $c ) ) {
			return $c;
		}
		$r   = self::api()->eligible( $irr );
		$out = array( 'eligible' => false, 'title' => '', 'description' => '' );
		if ( ! is_wp_error( $r ) ) {
			$out = array(
				'eligible'    => ! empty( $r['eligible'] ),
				'title'       => isset( $r['title_message'] ) ? sanitize_text_field( $r['title_message'] ) : '',
				'description' => isset( $r['description'] ) ? sanitize_text_field( $r['description'] ) : '',
			);
		}
		set_transient( $key, $out, is_wp_error( $r ) ? 5 * MINUTE_IN_SECONDS : 30 * MINUTE_IN_SECONDS );
		return $out;
	}

	/* ------------------------------------------------------------------ */
	/* Settings                                                            */
	/* ------------------------------------------------------------------ */

	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'       => array( 'title' => 'فعال‌سازی', 'type' => 'checkbox', 'label' => 'پرداخت اقساطی اسنپ‌پی فعال باشد', 'default' => 'no' ),
			'title'         => array( 'title' => 'عنوان در صفحه پرداخت', 'type' => 'text', 'default' => 'خرید اقساطی با اسنپ‌پی' ),
			'description'   => array( 'title' => 'توضیح', 'type' => 'textarea', 'default' => 'با حساب اسنپ‌پی خود خرید کنید و مبلغ را در چند قسط بپردازید (۲۵٪ اکنون و مابقی در اقساط ماهانه، بدون کارمزد).' ),
			'environment'   => array( 'title' => 'محیط', 'type' => 'select', 'default' => 'sandbox', 'options' => array( 'sandbox' => 'آزمایشی (Stage / Sandbox)', 'production' => 'عملیاتی (Production)' ), 'description' => 'تا پایان تست‌های پذیرش اسنپ‌پی روی «آزمایشی» بماند.' ),
			'sandbox_url'   => array( 'title' => 'آدرس سرور آزمایشی', 'type' => 'text', 'default' => BWS_SnappPay_API::SANDBOX, 'description' => 'آدرس محیط Stage که اسنپ‌پی برای شما فرستاده؛ پیش‌فرض: ' . BWS_SnappPay_API::SANDBOX, 'custom_attributes' => array( 'dir' => 'ltr' ) ),
			'base_url'      => array( 'title' => 'آدرس سرور عملیاتی', 'type' => 'text', 'default' => '', 'description' => 'آدرس API عملیاتی اختصاصی شما که بعد از تأیید نهایی، اسنپ‌پی ارسال می‌کند (با https).', 'custom_attributes' => array( 'dir' => 'ltr' ) ),
			'client_id'     => array( 'title' => 'Client ID', 'type' => 'text', 'default' => '', 'custom_attributes' => array( 'dir' => 'ltr', 'autocomplete' => 'off' ) ),
			'client_secret' => array( 'title' => 'Client Secret', 'type' => 'password', 'default' => '', 'description' => 'به‌صورت رمزنگاری‌شده ذخیره می‌شود.', 'custom_attributes' => array( 'dir' => 'ltr', 'autocomplete' => 'new-password' ) ),
			'username'      => array( 'title' => 'نام کاربری (Username)', 'type' => 'text', 'default' => '', 'custom_attributes' => array( 'dir' => 'ltr', 'autocomplete' => 'off' ) ),
			'password'      => array( 'title' => 'رمز (Password)', 'type' => 'password', 'default' => '', 'description' => 'به‌صورت رمزنگاری‌شده ذخیره می‌شود.', 'custom_attributes' => array( 'dir' => 'ltr', 'autocomplete' => 'new-password' ) ),
			'category'      => array( 'title' => 'دسته پیش‌فرض کالا', 'type' => 'text', 'default' => 'سایر', 'description' => 'برای محصولاتی که دسته ندارند در سبد ارسالی به اسنپ‌پی.' ),
			'commission'    => array( 'title' => 'نوع کمیسیون (commissionType)', 'type' => 'number', 'default' => '100', 'description' => 'مقداری که اسنپ‌پی در قرارداد برای شما تعیین کرده (پیش‌فرض مستندات: 100).' ),
			'cart_mode'     => array( 'title' => 'روش ارسال سبد', 'type' => 'select', 'default' => 'itemized', 'options' => array( 'itemized' => 'اقلام با تعداد و قیمت واحد (اعتبار عمده = externalSourceAmount)', 'allocated' => 'مبلغ خالص تقسیم‌شده روی اقلام (count=1)' ), 'description' => 'اگر اسنپ‌پی جمع سبد را نپذیرفت، افزونه خودکار روش دوم را امتحان می‌کند.' ),
			'show_badge'    => array( 'title' => 'نمایش در صفحه محصول', 'type' => 'checkbox', 'label' => 'پیام «خرید اقساطی» اسنپ‌پی زیر قیمت محصول (بدون کند کردن صفحه، بعد از بارگذاری)', 'default' => 'yes' ),
			'auto_revert'   => array( 'title' => 'برگشت خودکار', 'type' => 'checkbox', 'label' => 'اگر سفارش قبلاً با روش دیگری پرداخت شده بود، تراکنش اسنپ‌پی برگشت (revert) داده شود', 'default' => 'yes' ),
			'debug'         => array( 'title' => 'گزارش خطا', 'type' => 'checkbox', 'label' => 'ثبت لاگ در ووکامرس ← وضعیت ← گزارش‌ها (bws-snapppay) — اطلاعات حساس ماسک می‌شود', 'default' => 'no' ),
		);
	}

	/** Secrets: keep stored value when the mask is posted; store encrypted. */
	public function validate_password_field( $key, $value ) {
		$value = is_null( $value ) ? '' : trim( wp_unslash( $value ) );
		if ( bws_secret_mask() === $value ) {
			return $this->get_option( $key );
		}
		return '' === $value ? '' : bws_encrypt( $value );
	}

	public function generate_password_html( $key, $data ) {
		$stored = $this->get_option( $key );
		$this->settings[ $key ] = '' !== (string) $stored ? bws_secret_mask() : '';
		$html                   = parent::generate_password_html( $key, $data );
		$this->settings[ $key ] = $stored;
		return $html;
	}

	public function process_admin_options() {
		$r                       = parent::process_admin_options();
		self::$instance_settings = null;
		return $r;
	}

	public function admin_options() {
		echo '<h2>' . esc_html( $this->method_title ) . '</h2>';
		echo '<div class="notice notice-info inline" style="margin:10px 0"><p>';
		echo 'آدرس بازگشت (Callback / returnURL) که باید به اسنپ‌پی اعلام کنید: <code dir="ltr">' . esc_html( WC()->api_request_url( 'bws_snapppay' ) ) . '</code><br>';
		echo 'واحد پول فروشگاه: <b>' . esc_html( get_woocommerce_currency() ) . '</b> ' . ( self::currency_factor() ? '✔ (به ریال تبدیل می‌شود)' : '✖ اسنپ‌پی فقط با ریال/تومان کار می‌کند' );
		echo ' — <a href="' . esc_url( admin_url( 'admin.php?page=bws-help#snapppay' ) ) . '">راهنمای گام‌به‌گام اتصال</a>';
		echo '</p></div>';
		if ( 'yes' === $this->get_option( 'enabled' ) ) {
			$test = self::api()->access_token();
			echo is_wp_error( $test )
				? '<div class="notice notice-error inline"><p>اتصال ناموفق: ' . esc_html( $test->get_error_message() ) . '</p></div>'
				: '<div class="notice notice-success inline"><p>اتصال به اسنپ‌پی برقرار است (احراز هویت موفق).</p></div>';
		}
		echo '<table class="form-table">';
		$this->generate_settings_html();
		echo '</table>';
	}

	/* ------------------------------------------------------------------ */
	/* Checkout                                                            */
	/* ------------------------------------------------------------------ */

	public function is_available() {
		if ( ! parent::is_available() || ! self::is_ready() ) {
			return false;
		}
		if ( is_admin() && ! wp_doing_ajax() ) {
			return true;
		}
		$total = $this->get_order_total();
		if ( $total <= 0 ) {
			return false;
		}
		$e = self::eligibility( $total );
		return ! empty( $e['eligible'] );
	}

	public function payment_fields() {
		$e = self::eligibility( $this->get_order_total() );
		if ( $this->description ) {
			echo wpautop( wp_kses_post( $this->description ) ); // phpcs:ignore
		}
		if ( ! empty( $e['title'] ) ) {
			echo '<p><strong>' . esc_html( $e['title'] ) . '</strong>' . ( $e['description'] ? '<br>' . esc_html( $e['description'] ) : '' ) . '</p>';
		}
	}

	protected static function mobile_for( $order ) {
		$m = bws_normalize_mobile( $order->get_billing_phone() );
		if ( ! $m && $order->get_meta( '_bws_customer_id' ) ) {
			$c = BWS_Customers::get( (int) $order->get_meta( '_bws_customer_id' ) );
			$m = $c ? $c->mobile : '';
		}
		return $m ? '+98' . substr( $m, 1 ) : '';
	}

	protected static function category_of( $product ) {
		if ( $product ) {
			$pid   = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
			$terms = get_the_terms( $pid, 'product_cat' );
			if ( $terms && ! is_wp_error( $terms ) ) {
				return $terms[0]->name;
			}
		}
		return (string) self::opt( 'category', 'سایر' );
	}

	/**
	 * Build the SnappPay cartList.
	 * itemized:  items with count & unit price, shipping in shippingAmount, wholesale credit → externalSourceAmount, other reductions → discountAmount.
	 * allocated: payable amount split across lines (count=1) – exact sum, no discount/external.
	 */
	public static function build_cart( $order, $amount, $mode = 'itemized' ) {
		$commission = (int) self::opt( 'commission', 100 );
		$lines      = array();
		foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
			$qty     = max( 1, (int) $item->get_quantity() );
			$gross   = (float) $item->get_total() + (float) $item->get_total_tax();
			$product = $item->get_product();
			$lines[] = array(
				'id'       => (string) ( $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id() ),
				'name'     => wp_strip_all_tags( $item->get_name() ),
				'category' => self::category_of( $product ),
				'qty'      => $qty,
				'gross'    => self::to_irr( $gross ),
			);
		}
		foreach ( $order->get_fees() as $fee ) {
			if ( (float) $fee->get_total() > 0 ) {
				$lines[] = array( 'id' => 'fee-' . $fee->get_id(), 'name' => wp_strip_all_tags( $fee->get_name() ), 'category' => self::opt( 'category', 'سایر' ), 'qty' => 1, 'gross' => self::to_irr( (float) $fee->get_total() + (float) $fee->get_total_tax() ) );
			}
		}
		$shipping = self::to_irr( (float) $order->get_shipping_total() + (float) $order->get_shipping_tax() );
		$tax      = self::to_irr( $order->get_total_tax() );

		if ( 'itemized' === $mode ) {
			$items = array();
			$sum   = 0;
			foreach ( $lines as $l ) {
				$unit    = (int) round( $l['gross'] / $l['qty'] );
				$sum    += $unit * $l['qty'];
				$items[] = array( 'id' => $l['id'], 'name' => $l['name'], 'category' => $l['category'], 'amount' => $unit, 'count' => $l['qty'], 'commissionType' => $commission );
			}
			$credit = 0;
			$other  = 0;
			foreach ( $order->get_fees() as $fee ) {
				if ( (float) $fee->get_total() < 0 ) {
					if ( false !== mb_strpos( $fee->get_name(), 'اعتبار' ) ) {
						$credit += self::to_irr( abs( (float) $fee->get_total() ) );
					} else {
						$other += self::to_irr( abs( (float) $fee->get_total() ) );
					}
				}
			}
			$total    = $sum + $shipping;
			$discount = $total - $credit - $amount;
			if ( $discount < 0 || $discount > $total ) {
				return null; // Rounding does not add up – caller falls back to allocated.
			}
			return array(
				'discountAmount'       => $discount,
				'externalSourceAmount' => $credit,
				'cartList'             => array( array(
					'cartId'             => (int) $order->get_id(),
					'cartItems'          => $items,
					'isShipmentIncluded' => true,
					'isTaxIncluded'      => true,
					'shippingAmount'     => $shipping,
					'taxAmount'          => $tax,
					'totalAmount'        => $total,
				) ),
			);
		}

		// Allocated (net) mode.
		if ( $shipping > 0 ) {
			$lines[] = array( 'id' => 'shipping', 'name' => 'هزینه ارسال', 'category' => self::opt( 'category', 'سایر' ), 'qty' => 1, 'gross' => $shipping );
		}
		return array(
			'discountAmount'       => 0,
			'externalSourceAmount' => 0,
			'cartList'             => array( self::allocated_cart( $order->get_id(), $lines, $amount, $tax ) ),
		);
	}

	/** Split $amount (IRR) across lines in proportion to their gross value; exact sum guaranteed. */
	public static function allocated_cart( $cart_id, $lines, $amount, $tax = 0 ) {
		$commission = (int) self::opt( 'commission', 100 );
		$gross      = 0;
		foreach ( $lines as $l ) {
			$gross += max( 0, (int) $l['gross'] );
		}
		$items = array();
		$given = 0;
		$n     = count( $lines );
		foreach ( array_values( $lines ) as $i => $l ) {
			$share   = $i === $n - 1 ? $amount - $given : ( $gross > 0 ? (int) floor( $amount * max( 0, $l['gross'] ) / $gross ) : 0 );
			$given  += $share;
			if ( $share <= 0 ) {
				continue;
			}
			$name    = $l['name'] . ( $l['qty'] > 1 ? ' × ' . $l['qty'] : '' );
			$items[] = array( 'id' => (string) $l['id'], 'name' => $name, 'category' => $l['category'], 'amount' => $share, 'count' => 1, 'commissionType' => $commission );
		}
		return array(
			'cartId'             => (int) $cart_id,
			'cartItems'          => $items,
			'isShipmentIncluded' => true,
			'isTaxIncluded'      => true,
			'shippingAmount'     => 0,
			'taxAmount'          => $gross > 0 ? (int) round( $tax * $amount / $gross ) : 0,
			'totalAmount'        => $amount,
		);
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wc_add_notice( 'سفارش یافت نشد.', 'error' );
			return array( 'result' => 'failure' );
		}
		$amount = self::to_irr( $order->get_total() );
		$mobile = self::mobile_for( $order );
		if ( ! $mobile ) {
			wc_add_notice( 'برای پرداخت با اسنپ‌پی، شماره موبایل معتبر (مثل ۰۹۱۲۱۲۳۴۵۶۷) در اطلاعات صورتحساب وارد کنید.', 'error' );
			return array( 'result' => 'failure' );
		}
		if ( ! bws_lock( 'spp_' . $order_id, 5 ) ) {
			wc_add_notice( 'درخواست قبلی در حال انجام است؛ چند ثانیه بعد دوباره تلاش کنید.', 'error' );
			return array( 'result' => 'failure' );
		}
		try {
			$txn    = 'AV' . $order_id . 'T' . strtoupper( wp_generate_password( 10, false, false ) );
			$return = add_query_arg( array( 'order' => $order_id, 'key' => $order->get_order_key() ), WC()->api_request_url( 'bws_snapppay' ) );
			$modes  = 'allocated' === self::opt( 'cart_mode', 'itemized' ) ? array( 'allocated' ) : array( 'itemized', 'allocated' );
			$last   = null;
			foreach ( $modes as $mode ) {
				$cart = self::build_cart( $order, $amount, $mode );
				if ( ! $cart ) {
					continue;
				}
				$payload = array_merge( array(
					'amount'               => $amount,
					'mobile'               => $mobile,
					'paymentMethodTypeDto' => 'INSTALLMENT',
					'transactionId'        => $txn,
					'returnURL'            => $return,
				), $cart );
				// Persist before the call so a lost response can still be reconciled.
				$order->update_meta_data( '_bws_spp_txn', $txn );
				$order->update_meta_data( '_bws_spp_amount', $amount );
				$order->update_meta_data( '_bws_spp_state', 'CREATED' );
				$order->update_meta_data( '_bws_spp_cart', wp_json_encode( $payload['cartList'], JSON_UNESCAPED_UNICODE ) );
				$order->update_meta_data( '_bws_spp_ext', (int) $cart['externalSourceAmount'] );
				$order->save();
				$res = self::api()->token( $payload );
				if ( ! is_wp_error( $res ) && ! empty( $res['paymentToken'] ) && ! empty( $res['paymentPageUrl'] ) ) {
					$url = esc_url_raw( (string) $res['paymentPageUrl'] );
					if ( 0 !== strpos( $url, 'https://' ) && ! ( defined( 'BWS_SPP_ALLOW_HTTP' ) && BWS_SPP_ALLOW_HTTP ) ) {
						$last = new WP_Error( 'spp_url', 'آدرس صفحه پرداخت اسنپ‌پی نامعتبر است.' );
						break;
					}
					$order->update_meta_data( '_bws_spp_token', bws_encrypt( (string) $res['paymentToken'] ) );
					$order->update_meta_data( '_bws_spp_state', 'PENDING' );
					$order->set_transaction_id( $txn );
					$order->save();
					$order->add_order_note( 'اسنپ‌پی: انتقال مشتری به صفحه پرداخت. شناسه تراکنش: ' . $txn . ' — مبلغ: ' . number_format( $amount ) . ' ریال' );
					return array( 'result' => 'success', 'redirect' => $url );
				}
				$last = is_wp_error( $res ) ? $res : new WP_Error( 'spp_api', 'پاسخ نامعتبر از اسنپ‌پی.' );
				if ( ! empty( $last->get_error_data()['timeout'] ) ) {
					break; // Unknown outcome: do not resend the same transaction.
				}
			}
			$order->update_meta_data( '_bws_spp_state', 'FAILED' );
			$order->save();
			$msg = $last ? $last->get_error_message() : 'خطا در ایجاد تراکنش اسنپ‌پی.';
			$order->add_order_note( 'اسنپ‌پی: ایجاد تراکنش ناموفق — ' . $msg );
			wc_add_notice( 'پرداخت با اسنپ‌پی ممکن نشد: ' . $msg, 'error' );
			return array( 'result' => 'failure' );
		} finally {
			bws_unlock( 'spp_' . $order_id );
		}
	}

	/* ------------------------------------------------------------------ */
	/* Callback / verify / settle                                          */
	/* ------------------------------------------------------------------ */

	public static function callback() {
		$order_id = isset( $_GET['order'] ) ? absint( $_GET['order'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$key      = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : ''; // phpcs:ignore
		$src      = 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) ? $_POST : $_GET; // phpcs:ignore
		$txn      = isset( $src['transactionId'] ) ? sanitize_text_field( wp_unslash( $src['transactionId'] ) ) : '';
		$state    = isset( $src['state'] ) ? strtoupper( sanitize_key( wp_unslash( $src['state'] ) ) ) : '';
		$amount   = isset( $src['amount'] ) ? (int) preg_replace( '/\D/', '', (string) wp_unslash( $src['amount'] ) ) : -1;

		$order = $order_id ? wc_get_order( $order_id ) : null;
		if ( ! $order || ! hash_equals( $order->get_order_key(), $key ) || self::ID !== $order->get_payment_method() ) {
			wp_safe_redirect( wc_get_cart_url() );
			exit;
		}
		$saved_txn = (string) $order->get_meta( '_bws_spp_txn' );
		$saved_amt = (int) $order->get_meta( '_bws_spp_amount' );
		if ( '' === $txn || ! hash_equals( $saved_txn, $txn ) || ( $amount >= 0 && $amount !== $saved_amt ) ) {
			$order->add_order_note( 'اسنپ‌پی: بازگشت نامعتبر (شناسه/مبلغ مطابقت ندارد) نادیده گرفته شد.' );
			wc_add_notice( 'اطلاعات بازگشت از اسنپ‌پی معتبر نیست.', 'error' );
			wp_safe_redirect( $order->get_checkout_payment_url() );
			exit;
		}
		if ( $order->is_paid() && 'SETTLE' === $order->get_meta( '_bws_spp_state' ) ) {
			wp_safe_redirect( $order->get_checkout_order_received_url() );
			exit;
		}
		if ( 'OK' !== $state ) {
			// Callback is untrusted: confirm with an authenticated status request before marking failed.
			$s = self::api()->status( bws_decrypt( $order->get_meta( '_bws_spp_token' ) ) );
			if ( is_wp_error( $s ) || ! in_array( isset( $s['status'] ) ? $s['status'] : '', array( 'VERIFY', 'SETTLE' ), true ) ) {
				$order->update_meta_data( '_bws_spp_state', 'FAILED' );
				$order->save();
				$order->add_order_note( 'اسنپ‌پی: پرداخت انجام نشد یا توسط مشتری لغو شد.' );
				wc_add_notice( 'پرداخت اسنپ‌پی انجام نشد. می‌توانید دوباره تلاش کنید یا روش دیگری را انتخاب کنید.', 'error' );
				wp_safe_redirect( $order->get_checkout_payment_url() );
				exit;
			}
		}
		$r = self::confirm( $order );
		if ( true === $r ) {
			WC()->cart && WC()->cart->empty_cart();
			wp_safe_redirect( $order->get_checkout_order_received_url() );
			exit;
		}
		wc_add_notice( is_wp_error( $r ) ? $r->get_error_message() : 'پرداخت اسنپ‌پی تأیید نشد.', 'error' );
		wp_safe_redirect( $order->get_checkout_payment_url() );
		exit;
	}

	/**
	 * Verify + settle with recovery. Returns true when the order is paid (SETTLE), WP_Error otherwise.
	 * Safe to call repeatedly (callback, reconciliation, admin inquiry).
	 */
	public static function confirm( $order ) {
		$oid = $order->get_id();
		if ( ! bws_lock( 'spp_' . $oid, 20 ) ) {
			return new WP_Error( 'spp_busy', 'تراکنش در حال پردازش است؛ چند لحظه بعد صفحه سفارش را ببینید.' );
		}
		try {
			$order = wc_get_order( $oid ); // fresh.
			$token = bws_decrypt( (string) $order->get_meta( '_bws_spp_token' ) );
			$txn   = (string) $order->get_meta( '_bws_spp_txn' );
			$amt   = (int) $order->get_meta( '_bws_spp_amount' );
			$state = (string) $order->get_meta( '_bws_spp_state' );
			$api   = self::api();
			if ( '' === $token ) {
				return new WP_Error( 'spp_token', 'اطلاعات تراکنش اسنپ‌پی کامل نیست.' );
			}
			if ( 'SETTLE' === $state ) {
				self::mark_paid( $order, $txn );
				return true;
			}
			// The order changed after the payment started, or was paid another way → never take money twice.
			if ( self::to_irr( $order->get_total() ) !== $amt || ( $order->is_paid() && self::ID !== $order->get_payment_method() ) ) {
				if ( 'yes' === self::opt( 'auto_revert', 'yes' ) ) {
					$rv = $api->revert( $token );
					$order->add_order_note( 'اسنپ‌پی: مبلغ/وضعیت سفارش تغییر کرده بود؛ ' . ( is_wp_error( $rv ) ? 'برگشت تراکنش ناموفق: ' . $rv->get_error_message() : 'تراکنش برگشت داده شد (revert).' ) );
					if ( ! is_wp_error( $rv ) ) {
						$order->update_meta_data( '_bws_spp_state', 'REVERT' );
						$order->save();
					}
				}
				return new WP_Error( 'spp_changed', 'سفارش بعد از شروع پرداخت تغییر کرده است؛ با فروشگاه تماس بگیرید.' );
			}
			if ( 'VERIFY' !== $state ) {
				$v = $api->verify( $token );
				if ( ! is_wp_error( $v ) && ( empty( $v['transactionId'] ) || hash_equals( $txn, (string) $v['transactionId'] ) ) ) {
					$state = 'VERIFY';
				} else {
					$s = $api->status( $token );
					$st = ! is_wp_error( $s ) && isset( $s['status'] ) ? strtoupper( $s['status'] ) : '';
					if ( ! is_wp_error( $s ) && isset( $s['amount'] ) && (int) $s['amount'] !== $amt && ! in_array( $st, array( 'CANCEL', 'REVERT' ), true ) ) {
						return new WP_Error( 'spp_amount', 'مبلغ تراکنش اسنپ‌پی با سفارش یکسان نیست.' );
					}
					if ( in_array( $st, array( 'VERIFY', 'SETTLE' ), true ) ) {
						$state = $st;
					} elseif ( 'PENDING' === $st ) {
						$v2 = $api->verify( $token );
						if ( is_wp_error( $v2 ) ) {
							return new WP_Error( 'spp_verify', 'تأیید پرداخت اسنپ‌پی انجام نشد: ' . $v2->get_error_message() );
						}
						$state = 'VERIFY';
					} else {
						$order->update_meta_data( '_bws_spp_state', $st ? $st : 'FAILED' );
						$order->save();
						return new WP_Error( 'spp_verify', 'پرداخت اسنپ‌پی تأیید نشد' . ( is_wp_error( $v ) ? ': ' . $v->get_error_message() : '.' ) );
					}
				}
				$order->update_meta_data( '_bws_spp_state', $state );
				$order->save();
			}
			if ( 'VERIFY' === $state ) {
				$st = $api->settle( $token );
				if ( is_wp_error( $st ) ) {
					$s = $api->status( $token );
					if ( ! is_wp_error( $s ) && isset( $s['status'] ) && 'SETTLE' === strtoupper( $s['status'] ) ) {
						$state = 'SETTLE';
					} else {
						if ( 'on-hold' !== $order->get_status() ) {
							$order->update_status( 'on-hold', 'اسنپ‌پی: پرداخت تأیید شد ولی تسویه (settle) هنوز انجام نشده؛ به‌صورت خودکار دوباره تلاش می‌شود.' );
						}
						return new WP_Error( 'spp_settle', 'پرداخت شما تأیید شد و در حال نهایی شدن است. نتیجه به‌زودی در سفارش شما ثبت می‌شود.' );
					}
				} else {
					$state = 'SETTLE';
				}
			}
			$order->update_meta_data( '_bws_spp_state', $state );
			$order->save();
			if ( 'SETTLE' === $state ) {
				self::mark_paid( $order, $txn );
				return true;
			}
			return new WP_Error( 'spp_state', 'وضعیت تراکنش اسنپ‌پی: ' . $state );
		} finally {
			bws_unlock( 'spp_' . $oid );
		}
	}

	protected static function mark_paid( $order, $txn ) {
		if ( $order->is_paid() ) {
			return;
		}
		$order->payment_complete( $txn );
		$order->add_order_note( 'اسنپ‌پی: پرداخت تأیید و تسویه شد (VERIFY → SETTLE). شناسه تراکنش: ' . $txn );
		if ( class_exists( 'BWS_Log' ) && $order->get_meta( '_bws_customer_id' ) ) {
			BWS_Log::add( 'snapppay', 'customer', (int) $order->get_meta( '_bws_customer_id' ), array( 'order' => $order->get_id(), 'state' => 'SETTLE' ), 'customer' );
		}
	}

	/** Admin / cron status inquiry; finishes the payment when SnappPay says VERIFY/SETTLE. */
	public static function inquiry( $order ) {
		$token = bws_decrypt( (string) $order->get_meta( '_bws_spp_token' ) );
		if ( '' === $token ) {
			return new WP_Error( 'spp_token', 'این سفارش تراکنش اسنپ‌پی ندارد.' );
		}
		$s = self::api()->status( $token );
		if ( is_wp_error( $s ) ) {
			return $s;
		}
		$st = isset( $s['status'] ) ? strtoupper( (string) $s['status'] ) : '';
		$out = array( 'status' => $st, 'amount' => isset( $s['amount'] ) ? (int) $s['amount'] : null, 'transactionId' => isset( $s['transactionId'] ) ? $s['transactionId'] : '' );
		if ( in_array( $st, array( 'VERIFY', 'SETTLE' ), true ) && ! $order->is_paid() ) {
			if ( 'SETTLE' === $st ) {
				$order->update_meta_data( '_bws_spp_state', 'SETTLE' );
				$order->save();
			} else {
				$order->update_meta_data( '_bws_spp_state', 'VERIFY' );
				$order->save();
			}
			$r              = self::confirm( $order );
			$out['settled'] = true === $r;
			$out['message'] = true === $r ? 'پرداخت نهایی و سفارش پرداخت‌شده ثبت شد.' : $r->get_error_message();
		} else {
			$order->update_meta_data( '_bws_spp_state', $st ? $st : $order->get_meta( '_bws_spp_state' ) );
			$order->save();
			$labels         = array( 'PENDING' => 'در انتظار پرداخت مشتری', 'VERIFY' => 'تأییدشده (در انتظار تسویه)', 'SETTLE' => 'تسویه‌شده (پرداخت نهایی)', 'REVERT' => 'برگشت‌خورده', 'CANCEL' => 'لغو / مسترد شده' );
			$out['message'] = 'وضعیت در اسنپ‌پی: ' . ( isset( $labels[ $st ] ) ? $labels[ $st ] : $st );
		}
		return $out;
	}

	/** Hourly: finish payments whose callback never arrived. */
	public static function reconcile() {
		if ( ! self::api()->configured() ) {
			return;
		}
		$orders = wc_get_orders( array(
			'limit'          => 20,
			'payment_method' => self::ID,
			'status'         => array( 'pending', 'on-hold', 'failed' ),
			'date_created'   => '>' . ( time() - 3 * DAY_IN_SECONDS ),
			'meta_query'     => array( array( 'key' => '_bws_spp_state', 'value' => array( 'PENDING', 'VERIFY' ), 'compare' => 'IN' ) ), // phpcs:ignore
		) );
		foreach ( $orders as $o ) {
			if ( $o->get_date_created() && $o->get_date_created()->getTimestamp() > time() - 15 * MINUTE_IN_SECONDS ) {
				continue; // Customer may still be on the SnappPay page.
			}
			self::inquiry( $o );
		}
	}

	/* ------------------------------------------------------------------ */
	/* Refunds                                                             */
	/* ------------------------------------------------------------------ */

	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return new WP_Error( 'spp_404', 'سفارش یافت نشد.' );
		}
		$token = bws_decrypt( (string) $order->get_meta( '_bws_spp_token' ) );
		$state = (string) $order->get_meta( '_bws_spp_state' );
		if ( '' === $token || ! in_array( $state, array( 'SETTLE', 'VERIFY' ), true ) ) {
			return new WP_Error( 'spp_state', 'این سفارش تراکنش تسویه‌شده اسنپ‌پی ندارد.' );
		}
		$paid      = (int) $order->get_meta( '_bws_spp_amount' );
		$refunded  = (int) $order->get_meta( '_bws_spp_refunded' );
		$remaining = $paid - $refunded;
		$req       = null === $amount ? $remaining : self::to_irr( $amount );
		if ( $req <= 0 || $req > $remaining ) {
			return new WP_Error( 'spp_amount', 'مبلغ استرداد نامعتبر است.' );
		}
		if ( ! bws_lock( 'spp_' . $order_id, 10 ) ) {
			return new WP_Error( 'spp_busy', 'عملیات دیگری روی این تراکنش در حال انجام است.' );
		}
		try {
			$api = self::api();
			if ( $req === $remaining ) {
				$r = $api->cancel( $token );
				if ( is_wp_error( $r ) ) {
					return new WP_Error( 'spp_cancel', 'لغو تراکنش اسنپ‌پی ناموفق: ' . $r->get_error_message() );
				}
				$order->update_meta_data( '_bws_spp_state', 'CANCEL' );
				$order->update_meta_data( '_bws_spp_refunded', $paid );
				$order->save();
				$order->add_order_note( 'اسنپ‌پی: کل مبلغ مسترد شد (cancel). ' . ( $reason ? 'دلیل: ' . $reason : '' ) );
				return true;
			}
			$new   = $remaining - $req;
			$saved = json_decode( (string) $order->get_meta( '_bws_spp_cart' ), true );
			$lines = array();
			if ( is_array( $saved ) && isset( $saved[0]['cartItems'] ) ) {
				foreach ( $saved[0]['cartItems'] as $it ) {
					$lines[] = array( 'id' => $it['id'], 'name' => $it['name'], 'category' => $it['category'], 'qty' => 1, 'gross' => (int) $it['amount'] * max( 1, (int) $it['count'] ) );
				}
			}
			if ( ! $lines ) {
				$lines[] = array( 'id' => (string) $order_id, 'name' => 'سفارش ' . $order_id, 'category' => self::opt( 'category', 'سایر' ), 'qty' => 1, 'gross' => $new );
			}
			$cart = self::allocated_cart( $order_id, $lines, $new );
			$r    = $api->update( array(
				'paymentToken'         => $token,
				'amount'               => $new,
				'discountAmount'       => 0,
				'externalSourceAmount' => 0,
				'paymentMethodTypeDto' => 'INSTALLMENT',
				'cartList'             => array( $cart ),
			) );
			if ( is_wp_error( $r ) ) {
				return new WP_Error( 'spp_update', 'استرداد جزئی اسنپ‌پی ناموفق: ' . $r->get_error_message() );
			}
			$order->update_meta_data( '_bws_spp_refunded', $refunded + $req );
			$order->update_meta_data( '_bws_spp_cart', wp_json_encode( array( $cart ), JSON_UNESCAPED_UNICODE ) );
			$order->save();
			$order->add_order_note( 'اسنپ‌پی: استرداد جزئی ' . number_format( $req ) . ' ریال انجام شد (update). مبلغ جدید تراکنش: ' . number_format( $new ) . ' ریال.' );
			return true;
		} finally {
			bws_unlock( 'spp_' . $order_id );
		}
	}

	/* ------------------------------------------------------------------ */
	/* Admin box, product badge, blocks                                    */
	/* ------------------------------------------------------------------ */

	public static function admin_box( $order ) {
		if ( self::ID !== $order->get_payment_method() || ! $order->get_meta( '_bws_spp_txn' ) ) {
			return;
		}
		$labels = array( 'CREATED' => 'ایجاد شده', 'PENDING' => 'در انتظار پرداخت', 'VERIFY' => 'تأییدشده', 'SETTLE' => 'تسویه‌شده', 'FAILED' => 'ناموفق', 'REVERT' => 'برگشت‌خورده', 'CANCEL' => 'لغو/مسترد' );
		$st     = (string) $order->get_meta( '_bws_spp_state' );
		echo '<div class="bws-spp-box" style="margin-top:12px;padding:10px;border:1px solid #c5d9ed;background:#f6fbff;border-radius:6px">';
		echo '<strong>اسنپ‌پی</strong><br>شناسه تراکنش: <code>' . esc_html( $order->get_meta( '_bws_spp_txn' ) ) . '</code><br>';
		echo 'مبلغ: ' . esc_html( number_format( (int) $order->get_meta( '_bws_spp_amount' ) ) ) . ' ریال<br>';
		echo 'وضعیت: <b class="bws-spp-state">' . esc_html( isset( $labels[ $st ] ) ? $labels[ $st ] : $st ) . '</b><br>';
		echo '<button type="button" class="button bws-spp-inquiry" data-order="' . esc_attr( $order->get_id() ) . '" data-nonce="' . esc_attr( wp_create_nonce( 'wp_rest' ) ) . '" data-url="' . esc_url( rest_url( 'bws/v1/admin/snapppay/status' ) ) . '" style="margin-top:6px">استعلام وضعیت از اسنپ‌پی</button> <span class="bws-spp-msg"></span>';
		echo '</div>';
		?>
		<script>
		document.addEventListener('click',function(e){var b=e.target.closest('.bws-spp-inquiry');if(!b)return;var m=b.parentNode.querySelector('.bws-spp-msg');b.disabled=true;m.textContent='…';
		fetch(b.dataset.url,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-WP-Nonce':b.dataset.nonce},body:JSON.stringify({order_id:b.dataset.order})}).then(function(r){return r.json()}).then(function(j){m.textContent=j.message||'';b.disabled=false;if(j.settled)location.reload();}).catch(function(){m.textContent='خطا';b.disabled=false;});});
		</script>
		<?php
	}

	public static function product_badge() {
		if ( 'yes' !== self::opt( 'show_badge', 'yes' ) || ! self::is_ready() ) {
			return;
		}
		global $product;
		if ( ! $product || ! $product->get_price() ) {
			return;
		}
		echo '<div class="bws-spp-badge" data-amount="' . esc_attr( wc_get_price_to_display( $product ) ) . '" hidden style="margin:8px 0;padding:8px 12px;border-radius:10px;background:#f2f7ff;border:1px solid #d6e4ff;font-size:13px"></div>';
		?>
		<script>
		(function(){var el=document.querySelector('.bws-spp-badge');if(!el||!window.fetch)return;var go=function(){fetch(<?php echo wp_json_encode( esc_url_raw( rest_url( 'bws/v1/snapppay/offer' ) ) ); ?>+'?amount='+encodeURIComponent(el.dataset.amount)).then(function(r){return r.json()}).then(function(j){if(j&&j.eligible){var b=document.createElement('b');b.textContent=j.title||'خرید اقساطی با اسنپ‌پی';el.appendChild(b);if(j.description){el.appendChild(document.createElement('br'));el.appendChild(document.createTextNode(j.description));}el.hidden=false;}}).catch(function(){});};
		if('requestIdleCallback' in window){requestIdleCallback(go)}else{setTimeout(go,800)}})();
		</script>
		<?php
	}

	public static function register_blocks( $registry ) {
		if ( class_exists( '\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
			require_once BWS_DIR . 'includes/gateways/class-snapppay-blocks.php';
			$registry->register( new BWS_SnappPay_Blocks() );
		}
	}
}
