<?php
defined( 'ABSPATH' ) || exit;

class BWS_Customers {

	public static $editable = array( 'first_name', 'last_name', 'shop_name', 'mobile', 'phone', 'province', 'city', 'address', 'postal_code', 'national_id', 'notes' );

	public static function table() {
		return BWS_Install::table( 'customers' );
	}

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ) );
	}

	public static function get_by_code( $code ) {
		global $wpdb;
		$code = strtoupper( trim( bws_en_digits( $code ) ) );
		if ( '' === $code ) {
			return null;
		}
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE code = %s', $code ) );
	}

	public static function get_by_mobile( $mobile ) {
		global $wpdb;
		$mobile = bws_normalize_mobile( $mobile );
		if ( ! $mobile ) {
			return null;
		}
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE mobile = %s', $mobile ) );
	}

	public static function full_name( $c ) {
		return trim( $c->first_name . ' ' . $c->last_name );
	}

	/** Generate a unique random code according to settings. */
	public static function generate_code() {
		global $wpdb;
		$len    = max( 4, min( 16, (int) bws_opt( 'code_length', 8 ) ) );
		$type   = bws_opt( 'code_type', 'numeric' );
		$prefix = strtoupper( preg_replace( '/[^A-Za-z0-9\-]/', '', (string) bws_opt( 'code_prefix', '' ) ) );
		$chars  = ( 'alnum' === $type ) ? '23456789ABCDEFGHJKLMNPQRSTUVWXYZ' : '0123456789';
		$max    = strlen( $chars ) - 1;
		for ( $i = 0; $i < 50; $i++ ) {
			$code = '';
			for ( $j = 0; $j < $len; $j++ ) {
				$code .= $chars[ random_int( 0, $max ) ];
			}
			if ( 'numeric' === $type && '0' === $code[0] ) {
				$code[0] = (string) random_int( 1, 9 );
			}
			$code   = $prefix . $code;
			$exists = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::table() . ' WHERE code = %s', $code ) );
			if ( ! $exists ) {
				return $code;
			}
		}
		return $prefix . strtoupper( wp_generate_password( $len + 2, false, false ) );
	}

	/** Validate & sanitize input. Returns array or WP_Error. */
	public static function sanitize( $data, $id = 0 ) {
		$out = array();
		foreach ( self::$editable as $f ) {
			if ( ! array_key_exists( $f, $data ) ) {
				continue;
			}
			$v = is_string( $data[ $f ] ) ? wp_unslash( $data[ $f ] ) : $data[ $f ];
			if ( in_array( $f, array( 'address', 'notes' ), true ) ) {
				$out[ $f ] = sanitize_textarea_field( $v );
			} else {
				$out[ $f ] = sanitize_text_field( $v );
			}
		}
		foreach ( array( 'phone', 'postal_code', 'national_id' ) as $f ) {
			if ( isset( $out[ $f ] ) ) {
				$out[ $f ] = bws_en_digits( $out[ $f ] );
			}
		}
		if ( array_key_exists( 'mobile', $out ) || ! $id ) {
			$mobile = bws_normalize_mobile( isset( $out['mobile'] ) ? $out['mobile'] : '' );
			if ( ! $mobile ) {
				return new WP_Error( 'bws_mobile', 'شماره موبایل معتبر نیست (مثال: ۰۹۱۲۱۲۳۴۵۶۷).' );
			}
			$dup = self::get_by_mobile( $mobile );
			if ( $dup && (int) $dup->id !== (int) $id ) {
				return new WP_Error( 'bws_duplicate', sprintf( 'این شماره قبلاً برای «%s» با کد %s توسط %s ثبت شده است.', self::full_name( $dup ), $dup->code, bws_user_name( $dup->visitor_id ) ), array( 'customer_id' => (int) $dup->id ) );
			}
			$out['mobile'] = $mobile;
		}
		if ( ! $id ) {
			if ( empty( $out['first_name'] ) && empty( $out['last_name'] ) ) {
				return new WP_Error( 'bws_name', 'نام و نام خانوادگی را وارد کنید.' );
			}
			if ( empty( $out['address'] ) ) {
				return new WP_Error( 'bws_address', 'آدرس را وارد کنید.' );
			}
		}
		return $out;
	}

	/** Create customer. $visitor_id = registering visitor (or 0 for admin). */
	public static function create( $data, $visitor_id = 0 ) {
		global $wpdb;
		$clean = self::sanitize( $data );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		$now   = bws_now();
		$limit = isset( $data['credit_limit'] ) && '' !== $data['credit_limit'] ? self::allowed_limit( bws_parse_amount( $data['credit_limit'] ) ) : (float) bws_opt( 'default_credit' );
		$row   = array_merge(
			array_fill_keys( self::$editable, '' ),
			$clean,
			array(
				'code'         => self::generate_code(),
				'visitor_id'   => (int) $visitor_id,
				'created_by'   => get_current_user_id(),
				'status'       => 'active',
				'credit_limit' => $limit,
				'balance'      => 0,
				'created_at'   => $now,
				'updated_at'   => $now,
			)
		);
		$ok = $wpdb->insert( self::table(), $row );
		if ( ! $ok ) {
			return new WP_Error( 'bws_db', 'خطا در ذخیره اطلاعات مشتری: ' . $wpdb->last_error );
		}
		$id = (int) $wpdb->insert_id;
		BWS_Log::add( 'customer_create', 'customer', $id, array( 'code' => $row['code'], 'name' => trim( $row['first_name'] . ' ' . $row['last_name'] ) ) );

		$customer = self::get( $id );
		if ( ! isset( $data['send_sms'] ) || $data['send_sms'] ) {
			BWS_SMS::send_event( 'welcome', $customer );
		}
		do_action( 'bws_customer_created', $customer );
		return $customer;
	}

	/**
	 * Clamp a requested credit limit to what the current user may grant.
	 * Managers: any amount. Visitors: only with the credit_set permission, up to credit_max (0 = default credit).
	 */
	public static function allowed_limit( $requested ) {
		$requested = max( 0, (float) $requested );
		if ( bws_is_manager() ) {
			return $requested;
		}
		$p = BWS_Perms::for_user();
		if ( empty( $p['credit_set'] ) ) {
			return (float) bws_opt( 'default_credit' );
		}
		$max = (float) $p['credit_max'] > 0 ? (float) $p['credit_max'] : (float) bws_opt( 'default_credit' );
		return min( $requested, $max );
	}

	/** Save GPS location of the customer's shop. */
	public static function set_location( $id, $lat, $lng ) {
		global $wpdb;
		$lat = (float) bws_en_digits( $lat );
		$lng = (float) bws_en_digits( $lng );
		if ( $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180 || ( 0.0 === $lat && 0.0 === $lng ) ) {
			return new WP_Error( 'bws_loc', 'موقعیت مکانی معتبر نیست.' );
		}
		$wpdb->update( self::table(), array( 'lat' => round( $lat, 7 ), 'lng' => round( $lng, 7 ), 'updated_at' => bws_now() ), array( 'id' => $id ) );
		BWS_Log::add( 'customer_location', 'customer', $id, $lat . ',' . $lng );
		return true;
	}

	/** Per-customer wholesale discount (null = use product/global discount). */
	public static function set_discount( $id, $value ) {
		global $wpdb;
		$v = trim( bws_en_digits( (string) $value ) );
		$v = '' === $v ? null : max( 0, min( 100, (float) $v ) );
		$wpdb->update( self::table(), array( 'discount_percent' => $v, 'updated_at' => bws_now() ), array( 'id' => $id ) );
		update_option( 'bws_catalog_ver', time(), false );
		BWS_Log::add( 'customer_discount', 'customer', $id, null === $v ? 'default' : $v );
	}

	public static function update( $id, $data ) {
		global $wpdb;
		$clean = self::sanitize( $data, $id );
		if ( is_wp_error( $clean ) ) {
			return $clean;
		}
		if ( ! $clean ) {
			return self::get( $id );
		}
		$clean['updated_at'] = bws_now();
		$wpdb->update( self::table(), $clean, array( 'id' => $id ) );
		BWS_Log::add( 'customer_update', 'customer', $id, array_keys( $clean ) );
		return self::get( $id );
	}

	public static function set_status( $id, $status ) {
		global $wpdb;
		$status = ( 'inactive' === $status ) ? 'inactive' : 'active';
		$wpdb->update( self::table(), array( 'status' => $status, 'updated_at' => bws_now() ), array( 'id' => $id ) );
		BWS_Log::add( 'customer_status', 'customer', $id, $status );
	}

	public static function regenerate_code( $id ) {
		global $wpdb;
		$code = self::generate_code();
		$wpdb->update( self::table(), array( 'code' => $code, 'updated_at' => bws_now() ), array( 'id' => $id ) );
		BWS_Log::add( 'customer_code', 'customer', $id, $code );
		return $code;
	}

	public static function set_credit_limit( $id, $limit, $notify = true ) {
		global $wpdb;
		$old = self::get( $id );
		$wpdb->update( self::table(), array( 'credit_limit' => max( 0, (float) $limit ), 'updated_at' => bws_now() ), array( 'id' => $id ) );
		BWS_Log::add( 'credit_limit', 'customer', $id, array( 'from' => $old ? (float) $old->credit_limit : 0, 'to' => (float) $limit ) );
		if ( $notify ) {
			BWS_SMS::send_event( 'credit_change', self::get( $id ) );
		}
	}

	public static function transfer( $id, $visitor_id ) {
		global $wpdb;
		$wpdb->update( self::table(), array( 'visitor_id' => (int) $visitor_id, 'updated_at' => bws_now() ), array( 'id' => $id ) );
		BWS_Log::add( 'customer_transfer', 'customer', $id, array( 'visitor' => bws_user_name( $visitor_id ) ) );
	}

	public static function delete( $id ) {
		global $wpdb;
		$c = self::get( $id );
		if ( ! $c ) {
			return;
		}
		$wpdb->delete( self::table(), array( 'id' => $id ) );
		BWS_Log::add( 'customer_delete', 'customer', $id, array( 'code' => $c->code, 'name' => self::full_name( $c ) ) );
	}

	public static function save_cart( $id, $cart ) {
		global $wpdb;
		$clean = array();
		foreach ( (array) $cart as $pid => $qty ) {
			$pid = absint( $pid );
			$qty = absint( $qty );
			if ( $pid && $qty ) {
				$clean[ $pid ] = min( $qty, 100000 );
			}
		}
		$wpdb->update( self::table(), array( 'cart' => wp_json_encode( $clean ) ), array( 'id' => $id ) );
		return $clean;
	}

	public static function get_cart( $c ) {
		$cart = $c && $c->cart ? json_decode( $c->cart, true ) : array();
		return is_array( $cart ) ? $cart : array();
	}

	public static function touch( $id, $field ) {
		global $wpdb;
		$wpdb->update( self::table(), array( $field => bws_now() ), array( 'id' => $id ) );
	}

	/**
	 * Search/list customers.
	 * args: search, visitor_id, status, debt (1 = only with debt), orderby, order, page, per_page
	 */
	public static function query( $args = array() ) {
		global $wpdb;
		$t     = self::table();
		$where = array( '1=1' );
		$vals  = array();

		if ( ! empty( $args['search'] ) ) {
			$s     = trim( bws_en_digits( $args['search'] ) );
			$like  = '%' . $wpdb->esc_like( $s ) . '%';
			$parts = array( 'code LIKE %s', 'first_name LIKE %s', 'last_name LIKE %s', 'shop_name LIKE %s', 'mobile LIKE %s', 'phone LIKE %s', 'address LIKE %s', 'city LIKE %s', "CONCAT(first_name, ' ', last_name) LIKE %s" );
			$where[] = '(' . implode( ' OR ', $parts ) . ')';
			for ( $i = 0; $i < count( $parts ); $i++ ) {
				$vals[] = $like;
			}
			$norm = bws_normalize_mobile( $s );
			if ( $norm && $norm !== $s ) {
				$where[ count( $where ) - 1 ] = '(' . implode( ' OR ', $parts ) . ' OR mobile = %s)';
				$vals[]                         = $norm;
			}
		}
		if ( isset( $args['visitor_id'] ) && '' !== $args['visitor_id'] && null !== $args['visitor_id'] ) {
			$where[] = 'visitor_id = %d';
			$vals[]  = (int) $args['visitor_id'];
		}
		if ( ! empty( $args['status'] ) ) {
			$where[] = 'status = %s';
			$vals[]  = $args['status'];
		}
		if ( ! empty( $args['debt'] ) ) {
			$where[] = 'balance > 0';
		}
		if ( ! empty( $args['province'] ) ) {
			$where[] = 'province = %s';
			$vals[]  = $args['province'];
		}
		if ( ! empty( $args['ids'] ) ) {
			$ids     = array_map( 'absint', (array) $args['ids'] );
			$where[] = 'id IN (' . implode( ',', $ids ? $ids : array( 0 ) ) . ')';
		}

		$allowed = array( 'id', 'created_at', 'balance', 'last_order_at', 'first_name', 'last_name', 'code', 'credit_limit' );
		$orderby = isset( $args['orderby'] ) && in_array( $args['orderby'], $allowed, true ) ? $args['orderby'] : 'id';
		$order   = isset( $args['order'] ) && 'asc' === strtolower( $args['order'] ) ? 'ASC' : 'DESC';
		$per     = isset( $args['per_page'] ) ? max( 1, min( 5000, (int) $args['per_page'] ) ) : 20;
		$page    = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
		$offset  = ( $page - 1 ) * $per;

		$w     = implode( ' AND ', $where );
		$count = "SELECT COUNT(*) FROM $t WHERE $w";
		$list  = "SELECT * FROM $t WHERE $w ORDER BY $orderby $order LIMIT $offset, $per";

		$total = (int) ( $vals ? $wpdb->get_var( $wpdb->prepare( $count, $vals ) ) : $wpdb->get_var( $count ) );
		$items = $vals ? $wpdb->get_results( $wpdb->prepare( $list, $vals ) ) : $wpdb->get_results( $list );

		return array(
			'items' => $items,
			'total' => $total,
			'pages' => (int) ceil( $total / $per ),
			'page'  => $page,
		);
	}

	/** Public-facing array for APIs. */
	public static function to_array( $c, $full = true ) {
		if ( ! $c ) {
			return null;
		}
		$credit = BWS_Ledger::summary( $c );
		$arr    = array(
			'id'           => (int) $c->id,
			'code'         => $c->code,
			'first_name'   => $c->first_name,
			'last_name'    => $c->last_name,
			'full_name'    => self::full_name( $c ),
			'shop_name'    => $c->shop_name,
			'mobile'       => $c->mobile,
			'status'       => $c->status,
			'city'         => $c->city,
			'province'     => $c->province,
			'address'      => $c->address,
			'visitor_id'   => (int) $c->visitor_id,
			'visitor_name' => bws_user_name( $c->visitor_id ),
			'created_at'   => bws_jdate( $c->created_at ),
			'last_order'   => bws_jdate( $c->last_order_at ),
			'credit'       => $credit,
			'link'         => bws_customer_panel_url( $c->code ),
			'lat'          => isset( $c->lat ) && null !== $c->lat ? (float) $c->lat : null,
			'lng'          => isset( $c->lng ) && null !== $c->lng ? (float) $c->lng : null,
			'discount'     => isset( $c->discount_percent ) && null !== $c->discount_percent ? (float) $c->discount_percent : null,
			'overdue'      => BWS_Ledger::is_overdue( $c ),
		);
		if ( $full ) {
			$arr['phone']       = $c->phone;
			$arr['postal_code'] = $c->postal_code;
			$arr['national_id'] = $c->national_id;
			$arr['notes']       = $c->notes;
			$arr['last_login']  = bws_jdate( $c->last_login_at );
		}
		return $arr;
	}

	/** Placeholder vars for SMS templates (general vars like {company} are added by BWS_SMS::vars_for). */
	public static function template_vars( $c ) {
		$s = BWS_Ledger::summary( $c );
		return array(
			'name'             => $c->first_name ? $c->first_name : self::full_name( $c ),
			'first_name'       => $c->first_name,
			'last_name'        => $c->last_name,
			'full_name'        => self::full_name( $c ),
			'shop'             => $c->shop_name,
			'code'             => $c->code,
			'mobile'           => $c->mobile,
			'link'             => bws_customer_panel_url( $c->code ),
			'panel_url'        => bws_customer_panel_url(),
			'credit_limit'     => bws_money_text( $s['limit'] ),
			'credit_used'      => bws_money_text( max( 0, $s['debt'] ) ),
			'credit_available' => bws_money_text( $s['available'] ),
			'debt'             => bws_money_text( max( 0, $s['debt'] ) ),
			'city'             => $c->city,
			'visitor_name'     => bws_user_name( $c->visitor_id ),
			'visitor_mobile'   => $c->visitor_id ? (string) get_user_meta( $c->visitor_id, 'bws_mobile', true ) : '',
		);
	}
}
