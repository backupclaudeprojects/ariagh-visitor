<?php
defined( 'ABSPATH' ) || exit;

/**
 * Hardening for the panels and the REST API.
 * - Security headers + no-cache on panel pages (personal data must never be cached by page-cache plugins / CDNs).
 * - No-store on bws/v1 REST responses.
 * - Visitors cannot read the WordPress user list through REST.
 */
class BWS_Security {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'rest_nocache' ), 1 );
		add_action( 'template_redirect', array( __CLASS__, 'panel_headers' ), 1 );
		add_filter( 'rest_post_dispatch', array( __CLASS__, 'rest_headers' ), 10, 3 );
		add_filter( 'rest_endpoints', array( __CLASS__, 'hide_users_endpoint' ) );
	}

	public static function panel_headers() {
		if ( ! BWS_Frontend::is_panel_page() && empty( $_GET['bws_print'] ) ) { // phpcs:ignore
			return;
		}
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // WP Rocket, W3TC, LiteSpeed, WP Super Cache…
		}
		if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
			define( 'DONOTCACHEOBJECT', true );
		}
		nocache_headers();
		if ( ! headers_sent() ) {
			header( 'X-Frame-Options: SAMEORIGIN' );
			header( 'X-Content-Type-Options: nosniff' );
			header( 'Referrer-Policy: same-origin' );
			header( 'Permissions-Policy: geolocation=(self), camera=(), microphone=(), payment=(self)' );
			header( 'Cross-Origin-Opener-Policy: same-origin-allow-popups' );
			header( 'X-Robots-Tag: noindex, nofollow' );
			header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private' );
		}
	}

	/** Is the current request for our REST namespace? (pretty permalinks or ?rest_route=) */
	public static function is_bws_rest() {
		$uri   = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore
		$route = isset( $_GET['rest_route'] ) ? (string) wp_unslash( $_GET['rest_route'] ) : ''; // phpcs:ignore
		return false !== strpos( $uri, '/' . BWS_REST::NS . '/' ) || false !== strpos( rawurldecode( $uri ), '/' . BWS_REST::NS . '/' ) || 0 === strpos( $route, '/' . BWS_REST::NS . '/' );
	}

	/**
	 * Panel data is personal and changes every second: tell every cache layer (page-cache plugins,
	 * LiteSpeed, ArvanCloud / Cloudflare CDNs, browsers) never to store bws/v1 responses.
	 */
	public static function rest_nocache() {
		if ( ! self::is_bws_rest() ) {
			return;
		}
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
			define( 'DONOTCACHEOBJECT', true );
		}
		do_action( 'litespeed_control_set_nocache', 'ARIAGH.VISITOR panel API' );
		if ( ! headers_sent() ) {
			nocache_headers();
			header( 'X-LiteSpeed-Cache-Control: no-cache' );
		}
	}

	public static function rest_headers( $result, $server, $request ) {
		if ( 0 === strpos( $request->get_route(), '/' . BWS_REST::NS . '/' ) && $result instanceof WP_HTTP_Response ) {
			$result->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0, private' );
			$result->header( 'Pragma', 'no-cache' );
			$result->header( 'Expires', 'Wed, 11 Jan 1984 05:00:00 GMT' );
			$result->header( 'CDN-Cache-Control', 'no-store' );
			$result->header( 'Cloudflare-CDN-Cache-Control', 'no-store' );
			$result->header( 'Surrogate-Control', 'no-store' );
			$result->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
			$result->header( 'X-Accel-Expires', '0' );
			$result->header( 'X-Content-Type-Options', 'nosniff' );
		}
		return $result;
	}

	/** Hide /wp/v2/users from guests (stops username enumeration of visitor accounts). */
	public static function hide_users_endpoint( $endpoints ) {
		if ( current_user_can( 'list_users' ) ) {
			return $endpoints;
		}
		foreach ( array( '/wp/v2/users', '/wp/v2/users/(?P<id>[\d]+)' ) as $r ) {
			if ( isset( $endpoints[ $r ] ) && ! is_user_logged_in() ) {
				unset( $endpoints[ $r ] );
			}
		}
		return $endpoints;
	}
}
