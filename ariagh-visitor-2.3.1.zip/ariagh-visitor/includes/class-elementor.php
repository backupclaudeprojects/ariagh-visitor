<?php
defined( 'ABSPATH' ) || exit;

/**
 * Elementor integration: an "ARIAGH.VISITOR" widget category with the customer panel, visitor panel,
 * code-login form and leaderboard. Each widget has style controls (colours, radius, typography,
 * spacing) mapped to the panel's CSS variables, so every panel can be designed in Elementor.
 * Loaded only when Elementor is active – zero cost otherwise.
 */
class BWS_Elementor {

	public static function init() {
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'category' ) );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'widgets' ) );
		add_action( 'elementor/frontend/after_enqueue_scripts', array( __CLASS__, 'editor_boot' ) );
	}

	public static function category( $manager ) {
		$manager->add_category( 'ariagh-visitor', array( 'title' => 'ARIAGH.VISITOR — ویزیتور', 'icon' => 'eicon-person' ) );
	}

	public static function widgets( $manager ) {
		require_once BWS_DIR . 'includes/elementor/class-widget-base.php';
		require_once BWS_DIR . 'includes/elementor/class-widgets.php';
		$manager->register( new BWS_El_Customer_Panel() );
		$manager->register( new BWS_El_Visitor_Panel() );
		$manager->register( new BWS_El_Code_Login() );
		$manager->register( new BWS_El_Leaderboard() );
	}

	/** In the Elementor editor, widgets are re-rendered without a page load – boot the panel again. */
	public static function editor_boot() {
		if ( ! class_exists( '\Elementor\Plugin' ) || ! \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
			return;
		}
		wp_add_inline_script( 'elementor-frontend', "jQuery(window).on('elementor/frontend/init',function(){['bws-customer-panel','bws-visitor-panel'].forEach(function(n){elementorFrontend.hooks.addAction('frontend/element_ready/'+n+'.default',function(){var b=window.BWSBoot||{};var k=n==='bws-customer-panel'?'customer':'visitor';if(b[k])b[k]();});});});" );
	}
}
