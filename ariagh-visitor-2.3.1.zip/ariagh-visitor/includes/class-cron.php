<?php
defined( 'ABSPATH' ) || exit;

class BWS_Cron {

	public static function init() {
		add_action( 'bws_daily', array( __CLASS__, 'daily' ) );
		if ( ! wp_next_scheduled( 'bws_daily' ) ) {
			wp_schedule_event( time() + 600, 'daily', 'bws_daily' );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'bws_daily' );
		wp_clear_scheduled_hook( 'bws_snapppay_reconcile' );
		wp_clear_scheduled_hook( 'bws_returns_retry' );
		wp_clear_scheduled_hook( 'bws_bot_poll' );
	}

	public static function daily() {
		self::cancel_stale_orders();
		self::reminders();
		BWS_SMS::prune( 365 );
		BWS_Log::prune( 365 );
		// Expired OTP / rate-limit transients are removed by WordPress itself.
	}

	/** Pending online-excess orders keep credit reserved; cancel them after N hours so credit returns. */
	public static function cancel_stale_orders() {
		global $wpdb;
		$hours = (int) bws_opt( 'pending_cancel_hours', 48 );
		if ( $hours <= 0 || ! function_exists( 'wc_get_order' ) ) {
			return;
		}
		$before = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $hours * HOUR_IN_SECONDS );
		$ids    = $wpdb->get_col( $wpdb->prepare( 'SELECT order_id FROM ' . BWS_Orders::table() . " WHERE status = 'pending' AND created_at < %s", $before ) );
		foreach ( $ids as $id ) {
			$o = wc_get_order( $id );
			if ( $o && 'pending' === $o->get_status() ) {
				$o->update_status( 'cancelled', sprintf( 'لغو خودکار: پرداخت بیش از %d ساعت انجام نشد؛ اعتبار به مشتری برگشت.', $hours ) );
			}
		}
	}

	public static function reminders() {
		global $wpdb;
		if ( ! bws_opt( 'reminder_enabled' ) ) {
			return;
		}
		$days   = max( 1, (int) bws_opt( 'reminder_days', 30 ) );
		$repeat = max( 1, (int) bws_opt( 'reminder_repeat_days', 7 ) );
		$now    = current_time( 'timestamp' );
		$rows   = $wpdb->get_results( 'SELECT * FROM ' . BWS_Customers::table() . " WHERE status = 'active' AND balance > 0" );
		foreach ( $rows as $c ) {
			$oldest = BWS_Ledger::oldest_unpaid_date( $c->id );
			if ( ! $oldest || strtotime( $oldest ) > $now - $days * DAY_IN_SECONDS ) {
				continue;
			}
			if ( $c->last_reminder_at && strtotime( $c->last_reminder_at ) > $now - $repeat * DAY_IN_SECONDS ) {
				continue;
			}
			BWS_SMS::send_event( 'reminder', $c, array(), array( 'force' => true ) );
			BWS_Customers::touch( $c->id, 'last_reminder_at' );
		}
	}
}
