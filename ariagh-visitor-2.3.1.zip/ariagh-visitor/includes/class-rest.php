<?php
defined( 'ABSPATH' ) || exit;

/**
 * REST API (namespace bws/v1). Every staff endpoint re-checks the visitor's permissions (BWS_Perms)
 * on the server – the panel only hides what is not allowed.
 */
class BWS_REST {

	const NS = 'bws/v1';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	protected static function r( $route, $methods, $cb, $perm ) {
		register_rest_route( self::NS, $route, array(
			'methods'             => $methods,
			'callback'            => array( __CLASS__, $cb ),
			'permission_callback' => array( __CLASS__, $perm ),
		) );
	}

	public static function routes() {
		// Customer.
		self::r( '/customer/login', 'POST', 'customer_login', 'open' );
		self::r( '/customer/otp/request', 'POST', 'customer_otp_request', 'open' );
		self::r( '/customer/otp/verify', 'POST', 'customer_otp_verify', 'open' );
		self::r( '/customer/me', 'GET', 'customer_me', 'is_customer' );
		self::r( '/customer/cart', 'POST', 'customer_cart', 'is_customer' );
		self::r( '/customer/quote', 'POST', 'customer_quote', 'is_customer' );
		self::r( '/customer/order', 'POST', 'customer_order', 'is_customer' );
		self::r( '/customer/orders', 'GET', 'customer_orders', 'is_customer' );
		self::r( '/customer/orders/(?P<id>\d+)', 'GET', 'customer_order_detail', 'is_customer' );
		self::r( '/customer/orders/(?P<id>\d+)/cancel', 'POST', 'customer_order_cancel', 'is_customer' );
		self::r( '/customer/orders/(?P<id>\d+)/reorder', 'POST', 'customer_reorder', 'is_customer' );
		self::r( '/customer/ledger', 'GET', 'customer_ledger', 'is_customer' );
		self::r( '/customer/settle', 'POST', 'customer_settle', 'is_customer' );
		// Shared.
		self::r( '/catalog', 'GET', 'catalog', 'customer_or_staff' );
		self::r( '/snapppay/offer', 'GET', 'snapppay_eligible', 'open' );
		// Staff (visitors + managers).
		self::r( '/staff/me', 'GET', 'staff_me', 'is_staff' );
		self::r( '/staff/customers', 'GET', 'staff_customers', 'is_staff' );
		self::r( '/staff/customers', 'POST', 'staff_customer_create', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)', 'GET', 'staff_customer', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)', 'POST', 'staff_customer_update', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)/quote', 'POST', 'staff_quote', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)/order', 'POST', 'staff_order', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)/payment', 'POST', 'staff_payment', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)/sms', 'POST', 'staff_sms', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)/cart', 'POST', 'staff_cart', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)/code', 'POST', 'staff_regen_code', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)/location', 'POST', 'staff_location', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)/visit', 'POST', 'staff_visit', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)/reorder', 'POST', 'staff_reorder', 'is_staff' );
		self::r( '/staff/customers/(?P<id>\d+)/delete', 'POST', 'staff_delete', 'is_manager' );
		self::r( '/staff/followups', 'GET', 'staff_followups', 'is_staff' );
		self::r( '/staff/visits/(?P<id>\d+)/done', 'POST', 'staff_visit_done', 'is_staff' );
		self::r( '/staff/orders', 'GET', 'staff_orders', 'is_staff' );
		self::r( '/staff/orders/(?P<id>\d+)', 'GET', 'staff_order_detail', 'is_staff' );
		self::r( '/staff/orders/(?P<id>\d+)/cancel', 'POST', 'staff_order_cancel', 'is_staff' );
		self::r( '/staff/sms/bulk', 'POST', 'staff_bulk_sms', 'is_staff' );
		self::r( '/staff/leaderboard', 'GET', 'staff_leaderboard', 'is_staff' );
		self::r( '/staff/export', 'GET', 'staff_export', 'is_staff' );
		// Manager only.
		self::r( '/admin/products/sync', 'POST', 'admin_sync', 'is_manager' );
		self::r( '/admin/products/(?P<id>\d+)', 'POST', 'admin_product', 'is_manager' );
		self::r( '/admin/sms/test', 'POST', 'admin_sms_test', 'is_manager' );
		self::r( '/admin/sms/credit', 'GET', 'admin_sms_credit', 'is_manager' );
		self::r( '/admin/sms/preview', 'POST', 'admin_sms_preview', 'is_manager' );
		self::r( '/admin/snapppay/status', 'POST', 'admin_snapppay_status', 'is_manager' );
	}

	/* ---------------- Permissions ---------------- */

	public static function open() {
		return true;
	}

	public static function is_customer( $req ) {
		return (bool) BWS_Auth::current_customer( $req );
	}

	public static function is_staff() {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		if ( bws_is_manager() ) {
			return true;
		}
		return bws_is_visitor() && bws_visitor_active( get_current_user_id() );
	}

	public static function is_manager() {
		return bws_is_manager();
	}

	public static function customer_or_staff( $req ) {
		return self::is_customer( $req ) || self::is_staff();
	}

	protected static function err( $e, $status = 400 ) {
		$data = $e->get_error_data();
		return new WP_REST_Response( array( 'ok' => false, 'code' => $e->get_error_code(), 'message' => $e->get_error_message(), 'data' => $data ), $status );
	}

	protected static function deny( $msg = 'این امکان برای حساب شما فعال نیست. با مدیر تماس بگیرید.' ) {
		return self::err( new WP_Error( 'bws_forbidden', $msg ), 403 );
	}

	protected static function ok( $data = array() ) {
		return new WP_REST_Response( array_merge( array( 'ok' => true ), $data ), 200 );
	}

	protected static function items_from( $req ) {
		$items = $req->get_param( 'items' );
		if ( is_string( $items ) ) {
			$items = json_decode( $items, true );
		}
		$out = array();
		foreach ( (array) $items as $k => $v ) {
			if ( is_array( $v ) && isset( $v['id'] ) ) {
				$out[ absint( $v['id'] ) ] = absint( isset( $v['qty'] ) ? $v['qty'] : 0 );
			} else {
				$out[ absint( $k ) ] = absint( $v );
			}
		}
		return array_slice( array_filter( $out ), 0, 500, true );
	}

	protected static function p() {
		return BWS_Perms::for_user();
	}

	public static function public_settings() {
		return array(
			'min_qty'         => (int) bws_opt( 'min_qty' ),
			'max_qty'         => (int) bws_opt( 'max_qty' ),
			'min_amount'      => (float) bws_opt( 'min_amount' ),
			'min_amount_text' => (float) bws_opt( 'min_amount' ) > 0 ? bws_money_text( bws_opt( 'min_amount' ) ) : '',
			'discount'        => (float) bws_opt( 'discount_percent' ),
			'show_retail'     => (bool) bws_opt( 'show_retail_price' ),
			'wholesale_label' => bws_opt( 'wholesale_label' ),
			'retail_label'    => bws_opt( 'retail_label' ),
			'excess_online'   => (bool) bws_opt( 'excess_online' ),
			'excess_offline'  => (bool) bws_opt( 'excess_offline' ),
			'settle_online'   => (bool) bws_opt( 'allow_online_settlement' ),
			'settle_before'   => (bool) bws_opt( 'settle_before_order' ),
			'allow_note'      => (bool) bws_opt( 'allow_customer_note' ),
			'allow_reorder'   => (bool) bws_opt( 'allow_reorder' ),
			'company'         => bws_opt( 'company_name' ),
			'company_phone'   => bws_opt( 'company_phone' ),
			'currency'        => trim( str_replace( '0', '', bws_money_text( 0 ) ) ),
			'code_type'       => bws_opt( 'code_type' ),
			'snapppay'        => class_exists( 'BWS_Gateway_SnappPay' ) && BWS_Gateway_SnappPay::is_ready(),
			'customer_cancel' => bws_opt( 'customer_cancel', 'processing' ),
			'returns'         => class_exists( 'BWS_Returns' ) && BWS_Returns::enabled(),
		);
	}

	/* ---------------- Customer endpoints ---------------- */

	public static function customer_login( $req ) {
		$r = BWS_Auth::customer_login( (string) $req->get_param( 'code' ) );
		if ( is_wp_error( $r ) ) {
			return self::err( $r, 403 );
		}
		if ( ! empty( $r['otp_required'] ) ) {
			return self::ok( $r );
		}
		BWS_Log::add( 'customer_login', 'customer', $r['customer']->id, '', 'customer' );
		return self::ok( array( 'token' => $r['token'], 'customer' => BWS_Customers::to_array( $r['customer'], false ) ) );
	}

	public static function customer_otp_request( $req ) {
		$r = BWS_Auth::otp_request_mobile( (string) $req->get_param( 'mobile' ) );
		return is_wp_error( $r ) ? self::err( $r, 403 ) : self::ok( $r );
	}

	public static function customer_otp_verify( $req ) {
		$r = BWS_Auth::otp_verify( (string) $req->get_param( 'ticket' ), (string) $req->get_param( 'otp' ) );
		if ( is_wp_error( $r ) ) {
			return self::err( $r, 403 );
		}
		return self::ok( array( 'token' => $r['token'], 'customer' => BWS_Customers::to_array( $r['customer'], false ) ) );
	}

	public static function customer_me( $req ) {
		$c = BWS_Auth::current_customer( $req );
		return self::ok( array(
			'customer' => BWS_Customers::to_array( $c, false ),
			'cart'     => (object) BWS_Customers::get_cart( $c ),
			'settings' => self::public_settings(),
			'notice'   => wp_kses_post( (string) bws_opt( 'notice_customer' ) ),
		) );
	}

	public static function catalog( $req ) {
		$disc = null;
		$c    = BWS_Auth::current_customer( $req );
		if ( ! $c && $req->get_param( 'customer' ) && self::is_staff() ) {
			$c = BWS_Customers::get( (int) $req->get_param( 'customer' ) );
			if ( $c && ! BWS_Auth::can_view_customer( $c ) ) {
				$c = null;
			}
		}
		if ( $c && null !== $c->discount_percent ) {
			$disc = (float) $c->discount_percent;
		}
		$cache_key = 'bws_catalog_' . md5( wp_json_encode( bws_settings() ) . get_option( 'bws_last_sync' ) . get_option( 'bws_catalog_ver', 0 ) . '|' . ( null === $disc ? '-' : $disc ) );
		$cat       = get_transient( $cache_key );
		if ( false === $cat ) {
			$cat = BWS_Products::catalogue( $disc );
			set_transient( $cache_key, $cat, 15 * MINUTE_IN_SECONDS );
		}
		return self::ok( array( 'products' => $cat, 'settings' => self::public_settings() ) );
	}

	public static function snapppay_eligible( $req ) {
		if ( ! class_exists( 'BWS_Gateway_SnappPay' ) || ! BWS_Gateway_SnappPay::is_ready() ) {
			return self::ok( array( 'eligible' => false ) );
		}
		$amount = bws_parse_amount( $req->get_param( 'amount' ) );
		if ( $amount <= 0 || $amount > 1e11 || bws_rate_limited( 'spp_elig', 30, 60 ) ) {
			return self::ok( array( 'eligible' => false ) );
		}
		return self::ok( BWS_Gateway_SnappPay::eligibility( $amount ) );
	}

	public static function customer_cart( $req ) {
		$c = BWS_Auth::current_customer( $req );
		return self::ok( array( 'cart' => (object) BWS_Customers::save_cart( $c->id, self::items_from( $req ) ) ) );
	}

	public static function customer_quote( $req ) {
		$c = BWS_Auth::current_customer( $req );
		$q = BWS_Orders::quote( $c, self::items_from( $req ) );
		if ( is_wp_error( $q ) ) {
			return self::err( $q );
		}
		return self::ok( array( 'quote' => BWS_Orders::quote_to_array( $q ) ) );
	}

	public static function customer_order( $req ) {
		if ( bws_rate_limited( 'order', 10, 60 ) ) {
			return self::err( new WP_Error( 'bws_rate', 'درخواست‌ها زیاد است؛ کمی صبر کنید.' ), 429 );
		}
		$c = BWS_Auth::current_customer( $req );
		$r = BWS_Orders::create( $c, self::items_from( $req ), array(
			'excess_method' => sanitize_key( $req->get_param( 'excess_method' ) ),
			'note'          => bws_opt( 'allow_customer_note' ) ? (string) $req->get_param( 'note' ) : '',
			'placed_by'     => 'customer',
		) );
		if ( is_wp_error( $r ) ) {
			return self::err( $r );
		}
		return self::ok( array(
			'order_id' => $r['order_id'],
			'pay_url'  => $r['pay_url'],
			'message'  => $r['pay_url'] ? 'سفارش ثبت شد. برای تکمیل، مبلغ مازاد را پرداخت کنید.' : 'سفارش عمده شما با موفقیت ثبت شد.',
			'customer' => BWS_Customers::to_array( $r['customer'], false ),
		) );
	}

	public static function customer_orders( $req ) {
		$c   = BWS_Auth::current_customer( $req );
		$res = BWS_Orders::query( array( 'customer_id' => $c->id, 'per_page' => 50, 'page' => $req->get_param( 'page' ) ) );
		return self::ok( array( 'orders' => self::with_cancel_flags( $res['items'], 'customer' ), 'total' => $res['total'] ) );
	}

	/** Add can_cancel flags to order arrays for the given actor. */
	protected static function with_cancel_flags( $rows, $actor ) {
		$out = array();
		foreach ( $rows as $o ) {
			$a               = BWS_Orders::row_to_array( $o );
			$a['can_cancel'] = false;
			if ( 'order' === $o->kind && in_array( $o->status, BWS_Orders::cancellable_statuses( $actor ), true ) ) {
				$c               = 'staff' === $actor ? BWS_Customers::get( $o->customer_id ) : null;
				$a['can_cancel'] = true === BWS_Orders::can_cancel( wc_get_order( $o->order_id ), $actor, $c );
			}
			$out[] = $a;
		}
		return $out;
	}

	protected static function order_row( $order_id ) {
		global $wpdb;
		$t  = BWS_Orders::table();
		$ct = BWS_Customers::table();
		return $wpdb->get_row( $wpdb->prepare( "SELECT o.*, c.first_name, c.last_name, c.code, c.shop_name, c.mobile FROM $t o LEFT JOIN $ct c ON c.id = o.customer_id WHERE o.order_id = %d", $order_id ) );
	}

	public static function customer_order_detail( $req ) {
		$c   = BWS_Auth::current_customer( $req );
		$row = self::order_row( (int) $req['id'] );
		if ( ! $row || (int) $row->customer_id !== (int) $c->id ) {
			return self::err( new WP_Error( 'bws_404', 'سفارش یافت نشد.' ), 404 );
		}
		return self::ok( array( 'order' => BWS_Orders::row_to_array( $row, true ) ) );
	}

	public static function customer_order_cancel( $req ) {
		$c   = BWS_Auth::current_customer( $req );
		$row = self::order_row( (int) $req['id'] );
		if ( ! $row || (int) $row->customer_id !== (int) $c->id ) {
			return self::err( new WP_Error( 'bws_404', 'سفارش یافت نشد.' ), 404 );
		}
		$order = wc_get_order( $row->order_id );
		$can   = BWS_Orders::can_cancel( $order, 'customer' );
		if ( is_wp_error( $can ) ) {
			return self::err( $can );
		}
		BWS_Orders::cancel( $order, 'خود مشتری', (string) $req->get_param( 'reason' ) );
		return self::ok( array( 'message' => 'سفارش لغو شد و اعتبار به حساب شما برگشت.', 'customer' => BWS_Customers::to_array( BWS_Customers::get( $c->id ), false ) ) );
	}

	/** Put the items of a previous order back into the cart. */
	public static function customer_reorder( $req ) {
		if ( ! bws_opt( 'allow_reorder' ) ) {
			return self::deny( 'تکرار سفارش غیرفعال است.' );
		}
		$c   = BWS_Auth::current_customer( $req );
		$row = self::order_row( (int) $req['id'] );
		if ( ! $row || (int) $row->customer_id !== (int) $c->id ) {
			return self::err( new WP_Error( 'bws_404', 'سفارش یافت نشد.' ), 404 );
		}
		$items = BWS_Orders::reorder_items( $row->order_id );
		if ( ! $items ) {
			return self::err( new WP_Error( 'bws_empty', 'محصولات این سفارش دیگر برای خرید عمده فعال نیستند.' ) );
		}
		return self::ok( array( 'cart' => (object) BWS_Customers::save_cart( $c->id, $items ) ) );
	}

	public static function customer_ledger( $req ) {
		$c   = BWS_Auth::current_customer( $req );
		$res = BWS_Ledger::entries( array( 'customer_id' => $c->id, 'per_page' => 100 ) );
		return self::ok( array( 'entries' => array_map( array( 'BWS_Ledger', 'entry_to_array' ), $res['items'] ) ) );
	}

	public static function customer_settle( $req ) {
		if ( ! bws_opt( 'allow_online_settlement' ) ) {
			return self::err( new WP_Error( 'bws_off', 'تسویه آنلاین غیرفعال است.' ) );
		}
		$c = BWS_Auth::current_customer( $req );
		$r = BWS_Orders::create_settlement( $c, bws_parse_amount( $req->get_param( 'amount' ) ) );
		if ( is_wp_error( $r ) ) {
			return self::err( $r );
		}
		return self::ok( $r );
	}

	/* ---------------- Staff endpoints ---------------- */

	public static function staff_me() {
		$uid   = get_current_user_id();
		$p     = self::p();
		$month = gmdate( 'Y-m-d 00:00:00', current_time( 'timestamp' ) - 30 * DAY_IN_SECONDS );
		$mine  = BWS_Customers::query( array( 'visitor_id' => $uid, 'per_page' => 1 ) );
		$debt  = BWS_Customers::query( array( 'visitor_id' => $uid, 'debt' => 1, 'per_page' => 1 ) );
		$s_all = BWS_Orders::stats( $uid );
		$s_30  = BWS_Orders::stats( $uid, $month );
		global $wpdb;
		$outstanding = (float) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(balance),0) FROM ' . BWS_Customers::table() . ' WHERE visitor_id = %d AND balance > 0', $uid ) );
		$methods     = array();
		foreach ( BWS_Ledger::$methods as $k => $v ) {
			if ( ! in_array( $k, array( 'credit', 'online' ), true ) ) {
				$methods[ $k ] = $v;
			}
		}
		// Monthly target & commission.
		$target     = (float) get_user_meta( $uid, 'bws_target', true );
		$target     = $target > 0 ? $target : (float) bws_opt( 'visitor_default_target' );
		$commission = (float) get_user_meta( $uid, 'bws_commission', true );
		$month_s    = BWS_Stats::visitor_period( $uid, 'month' );
		$sms_events = array();
		foreach ( array( 'login_link', 'welcome', 'reminder' ) as $e ) {
			$ev                 = BWS_Events::get( $e );
			$sms_events[ $e ] = array( 'label' => $ev['label'], 'text' => bws_opt( 'tpl_' . $e ), 'pattern' => 'pattern' === bws_opt( 'tpl_' . $e . '_mode' ) );
		}
		$visitors = array();
		if ( $p['manager'] || 'all' === $p['customers_view'] ) {
			foreach ( BWS_Auth::visitors() as $u ) {
				$visitors[] = array( 'id' => $u->ID, 'name' => $u->display_name ? $u->display_name : $u->user_login, 'mobile' => $p['manager'] ? (string) get_user_meta( $u->ID, 'bws_mobile', true ) : '' );
			}
		}
		return self::ok( array(
			'user'      => array( 'id' => $uid, 'name' => bws_user_name( $uid ) ),
			'perms'     => $p,
			'settings'  => self::public_settings(),
			'methods'   => $methods,
			'provinces' => bws_provinces(),
			'results'   => BWS_Visits::$results,
			'templates' => $sms_events,
			'notice'    => wp_kses_post( (string) bws_opt( 'notice_visitor' ) ),
			'stats'     => array(
				'customers'    => $mine['total'],
				'debtors'      => $debt['total'],
				'outstanding'  => bws_money_text( $outstanding ),
				'orders_total' => (int) $s_all->cnt,
				'sales_total'  => bws_money_text( $s_all->total ),
				'orders_30'    => (int) $s_30->cnt,
				'sales_30'     => bws_money_text( $s_30->total ),
				'qty_30'       => (int) $s_30->qty,
				'visits_today' => BWS_Visits::count_today( $uid ),
				'returns_pending' => class_exists( 'BWS_Returns' ) && ( $p['manager'] || ( ! empty( $p['returns_view'] ) && 'none' !== $p['returns_view'] ) ) ? BWS_Returns::count_pending( $p['manager'] || 'all' === $p['returns_view'] ? 0 : $uid ) : 0,
			),
			'target'    => array(
				'amount'          => $target,
				'amount_text'     => $target > 0 ? bws_money_text( $target ) : '',
				'sales'           => $month_s['sales'],
				'sales_text'      => bws_money_text( $month_s['sales'] ),
				'percent'         => $target > 0 ? min( 100, round( $month_s['sales'] / $target * 100 ) ) : 0,
				'commission'      => $commission,
				'commission_text' => $commission > 0 ? bws_money_text( $month_s['sales'] * $commission / 100 ) : '',
			),
			'followups' => $p['visits'] ? BWS_Visits::due( $p['manager'] ? 0 : $uid, 20 ) : array(),
			'logout'    => wp_logout_url( bws_visitor_panel_url() ),
			'visitors'  => $visitors,
		) );
	}

	public static function staff_customers( $req ) {
		$p    = self::p();
		$args = array(
			'search'   => (string) $req->get_param( 'search' ),
			'page'     => (int) $req->get_param( 'page' ),
			'per_page' => 20,
			'status'   => sanitize_key( (string) $req->get_param( 'status' ) ),
			'debt'     => (int) $req->get_param( 'debt' ),
			'orderby'  => sanitize_key( (string) $req->get_param( 'orderby' ) ),
			'province' => sanitize_text_field( (string) $req->get_param( 'province' ) ),
		);
		if ( (int) $req->get_param( 'mine' ) || 'all' !== $p['customers_view'] ) {
			$args['visitor_id'] = get_current_user_id();
		} elseif ( $req->get_param( 'visitor' ) ) {
			$args['visitor_id'] = (int) $req->get_param( 'visitor' );
		}
		$res = BWS_Customers::query( $args );
		$uid = get_current_user_id();
		$out = array();
		foreach ( $res['items'] as $c ) {
			$a             = BWS_Customers::to_array( $c, false );
			$a['is_mine']  = (int) $c->visitor_id === $uid;
			$a['can_edit'] = BWS_Auth::can_edit_customer( $c );
			$out[]         = $a;
		}
		return self::ok( array( 'customers' => $out, 'total' => $res['total'], 'pages' => $res['pages'], 'page' => $res['page'] ) );
	}

	protected static function load_customer( $req, $edit = false ) {
		$c = BWS_Customers::get( (int) $req['id'] );
		if ( ! $c ) {
			return new WP_Error( 'bws_404', 'مشتری یافت نشد.' );
		}
		if ( ! BWS_Auth::can_view_customer( $c ) || ( $edit && ! BWS_Auth::can_edit_customer( $c ) ) ) {
			return new WP_Error( 'bws_forbidden', 'اجازه دسترسی به این مشتری را ندارید.' );
		}
		return $c;
	}

	public static function staff_customer_create( $req ) {
		$p = self::p();
		if ( empty( $p['customers_create'] ) ) {
			return self::deny( 'اجازه ثبت مشتری جدید ندارید.' );
		}
		$data = $req->get_params();
		$vid  = get_current_user_id();
		if ( $p['manager'] && isset( $data['visitor_id'] ) ) {
			$vid = (int) $data['visitor_id'];
		}
		$data['send_sms'] = ! isset( $data['send_sms'] ) || filter_var( $data['send_sms'], FILTER_VALIDATE_BOOLEAN );
		$c                = BWS_Customers::create( $data, $vid );
		if ( is_wp_error( $c ) ) {
			return self::err( $c );
		}
		if ( ! empty( $p['location'] ) && ! empty( $data['lat'] ) && ! empty( $data['lng'] ) ) {
			BWS_Customers::set_location( $c->id, $data['lat'], $data['lng'] );
			$c = BWS_Customers::get( $c->id );
		}
		if ( $p['manager'] && isset( $data['discount'] ) && '' !== $data['discount'] ) {
			BWS_Customers::set_discount( $c->id, $data['discount'] );
			$c = BWS_Customers::get( $c->id );
		}
		return self::ok( array( 'customer' => BWS_Customers::to_array( $c ), 'print' => ! empty( $p['print'] ) ? BWS_Print::urls( $c ) : null ) );
	}

	public static function staff_customer( $req ) {
		$c = self::load_customer( $req );
		if ( is_wp_error( $c ) ) {
			return self::err( $c, 403 );
		}
		$p      = self::p();
		$a      = BWS_Customers::to_array( $c );
		$ledger = array();
		$can_l  = BWS_Perms::scope_allows( 'ledger_view', $c );
		if ( $can_l ) {
			$res    = BWS_Ledger::entries( array( 'customer_id' => $c->id, 'per_page' => 100 ) );
			$ledger = array_map( array( 'BWS_Ledger', 'entry_to_array' ), $res['items'] );
		}
		$orders = BWS_Orders::query( array( 'customer_id' => $c->id, 'per_page' => 50 ) );
		$sms    = BWS_SMS::log_query( array( 'customer_id' => $c->id, 'per_page' => 20 ) );
		$sms_o  = array();
		foreach ( $sms['items'] as $s ) {
			$sms_o[] = array( 'text' => $s->message, 'status' => $s->status, 'date' => bws_jdate( $s->created_at ), 'context' => BWS_SMS::context_label( $s->context ) );
		}
		$a['can_edit'] = BWS_Auth::can_edit_customer( $c );
		$a['is_mine']  = (int) $c->visitor_id === get_current_user_id();
		$a['cart']     = (object) BWS_Customers::get_cart( $c );
		$a['can']      = array(
			'ledger'   => $can_l,
			'payment'  => BWS_Perms::scope_allows( 'payments_record', $c ),
			'order'    => BWS_Perms::scope_allows( 'orders_place', $c ),
			'status'   => $a['can_edit'] && ! empty( $p['customers_status'] ),
			'credit'   => $a['can_edit'] && ! empty( $p['credit_set'] ),
			'code'     => $p['manager'] || ( $a['can_edit'] && ! empty( $p['code_regenerate'] ) ),
			'location' => $a['can_edit'] && ! empty( $p['location'] ),
			'visits'   => ! empty( $p['visits'] ),
			'print'    => ! empty( $p['print'] ),
			'sms'      => ! empty( $p['sms_single'] ),
			'sms_text' => ! empty( $p['sms_single'] ) && ! empty( $p['sms_custom'] ),
			'returns'  => class_exists( 'BWS_Returns' ) && BWS_Perms::scope_allows( 'returns_view', $c ),
			'return_new' => class_exists( 'BWS_Returns' ) && BWS_Returns::enabled() && BWS_Perms::scope_allows( 'returns_create', $c ),
		);
		return self::ok( array(
			'customer' => $a,
			'ledger'   => $ledger,
			'orders'   => self::with_cancel_flags( $orders['items'], 'staff' ),
			'sms'      => $sms_o,
			'visits'   => ! empty( $p['visits'] ) ? BWS_Visits::for_customer( $c->id, 20 ) : array(),
			'print'    => ! empty( $p['print'] ) ? BWS_Print::urls( $c ) : null,
		) );
	}

	public static function staff_customer_update( $req ) {
		$c = self::load_customer( $req, true );
		if ( is_wp_error( $c ) ) {
			return self::err( $c, 403 );
		}
		$p    = self::p();
		$data = $req->get_params();
		unset( $data['id'] );
		$r = BWS_Customers::update( $c->id, $data );
		if ( is_wp_error( $r ) ) {
			return self::err( $r );
		}
		if ( isset( $data['credit_limit'] ) && '' !== $data['credit_limit'] && ( $p['manager'] || ! empty( $p['credit_set'] ) ) ) {
			$new = BWS_Customers::allowed_limit( bws_parse_amount( $data['credit_limit'] ) );
			if ( (float) $new !== (float) $c->credit_limit ) {
				BWS_Customers::set_credit_limit( $c->id, $new );
			}
		}
		if ( isset( $data['status'] ) && $data['status'] !== $c->status && ( $p['manager'] || ! empty( $p['customers_status'] ) ) ) {
			BWS_Customers::set_status( $c->id, $data['status'] );
		}
		if ( $p['manager'] ) {
			if ( isset( $data['visitor_id'] ) && (int) $data['visitor_id'] !== (int) $c->visitor_id ) {
				BWS_Customers::transfer( $c->id, (int) $data['visitor_id'] );
			}
			if ( array_key_exists( 'discount', $data ) ) {
				$cur = null === $c->discount_percent ? '' : (string) (float) $c->discount_percent;
				if ( trim( bws_en_digits( (string) $data['discount'] ) ) !== $cur ) {
					BWS_Customers::set_discount( $c->id, $data['discount'] );
				}
			}
		}
		return self::ok( array( 'customer' => BWS_Customers::to_array( BWS_Customers::get( $c->id ) ) ) );
	}

	public static function staff_location( $req ) {
		$c = self::load_customer( $req );
		if ( is_wp_error( $c ) ) {
			return self::err( $c, 403 );
		}
		if ( empty( self::p()['location'] ) || ! BWS_Auth::can_edit_customer( $c ) ) {
			return self::deny();
		}
		$r = BWS_Customers::set_location( $c->id, $req->get_param( 'lat' ), $req->get_param( 'lng' ) );
		if ( is_wp_error( $r ) ) {
			return self::err( $r );
		}
		return self::ok( array( 'customer' => BWS_Customers::to_array( BWS_Customers::get( $c->id ) ) ) );
	}

	public static function staff_visit( $req ) {
		$c = self::load_customer( $req );
		if ( is_wp_error( $c ) ) {
			return self::err( $c, 403 );
		}
		$p = self::p();
		if ( empty( $p['visits'] ) ) {
			return self::deny();
		}
		$data = $req->get_params();
		if ( empty( $p['location'] ) ) {
			unset( $data['lat'], $data['lng'] );
		}
		BWS_Visits::add( $c->id, $data );
		return self::ok( array( 'visits' => BWS_Visits::for_customer( $c->id, 20 ), 'message' => 'ویزیت ثبت شد.' ) );
	}

	public static function staff_followups() {
		$p = self::p();
		if ( empty( $p['visits'] ) ) {
			return self::deny();
		}
		return self::ok( array( 'followups' => BWS_Visits::due( $p['manager'] ? 0 : get_current_user_id(), 100 ) ) );
	}

	public static function staff_visit_done( $req ) {
		$r = BWS_Visits::done( (int) $req['id'] );
		return is_wp_error( $r ) ? self::err( $r, 403 ) : self::ok();
	}

	public static function staff_quote( $req ) {
		$c = self::load_customer( $req );
		if ( is_wp_error( $c ) ) {
			return self::err( $c, 403 );
		}
		if ( ! BWS_Perms::scope_allows( 'orders_place', $c ) ) {
			return self::deny( 'اجازه ثبت سفارش برای این مشتری را ندارید.' );
		}
		$q = BWS_Orders::quote( $c, self::items_from( $req ) );
		if ( is_wp_error( $q ) ) {
			return self::err( $q );
		}
		return self::ok( array( 'quote' => BWS_Orders::quote_to_array( $q ) ) );
	}

	public static function staff_cart( $req ) {
		$c = self::load_customer( $req );
		if ( is_wp_error( $c ) ) {
			return self::err( $c, 403 );
		}
		if ( ! BWS_Perms::scope_allows( 'orders_place', $c ) ) {
			return self::deny( 'اجازه ثبت سفارش برای این مشتری را ندارید.' );
		}
		return self::ok( array( 'cart' => (object) BWS_Customers::save_cart( $c->id, self::items_from( $req ) ) ) );
	}

	public static function staff_reorder( $req ) {
		$c = self::load_customer( $req );
		if ( is_wp_error( $c ) ) {
			return self::err( $c, 403 );
		}
		if ( ! BWS_Perms::scope_allows( 'orders_place', $c ) ) {
			return self::deny( 'اجازه ثبت سفارش برای این مشتری را ندارید.' );
		}
		$row = self::order_row( (int) $req->get_param( 'order_id' ) );
		if ( ! $row || (int) $row->customer_id !== (int) $c->id ) {
			return self::err( new WP_Error( 'bws_404', 'سفارش یافت نشد.' ), 404 );
		}
		$items = BWS_Orders::reorder_items( $row->order_id );
		if ( ! $items ) {
			return self::err( new WP_Error( 'bws_empty', 'محصولات این سفارش دیگر برای خرید عمده فعال نیستند.' ) );
		}
		return self::ok( array( 'cart' => (object) BWS_Customers::save_cart( $c->id, $items ) ) );
	}

	public static function staff_order( $req ) {
		$c = self::load_customer( $req );
		if ( is_wp_error( $c ) ) {
			return self::err( $c, 403 );
		}
		if ( ! BWS_Perms::scope_allows( 'orders_place', $c ) ) {
			return self::deny( 'اجازه ثبت سفارش برای این مشتری را ندارید.' );
		}
		$method = sanitize_key( $req->get_param( 'excess_method' ) );
		$r      = BWS_Orders::create( $c, self::items_from( $req ), array(
			'excess_method' => $method,
			'note'          => (string) $req->get_param( 'note' ),
			'placed_by'     => bws_is_manager() ? 'admin' : 'visitor',
		) );
		if ( is_wp_error( $r ) ) {
			return self::err( $r );
		}
		$sent = false;
		if ( $r['pay_url'] ) {
			$order = wc_get_order( $r['order_id'] );
			$res   = BWS_SMS::send_event( 'pay_link', $r['customer'], BWS_Orders::sms_vars( $order, array( 'pay_url' => $r['pay_url'] ) ), array( 'force' => true ) );
			$sent  = ! empty( $res['sent'] );
		}
		return self::ok( array(
			'order_id' => $r['order_id'],
			'pay_url'  => $r['pay_url'],
			'message'  => 'سفارش #' . $r['order_id'] . ' ثبت شد.' . ( $r['pay_url'] ? ( $sent ? ' لینک پرداخت مازاد برای مشتری پیامک شد.' : ' لینک پرداخت مازاد را برای مشتری بفرستید.' ) : '' ),
			'customer' => BWS_Customers::to_array( $r['customer'] ),
		) );
	}

	public static function staff_payment( $req ) {
		$c = self::load_customer( $req );
		if ( is_wp_error( $c ) ) {
			return self::err( $c, 403 );
		}
		$kind   = sanitize_key( (string) $req->get_param( 'kind' ) );
		$amount = bws_parse_amount( $req->get_param( 'amount' ) );
		if ( 'adjust' === $kind ) {
			if ( ! bws_is_manager() ) {
				return self::deny( 'فقط مدیر می‌تواند حساب را اصلاح کند.' );
			}
			BWS_Ledger::adjust( $c->id, $amount, (string) $req->get_param( 'note' ) );
		} else {
			if ( ! BWS_Perms::scope_allows( 'payments_record', $c ) ) {
				return self::deny( 'اجازه ثبت پرداخت برای این مشتری را ندارید.' );
			}
			$notify = $req->get_param( 'notify' );
			$r      = BWS_Ledger::record_payment( $c->id, $amount, sanitize_key( (string) $req->get_param( 'method' ) ), (string) $req->get_param( 'reference' ), (string) $req->get_param( 'note' ), null === $notify ? true : filter_var( $notify, FILTER_VALIDATE_BOOLEAN ) );
			if ( is_wp_error( $r ) ) {
				return self::err( $r );
			}
		}
		return self::ok( array( 'customer' => BWS_Customers::to_array( BWS_Customers::get( $c->id ) ) ) );
	}

	public static function staff_sms( $req ) {
		$c = self::load_customer( $req );
		if ( is_wp_error( $c ) ) {
			return self::err( $c, 403 );
		}
		$p = self::p();
		if ( empty( $p['sms_single'] ) ) {
			return self::deny( 'اجازه ارسال پیامک ندارید.' );
		}
		if ( bws_rate_limited( 'sms1_' . get_current_user_id(), 30, 60 ) ) {
			return self::err( new WP_Error( 'bws_rate', 'تعداد ارسال زیاد است؛ یک دقیقه صبر کنید.' ), 429 );
		}
		$kind = sanitize_key( (string) $req->get_param( 'kind' ) );
		if ( in_array( $kind, array( 'welcome', 'login_link', 'reminder' ), true ) ) {
			$r = BWS_SMS::send_event( $kind, $c, array(), array( 'force' => true ) );
		} else {
			if ( empty( $p['sms_custom'] ) ) {
				return self::deny( 'ارسال پیام دلخواه برای شما فعال نیست؛ از پیام‌های آماده استفاده کنید.' );
			}
			$text = sanitize_textarea_field( (string) $req->get_param( 'text' ) );
			if ( ! $text ) {
				return self::err( new WP_Error( 'bws_text', 'متن پیامک خالی است.' ) );
			}
			$r = BWS_SMS::send_text( $c, $text, 'custom' );
		}
		return self::ok( array( 'result' => $r, 'message' => $r['sent'] ? ( 'live' === BWS_SMS::mode() ? 'پیامک ارسال شد.' : 'پیامک ثبت شد (حالت تست / غیرفعال — ارسال واقعی انجام نشد).' ) : 'ارسال پیامک ناموفق بود؛ گزارش پیامک‌ها را ببینید.' ) );
	}

	public static function staff_regen_code( $req ) {
		$c = self::load_customer( $req );
		if ( is_wp_error( $c ) ) {
			return self::err( $c, 403 );
		}
		$p = self::p();
		if ( ! $p['manager'] && ( empty( $p['code_regenerate'] ) || ! BWS_Auth::can_edit_customer( $c ) ) ) {
			return self::deny( 'اجازه تغییر کد مشتری را ندارید.' );
		}
		BWS_Customers::regenerate_code( $c->id );
		$c = BWS_Customers::get( $c->id );
		if ( filter_var( $req->get_param( 'notify' ), FILTER_VALIDATE_BOOLEAN ) ) {
			BWS_SMS::send_event( 'login_link', $c, array(), array( 'force' => true ) );
		}
		return self::ok( array( 'customer' => BWS_Customers::to_array( $c ) ) );
	}

	public static function staff_delete( $req ) {
		$c = BWS_Customers::get( (int) $req['id'] );
		if ( ! $c ) {
			return self::err( new WP_Error( 'bws_404', 'مشتری یافت نشد.' ), 404 );
		}
		if ( abs( (float) $c->balance ) > 0.01 ) {
			return self::err( new WP_Error( 'bws_balance', 'این مشتری مانده حساب دارد؛ ابتدا حساب را تسویه کنید یا به‌جای حذف، غیرفعالش کنید.' ) );
		}
		BWS_Customers::delete( $c->id );
		return self::ok();
	}

	public static function staff_orders( $req ) {
		$p    = self::p();
		$args = array( 'kind' => 'order', 'page' => (int) $req->get_param( 'page' ), 'per_page' => 20, 'search' => (string) $req->get_param( 'search' ), 'status' => sanitize_key( (string) $req->get_param( 'status' ) ) );
		if ( (int) $req->get_param( 'mine' ) || 'all' !== $p['orders_view'] ) {
			$args['visitor_id'] = get_current_user_id();
		}
		$res = BWS_Orders::query( $args );
		return self::ok( array( 'orders' => self::with_cancel_flags( $res['items'], 'staff' ), 'total' => $res['total'], 'pages' => $res['pages'] ) );
	}

	public static function staff_order_detail( $req ) {
		$row = self::order_row( (int) $req['id'] );
		if ( ! $row ) {
			return self::err( new WP_Error( 'bws_404', 'سفارش یافت نشد.' ), 404 );
		}
		$c = BWS_Customers::get( $row->customer_id );
		$p = self::p();
		$ok = $c && BWS_Auth::can_view_customer( $c ) && ( 'all' === $p['orders_view'] || (int) $row->visitor_id === get_current_user_id() );
		if ( ! $ok ) {
			return self::deny( 'دسترسی ندارید.' );
		}
		$a               = BWS_Orders::row_to_array( $row, true );
		$a['can_cancel'] = 'order' === $row->kind && true === BWS_Orders::can_cancel( wc_get_order( $row->order_id ), 'staff', $c );
		return self::ok( array( 'order' => $a ) );
	}

	public static function staff_order_cancel( $req ) {
		$row = self::order_row( (int) $req['id'] );
		if ( ! $row ) {
			return self::err( new WP_Error( 'bws_404', 'سفارش یافت نشد.' ), 404 );
		}
		$c = BWS_Customers::get( $row->customer_id );
		if ( ! $c || ! BWS_Auth::can_view_customer( $c ) ) {
			return self::deny( 'دسترسی ندارید.' );
		}
		$order = wc_get_order( $row->order_id );
		$can   = BWS_Orders::can_cancel( $order, 'staff', $c );
		if ( is_wp_error( $can ) ) {
			return self::err( $can, 'bws_forbidden' === $can->get_error_code() ? 403 : 400 );
		}
		$paid = BWS_Orders::paid_online( $order );
		BWS_Orders::cancel( $order, bws_user_name( get_current_user_id() ), (string) $req->get_param( 'reason' ) );
		if ( filter_var( $req->get_param( 'notify' ), FILTER_VALIDATE_BOOLEAN ) ) {
			BWS_SMS::send_event( 'order_status', BWS_Customers::get( $c->id ), BWS_Orders::sms_vars( wc_get_order( $row->order_id ) ), array( 'force' => true ) );
		}
		return self::ok( array( 'message' => 'سفارش #' . $row->order_id . ' لغو شد؛ اعتبار و موجودی انبار برگشت.' . ( $paid ? ' مبلغ پرداخت آنلاین را از ووکامرس بازپرداخت کنید.' : '' ), 'customer' => BWS_Customers::to_array( BWS_Customers::get( $c->id ) ) ) );
	}

	public static function staff_leaderboard( $req ) {
		$period = BWS_Stats::period_key( $req->get_param( 'period' ) );
		$p      = self::p();
		$uid    = get_current_user_id();
		$out    = array( 'period' => $period, 'periods' => BWS_Stats::$periods, 'visitors' => array(), 'me' => null, 'customers' => array(), 'my_customers' => array() );
		if ( empty( $p['leaderboard'] ) ) {
			return self::deny( 'دسترسی به رتبه‌بندی برای شما فعال نیست.' );
		}
		$all = BWS_Stats::top_visitors( $period, 500 );
		foreach ( $all as $v ) {
			if ( $v['id'] === $uid ) {
				$out['me'] = $v;
			}
		}
		$out['visitors'] = array_slice( $all, 0, 10 );
		if ( ! $p['manager'] && empty( $p['see_others_stats'] ) ) {
			// Hide other visitors' figures; keep names and ranks only.
			foreach ( $out['visitors'] as &$v ) {
				if ( $v['id'] !== $uid ) {
					$v['sales_text'] = '';
					$v['sales']      = 0;
					$v['orders']     = 0;
					$v['qty']        = 0;
					$v['buyers']     = 0;
				}
			}
			unset( $v );
		}
		$out['customers']    = BWS_Stats::top_customers( $period, 10, 'all' === $p['customers_view'] ? 0 : $uid );
		$out['my_customers'] = $p['manager'] ? array() : BWS_Stats::top_customers( $period, 5, $uid );
		return self::ok( $out );
	}

	public static function staff_bulk_sms( $req ) {
		$p     = self::p();
		$scope = $p['sms_bulk'];
		if ( 'none' === $scope || empty( $scope ) ) {
			return self::deny( 'اجازه ارسال پیامک گروهی ندارید.' );
		}
		$filter   = sanitize_text_field( (string) $req->get_param( 'filter' ) );
		$event    = sanitize_key( (string) $req->get_param( 'event' ) );
		$template = sanitize_textarea_field( (string) $req->get_param( 'template' ) );
		$offset   = max( 0, (int) $req->get_param( 'offset' ) );
		// Messages to visitors (manager only).
		if ( 'visitors' === $filter || 0 === strpos( $filter, 'visitor_user:' ) ) {
			if ( ! $p['manager'] ) {
				return self::deny( 'فقط مدیر می‌تواند به ویزیتورها پیامک گروهی بفرستد.' );
			}
			if ( ! $template ) {
				return self::err( new WP_Error( 'bws_text', 'متن پیامک خالی است.' ) );
			}
			$ids = BWS_SMS::visitor_target_ids( $filter );
			if ( 'count' === $req->get_param( 'mode' ) ) {
				return self::ok( array( 'total' => count( $ids ) ) );
			}
			if ( 0 === $offset ) {
				BWS_Log::add( 'sms_bulk_visitors', 'sms', 0, array( 'filter' => $filter, 'count' => count( $ids ) ) );
			}
			return self::ok( BWS_SMS::bulk_visitors_batch( $ids, $template, $offset ) );
		}
		if ( $event && ! in_array( $event, array( 'login_link', 'welcome', 'reminder' ), true ) ) {
			$event = '';
		}
		if ( ! $event ) {
			if ( empty( $p['sms_custom'] ) ) {
				return self::deny( 'ارسال پیام دلخواه برای شما فعال نیست؛ یکی از پیام‌های آماده را انتخاب کنید.' );
			}
			if ( ! $template ) {
				return self::err( new WP_Error( 'bws_text', 'متن پیامک خالی است.' ) );
			}
		}
		$restrict = 'own' === $scope ? get_current_user_id() : 0;
		$ids      = BWS_SMS::bulk_target_ids( $filter ? $filter : 'all', $restrict, $req->get_param( 'ids' ) );
		if ( 'count' === $req->get_param( 'mode' ) ) {
			return self::ok( array( 'total' => count( $ids ) ) );
		}
		if ( 0 === $offset ) {
			BWS_Log::add( 'sms_bulk', 'sms', 0, array( 'filter' => $filter, 'event' => $event, 'count' => count( $ids ) ) );
		}
		return self::ok( BWS_SMS::bulk_batch( $ids, $template, $offset, $event ) );
	}

	/** CSV export of customers (own customers for visitors with the export permission, all for managers). */
	public static function staff_export( $req ) {
		$p = self::p();
		if ( ! $p['manager'] && empty( $p['export'] ) ) {
			return self::deny( 'اجازه خروجی گرفتن ندارید.' );
		}
		$args = array( 'per_page' => 5000, 'orderby' => 'id', 'order' => 'asc' );
		if ( ! $p['manager'] ) {
			$args['visitor_id'] = get_current_user_id();
		}
		$res  = BWS_Customers::query( $args );
		$rows = array( array( 'کد', 'نام', 'نام خانوادگی', 'فروشگاه', 'موبایل', 'تلفن', 'استان', 'شهر', 'آدرس', 'ویزیتور', 'سقف اعتبار', 'بدهی', 'وضعیت', 'آخرین سفارش', 'موقعیت' ) );
		foreach ( $res['items'] as $c ) {
			$rows[] = array( $c->code, $c->first_name, $c->last_name, $c->shop_name, $c->mobile, $c->phone, $c->province, $c->city, $c->address, bws_user_name( $c->visitor_id ), (float) $c->credit_limit, (float) $c->balance, 'active' === $c->status ? 'فعال' : 'غیرفعال', bws_jdate( $c->last_order_at, false ), null !== $c->lat ? $c->lat . ',' . $c->lng : '' );
		}
		return self::ok( array( 'csv' => bws_csv( $rows ), 'filename' => 'customers-' . gmdate( 'Ymd' ) . '.csv' ) );
	}

	/* ---------------- Manager endpoints ---------------- */

	public static function admin_sync() {
		$r = BWS_Products::sync();
		if ( is_wp_error( $r ) ) {
			return self::err( $r );
		}
		return self::ok( array( 'result' => $r, 'message' => sprintf( '%s محصول بارگذاری شد (%s جدید، %s حذف‌شده از فروشگاه).', bws_fa_digits( $r['total'] ), bws_fa_digits( $r['added'] ), bws_fa_digits( $r['missing'] ) ) ) );
	}

	public static function admin_product( $req ) {
		BWS_Products::update_row( (int) $req['id'], $req->get_params() );
		update_option( 'bws_catalog_ver', time(), false );
		$p   = wc_get_product( (int) $req['id'] );
		$row = BWS_Products::row( (int) $req['id'] );
		return self::ok( array( 'wholesale_text' => $p ? bws_money_text( BWS_Products::wholesale_price( $p, $row ) ) : '' ) );
	}

	public static function admin_sms_test( $req ) {
		$mobile = bws_normalize_mobile( (string) $req->get_param( 'mobile' ) );
		if ( ! $mobile ) {
			return self::err( new WP_Error( 'bws_mobile', 'شماره موبایل معتبر نیست.' ) );
		}
		$event = sanitize_key( (string) $req->get_param( 'event' ) );
		if ( $event && BWS_Events::get( $event ) ) {
			// Send a real event with sample values (tests text or pattern mode exactly as configured).
			$vars = array_merge( BWS_Events::sample_vars(), BWS_SMS::general_vars() );
			$r    = BWS_SMS::send_many( array( BWS_SMS::build( $event, $vars, $mobile, 0 ) ), 'test' );
		} else {
			$text = sanitize_textarea_field( (string) $req->get_param( 'text' ) );
			$r    = BWS_SMS::send_many( array( array( 'mobile' => $mobile, 'text' => $text ? $text : 'پیامک تست از ' . bws_opt( 'company_name' ), 'customer_id' => 0 ) ), 'test' );
		}
		return self::ok( array( 'result' => $r, 'mode' => BWS_SMS::mode(), 'response' => $r['response'] ) );
	}

	public static function admin_sms_credit() {
		$r = BWS_SMS::driver()->credit( BWS_SMS::driver_cfg() );
		if ( is_wp_error( $r ) ) {
			return self::err( $r );
		}
		return self::ok( array( 'credit' => is_scalar( $r ) ? (string) $r : wp_json_encode( $r, JSON_UNESCAPED_UNICODE ) ) );
	}

	/** Live preview of a template: rendered text, length/parts, unknown variables, link warning. */
	public static function admin_sms_preview( $req ) {
		$event = sanitize_key( (string) $req->get_param( 'event' ) );
		$text  = (string) $req->get_param( 'text' );
		$vars  = array_merge( BWS_Events::sample_vars(), BWS_SMS::general_vars() );
		$out   = bws_render_template( $text, $vars );
		$parts = bws_sms_parts( $out );
		$warn  = array();
		$unk   = $event ? BWS_Events::unknown_vars( $event, $text ) : array();
		if ( $unk ) {
			$warn[] = 'این متغیرها در این پیامک مقدار ندارند و همان‌طور خام ارسال می‌شوند: {' . implode( '}، {', $unk ) . '}';
		}
		if ( preg_match( '#https?://|\{(link|panel_url|pay_url|site_url|visitor_panel_url)\}#', $text ) ) {
			$warn[] = 'این پیامک لینک دارد. خطوط عمومی/تبلیغاتی معمولاً پیامک لینک‌دار را ارسال نمی‌کنند؛ از خط خدماتی یا «ارسال با الگو» استفاده کنید.';
		}
		$params = array();
		foreach ( BWS_Events::parse_params( (string) $req->get_param( 'params' ) ) as $k => $v ) {
			$params[ $k ] = bws_render_template( $v, $vars );
			foreach ( $event ? BWS_Events::unknown_vars( $event, $v ) : array() as $u ) {
				$warn[] = 'پارامتر «' . $k . '»: متغیر {' . $u . '} در این پیامک وجود ندارد.';
			}
		}
		return self::ok( array( 'text' => $out, 'chars' => $parts['chars'], 'parts' => $parts['parts'], 'unicode' => $parts['unicode'], 'warnings' => array_values( array_unique( $warn ) ), 'params' => $params ) );
	}

	public static function admin_snapppay_status( $req ) {
		if ( ! class_exists( 'BWS_Gateway_SnappPay' ) ) {
			return self::err( new WP_Error( 'bws_wc', 'ووکامرس فعال نیست.' ) );
		}
		$order = wc_get_order( (int) $req->get_param( 'order_id' ) );
		if ( ! $order ) {
			return self::err( new WP_Error( 'bws_404', 'سفارش یافت نشد.' ), 404 );
		}
		$r = BWS_Gateway_SnappPay::inquiry( $order );
		return is_wp_error( $r ) ? self::err( $r ) : self::ok( $r );
	}
}
