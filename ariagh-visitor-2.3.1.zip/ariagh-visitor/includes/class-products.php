<?php
defined( 'ABSPATH' ) || exit;

class BWS_Products {

	public static function table() {
		return BWS_Install::table( 'products' );
	}

	/**
	 * Import / refresh all WooCommerce products (simple + variations) into the wholesale catalogue.
	 * Existing per-product settings are kept. Products deleted from WooCommerce are flagged as missing.
	 */
	public static function sync() {
		global $wpdb;
		if ( ! function_exists( 'wc_get_products' ) ) {
			return new WP_Error( 'bws_wc', 'ووکامرس فعال نیست.' );
		}
		$t        = self::table();
		$now      = bws_now();
		$existing = $wpdb->get_col( "SELECT product_id FROM $t" );
		$existing = array_flip( array_map( 'intval', $existing ) );
		$seen     = array();
		$added    = 0;
		$page     = 1;
		$sort     = 0;

		do {
			$products = wc_get_products( array(
				'status'  => array( 'publish' ),
				'limit'   => 100,
				'page'    => $page,
				'orderby' => 'menu_order',
				'order'   => 'ASC',
				'type'    => array( 'simple', 'variable' ),
			) );
			foreach ( $products as $p ) {
				$ids = array();
				if ( $p->is_type( 'variable' ) ) {
					foreach ( $p->get_children() as $vid ) {
						$ids[ $vid ] = $p->get_id();
					}
				} else {
					$ids[ $p->get_id() ] = 0;
				}
				foreach ( $ids as $pid => $parent ) {
					$sort++;
					$seen[ $pid ] = true;
					if ( isset( $existing[ $pid ] ) ) {
						$wpdb->update( $t, array( 'missing' => 0, 'parent_id' => $parent, 'synced_at' => $now ), array( 'product_id' => $pid ) );
					} else {
						$wpdb->insert( $t, array(
							'product_id' => $pid,
							'parent_id'  => $parent,
							'enabled'    => 1,
							'sort_order' => $sort,
							'missing'    => 0,
							'synced_at'  => $now,
						) );
						$added++;
					}
				}
			}
			$page++;
		} while ( count( $products ) === 100 );

		$missing = 0;
		foreach ( $existing as $pid => $_ ) {
			if ( ! isset( $seen[ $pid ] ) ) {
				$wpdb->update( $t, array( 'missing' => 1 ), array( 'product_id' => $pid ) );
				$missing++;
			}
		}
		update_option( 'bws_last_sync', $now, false );
		BWS_Log::add( 'products_sync', 'product', 0, array( 'total' => count( $seen ), 'added' => $added, 'missing' => $missing ) );
		return array( 'total' => count( $seen ), 'added' => $added, 'missing' => $missing );
	}

	public static function rows( $only_enabled = false ) {
		global $wpdb;
		$t   = self::table();
		$sql = "SELECT * FROM $t WHERE missing = 0" . ( $only_enabled ? ' AND enabled = 1' : '' ) . ' ORDER BY sort_order ASC, product_id ASC';
		return $wpdb->get_results( $sql, OBJECT_K );
	}

	public static function row( $pid ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE product_id = %d', $pid ) );
	}

	public static function update_row( $pid, $data ) {
		global $wpdb;
		$clean = array();
		if ( isset( $data['enabled'] ) ) {
			$clean['enabled'] = $data['enabled'] ? 1 : 0;
		}
		if ( array_key_exists( 'discount_percent', $data ) ) {
			$v                         = trim( bws_en_digits( $data['discount_percent'] ) );
			$clean['discount_percent'] = '' === $v ? null : max( 0, min( 100, (float) $v ) );
		}
		if ( array_key_exists( 'fixed_price', $data ) ) {
			$v                    = trim( bws_en_digits( $data['fixed_price'] ) );
			$clean['fixed_price'] = '' === $v ? null : max( 0, bws_parse_amount( $v ) );
		}
		if ( isset( $data['sort_order'] ) ) {
			$clean['sort_order'] = (int) bws_en_digits( $data['sort_order'] );
		}
		if ( $clean ) {
			$wpdb->update( self::table(), $clean, array( 'product_id' => $pid ) );
		}
	}

	/** Base (single / retail) price. */
	public static function retail_price( $product ) {
		$price = 'regular' === bws_opt( 'price_base' ) ? $product->get_regular_price() : $product->get_price();
		if ( '' === $price || null === $price ) {
			$price = $product->get_price();
		}
		return (float) $price;
	}

	public static function discount_for( $row, $customer_discount = null ) {
		if ( null !== $customer_discount && '' !== $customer_discount ) {
			return (float) $customer_discount; // Per-customer discount wins over product/global discount.
		}
		if ( $row && null !== $row->discount_percent && '' !== $row->discount_percent ) {
			return (float) $row->discount_percent;
		}
		return (float) bws_opt( 'discount_percent', 20 );
	}

	/** Wholesale price for product, considering per-product fixed price, customer discount and product/global discount. */
	public static function wholesale_price( $product, $row = null, $customer_discount = null ) {
		if ( null === $row ) {
			$row = self::row( $product->get_id() );
		}
		if ( $row && null !== $row->fixed_price && '' !== $row->fixed_price && (float) $row->fixed_price > 0 ) {
			return (float) $row->fixed_price;
		}
		$retail = self::retail_price( $product );
		$price  = $retail * ( 1 - self::discount_for( $row, $customer_discount ) / 100 );
		$round  = (int) bws_opt( 'price_rounding', 0 );
		if ( $round > 1 ) {
			$price = round( $price / $round ) * $round;
		}
		return max( 0, round( $price, wc_get_price_decimals() ) );
	}

	/** Product name including variation attributes. */
	public static function display_name( $p ) {
		$name = $p->get_name();
		if ( $p->is_type( 'variation' ) ) {
			$attrs = wc_get_formatted_variation( $p, true, false, false );
			if ( $attrs && false === mb_strpos( $name, $attrs ) ) {
				$parent = wc_get_product( $p->get_parent_id() );
				$name   = ( $parent ? $parent->get_name() : $name ) . ' — ' . $attrs;
			}
		}
		return wp_strip_all_tags( $name );
	}

	/** Catalogue for panels. $customer_discount = per-customer discount override (or null). */
	public static function catalogue( $customer_discount = null ) {
		$rows = self::rows( true );
		if ( ! $rows || ! function_exists( 'wc_get_product' ) ) {
			return array();
		}
		$out       = array();
		$hide_oos  = (bool) bws_opt( 'hide_out_of_stock' );
		foreach ( $rows as $pid => $row ) {
			$p = wc_get_product( $pid );
			if ( ! $p || 'publish' !== get_post_status( $row->parent_id ? $row->parent_id : $pid ) ) {
				continue;
			}
			$in_stock = $p->is_in_stock();
			if ( $hide_oos && ! $in_stock ) {
				continue;
			}
			$parent    = $row->parent_id ? wc_get_product( $row->parent_id ) : null;
			$name      = self::display_name( $p );
			$image_id  = $p->get_image_id() ? $p->get_image_id() : ( $parent ? $parent->get_image_id() : 0 );
			$desc_src  = $parent ? $parent : $p;
			$desc      = $desc_src->get_short_description() ? $desc_src->get_short_description() : wp_trim_words( $desc_src->get_description(), 30 );
			if ( $p->is_type( 'variation' ) && $p->get_description() ) {
				$desc = $p->get_description();
			}
			$cats      = wp_get_post_terms( $row->parent_id ? $row->parent_id : $pid, 'product_cat', array( 'fields' => 'names' ) );
			$retail    = self::retail_price( $p );
			$wholesale = self::wholesale_price( $p, $row, $customer_discount );
			$stock_qty = $p->managing_stock() ? (int) $p->get_stock_quantity() : null;
			$out[]     = array(
				'id'             => (int) $pid,
				'name'           => wp_strip_all_tags( $name ),
				'sku'            => $p->get_sku(),
				'image'          => $image_id ? wp_get_attachment_image_url( $image_id, 'woocommerce_thumbnail' ) : wc_placeholder_img_src(),
				'image_large'    => $image_id ? wp_get_attachment_image_url( $image_id, 'large' ) : wc_placeholder_img_src(),
				'desc'           => wp_kses_post( wpautop( $desc ) ),
				'categories'     => is_wp_error( $cats ) ? array() : array_values( $cats ),
				'retail'         => $retail,
				'retail_text'    => bws_money_text( $retail ),
				'price'          => $wholesale,
				'price_text'     => bws_money_text( $wholesale ),
				'discount'       => $retail > 0 ? round( ( 1 - $wholesale / $retail ) * 100 ) : 0,
				'in_stock'       => $in_stock,
				'stock'          => $stock_qty,
				'backorders'     => $p->backorders_allowed(),
				'url'            => get_permalink( $row->parent_id ? $row->parent_id : $pid ),
			);
		}
		return $out;
	}
}
