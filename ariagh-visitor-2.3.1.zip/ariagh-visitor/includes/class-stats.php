<?php
defined( 'ABSPATH' ) || exit;

/** Leaderboards: top visitors and top customers for a period. */
class BWS_Stats {

	public static $periods = array(
		'month' => 'این ماه',
		'30'    => '۳۰ روز اخیر',
		'90'    => '۳ ماه اخیر',
		'year'  => 'امسال',
		'all'   => 'از ابتدا',
	);

	/** Start datetime (site local) for a period key, or '' for all time. */
	public static function from( $period ) {
		$now = current_time( 'timestamp' );
		list( $jy, $jm ) = bws_g2j( (int) gmdate( 'Y', $now ), (int) gmdate( 'n', $now ), (int) gmdate( 'j', $now ) );
		switch ( (string) $period ) {
			case 'month':
				list( $gy, $gm, $gd ) = bws_j2g( $jy, $jm, 1 );
				return sprintf( '%04d-%02d-%02d 00:00:00', $gy, $gm, $gd );
			case 'year':
				list( $gy, $gm, $gd ) = bws_j2g( $jy, 1, 1 );
				return sprintf( '%04d-%02d-%02d 00:00:00', $gy, $gm, $gd );
			case '30':
			case '90':
				return gmdate( 'Y-m-d 00:00:00', $now - (int) $period * DAY_IN_SECONDS );
			default:
				return '';
		}
	}

	public static function period_key( $p ) {
		return isset( self::$periods[ (string) $p ] ) ? (string) $p : 'month';
	}

	protected static function where( $from ) {
		global $wpdb;
		$w = "o.kind = 'order' AND o.status NOT IN ('cancelled','refunded','failed','pending')";
		if ( $from ) {
			$w .= $wpdb->prepare( ' AND o.created_at >= %s', $from );
		}
		return $w;
	}

	/** Leaderboards are cached until the next order / status change (cheap on busy sites). */
	public static function cached( $key, $cb ) {
		$k   = 'bws_st_' . md5( $key . '|' . get_option( 'bws_stats_ver', 0 ) );
		$val = get_transient( $k );
		if ( false === $val ) {
			$val = call_user_func( $cb );
			set_transient( $k, $val, HOUR_IN_SECONDS );
		}
		return $val;
	}

	public static function bump() {
		update_option( 'bws_stats_ver', time(), true );
	}

	/** Sales of one visitor in a period (for targets and commission). */
	public static function visitor_period( $visitor_id, $period = 'month' ) {
		return self::cached( 'vp|' . $visitor_id . '|' . $period, function () use ( $visitor_id, $period ) {
			global $wpdb;
			$t   = BWS_Orders::table();
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) orders, COALESCE(SUM(o.total),0) sales, COALESCE(SUM(o.items_qty),0) qty FROM $t o WHERE " . self::where( self::from( $period ) ) . ' AND o.visitor_id = %d', $visitor_id ) );
			return array( 'orders' => (int) $row->orders, 'sales' => (float) $row->sales, 'qty' => (int) $row->qty );
		} );
	}

	public static function top_visitors( $period = 'month', $limit = 10 ) {
		return self::cached( 'tv|' . $period . '|' . $limit, function () use ( $period, $limit ) {
			return self::top_visitors_raw( $period, $limit );
		} );
	}

	public static function top_customers( $period = 'month', $limit = 10, $visitor_id = 0 ) {
		return self::cached( 'tc|' . $period . '|' . $limit . '|' . $visitor_id, function () use ( $period, $limit, $visitor_id ) {
			return self::top_customers_raw( $period, $limit, $visitor_id );
		} );
	}

	protected static function top_visitors_raw( $period, $limit ) {
		global $wpdb;
		$from = self::from( $period );
		$t    = BWS_Orders::table();
		$ct   = BWS_Customers::table();
		$rows = $wpdb->get_results( "SELECT o.visitor_id, COUNT(*) orders, SUM(o.total) sales, SUM(o.items_qty) qty, COUNT(DISTINCT o.customer_id) buyers FROM $t o WHERE " . self::where( $from ) . ' AND o.visitor_id > 0 GROUP BY o.visitor_id ORDER BY sales DESC LIMIT ' . (int) $limit );
		$out  = array();
		$rank = 0;
		$news = array();
		if ( $rows ) {
			$ids  = implode( ',', array_map( 'intval', wp_list_pluck( $rows, 'visitor_id' ) ) );
			$q    = "SELECT visitor_id, COUNT(*) n FROM $ct WHERE visitor_id IN ($ids)" . ( $from ? $wpdb->prepare( ' AND created_at >= %s', $from ) : '' ) . ' GROUP BY visitor_id';
			$news = wp_list_pluck( $wpdb->get_results( $q ), 'n', 'visitor_id' );
		}
		foreach ( $rows as $r ) {
			$new   = isset( $news[ $r->visitor_id ] ) ? (int) $news[ $r->visitor_id ] : 0;
			$out[] = array(
				'rank'        => ++$rank,
				'id'          => (int) $r->visitor_id,
				'name'        => bws_user_name( $r->visitor_id ),
				'region'      => (string) get_user_meta( $r->visitor_id, 'bws_region', true ),
				'orders'      => (int) $r->orders,
				'sales'       => (float) $r->sales,
				'sales_text'  => bws_money_text( $r->sales ),
				'qty'         => (int) $r->qty,
				'buyers'      => (int) $r->buyers,
				'new_customers' => $new,
			);
		}
		return $out;
	}

	protected static function top_customers_raw( $period, $limit, $visitor_id ) {
		global $wpdb;
		$from  = self::from( $period );
		$t     = BWS_Orders::table();
		$ct    = BWS_Customers::table();
		$where = self::where( $from );
		if ( $visitor_id ) {
			$where .= $wpdb->prepare( ' AND o.visitor_id = %d', $visitor_id );
		}
		$rows = $wpdb->get_results( "SELECT o.customer_id, COUNT(*) orders, SUM(o.total) sales, SUM(o.items_qty) qty, MAX(o.created_at) last_at, c.first_name, c.last_name, c.shop_name, c.code, c.city, c.visitor_id, c.balance FROM $t o INNER JOIN $ct c ON c.id = o.customer_id WHERE $where GROUP BY o.customer_id ORDER BY sales DESC LIMIT " . (int) $limit );
		$out  = array();
		$rank = 0;
		foreach ( $rows as $r ) {
			$out[] = array(
				'rank'       => ++$rank,
				'id'         => (int) $r->customer_id,
				'name'       => trim( $r->first_name . ' ' . $r->last_name ),
				'shop'       => $r->shop_name,
				'code'       => $r->code,
				'city'       => $r->city,
				'visitor'    => bws_user_name( $r->visitor_id ),
				'orders'     => (int) $r->orders,
				'sales'      => (float) $r->sales,
				'sales_text' => bws_money_text( $r->sales ),
				'qty'        => (int) $r->qty,
				'debt_text'  => (float) $r->balance > 0 ? bws_money_text( $r->balance ) : '',
				'last'       => bws_jdate( $r->last_at, false ),
			);
		}
		return $out;
	}
}
