<?php
defined( 'ABSPATH' ) || exit;

class BWS_Orders {

	public static function init() {
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'status_changed' ), 20, 4 );
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'status_sms' ), 30, 4 );
		add_action( 'woocommerce_payment_complete', array( __CLASS__, 'payment_complete' ) );
		add_filter( 'woocommerce_order_email_verification_required', array( __CLASS__, 'skip_email_verification' ), 10, 2 );
		add_action( 'woocommerce_admin_order_data_after_order_details', array( __CLASS__, 'admin_order_box' ) );
		add_filter( 'woocommerce_valid_order_statuses_for_payment', array( __CLASS__, 'payable_statuses' ), 10, 2 );
		// Make panel orders recognisable everywhere the shop owner sees orders.
		add_filter( 'woocommerce_admin_order_buyer_name', array( __CLASS__, 'buyer_name_tag' ), 10, 2 );
		foreach ( array( 'new_order', 'cancelled_order', 'failed_order' ) as $e ) {
			add_filter( 'woocommerce_email_subject_' . $e, array( __CLASS__, 'email_subject_tag' ), 20, 2 );
			add_filter( 'woocommerce_email_heading_' . $e, array( __CLASS__, 'email_subject_tag' ), 20, 2 );
		}
		add_action( 'woocommerce_order_list_table_restrict_manage_orders', array( __CLASS__, 'list_filter_hpos' ), 20, 2 );
		add_filter( 'woocommerce_order_list_table_prepare_items_query_args', array( __CLASS__, 'list_query_hpos' ) );
		add_action( 'restrict_manage_posts', array( __CLASS__, 'list_filter_legacy' ), 20 );
		add_filter( 'request', array( __CLASS__, 'list_query_legacy' ) );
	}

	/* ---------------- Order source label ("* سفارش از پنل مشتری *") ---------------- */

	/** Fill WooCommerce's "Origin" column (order attribution) so panel orders never look like normal site orders. */
	public static function set_origin( $order, $label ) {
		$order->update_meta_data( '_wc_order_attribution_source_type', 'utm' );
		$order->update_meta_data( '_wc_order_attribution_utm_source', $label );
		$order->update_meta_data( '_wc_order_attribution_utm_medium', 'ARIAGH.VISITOR' );
	}

	public static function is_panel_order( $order ) {
		return $order && ( $order->get_meta( '_bws_wholesale' ) || $order->get_meta( '_bws_settlement' ) || $order->get_meta( '_bws_replacement' ) );
	}

	/** Human label of where the order came from. */
	public static function source_label( $order ) {
		if ( ! self::is_panel_order( $order ) ) {
			return '';
		}
		if ( $order->get_meta( '_bws_settlement' ) ) {
			$tpl = bws_opt( 'order_label_settlement', '* تسویه بدهی از پنل مشتری *' );
		} elseif ( $order->get_meta( '_bws_replacement' ) ) {
			$rid = (int) $order->get_meta( '_bws_replacement' );
			$tpl = '* ارسال جایگزین مرجوعی R-' . ( 1000 + $rid ) . ' *';
		} else {
			$by  = $order->get_meta( '_bws_placed_by' );
			$tpl = 'customer' === $by ? bws_opt( 'order_label_customer', '* سفارش از پنل مشتری *' ) : ( 'visitor' === $by ? bws_opt( 'order_label_visitor', '* سفارش از پنل عمده — ویزیتور: {visitor} *' ) : bws_opt( 'order_label_admin', '* سفارش از پنل عمده *' ) );
		}
		return trim( strtr( (string) $tpl, array(
			'{visitor}' => bws_user_name( $order->get_meta( '_bws_placed_by_user' ) ? $order->get_meta( '_bws_placed_by_user' ) : $order->get_meta( '_bws_visitor_id' ) ),
			'{code}'    => (string) $order->get_meta( '_bws_customer_code' ),
		) ) );
	}

	public static function buyer_name_tag( $buyer, $order ) {
		$l = self::source_label( $order );
		return $l ? $buyer . ' — ' . $l : $buyer;
	}

	public static function email_subject_tag( $subject, $order ) {
		$l = $order instanceof WC_Order ? self::source_label( $order ) : '';
		return $l && false === mb_strpos( (string) $subject, $l ) ? $l . ' ' . $subject : $subject;
	}

	protected static function list_filter_html() {
		$v = isset( $_GET['bws_src'] ) ? sanitize_key( wp_unslash( $_GET['bws_src'] ) ) : ''; // phpcs:ignore
		echo '<select name="bws_src"><option value="">همه سفارش‌ها (پنل و سایت)</option>';
		foreach ( array( 'panel' => 'فقط سفارش‌های پنل عمده/مشتری', 'site' => 'فقط سفارش‌های عادی سایت', 'customer' => 'ثبت‌شده توسط خود مشتری (پنل)', 'visitor' => 'ثبت‌شده توسط ویزیتور', 'settlement' => 'تسویه بدهی', 'replacement' => 'ارسال جایگزین مرجوعی' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '" ' . selected( $v, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select>';
	}

	protected static function src_meta_query() {
		$v = isset( $_GET['bws_src'] ) ? sanitize_key( wp_unslash( $_GET['bws_src'] ) ) : ''; // phpcs:ignore
		switch ( $v ) {
			case 'panel':
				return array( 'relation' => 'OR', array( 'key' => '_bws_wholesale', 'compare' => 'EXISTS' ), array( 'key' => '_bws_settlement', 'compare' => 'EXISTS' ), array( 'key' => '_bws_replacement', 'compare' => 'EXISTS' ) );
			case 'site':
				return array( 'relation' => 'AND', array( 'key' => '_bws_wholesale', 'compare' => 'NOT EXISTS' ), array( 'key' => '_bws_settlement', 'compare' => 'NOT EXISTS' ), array( 'key' => '_bws_replacement', 'compare' => 'NOT EXISTS' ) );
			case 'customer':
			case 'visitor':
				return array( array( 'key' => '_bws_placed_by', 'value' => $v ) );
			case 'settlement':
				return array( array( 'key' => '_bws_settlement', 'compare' => 'EXISTS' ) );
			case 'replacement':
				return array( array( 'key' => '_bws_replacement', 'compare' => 'EXISTS' ) );
		}
		return null;
	}

	public static function list_filter_hpos( $order_type = 'shop_order', $which = 'top' ) {
		if ( 'shop_order' === $order_type && 'top' === $which ) {
			self::list_filter_html();
		}
	}

	public static function list_query_hpos( $args ) {
		$mq = self::src_meta_query();
		if ( $mq ) {
			$args['meta_query'] = isset( $args['meta_query'] ) && is_array( $args['meta_query'] ) ? array( 'relation' => 'AND', $args['meta_query'], $mq ) : $mq; // phpcs:ignore
		}
		return $args;
	}

	public static function list_filter_legacy( $post_type ) {
		if ( 'shop_order' === $post_type ) {
			self::list_filter_html();
		}
	}

	public static function list_query_legacy( $vars ) {
		global $typenow;
		if ( is_admin() && 'shop_order' === $typenow ) {
			$mq = self::src_meta_query();
			if ( $mq ) {
				$vars['meta_query'] = $mq; // phpcs:ignore
			}
		}
		return $vars;
	}

	/* ---------------- Cancel ---------------- */

	/** Order statuses that may still be cancelled (nothing shipped yet). */
	public static function cancellable_statuses( $actor ) {
		if ( 'customer' === $actor ) {
			$m = bws_opt( 'customer_cancel', 'processing' );
			return 'none' === $m ? array() : ( 'pending' === $m ? array( 'pending' ) : array( 'pending', 'on-hold', 'processing' ) );
		}
		return array( 'pending', 'on-hold', 'processing' );
	}

	/** Paid online (gateway) part that would need a refund. */
	public static function paid_online( $order ) {
		return 'online' === $order->get_meta( '_bws_excess_method' ) && (float) $order->get_meta( '_bws_excess' ) > 0 && $order->is_paid();
	}

	/**
	 * Can this actor cancel the order? actor: customer | staff. Returns true or WP_Error.
	 */
	public static function can_cancel( $order, $actor, $customer = null ) {
		if ( ! $order || ! $order->get_meta( '_bws_wholesale' ) ) {
			return new WP_Error( 'bws_404', 'سفارش یافت نشد.' );
		}
		if ( ! in_array( $order->get_status(), self::cancellable_statuses( $actor ), true ) ) {
			return new WP_Error( 'bws_state', 'این سفارش در وضعیت «' . self::status_label( $order->get_status() ) . '» است و دیگر قابل لغو نیست.' );
		}
		if ( 'customer' === $actor ) {
			if ( self::paid_online( $order ) ) {
				return new WP_Error( 'bws_paid', 'مبلغ این سفارش آنلاین پرداخت شده است؛ برای لغو و بازگشت وجه با فروشگاه تماس بگیرید.' );
			}
			return true;
		}
		if ( bws_is_manager() ) {
			return true;
		}
		if ( ! $customer || ! BWS_Perms::scope_allows( 'orders_cancel', $customer ) ) {
			return new WP_Error( 'bws_forbidden', 'اجازه لغو این سفارش را ندارید.' );
		}
		if ( self::paid_online( $order ) ) {
			return new WP_Error( 'bws_paid', 'این سفارش آنلاین پرداخت شده؛ لغو و بازگشت وجه فقط توسط مدیر انجام می‌شود.' );
		}
		return true;
	}

	/** Cancel: credit, stock and debt are restored automatically by the status change. */
	public static function cancel( $order, $by, $reason = '' ) {
		$reason = sanitize_textarea_field( (string) $reason );
		$note   = 'لغو سفارش توسط ' . $by . ' از پنل عمده.' . ( $reason ? "\nدلیل: " . $reason : '' ) . ( self::paid_online( $order ) ? "\nتوجه: مبلغ مازاد آنلاین پرداخت شده بود؛ بازگشت وجه را از «بازپرداخت» ووکامرس انجام دهید." : '' );
		$order->update_status( 'cancelled', $note );
		BWS_Log::add( 'order_cancel', 'customer', (int) $order->get_meta( '_bws_customer_id' ), array( 'order' => $order->get_id(), 'reason' => $reason ) );
		return true;
	}

	public static function table() {
		return BWS_Install::table( 'orders' );
	}

	public static $status_labels = array(
		'pending'    => 'در انتظار پرداخت',
		'processing' => 'در حال انجام',
		'on-hold'    => 'در انتظار بررسی',
		'completed'  => 'تکمیل شده',
		'cancelled'  => 'لغو شده',
		'refunded'   => 'مسترد شده',
		'failed'     => 'ناموفق',
	);

	public static function status_label( $s ) {
		$s = str_replace( 'wc-', '', $s );
		if ( isset( self::$status_labels[ $s ] ) ) {
			return self::$status_labels[ $s ];
		}
		return function_exists( 'wc_get_order_status_name' ) ? wc_get_order_status_name( $s ) : $s;
	}

	/**
	 * Validate cart and compute totals.
	 *
	 * @param object $customer
	 * @param array  $items product_id => qty
	 * @return array|WP_Error
	 */
	public static function quote( $customer, $items ) {
		$rows  = BWS_Products::rows( true );
		$cdisc = isset( $customer->discount_percent ) ? $customer->discount_percent : null;
		$lines = array();
		$qty   = 0;
		$total = 0;
		$rtot  = 0;
		foreach ( (array) $items as $pid => $q ) {
			$pid = absint( $pid );
			$q   = absint( $q );
			if ( ! $pid || ! $q ) {
				continue;
			}
			if ( ! isset( $rows[ $pid ] ) ) {
				return new WP_Error( 'bws_product', 'یکی از محصولات انتخابی برای خرید عمده فعال نیست. صفحه را تازه کنید.' );
			}
			$p = wc_get_product( $pid );
			if ( ! $p || ! $p->is_purchasable() ) {
				return new WP_Error( 'bws_product', 'محصول انتخابی قابل خرید نیست.' );
			}
			if ( ! $p->is_in_stock() ) {
				return new WP_Error( 'bws_stock', sprintf( '«%s» موجود نیست.', $p->get_name() ) );
			}
			if ( $p->managing_stock() && ! $p->backorders_allowed() && $p->get_stock_quantity() < $q ) {
				return new WP_Error( 'bws_stock', sprintf( 'موجودی «%s» فقط %s عدد است.', $p->get_name(), bws_fa_digits( (int) $p->get_stock_quantity() ) ) );
			}
			$price   = BWS_Products::wholesale_price( $p, $rows[ $pid ], $cdisc );
			$retail  = BWS_Products::retail_price( $p );
			$lines[] = array(
				'product' => $p,
				'id'      => $pid,
				'name'    => BWS_Products::display_name( $p ),
				'qty'     => $q,
				'price'   => $price,
				'retail'  => $retail,
				'total'   => $price * $q,
			);
			$qty   += $q;
			$total += $price * $q;
			$rtot  += $retail * $q;
		}
		if ( ! $lines ) {
			return new WP_Error( 'bws_empty', 'سبد خرید عمده خالی است.' );
		}
		$min = (int) bws_opt( 'min_qty', 20 );
		if ( $qty < $min ) {
			return new WP_Error( 'bws_min', sprintf( 'حداقل تعداد سفارش عمده %s عدد است (جمع همه محصولات، از هر نوعی). تعداد فعلی: %s عدد.', bws_fa_digits( $min ), bws_fa_digits( $qty ) ) );
		}
		$max = (int) bws_opt( 'max_qty', 0 );
		if ( $max > 0 && $qty > $max ) {
			return new WP_Error( 'bws_max', sprintf( 'حداکثر تعداد در هر سفارش %s عدد است.', bws_fa_digits( $max ) ) );
		}
		$min_amount = (float) bws_opt( 'min_amount', 0 );
		if ( $min_amount > 0 && $total < $min_amount ) {
			return new WP_Error( 'bws_min_amount', sprintf( 'حداقل مبلغ سفارش عمده %s است. مبلغ فعلی: %s', bws_money_text( $min_amount ), bws_money_text( $total ) ) );
		}
		$sum       = BWS_Ledger::summary( $customer );
		$available = $sum['available'];
		$credit    = min( $total, $available );
		$excess    = max( 0, $total - $credit );
		return array(
			'lines'        => $lines,
			'qty'          => $qty,
			'total'        => $total,
			'retail_total' => $rtot,
			'saving'       => max( 0, $rtot - $total ),
			'credit_used'  => $credit,
			'excess'       => $excess,
			'available'    => $available,
			'debt'         => $sum['debt'],
		);
	}

	public static function quote_to_array( $q ) {
		$lines = array();
		foreach ( $q['lines'] as $l ) {
			$lines[] = array( 'id' => $l['id'], 'name' => $l['name'], 'qty' => $l['qty'], 'price' => $l['price'], 'total' => $l['total'], 'total_text' => bws_money_text( $l['total'] ) );
		}
		return array(
			'lines'            => $lines,
			'qty'              => $q['qty'],
			'total'            => $q['total'],
			'total_text'       => bws_money_text( $q['total'] ),
			'retail_text'      => bws_money_text( $q['retail_total'] ),
			'saving_text'      => bws_money_text( $q['saving'] ),
			'credit_used'      => $q['credit_used'],
			'credit_used_text' => bws_money_text( $q['credit_used'] ),
			'excess'           => $q['excess'],
			'excess_text'      => bws_money_text( $q['excess'] ),
			'available_after'  => bws_money_text( max( 0, $q['available'] - $q['credit_used'] ) ),
		);
	}

	/**
	 * Create a wholesale order.
	 *
	 * @param object $customer
	 * @param array  $items
	 * @param array  $args excess_method (online|offline), note, placed_by (customer|visitor|admin)
	 * @return array|WP_Error
	 */
	public static function create( $customer, $items, $args = array() ) {
		if ( ! $customer || 'active' !== $customer->status ) {
			return new WP_Error( 'bws_inactive', 'حساب مشتری غیرفعال است. با ویزیتور خود تماس بگیرید.' );
		}
		if ( bws_opt( 'settle_before_order' ) && (float) $customer->balance > 0 ) {
			return new WP_Error( 'bws_settle', sprintf( 'برای ثبت سفارش جدید ابتدا بدهی قبلی (%s) را تسویه کنید.', bws_money_text( $customer->balance ) ) );
		}
		$lock = 'cust_' . $customer->id;
		if ( ! bws_lock( $lock ) ) {
			return new WP_Error( 'bws_busy', 'سفارش دیگری در حال ثبت است؛ چند ثانیه بعد دوباره تلاش کنید.' );
		}
		try {
			$customer = BWS_Customers::get( $customer->id ); // fresh balance.
			$q        = self::quote( $customer, $items );
			if ( is_wp_error( $q ) ) {
				return $q;
			}
			$placed_by = isset( $args['placed_by'] ) ? $args['placed_by'] : 'customer';
			$method    = '';
			if ( $q['excess'] > 0 ) {
				$method  = isset( $args['excess_method'] ) ? $args['excess_method'] : '';
				$allowed = array();
				if ( bws_opt( 'excess_online' ) ) {
					$allowed[] = 'online';
				}
				if ( bws_opt( 'excess_offline' ) ) {
					$allowed[] = 'offline';
				}
				if ( ! $allowed ) {
					return new WP_Error( 'bws_excess', sprintf( 'مبلغ سفارش بیشتر از اعتبار شماست. اعتبار قابل استفاده: %s', bws_money_text( $q['available'] ) ) );
				}
				if ( ! in_array( $method, $allowed, true ) ) {
					$method = $allowed[0];
				}
			}

			$order = wc_create_order( array( 'created_via' => 'bws_wholesale', 'status' => 'pending' ) );
			if ( is_wp_error( $order ) ) {
				return $order;
			}
			foreach ( $q['lines'] as $l ) {
				$order->add_product( $l['product'], $l['qty'], array(
					'subtotal' => $l['price'] * $l['qty'],
					'total'    => $l['price'] * $l['qty'],
				) );
			}
			$address = array(
				'first_name' => $customer->first_name,
				'last_name'  => $customer->last_name,
				'company'    => $customer->shop_name,
				'phone'      => $customer->mobile,
				'state'      => $customer->province,
				'city'       => $customer->city,
				'address_1'  => $customer->address,
				'postcode'   => $customer->postal_code,
				'country'    => 'IR',
			);
			$order->set_address( $address, 'billing' );
			$order->set_address( $address, 'shipping' );

			if ( $q['credit_used'] > 0 ) {
				$fee = new WC_Order_Item_Fee();
				$fee->set_name( 'پرداخت از اعتبار خرید عمده' );
				$fee->set_amount( -$q['credit_used'] );
				$fee->set_total( -$q['credit_used'] );
				$fee->set_tax_status( 'none' );
				$order->add_item( $fee );
			}
			$order->calculate_totals( false );

			$note = isset( $args['note'] ) ? sanitize_textarea_field( $args['note'] ) : '';
			if ( $note ) {
				$order->set_customer_note( $note );
			}
			$order->update_meta_data( '_bws_wholesale', 1 );
			$order->update_meta_data( '_bws_customer_id', (int) $customer->id );
			$order->update_meta_data( '_bws_customer_code', $customer->code );
			$order->update_meta_data( '_bws_visitor_id', (int) $customer->visitor_id );
			$order->update_meta_data( '_bws_placed_by', $placed_by );
			$order->update_meta_data( '_bws_placed_by_user', get_current_user_id() );
			$order->update_meta_data( '_bws_wholesale_total', $q['total'] );
			$order->update_meta_data( '_bws_retail_total', $q['retail_total'] );
			$order->update_meta_data( '_bws_credit_used', $q['credit_used'] );
			$order->update_meta_data( '_bws_excess', $q['excess'] );
			$order->update_meta_data( '_bws_excess_method', $method );
			self::set_origin( $order, 'customer' === $placed_by ? 'پنل مشتری' : ( 'visitor' === $placed_by ? 'پنل ویزیتور' : 'پنل عمده (مدیر)' ) );

			$by_label = 'customer' === $placed_by ? 'خود مشتری (پنل)' : bws_user_name( get_current_user_id() );
			$order->add_order_note( sprintf( "سفارش عمده — ثبت توسط: %s\nمشتری: %s (کد %s)\nجمع عمده: %s | از اعتبار: %s | مازاد: %s %s", $by_label, BWS_Customers::full_name( $customer ), $customer->code, bws_money_text( $q['total'] ), bws_money_text( $q['credit_used'] ), bws_money_text( $q['excess'] ), $method ? '(' . ( 'online' === $method ? 'پرداخت آنلاین' : 'پرداخت حضوری/نقدی' ) . ')' : '' ) );

			$pay_url = '';
			if ( $q['excess'] > 0 && 'online' === $method ) {
				$order->set_payment_method_title( 'اعتبار عمده + پرداخت آنلاین مازاد' );
				$order->save();
				$order->update_status( 'pending' );
				$pay_url = $order->get_checkout_payment_url();
			} else {
				$order->set_payment_method( 'bws_credit' );
				$order->set_payment_method_title( $q['excess'] > 0 ? 'اعتبار عمده + پرداخت حضوری مازاد' : 'اعتبار خرید عمده' );
				$order->save();
				$order->update_status( bws_opt( 'new_order_status', 'processing' ) );
			}
			$order_id = $order->get_id();

			// Ledger.
			if ( $q['credit_used'] > 0 ) {
				BWS_Ledger::add( $customer->id, 'purchase', $q['credit_used'], array( 'order_id' => $order_id, 'method' => 'credit', 'note' => 'سفارش #' . $order_id ) );
			}
			if ( $q['excess'] > 0 && 'offline' === $method ) {
				BWS_Ledger::add( $customer->id, 'cash_due', $q['excess'], array( 'order_id' => $order_id, 'note' => 'مازاد سفارش #' . $order_id . ' — پرداخت حضوری' ) );
			}

			global $wpdb;
			$wpdb->insert( self::table(), array(
				'order_id'       => $order_id,
				'customer_id'    => (int) $customer->id,
				'visitor_id'     => (int) $customer->visitor_id,
				'placed_by'      => $placed_by,
				'placed_by_user' => get_current_user_id(),
				'kind'           => 'order',
				'items_qty'      => $q['qty'],
				'retail_total'   => $q['retail_total'],
				'total'          => $q['total'],
				'credit_used'    => $q['credit_used'],
				'excess'         => $q['excess'],
				'excess_method'  => $method,
				'excess_paid'    => 0,
				'status'         => $order->get_status(),
				'created_at'     => bws_now(),
			) );

			BWS_Customers::touch( $customer->id, 'last_order_at' );
			BWS_Customers::save_cart( $customer->id, array() );
			BWS_Log::add( 'order_create', 'customer', $customer->id, array( 'order' => $order_id, 'total' => $q['total'] ), 'customer' === $placed_by ? 'customer' : '' );

			$customer = BWS_Customers::get( $customer->id );
			$vars     = self::sms_vars( $order, array( 'by' => $by_label, 'pay_url' => $pay_url ) );
			BWS_SMS::send_event( 'order', $customer, $vars );
			BWS_SMS::send_event( 'order_admin', $customer, $vars );
			BWS_Stats::bump();
			do_action( 'bws_order_created', $order_id, $customer, $q );

			return array(
				'order_id'    => $order_id,
				'total'       => $q['total'],
				'credit_used' => $q['credit_used'],
				'excess'      => $q['excess'],
				'method'      => $method,
				'pay_url'     => $pay_url,
				'customer'    => $customer,
			);
		} finally {
			bws_unlock( $lock );
		}
	}

	/** SMS variables for an order. */
	public static function sms_vars( $order, $extra = array() ) {
		$method = $order->get_meta( '_bws_excess_method' );
		$credit = (float) $order->get_meta( '_bws_credit_used' );
		$qty    = 0;
		foreach ( $order->get_items() as $it ) {
			$qty += (int) $it->get_quantity();
		}
		$placed = $order->get_meta( '_bws_placed_by' );
		return array_merge( array(
			'order_id'      => $order->get_order_number(),
			'order_total'   => bws_money_text( $order->get_meta( '_bws_wholesale_total' ) ),
			'order_credit'  => bws_money_text( $credit ),
			'credit_used'   => bws_money_text( $credit ), // legacy alias.
			'excess'        => bws_money_text( $order->get_meta( '_bws_excess' ) ),
			'excess_method' => 'online' === $method ? 'آنلاین' : ( 'offline' === $method ? 'حضوری' : '—' ),
			'items_count'   => bws_fa_digits( $qty ),
			'order_status'  => self::status_label( $order->get_status() ),
			'pay_url'       => 'pending' === $order->get_status() && $order->get_total() > 0 ? $order->get_checkout_payment_url() : '',
			'by'            => 'customer' === $placed ? 'خود مشتری' : bws_user_name( $order->get_meta( '_bws_placed_by_user' ) ),
		), $extra );
	}

	/** Order status SMS (settings → statuses that trigger an SMS). */
	public static function status_sms( $order_id, $from, $to, $order ) {
		if ( ! $order || ! $order->get_meta( '_bws_wholesale' ) || ! bws_opt( 'sms_on_order_status' ) ) {
			return;
		}
		if ( ! in_array( $to, (array) bws_opt( 'order_status_sms', array() ), true ) ) {
			return;
		}
		$c = BWS_Customers::get( (int) $order->get_meta( '_bws_customer_id' ) );
		if ( $c ) {
			BWS_SMS::send_event( 'order_status', $c, self::sms_vars( $order ) );
		}
	}

	/** Items of a previous order (for "repeat order"): product_id => qty, only products still on sale. */
	public static function reorder_items( $order_id ) {
		$order = wc_get_order( $order_id );
		$out   = array();
		if ( ! $order ) {
			return $out;
		}
		$rows = BWS_Products::rows( true );
		foreach ( $order->get_items() as $it ) {
			$pid = $it->get_variation_id() ? $it->get_variation_id() : $it->get_product_id();
			if ( isset( $rows[ $pid ] ) ) {
				$out[ $pid ] = ( isset( $out[ $pid ] ) ? $out[ $pid ] : 0 ) + (int) $it->get_quantity();
			}
		}
		return $out;
	}

	/** Online settlement of debt: creates a fee-only order and returns its payment URL. */
	public static function create_settlement( $customer, $amount ) {
		$amount = round( (float) $amount );
		$debt   = (float) $customer->balance;
		if ( $amount <= 0 ) {
			return new WP_Error( 'bws_amount', 'مبلغ معتبر نیست.' );
		}
		if ( $amount > $debt ) {
			return new WP_Error( 'bws_amount', sprintf( 'مبلغ نمی‌تواند بیشتر از بدهی (%s) باشد.', bws_money_text( $debt ) ) );
		}
		$order = wc_create_order( array( 'created_via' => 'bws_settlement', 'status' => 'pending' ) );
		if ( is_wp_error( $order ) ) {
			return $order;
		}
		$fee = new WC_Order_Item_Fee();
		$fee->set_name( 'تسویه اعتبار خرید عمده — کد ' . $customer->code );
		$fee->set_amount( $amount );
		$fee->set_total( $amount );
		$fee->set_tax_status( 'none' );
		$order->add_item( $fee );
		$order->set_address( array(
			'first_name' => $customer->first_name,
			'last_name'  => $customer->last_name,
			'phone'      => $customer->mobile,
			'company'    => $customer->shop_name,
			'city'       => $customer->city,
			'state'      => $customer->province,
			'address_1'  => $customer->address,
			'country'    => 'IR',
		), 'billing' );
		$order->calculate_totals( false );
		$order->update_meta_data( '_bws_settlement', 1 );
		self::set_origin( $order, 'پنل مشتری (تسویه)' );
		$order->update_meta_data( '_bws_customer_id', (int) $customer->id );
		$order->update_meta_data( '_bws_customer_code', $customer->code );
		$order->save();

		global $wpdb;
		$wpdb->insert( self::table(), array(
			'order_id'       => $order->get_id(),
			'customer_id'    => (int) $customer->id,
			'visitor_id'     => (int) $customer->visitor_id,
			'placed_by'      => 'customer',
			'placed_by_user' => get_current_user_id(),
			'kind'           => 'settlement',
			'total'          => $amount,
			'status'         => 'pending',
			'created_at'     => bws_now(),
		) );
		return array( 'order_id' => $order->get_id(), 'pay_url' => $order->get_checkout_payment_url() );
	}

	/** Keep ledger and index table in sync with WooCommerce order status. */
	public static function status_changed( $order_id, $from, $to, $order ) {
		global $wpdb;
		if ( $order && $order->get_meta( '_bws_replacement' ) ) {
			$wpdb->update( self::table(), array( 'status' => $to ), array( 'order_id' => $order_id ) ); // Free order: no ledger effect.
			return;
		}
		if ( ! $order || ( ! $order->get_meta( '_bws_wholesale' ) && ! $order->get_meta( '_bws_settlement' ) ) ) {
			return;
		}
		$wpdb->update( self::table(), array( 'status' => $to ), array( 'order_id' => $order_id ) );
		BWS_Stats::bump();
		$cid = (int) $order->get_meta( '_bws_customer_id' );
		if ( ! $cid ) {
			return;
		}

		if ( $order->get_meta( '_bws_settlement' ) ) {
			if ( in_array( $to, array( 'processing', 'completed' ), true ) ) {
				self::apply_settlement( $order );
			}
			return;
		}

		$dead     = array( 'cancelled', 'refunded', 'failed' );
		$reversed = (bool) $order->get_meta( '_bws_reversed' );

		// Failed online payment is retryable; reverse only for cancelled/refunded,
		// or for failed orders that are not online-excess orders.
		$should_reverse = in_array( $to, array( 'cancelled', 'refunded' ), true ) || ( 'failed' === $to && 'online' !== $order->get_meta( '_bws_excess_method' ) );

		if ( $should_reverse && ! $reversed ) {
			$lock = 'cust_' . $cid;
			bws_lock( $lock );
			$sum = (float) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(amount),0) FROM ' . BWS_Ledger::table() . " WHERE order_id = %d AND type IN ('purchase','cash_due','reversal')", $order_id ) );
			if ( $sum > 0 ) {
				BWS_Ledger::add( $cid, 'reversal', -$sum, array( 'order_id' => $order_id, 'note' => 'لغو/استرداد سفارش #' . $order_id, 'created_by' => get_current_user_id() ) );
			}
			$order->update_meta_data( '_bws_reversed', 1 );
			$order->save_meta_data();
			bws_unlock( $lock );
		} elseif ( $reversed && ! in_array( $to, $dead, true ) && 'pending' !== $to ) {
			// Order revived – charge credit again.
			$lock = 'cust_' . $cid;
			bws_lock( $lock );
			$credit = (float) $order->get_meta( '_bws_credit_used' );
			if ( $credit > 0 ) {
				BWS_Ledger::add( $cid, 'purchase', $credit, array( 'order_id' => $order_id, 'note' => 'بازگشایی سفارش #' . $order_id ) );
			}
			if ( 'offline' === $order->get_meta( '_bws_excess_method' ) && (float) $order->get_meta( '_bws_excess' ) > 0 ) {
				BWS_Ledger::add( $cid, 'cash_due', (float) $order->get_meta( '_bws_excess' ), array( 'order_id' => $order_id, 'note' => 'بازگشایی سفارش #' . $order_id ) );
			}
			$order->delete_meta_data( '_bws_reversed' );
			$order->save_meta_data();
			bws_unlock( $lock );
		}

		if ( in_array( $to, array( 'processing', 'completed' ), true ) && 'online' === $order->get_meta( '_bws_excess_method' ) && $order->is_paid() ) {
			$wpdb->update( self::table(), array( 'excess_paid' => 1 ), array( 'order_id' => $order_id ) );
		}
	}

	public static function payment_complete( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( $order && $order->get_meta( '_bws_settlement' ) ) {
			self::apply_settlement( $order );
		}
	}

	protected static function apply_settlement( $order ) {
		if ( $order->get_meta( '_bws_settlement_applied' ) ) {
			return;
		}
		$cid = (int) $order->get_meta( '_bws_customer_id' );
		$order->update_meta_data( '_bws_settlement_applied', 1 );
		$order->save_meta_data();
		BWS_Ledger::record_payment( $cid, $order->get_total(), 'online', 'سفارش #' . $order->get_id() . ' ' . $order->get_transaction_id(), 'تسویه آنلاین از پنل مشتری' );
		if ( 'completed' !== $order->get_status() ) {
			$order->update_status( 'completed', 'تسویه اعتبار عمده ثبت شد.' );
		}
	}

	public static function skip_email_verification( $required, $order ) {
		if ( $order && ( $order->get_meta( '_bws_wholesale' ) || $order->get_meta( '_bws_settlement' ) ) ) {
			return false;
		}
		return $required;
	}

	public static function payable_statuses( $statuses, $order ) {
		return $statuses;
	}

	public static function admin_order_box( $order ) {
		if ( ! $order->get_meta( '_bws_wholesale' ) && ! $order->get_meta( '_bws_settlement' ) ) {
			return;
		}
		$cid = (int) $order->get_meta( '_bws_customer_id' );
		$url = admin_url( 'admin.php?page=bws-customers&view=' . $cid );
		echo '<div class="form-field form-field-wide" style="margin-top:12px;padding:10px;background:#f0f6fc;border:1px solid #c5d9ed;border-radius:4px">';
		echo '<div style="font-weight:700;color:#1d4ed8;margin-bottom:4px">' . esc_html( self::source_label( $order ) ) . '</div>';
		if ( $order->get_meta( '_bws_settlement' ) ) {
			echo '<strong>تسویه اعتبار عمده</strong><br>';
		} else {
			echo '<strong>سفارش عمده (ویزیتور)</strong><br>';
			echo 'جمع عمده: ' . esc_html( bws_money_text( $order->get_meta( '_bws_wholesale_total' ) ) ) . '<br>';
			echo 'از اعتبار: ' . esc_html( bws_money_text( $order->get_meta( '_bws_credit_used' ) ) ) . '<br>';
			echo 'مازاد: ' . esc_html( bws_money_text( $order->get_meta( '_bws_excess' ) ) );
			$m = $order->get_meta( '_bws_excess_method' );
			if ( $m ) {
				echo ' (' . ( 'online' === $m ? 'آنلاین' : 'حضوری' ) . ')';
			}
			echo '<br>ویزیتور: ' . esc_html( bws_user_name( $order->get_meta( '_bws_visitor_id' ) ) ) . '<br>';
		}
		echo 'مشتری: <a href="' . esc_url( $url ) . '">کد ' . esc_html( $order->get_meta( '_bws_customer_code' ) ) . '</a>';
		echo '</div>';
	}

	/* ------------------------------------------------------------ */

	public static function query( $args = array() ) {
		global $wpdb;
		$t     = self::table();
		$ct    = BWS_Customers::table();
		$where = array( '1=1' );
		$vals  = array();
		if ( ! empty( $args['customer_id'] ) ) {
			$where[] = 'o.customer_id = %d';
			$vals[]  = (int) $args['customer_id'];
		}
		if ( ! empty( $args['visitor_id'] ) ) {
			$where[] = 'o.visitor_id = %d';
			$vals[]  = (int) $args['visitor_id'];
		}
		if ( ! empty( $args['kind'] ) ) {
			$where[] = 'o.kind = %s';
			$vals[]  = $args['kind'];
		}
		if ( ! empty( $args['status'] ) ) {
			$where[] = 'o.status = %s';
			$vals[]  = $args['status'];
		}
		if ( ! empty( $args['from'] ) ) {
			$where[] = 'o.created_at >= %s';
			$vals[]  = $args['from'];
		}
		if ( ! empty( $args['search'] ) ) {
			$s       = '%' . $wpdb->esc_like( bws_en_digits( $args['search'] ) ) . '%';
			$where[] = "(c.code LIKE %s OR c.first_name LIKE %s OR c.last_name LIKE %s OR c.mobile LIKE %s OR o.order_id LIKE %s)";
			array_push( $vals, $s, $s, $s, $s, $s );
		}
		$per    = isset( $args['per_page'] ) ? max( 1, (int) $args['per_page'] ) : 20;
		$page   = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
		$offset = ( $page - 1 ) * $per;
		$w      = implode( ' AND ', $where );
		$sql    = "SELECT o.*, c.first_name, c.last_name, c.code, c.shop_name, c.mobile FROM $t o LEFT JOIN $ct c ON c.id = o.customer_id WHERE $w ORDER BY o.id DESC LIMIT $offset, $per";
		$csql   = "SELECT COUNT(*) FROM $t o LEFT JOIN $ct c ON c.id = o.customer_id WHERE $w";
		$total  = (int) ( $vals ? $wpdb->get_var( $wpdb->prepare( $csql, $vals ) ) : $wpdb->get_var( $csql ) );
		return array(
			'items' => $vals ? $wpdb->get_results( $wpdb->prepare( $sql, $vals ) ) : $wpdb->get_results( $sql ),
			'total' => $total,
			'pages' => (int) ceil( $total / $per ),
		);
	}

	public static function row_to_array( $o, $with_items = false ) {
		$arr = array(
			'order_id'      => (int) $o->order_id,
			'kind'          => $o->kind,
			'kind_label'    => 'replacement' === $o->kind ? 'جایگزین مرجوعی' : ( 'settlement' === $o->kind ? 'تسویه بدهی' : '' ),
			'customer_id'   => (int) $o->customer_id,
			'customer'      => trim( $o->first_name . ' ' . $o->last_name ),
			'code'          => $o->code,
			'qty'           => (int) $o->items_qty,
			'total'         => (float) $o->total,
			'total_text'    => bws_money_text( $o->total ),
			'retail_text'   => bws_money_text( $o->retail_total ),
			'credit_text'   => bws_money_text( $o->credit_used ),
			'excess'        => (float) $o->excess,
			'excess_text'   => bws_money_text( $o->excess ),
			'excess_method' => $o->excess_method,
			'excess_paid'   => (int) $o->excess_paid,
			'status'        => $o->status,
			'status_label'  => self::status_label( $o->status ),
			'placed_by'     => 'customer' === $o->placed_by ? 'مشتری' : bws_user_name( $o->placed_by_user ),
			'visitor'       => bws_user_name( $o->visitor_id ),
			'date'          => bws_jdate( $o->created_at ),
			'pay_url'       => '',
		);
		if ( $with_items || 'pending' === $o->status ) {
			$order = wc_get_order( $o->order_id );
			if ( $order ) {
				if ( 'pending' === $order->get_status() && $order->get_total() > 0 ) {
					$arr['pay_url'] = $order->get_checkout_payment_url();
				}
				if ( $with_items ) {
					$items = array();
					foreach ( $order->get_items() as $it ) {
						$items[] = array( 'name' => $it->get_name(), 'qty' => (int) $it->get_quantity(), 'total_text' => bws_money_text( $it->get_total() ), 'unit_text' => bws_money_text( $it->get_quantity() ? $it->get_total() / $it->get_quantity() : 0 ) );
					}
					$arr['items'] = $items;
					$arr['note']  = $order->get_customer_note();
				}
			}
		}
		return $arr;
	}

	public static function stats( $visitor_id = 0, $from = '' ) {
		global $wpdb;
		$t     = self::table();
		$where = "kind = 'order' AND status NOT IN ('cancelled','refunded','failed')";
		$vals  = array();
		if ( $visitor_id ) {
			$where .= ' AND visitor_id = %d';
			$vals[] = $visitor_id;
		}
		if ( $from ) {
			$where .= ' AND created_at >= %s';
			$vals[] = $from;
		}
		$sql = "SELECT COUNT(*) AS cnt, COALESCE(SUM(total),0) AS total, COALESCE(SUM(items_qty),0) AS qty, COALESCE(SUM(credit_used),0) AS credit FROM $t WHERE $where";
		return $vals ? $wpdb->get_row( $wpdb->prepare( $sql, $vals ) ) : $wpdb->get_row( $sql );
	}
}
