<?php
defined( 'ABSPATH' ) || exit;

class BWS_Install {

	public static function activate() {
		self::create_tables();
		self::create_roles();
		self::create_pages();
		update_option( 'bws_db_version', BWS_DB_VERSION );
		if ( ! wp_next_scheduled( 'bws_daily' ) ) {
			wp_schedule_event( time() + 300, 'daily', 'bws_daily' );
		}
		flush_rewrite_rules();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'bws_db_version' ) !== BWS_DB_VERSION ) {
			self::create_tables();
			self::create_roles();
			self::protect_dirs();
			// Settings are small: autoload them so front-end pages never run an extra query.
			$s = get_option( 'bws_settings' );
			if ( is_array( $s ) ) {
				if ( ! isset( $s['panel_mode'] ) ) {
					$s['panel_mode'] = ( isset( $s['panel_fullscreen'] ) && ! $s['panel_fullscreen'] ) ? 'theme' : 'app';
				}
				// Migrate the old global visitor switches into the new permission defaults.
				if ( ! isset( $s['visitor_perms'] ) ) {
					$s['visitor_perms'] = array(
						'customers_view'  => ( ! isset( $s['visitor_view_all'] ) || $s['visitor_view_all'] ) ? 'all' : 'own',
						'customers_edit'  => ! empty( $s['visitor_edit_all'] ) ? 'all' : 'own',
						'payments_record' => ( ! isset( $s['visitor_record_payment'] ) || $s['visitor_record_payment'] ) ? 'own' : 'none',
						'orders_place'    => ( ! isset( $s['visitor_place_order'] ) || $s['visitor_place_order'] ) ? 'own' : 'none',
						'sms_bulk'        => isset( $s['visitor_bulk_sms'] ) ? $s['visitor_bulk_sms'] : 'own',
						'ledger_view'     => ( ! isset( $s['visitor_see_ledger_all'] ) || $s['visitor_see_ledger_all'] ) ? 'all' : 'own',
						'leaderboard'     => ( ! isset( $s['visitor_see_leaderboard'] ) || $s['visitor_see_leaderboard'] ) ? 1 : 0,
					);
				}
				// 2.1: "قیمت تکی" is now called "قیمت مصرف‌کننده".
				if ( isset( $s['retail_label'] ) && in_array( trim( $s['retail_label'] ), array( 'قیمت تکی:', 'قیمت تکی' ), true ) ) {
					$s['retail_label'] = 'قیمت مصرف‌کننده:';
				}
				// 2.3: per-recipient bot routing replaces the flat chat-id lists.
				if ( ! isset( $s['bot_recipients'] ) ) {
					$s['bot_recipients'] = array();
					$ev                  = isset( $s['bot_events'] ) ? (array) $s['bot_events'] : array( 'new', 'decision', 'cancel' );
					foreach ( array( 'telegram' => 'tg_chats', 'bale' => 'bale_chats' ) as $bp => $bk ) {
						if ( ! empty( $s[ $bk ] ) && class_exists( 'BWS_Messenger' ) ) {
							foreach ( BWS_Messenger::parse_chats( $s[ $bk ] ) as $bc ) {
								$s['bot_recipients'][] = array( 'id' => 'r' . substr( md5( $bp . $bc ), 0, 8 ), 'p' => $bp, 'chat' => $bc, 'name' => '', 'user' => 0, 'scope' => 'all', 'ev' => $ev, 'photos' => 1, 'list' => 1, 'decide' => 0, 'on' => 1 );
							}
						}
					}
				}
				delete_option( 'bws_settings' );
				add_option( 'bws_settings', $s, '', 'yes' );
				$GLOBALS['bws_settings_cache'] = null;
			}
			update_option( 'bws_db_version', BWS_DB_VERSION, true );
		}
	}

	/** Block direct HTTP access to PHP files inside the plugin folders. */
	public static function protect_dirs() {
		foreach ( array( '', 'includes', 'includes/sms', 'includes/admin', 'includes/gateways', 'includes/elementor', 'includes/returns', 'templates', 'assets', 'assets/js', 'assets/css', 'assets/img', 'assets/fonts', 'languages' ) as $d ) {
			$f = BWS_DIR . ( $d ? $d . '/' : '' ) . 'index.php';
			if ( is_dir( dirname( $f ) ) && ! file_exists( $f ) && is_writable( dirname( $f ) ) ) {
				@file_put_contents( $f, "<?php\n// Silence is golden.\n" ); // phpcs:ignore
			}
		}
	}

	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'bws_' . $name;
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();

		$customers = self::table( 'customers' );
		$ledger    = self::table( 'ledger' );
		$orders    = self::table( 'orders' );
		$products  = self::table( 'products' );
		$sms       = self::table( 'sms_log' );
		$log       = self::table( 'activity' );

		dbDelta( "CREATE TABLE $customers (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			code varchar(32) NOT NULL,
			first_name varchar(100) NOT NULL DEFAULT '',
			last_name varchar(100) NOT NULL DEFAULT '',
			shop_name varchar(191) NOT NULL DEFAULT '',
			mobile varchar(20) NOT NULL,
			phone varchar(30) NOT NULL DEFAULT '',
			province varchar(60) NOT NULL DEFAULT '',
			city varchar(100) NOT NULL DEFAULT '',
			address text NULL,
			postal_code varchar(20) NOT NULL DEFAULT '',
			national_id varchar(20) NOT NULL DEFAULT '',
			lat decimal(10,7) NULL,
			lng decimal(10,7) NULL,
			discount_percent decimal(5,2) NULL,
			notes text NULL,
			visitor_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			status varchar(20) NOT NULL DEFAULT 'active',
			credit_limit decimal(20,2) NOT NULL DEFAULT 0,
			balance decimal(20,2) NOT NULL DEFAULT 0,
			cart longtext NULL,
			last_login_at datetime NULL,
			last_order_at datetime NULL,
			last_reminder_at datetime NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY code (code),
			UNIQUE KEY mobile (mobile),
			KEY visitor_id (visitor_id),
			KEY status (status),
			KEY balance (balance)
		) $c;" );

		dbDelta( "CREATE TABLE $ledger (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			customer_id bigint(20) unsigned NOT NULL,
			type varchar(30) NOT NULL,
			amount decimal(20,2) NOT NULL DEFAULT 0,
			balance_after decimal(20,2) NOT NULL DEFAULT 0,
			order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			method varchar(30) NOT NULL DEFAULT '',
			reference varchar(191) NOT NULL DEFAULT '',
			note text NULL,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY customer_id (customer_id),
			KEY order_id (order_id),
			KEY type (type),
			KEY created_at (created_at)
		) $c;" );

		dbDelta( "CREATE TABLE $orders (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			order_id bigint(20) unsigned NOT NULL,
			customer_id bigint(20) unsigned NOT NULL,
			visitor_id bigint(20) unsigned NOT NULL DEFAULT 0,
			placed_by varchar(20) NOT NULL DEFAULT 'customer',
			placed_by_user bigint(20) unsigned NOT NULL DEFAULT 0,
			kind varchar(20) NOT NULL DEFAULT 'order',
			items_qty int(11) NOT NULL DEFAULT 0,
			retail_total decimal(20,2) NOT NULL DEFAULT 0,
			total decimal(20,2) NOT NULL DEFAULT 0,
			credit_used decimal(20,2) NOT NULL DEFAULT 0,
			excess decimal(20,2) NOT NULL DEFAULT 0,
			excess_method varchar(20) NOT NULL DEFAULT '',
			excess_paid tinyint(1) NOT NULL DEFAULT 0,
			status varchar(30) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY order_id (order_id),
			KEY customer_id (customer_id),
			KEY visitor_id (visitor_id),
			KEY kind (kind),
			KEY status (status),
			KEY created_at (created_at)
		) $c;" );

		$visits = self::table( 'visits' );
		dbDelta( "CREATE TABLE $visits (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			customer_id bigint(20) unsigned NOT NULL,
			visitor_id bigint(20) unsigned NOT NULL DEFAULT 0,
			result varchar(20) NOT NULL DEFAULT '',
			note text NULL,
			follow_up date NULL,
			follow_done tinyint(1) NOT NULL DEFAULT 0,
			lat decimal(10,7) NULL,
			lng decimal(10,7) NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY customer_id (customer_id),
			KEY visitor_follow (visitor_id, follow_done, follow_up),
			KEY created_at (created_at)
		) $c;" );

		$returns = self::table( 'returns' );
		$ritems  = self::table( 'return_items' );
		$rfiles  = self::table( 'return_files' );
		dbDelta( "CREATE TABLE $returns (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			code varchar(20) NOT NULL DEFAULT '',
			customer_id bigint(20) unsigned NOT NULL,
			visitor_id bigint(20) unsigned NOT NULL DEFAULT 0,
			order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			reason varchar(191) NOT NULL DEFAULT '',
			description text NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			resolution varchar(20) NOT NULL DEFAULT '',
			amount decimal(20,2) NOT NULL DEFAULT 0,
			approved_amount decimal(20,2) NOT NULL DEFAULT 0,
			replacement_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			decision_note text NULL,
			decided_by bigint(20) unsigned NOT NULL DEFAULT 0,
			decided_at datetime NULL,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_by_type varchar(20) NOT NULL DEFAULT 'customer',
			storage varchar(10) NOT NULL DEFAULT 'host',
			files_state varchar(20) NOT NULL DEFAULT 'ok',
			notify_state longtext NULL,
			attempts int(11) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY customer_id (customer_id),
			KEY visitor_id (visitor_id),
			KEY order_id (order_id),
			KEY status (status),
			KEY created_at (created_at)
		) $c;" );
		dbDelta( "CREATE TABLE $ritems (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			return_id bigint(20) unsigned NOT NULL,
			order_item_id bigint(20) unsigned NOT NULL DEFAULT 0,
			product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			name varchar(255) NOT NULL DEFAULT '',
			qty int(11) NOT NULL DEFAULT 0,
			approved_qty int(11) NOT NULL DEFAULT 0,
			unit_price decimal(20,2) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY return_id (return_id),
			KEY order_item_id (order_item_id),
			KEY product_id (product_id)
		) $c;" );
		dbDelta( "CREATE TABLE $rfiles (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			return_id bigint(20) unsigned NOT NULL,
			storage varchar(10) NOT NULL DEFAULT 'host',
			path varchar(255) NOT NULL DEFAULT '',
			drive_id varchar(191) NOT NULL DEFAULT '',
			drive_link varchar(255) NOT NULL DEFAULT '',
			drive_public tinyint(1) NOT NULL DEFAULT 0,
			mime varchar(50) NOT NULL DEFAULT '',
			size int(11) NOT NULL DEFAULT 0,
			width int(11) NOT NULL DEFAULT 0,
			height int(11) NOT NULL DEFAULT 0,
			state varchar(20) NOT NULL DEFAULT 'local',
			md5 varchar(32) NOT NULL DEFAULT '',
			error text NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY return_id (return_id)
		) $c;" );

		dbDelta( "CREATE TABLE $products (
			product_id bigint(20) unsigned NOT NULL,
			parent_id bigint(20) unsigned NOT NULL DEFAULT 0,
			enabled tinyint(1) NOT NULL DEFAULT 1,
			discount_percent decimal(5,2) NULL,
			fixed_price decimal(20,2) NULL,
			sort_order int(11) NOT NULL DEFAULT 0,
			missing tinyint(1) NOT NULL DEFAULT 0,
			synced_at datetime NULL,
			PRIMARY KEY  (product_id),
			KEY enabled (enabled)
		) $c;" );

		dbDelta( "CREATE TABLE $sms (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			customer_id bigint(20) unsigned NOT NULL DEFAULT 0,
			mobile varchar(20) NOT NULL,
			message text NOT NULL,
			context varchar(40) NOT NULL DEFAULT '',
			provider varchar(40) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT '',
			response text NULL,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY customer_id (customer_id),
			KEY created_at (created_at)
		) $c;" );

		dbDelta( "CREATE TABLE $log (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			actor varchar(20) NOT NULL DEFAULT '',
			action varchar(60) NOT NULL,
			object_type varchar(30) NOT NULL DEFAULT '',
			object_id bigint(20) unsigned NOT NULL DEFAULT 0,
			details text NULL,
			ip varchar(64) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY object (object_type, object_id),
			KEY created_at (created_at)
		) $c;" );
	}

	public static function create_roles() {
		if ( ! get_role( 'bws_visitor' ) ) {
			add_role( 'bws_visitor', 'ویزیتور', array( 'read' => true, 'bws_visitor' => true ) );
		}
		foreach ( array( 'administrator', 'shop_manager' ) as $r ) {
			$role = get_role( $r );
			if ( $role && ! $role->has_cap( 'bws_manage' ) ) {
				$role->add_cap( 'bws_manage' );
			}
		}
	}

	public static function create_pages() {
		$s       = get_option( 'bws_settings', array() );
		$s       = is_array( $s ) ? $s : array();
		$changed = false;

		$pages = array(
			'customer_page_id' => array( 'buy-panel', 'پنل خرید همکاران', '[bws_customer_panel]' ),
			'visitor_page_id'  => array( 'visitor-panel', 'پنل ویزیتور', '[bws_visitor_panel]' ),
		);
		foreach ( $pages as $key => $p ) {
			if ( ! empty( $s[ $key ] ) && get_post( $s[ $key ] ) && 'trash' !== get_post_status( $s[ $key ] ) ) {
				continue;
			}
			$existing = get_page_by_path( $p[0] );
			if ( $existing ) {
				$s[ $key ] = $existing->ID;
			} else {
				$s[ $key ] = wp_insert_post( array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_name'    => $p[0],
					'post_title'   => $p[1],
					'post_content' => $p[2],
				) );
			}
			$changed = true;
		}
		if ( $changed ) {
			update_option( 'bws_settings', $s, true );
			$GLOBALS['bws_settings_cache'] = null;
		}
	}
}
