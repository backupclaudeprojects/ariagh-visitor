<?php
defined( 'ABSPATH' ) || exit;

class BWS_Auth {

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'block_visitor_admin' ) );
		add_filter( 'show_admin_bar', array( __CLASS__, 'hide_admin_bar' ) );
		add_filter( 'login_redirect', array( __CLASS__, 'login_redirect' ), 20, 3 );
		add_filter( 'wp_authenticate_user', array( __CLASS__, 'check_active_visitor' ), 20 );
	}

	/* ---------------- Customer token (stateless, HMAC signed) ---------------- */

	protected static function sign( $payload ) {
		return hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) . 'bws' );
	}

	public static function make_token( $customer ) {
		$exp     = time() + DAY_IN_SECONDS * max( 1, (int) bws_opt( 'session_days', 30 ) );
		$payload = $customer->id . '|' . $exp . '|' . substr( hash( 'sha256', $customer->code ), 0, 16 );
		return base64_encode( $customer->id . '|' . $exp . '|' . self::sign( $payload ) );
	}

	/** @return object|null customer */
	public static function customer_from_token( $token ) {
		$raw = base64_decode( (string) $token, true );
		if ( ! $raw || 2 !== substr_count( $raw, '|' ) ) {
			return null;
		}
		list( $id, $exp, $sig ) = explode( '|', $raw );
		if ( (int) $exp < time() ) {
			return null;
		}
		$c = BWS_Customers::get( (int) $id );
		if ( ! $c || 'active' !== $c->status ) {
			return null;
		}
		$payload = $c->id . '|' . (int) $exp . '|' . substr( hash( 'sha256', $c->code ), 0, 16 );
		return hash_equals( self::sign( $payload ), $sig ) ? $c : null;
	}

	public static function current_customer( $request = null ) {
		$token = '';
		if ( $request ) {
			$token = $request->get_header( 'x-bws-token' );
		}
		if ( ! $token && isset( $_SERVER['HTTP_X_BWS_TOKEN'] ) ) {
			$token = sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_BWS_TOKEN'] ) );
		}
		return $token ? self::customer_from_token( $token ) : null;
	}

	/* ---------------- Rate limiting ---------------- */

	public static function too_many( $bucket ) {
		$key = 'bws_rl_' . md5( $bucket . bws_client_ip() );
		$n   = (int) get_transient( $key );
		return $n >= max( 3, (int) bws_opt( 'login_max_attempts', 10 ) );
	}

	public static function hit( $bucket ) {
		$key = 'bws_rl_' . md5( $bucket . bws_client_ip() );
		$n   = (int) get_transient( $key );
		set_transient( $key, $n + 1, 15 * MINUTE_IN_SECONDS );
	}

	public static function clear( $bucket ) {
		delete_transient( 'bws_rl_' . md5( $bucket . bws_client_ip() ) );
	}

	/** Customer login by code. Returns [token, customer] or WP_Error. */
	public static function customer_login( $code ) {
		if ( self::too_many( 'cust' ) ) {
			return new WP_Error( 'bws_rate', 'تعداد تلاش‌های ناموفق زیاد است. ۱۵ دقیقه بعد دوباره امتحان کنید.' );
		}
		$c = BWS_Customers::get_by_code( $code );
		if ( ! $c ) {
			self::hit( 'cust' );
			return new WP_Error( 'bws_code', 'کد وارد شده معتبر نیست.' );
		}
		if ( 'active' !== $c->status ) {
			return new WP_Error( 'bws_inactive', 'حساب شما غیرفعال است. لطفاً با ویزیتور یا شرکت تماس بگیرید.' );
		}
		self::clear( 'cust' );
		if ( bws_opt( 'customer_otp' ) ) {
			return self::otp_start( $c );
		}
		BWS_Customers::touch( $c->id, 'last_login_at' );
		return array( 'token' => self::make_token( $c ), 'customer' => $c );
	}

	/* ---------------- One-time password (SMS) ---------------- */

	protected static function otp_key( $ticket ) {
		return 'bws_otp_' . hash_hmac( 'sha256', $ticket, wp_salt( 'nonce' ) );
	}

	/** Mask 09121234567 → 0912***4567 */
	public static function mask_mobile( $m ) {
		return substr( $m, 0, 4 ) . '***' . substr( $m, -4 );
	}

	/** Create an OTP for a customer, send it by SMS, return a ticket the browser keeps. */
	public static function otp_start( $c ) {
		if ( bws_rate_limited( 'otp_send', 6, 15 * MINUTE_IN_SECONDS ) ) {
			return new WP_Error( 'bws_rate', 'درخواست کد تأیید بیش از حد مجاز بود. ۱۵ دقیقه بعد امتحان کنید.' );
		}
		$cool = 'bws_otp_cool_' . $c->id;
		if ( get_transient( $cool ) ) {
			return new WP_Error( 'bws_wait', 'کد تأیید همین الان ارسال شد؛ یک دقیقه صبر کنید.' );
		}
		$len     = max( 4, min( 8, (int) bws_opt( 'otp_length', 5 ) ) );
		$minutes = max( 1, min( 15, (int) bws_opt( 'otp_minutes', 3 ) ) );
		$otp     = (string) random_int( (int) pow( 10, $len - 1 ), (int) pow( 10, $len ) - 1 );
		$ticket  = bin2hex( random_bytes( 16 ) );
		set_transient( self::otp_key( $ticket ), array(
			'cid'   => (int) $c->id,
			'hash'  => wp_hash_password( $otp ),
			'exp'   => time() + $minutes * MINUTE_IN_SECONDS,
			'tries' => 0,
		), $minutes * MINUTE_IN_SECONDS + 60 );
		set_transient( $cool, 1, 60 );
		$r = BWS_SMS::send_event( 'otp', $c, array( 'otp' => $otp, 'minutes' => bws_fa_digits( $minutes ) ), array( 'force' => true ) );
		if ( empty( $r['sent'] ) ) {
			return new WP_Error( 'bws_sms', 'ارسال پیامک کد تأیید ناموفق بود. با پشتیبانی تماس بگیرید.' );
		}
		return array(
			'otp_required' => true,
			'ticket'       => $ticket,
			'mobile'       => self::mask_mobile( $c->mobile ),
			'minutes'      => $minutes,
			'length'       => $len,
		);
	}

	/** Request an OTP by mobile number ("I forgot my code"). */
	public static function otp_request_mobile( $mobile ) {
		if ( ! bws_opt( 'customer_mobile_login' ) ) {
			return new WP_Error( 'bws_off', 'ورود با موبایل غیرفعال است.' );
		}
		$c = BWS_Customers::get_by_mobile( $mobile );
		if ( ! $c ) {
			self::hit( 'cust' );
			return new WP_Error( 'bws_mobile', 'این شماره در سامانه ثبت نشده است. با ویزیتور خود تماس بگیرید.' );
		}
		if ( 'active' !== $c->status ) {
			return new WP_Error( 'bws_inactive', 'حساب شما غیرفعال است. لطفاً با ویزیتور یا شرکت تماس بگیرید.' );
		}
		return self::otp_start( $c );
	}

	public static function otp_verify( $ticket, $otp ) {
		$ticket = preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $ticket ) );
		$otp    = preg_replace( '/\D/', '', bws_en_digits( (string) $otp ) );
		if ( self::too_many( 'otp' ) ) {
			return new WP_Error( 'bws_rate', 'تعداد تلاش‌های ناموفق زیاد است. ۱۵ دقیقه بعد دوباره امتحان کنید.' );
		}
		$key  = self::otp_key( $ticket );
		$data = 32 === strlen( $ticket ) ? get_transient( $key ) : false;
		if ( ! is_array( $data ) || $data['exp'] < time() ) {
			return new WP_Error( 'bws_otp_exp', 'کد تأیید منقضی شده است؛ دوباره درخواست کنید.' );
		}
		if ( ! wp_check_password( $otp, $data['hash'] ) ) {
			self::hit( 'otp' );
			$data['tries']++;
			if ( $data['tries'] >= 5 ) {
				delete_transient( $key );
				return new WP_Error( 'bws_otp_exp', 'کد اشتباه بود و کد تأیید باطل شد؛ دوباره درخواست کنید.' );
			}
			set_transient( $key, $data, max( 60, $data['exp'] - time() ) );
			return new WP_Error( 'bws_otp', 'کد تأیید اشتباه است.' );
		}
		delete_transient( $key );
		$c = BWS_Customers::get( $data['cid'] );
		if ( ! $c || 'active' !== $c->status ) {
			return new WP_Error( 'bws_inactive', 'حساب شما غیرفعال است.' );
		}
		self::clear( 'otp' );
		BWS_Customers::touch( $c->id, 'last_login_at' );
		BWS_Log::add( 'otp_login', 'customer', $c->id, '', 'customer' );
		return array( 'token' => self::make_token( $c ), 'customer' => $c );
	}

	/* ---------------- Visitors ---------------- */

	public static function block_visitor_admin() {
		if ( wp_doing_ajax() || ! is_user_logged_in() ) {
			return;
		}
		if ( bws_is_visitor() && ! current_user_can( 'edit_posts' ) && ! current_user_can( 'bws_manage' ) ) {
			wp_safe_redirect( bws_visitor_panel_url() );
			exit;
		}
	}

	public static function hide_admin_bar( $show ) {
		if ( bws_is_visitor() && ! current_user_can( 'edit_posts' ) ) {
			return false;
		}
		return $show;
	}

	public static function login_redirect( $redirect, $requested, $user ) {
		if ( $user && ! is_wp_error( $user ) && in_array( 'bws_visitor', (array) $user->roles, true ) && ! user_can( $user, 'edit_posts' ) ) {
			return bws_visitor_panel_url();
		}
		return $redirect;
	}

	public static function check_active_visitor( $user ) {
		if ( $user instanceof WP_User && in_array( 'bws_visitor', (array) $user->roles, true ) && ! bws_visitor_active( $user->ID ) ) {
			return new WP_Error( 'bws_inactive', 'حساب ویزیتوری شما غیرفعال شده است.' );
		}
		return $user;
	}

	/** Can current visitor/admin access a customer? (Permissions: BWS_Perms) */
	public static function can_view_customer( $c ) {
		if ( bws_is_manager() ) {
			return true;
		}
		if ( ! bws_is_visitor() || ! $c ) {
			return false;
		}
		return BWS_Perms::scope_allows( 'customers_view', $c ) || (int) $c->visitor_id === get_current_user_id();
	}

	public static function can_edit_customer( $c ) {
		if ( bws_is_manager() ) {
			return true;
		}
		if ( ! bws_is_visitor() || ! $c ) {
			return false;
		}
		return BWS_Perms::scope_allows( 'customers_edit', $c );
	}

	/* ---------------- Visitor CRUD (WP users) ---------------- */

	public static function visitor_fields() {
		return array( 'mobile' => 'موبایل', 'region' => 'منطقه / مسیر', 'national_id' => 'کد ملی', 'note' => 'یادداشت' );
	}

	/** Find a visitor by username, email or mobile (visitors may log in with their mobile number). */
	public static function find_login( $login ) {
		$login  = trim( bws_en_digits( $login ) );
		$mobile = bws_normalize_mobile( $login );
		if ( $mobile ) {
			$users = get_users( array( 'meta_key' => 'bws_mobile', 'meta_value' => $mobile, 'number' => 1, 'fields' => array( 'user_login' ) ) );
			if ( $users ) {
				return $users[0]->user_login;
			}
		}
		return $login;
	}

	public static function save_visitor( $data, $user_id = 0 ) {
		$first = sanitize_text_field( isset( $data['first_name'] ) ? wp_unslash( $data['first_name'] ) : '' );
		$last  = sanitize_text_field( isset( $data['last_name'] ) ? wp_unslash( $data['last_name'] ) : '' );
		$pass  = isset( $data['password'] ) ? (string) wp_unslash( $data['password'] ) : '';
		$email = sanitize_email( isset( $data['email'] ) ? wp_unslash( $data['email'] ) : '' );

		if ( ! $user_id ) {
			$login = sanitize_user( bws_en_digits( isset( $data['username'] ) ? wp_unslash( $data['username'] ) : '' ), true );
			if ( ! $login ) {
				return new WP_Error( 'bws_login', 'نام کاربری لازم است (حروف انگلیسی یا عدد).' );
			}
			if ( username_exists( $login ) ) {
				return new WP_Error( 'bws_login', 'این نام کاربری قبلاً استفاده شده است.' );
			}
			if ( strlen( $pass ) < 6 ) {
				return new WP_Error( 'bws_pass', 'رمز عبور باید حداقل ۶ کاراکتر باشد.' );
			}
			if ( ! $email ) {
				$email = $login . '@visitor.' . wp_parse_url( home_url(), PHP_URL_HOST );
			}
			if ( email_exists( $email ) ) {
				return new WP_Error( 'bws_email', 'این ایمیل قبلاً استفاده شده است.' );
			}
			$user_id = wp_insert_user( array(
				'user_login'   => $login,
				'user_pass'    => $pass,
				'user_email'   => $email,
				'first_name'   => $first,
				'last_name'    => $last,
				'display_name' => trim( $first . ' ' . $last ) ? trim( $first . ' ' . $last ) : $login,
				'role'         => 'bws_visitor',
			) );
			if ( is_wp_error( $user_id ) ) {
				return $user_id;
			}
			BWS_Log::add( 'visitor_create', 'visitor', $user_id, $login );
		} else {
			$upd = array(
				'ID'           => $user_id,
				'first_name'   => $first,
				'last_name'    => $last,
				'display_name' => trim( $first . ' ' . $last ),
			);
			if ( $email ) {
				$upd['user_email'] = $email;
			}
			if ( $pass ) {
				if ( strlen( $pass ) < 6 ) {
					return new WP_Error( 'bws_pass', 'رمز عبور باید حداقل ۶ کاراکتر باشد.' );
				}
				$upd['user_pass'] = $pass;
			}
			$r = wp_update_user( $upd );
			if ( is_wp_error( $r ) ) {
				return $r;
			}
			BWS_Log::add( 'visitor_update', 'visitor', $user_id, $pass ? 'password changed' : '' );
		}
		foreach ( array_keys( self::visitor_fields() ) as $f ) {
			if ( isset( $data[ $f ] ) ) {
				$v = 'mobile' === $f ? bws_normalize_mobile( $data[ $f ] ) : sanitize_text_field( wp_unslash( $data[ $f ] ) );
				update_user_meta( $user_id, 'bws_' . $f, $v );
			}
		}
		$active = ! empty( $data['active'] );
		update_user_meta( $user_id, 'bws_active', $active ? '1' : '0' );
		if ( ! $active && class_exists( 'WP_Session_Tokens' ) ) {
			WP_Session_Tokens::get_instance( $user_id )->destroy_all(); // Log the visitor out everywhere.
		}
		if ( isset( $data['target'] ) ) {
			update_user_meta( $user_id, 'bws_target', max( 0, bws_parse_amount( $data['target'] ) ) );
		}
		if ( isset( $data['commission'] ) ) {
			update_user_meta( $user_id, 'bws_commission', max( 0, min( 100, (float) bws_en_digits( $data['commission'] ) ) ) );
		}
		if ( isset( $data['perm_mode'] ) ) {
			$mode = 'custom' === $data['perm_mode'] ? 'custom' : 'inherit';
			update_user_meta( $user_id, 'bws_perm_mode', $mode );
			if ( 'custom' === $mode ) {
				update_user_meta( $user_id, 'bws_perms', BWS_Perms::sanitize( isset( $data['perms'] ) ? (array) $data['perms'] : array() ) );
			}
			BWS_Log::add( 'visitor_perms', 'visitor', $user_id, $mode );
		}
		return $user_id;
	}

	public static function visitors( $only_active = false ) {
		$users = get_users( array( 'role' => 'bws_visitor', 'orderby' => 'display_name' ) );
		if ( $only_active ) {
			$users = array_filter( $users, function ( $u ) {
				return bws_visitor_active( $u->ID );
			} );
		}
		return $users;
	}
}
