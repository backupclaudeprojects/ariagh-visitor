<?php
defined( 'ABSPATH' ) || exit;

/** Audit log: who did what, when. */
class BWS_Log {

	public static $labels = array(
		'customer_create'   => 'ثبت مشتری',
		'customer_update'   => 'ویرایش مشتری',
		'customer_code'     => 'تغییر کد مشتری',
		'customer_status'   => 'تغییر وضعیت مشتری',
		'customer_delete'   => 'حذف مشتری',
		'customer_login'    => 'ورود مشتری به پنل',
		'credit_limit'      => 'تغییر سقف اعتبار',
		'ledger_payment'    => 'ثبت پرداخت',
		'ledger_adjust'     => 'اصلاح حساب',
		'order_create'      => 'ثبت سفارش عمده',
		'visitor_create'    => 'ایجاد ویزیتور',
		'visitor_update'    => 'ویرایش ویزیتور',
		'visitor_login'     => 'ورود ویزیتور',
		'products_sync'     => 'بارگذاری محصولات',
		'sms_bulk'          => 'ارسال پیامک گروهی',
		'settings_save'     => 'ذخیره تنظیمات',
		'customer_transfer' => 'انتقال مشتری به ویزیتور دیگر',
		'customer_location' => 'ثبت موقعیت مکانی مشتری',
		'customer_discount' => 'تخفیف اختصاصی مشتری',
		'visit_add'         => 'ثبت ویزیت',
		'visitor_perms'     => 'تغییر دسترسی ویزیتور',
		'otp_login'         => 'ورود مشتری با رمز یک‌بار مصرف',
		'login_failed'      => 'تلاش ناموفق ورود',
		'snapppay'          => 'اسنپ‌پی',
		'settings_import'   => 'درون‌ریزی تنظیمات',
		'order_cancel'      => 'لغو سفارش',
		'sms_bulk_visitors' => 'پیامک گروهی به ویزیتورها',
		'return_create'     => 'ثبت درخواست مرجوعی',
		'return_approve'    => 'تأیید مرجوعی',
		'return_reject'     => 'رد مرجوعی',
		'return_cancel'     => 'لغو مرجوعی توسط مشتری',
		'return_delete'     => 'حذف درخواست مرجوعی',
		'gdrive_connect'    => 'اتصال / قطع گوگل درایو',
		'return_cleanup'    => 'پاک‌سازی عکس‌های مرجوعی از هاست',
	);

	public static function add( $action, $object_type = '', $object_id = 0, $details = '', $actor = '' ) {
		global $wpdb;
		$uid = get_current_user_id();
		if ( ! $actor ) {
			$actor = $uid ? ( bws_is_visitor( $uid ) ? 'visitor' : 'admin' ) : 'customer';
		}
		$wpdb->insert( BWS_Install::table( 'activity' ), array(
			'user_id'     => $uid,
			'actor'       => $actor,
			'action'      => $action,
			'object_type' => $object_type,
			'object_id'   => (int) $object_id,
			'details'     => is_array( $details ) ? wp_json_encode( $details, JSON_UNESCAPED_UNICODE ) : (string) $details,
			'ip'          => bws_client_ip(),
			'created_at'  => bws_now(),
		) );
	}

	public static function query( $args = array() ) {
		global $wpdb;
		$t     = BWS_Install::table( 'activity' );
		$where = array( '1=1' );
		$vals  = array();
		if ( ! empty( $args['object_type'] ) ) {
			$where[] = 'object_type = %s';
			$vals[]  = $args['object_type'];
		}
		if ( ! empty( $args['object_id'] ) ) {
			$where[] = 'object_id = %d';
			$vals[]  = $args['object_id'];
		}
		if ( ! empty( $args['user_id'] ) ) {
			$where[] = 'user_id = %d';
			$vals[]  = $args['user_id'];
		}
		$limit  = isset( $args['limit'] ) ? (int) $args['limit'] : 50;
		$offset = isset( $args['offset'] ) ? (int) $args['offset'] : 0;
		$sql    = "SELECT * FROM $t WHERE " . implode( ' AND ', $where ) . " ORDER BY id DESC LIMIT $offset, $limit";
		return $vals ? $wpdb->get_results( $wpdb->prepare( $sql, $vals ) ) : $wpdb->get_results( $sql );
	}

	public static function prune( $days = 365 ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . BWS_Install::table( 'activity' ) . ' WHERE created_at < %s', gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $days * DAY_IN_SECONDS ) ) );
	}
}
