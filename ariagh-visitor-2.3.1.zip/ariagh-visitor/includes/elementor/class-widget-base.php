<?php
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Border;

/** Shared style controls for all ARIAGH.VISITOR widgets. */
abstract class BWS_El_Base extends \Elementor\Widget_Base {

	public function get_categories() {
		return array( 'ariagh-visitor' );
	}

	public function get_keywords() {
		return array( 'visitor', 'wholesale', 'ویزیتور', 'عمده', 'ariagh', 'پنل' );
	}

	protected function style_controls( $sel = '.bws-ui' ) {
		$w = '{{WRAPPER}} ' . $sel;

		$this->start_controls_section( 'bws_colors', array( 'label' => 'رنگ‌ها', 'tab' => Controls_Manager::TAB_STYLE ) );
		$vars = array(
			'primary' => array( 'رنگ اصلی (دکمه‌ها، لینک‌ها)', '--bws-primary' ),
			'navy'    => array( 'رنگ تیره (نوار پایین سبد، تیترها)', '--bws-navy' ),
			'bg'      => array( 'پس‌زمینه پنل', '--bws-bg' ),
			'surface' => array( 'پس‌زمینه کارت‌ها', '--bws-surface' ),
			'text'    => array( 'رنگ متن', '--bws-text' ),
			'muted'   => array( 'متن کم‌رنگ', '--bws-muted' ),
			'border'  => array( 'رنگ خطوط و حاشیه', '--bws-border' ),
			'green'   => array( 'رنگ موفقیت / اعتبار', '--bws-green' ),
			'red'     => array( 'رنگ خطا / بدهی', '--bws-red' ),
		);
		foreach ( $vars as $k => $v ) {
			$this->add_control( 'bws_c_' . $k, array(
				'label'     => $v[0],
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( $w => $v[1] . ': {{VALUE}};' . ( 'primary' === $k ? '--bws-primary-600: color-mix(in srgb, {{VALUE}} 82%, #000); --bws-primary-50: color-mix(in srgb, {{VALUE}} 7%, #fff); --bws-primary-100: color-mix(in srgb, {{VALUE}} 16%, #fff);' : '' ) ),
			) );
		}
		$this->end_controls_section();

		$this->start_controls_section( 'bws_shape', array( 'label' => 'ظاهر و فاصله‌ها', 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'bws_radius', array(
			'label'      => 'گردی گوشه‌ها',
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range'      => array( 'px' => array( 'min' => 0, 'max' => 32 ) ),
			'selectors'  => array( $w => '--bws-radius: {{SIZE}}{{UNIT}}; --bws-radius-sm: calc({{SIZE}}{{UNIT}} * .62);' ),
		) );
		$this->add_responsive_control( 'bws_maxw', array(
			'label'      => 'حداکثر عرض',
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( 'px', '%', 'vw' ),
			'range'      => array( 'px' => array( 'min' => 320, 'max' => 1920 ) ),
			'selectors'  => array( $w => 'max-width: {{SIZE}}{{UNIT}}; margin-inline: auto;' ),
		) );
		$this->add_responsive_control( 'bws_pad', array(
			'label'      => 'فاصله داخلی',
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px', 'em', '%' ),
			'selectors'  => array( $w => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );
		$this->add_group_control( Group_Control_Border::get_type(), array( 'name' => 'bws_border', 'selector' => $w ) );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), array( 'name' => 'bws_shadow', 'selector' => $w ) );
		$this->end_controls_section();

		$this->start_controls_section( 'bws_type', array( 'label' => 'تایپوگرافی', 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'bws_font_inherit', array(
			'label'        => 'استفاده از فونت قالب سایت',
			'type'         => Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'selectors'    => array( $w => '--bws-font: inherit;' ),
		) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'bws_typo', 'label' => 'متن پنل', 'selector' => $w ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'bws_typo_h', 'label' => 'تیترها', 'selector' => $w . ' h1, ' . $w . ' h2, ' . $w . ' h3' ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array( 'name' => 'bws_typo_btn', 'label' => 'دکمه‌ها', 'selector' => $w . ' .bws-btn' ) );
		$this->end_controls_section();
	}

	protected function editor_note( $text ) {
		if ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			echo '<div style="font:12px/1.6 Tahoma;background:#eef4ff;border:1px dashed #9db8f5;color:#1e3a8a;padding:6px 10px;border-radius:8px;margin-bottom:8px;direction:rtl">' . esc_html( $text ) . '</div>';
		}
	}
}
