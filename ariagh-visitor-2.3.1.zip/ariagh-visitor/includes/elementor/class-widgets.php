<?php
defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;

class BWS_El_Customer_Panel extends BWS_El_Base {
	public function get_name() { return 'bws-customer-panel'; }
	public function get_title() { return 'پنل خرید همکاران (مشتری)'; }
	public function get_icon() { return 'eicon-cart'; }

	protected function register_controls() {
		$this->start_controls_section( 'c', array( 'label' => 'پنل مشتری' ) );
		$this->add_control( 'info', array( 'type' => Controls_Manager::RAW_HTML, 'raw' => 'ورود با کد اختصاصی، فهرست محصولات با قیمت همکار، سبد خرید، سفارش‌ها و اعتبار. فقط یک پنل در هر برگه قرار دهید. برای نمایش تمام‌صفحه، قالب برگه را «Elementor Canvas» یا «تمام عرض» انتخاب کنید.', 'content_classes' => 'elementor-descriptor' ) );
		$this->end_controls_section();
		$this->style_controls( '#bws-app' );
	}

	protected function render() {
		$this->editor_note( 'پیش‌نمایش زنده پنل مشتری — رنگ‌ها و فونت را از تب «استایل» تغییر دهید.' );
		echo do_shortcode( '[bws_customer_panel]' ); // phpcs:ignore
	}
}

class BWS_El_Visitor_Panel extends BWS_El_Base {
	public function get_name() { return 'bws-visitor-panel'; }
	public function get_title() { return 'پنل ویزیتور'; }
	public function get_icon() { return 'eicon-person'; }

	protected function register_controls() {
		$this->start_controls_section( 'c', array( 'label' => 'پنل ویزیتور' ) );
		$this->add_control( 'info', array( 'type' => Controls_Manager::RAW_HTML, 'raw' => 'فرم ورود ویزیتور و پنل کامل ثبت مشتری، سفارش، پرداخت، ویزیت و پیامک. امکانات هر ویزیتور از «ویزیتور ← ویزیتورها ← دسترسی‌ها» تعیین می‌شود.', 'content_classes' => 'elementor-descriptor' ) );
		$this->end_controls_section();
		$this->style_controls( '.bws-front' );
	}

	protected function render() {
		$this->editor_note( 'پیش‌نمایش پنل ویزیتور (شما به‌عنوان مدیر وارد شده‌اید).' );
		echo do_shortcode( '[bws_visitor_panel]' ); // phpcs:ignore
	}
}

class BWS_El_Code_Login extends BWS_El_Base {
	public function get_name() { return 'bws-code-login'; }
	public function get_title() { return 'فرم ورود با کد (همکاران)'; }
	public function get_icon() { return 'eicon-lock-user'; }

	protected function register_controls() {
		$this->start_controls_section( 'c', array( 'label' => 'محتوا' ) );
		$this->add_control( 'title', array( 'label' => 'عنوان', 'type' => Controls_Manager::TEXT, 'default' => 'ورود همکاران' ) );
		$this->add_control( 'placeholder', array( 'label' => 'متن داخل کادر', 'type' => Controls_Manager::TEXT, 'default' => 'کد اختصاصی خود را وارد کنید' ) );
		$this->add_control( 'button', array( 'label' => 'متن دکمه', 'type' => Controls_Manager::TEXT, 'default' => 'ورود به پنل خرید' ) );
		$this->add_control( 'visitor_link', array( 'label' => 'لینک ورود ویزیتورها', 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => 'yes' ) );
		$this->end_controls_section();
		$this->style_controls( '.bws-ui' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo do_shortcode( sprintf( '[bws_code_login title="%s" placeholder="%s" button="%s" visitor_link="%s"]', esc_attr( $s['title'] ), esc_attr( $s['placeholder'] ), esc_attr( $s['button'] ), 'yes' === $s['visitor_link'] ? 'yes' : 'no' ) ); // phpcs:ignore
	}
}

class BWS_El_Leaderboard extends BWS_El_Base {
	public function get_name() { return 'bws-leaderboard'; }
	public function get_title() { return 'برترین‌ها (ویزیتور/مشتری)'; }
	public function get_icon() { return 'eicon-number-field'; }

	protected function register_controls() {
		$this->start_controls_section( 'c', array( 'label' => 'محتوا' ) );
		$this->add_control( 'type', array( 'label' => 'نوع', 'type' => Controls_Manager::SELECT, 'default' => 'visitors', 'options' => array( 'visitors' => 'ویزیتورهای برتر', 'customers' => 'مشتریان برتر' ) ) );
		$this->add_control( 'period', array( 'label' => 'بازه', 'type' => Controls_Manager::SELECT, 'default' => 'month', 'options' => BWS_Stats::$periods ) );
		$this->add_control( 'limit', array( 'label' => 'تعداد', 'type' => Controls_Manager::NUMBER, 'default' => 5, 'min' => 1, 'max' => 20 ) );
		$this->add_control( 'sales', array( 'label' => 'نمایش مبلغ فروش', 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes' ) );
		$this->add_control( 'public', array( 'label' => 'نمایش برای همه بازدیدکنندگان', 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'description' => 'خاموش: مشتریان برتر فقط برای ویزیتورها و مدیر نمایش داده می‌شود.' ) );
		$this->add_control( 'title', array( 'label' => 'عنوان (اختیاری)', 'type' => Controls_Manager::TEXT ) );
		$this->end_controls_section();
		$this->style_controls( '.bws-ui' );
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		echo do_shortcode( sprintf( '[bws_leaderboard type="%s" period="%s" limit="%d" sales="%s" public="%s" title="%s"]', esc_attr( $s['type'] ), esc_attr( $s['period'] ), (int) $s['limit'], 'yes' === $s['sales'] ? 'yes' : 'no', 'yes' === $s['public'] ? 'yes' : 'no', esc_attr( $s['title'] ) ) ); // phpcs:ignore
	}
}
