<?php
defined( 'ABSPATH' ) || exit;

/** Printable customer card and order invoice (thermal 80mm or A5/A4). */
class BWS_Print {

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'route' ), 2 );
	}

	public static function urls( $c ) {
		$base = add_query_arg( array( 'bws_print' => 'card', 'customer' => $c->id, '_bwsn' => wp_create_nonce( 'bws_print' ) ), home_url( '/' ) );
		return array(
			'thermal' => add_query_arg( 'format', '80', $base ),
			'a5'      => add_query_arg( 'format', 'a5', $base ),
		);
	}

	public static function order_urls( $order_id, $token = '' ) {
		$args = array( 'bws_print' => 'order', 'order' => $order_id );
		if ( $token ) {
			$args['t'] = rawurlencode( $token );
		} else {
			$args['_bwsn'] = wp_create_nonce( 'bws_print' );
		}
		$base = add_query_arg( $args, home_url( '/' ) );
		return array( 'thermal' => add_query_arg( 'format', '80', $base ), 'a5' => add_query_arg( 'format', 'a5', $base ) );
	}

	public static function route() {
		if ( empty( $_GET['bws_print'] ) ) {
			return;
		}
		$type   = sanitize_key( $_GET['bws_print'] );
		$format = isset( $_GET['format'] ) && '80' === $_GET['format'] ? '80' : 'a5';
		$staff  = is_user_logged_in() && ( bws_is_manager() || ( bws_is_visitor() && bws_visitor_active( get_current_user_id() ) && BWS_Perms::can( 'print' ) ) ) && isset( $_GET['_bwsn'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_bwsn'] ) ), 'bws_print' );

		if ( 'card' === $type ) {
			$c = BWS_Customers::get( isset( $_GET['customer'] ) ? (int) $_GET['customer'] : 0 );
			if ( ! $staff || ! $c || ! BWS_Auth::can_view_customer( $c ) ) {
				wp_die( 'دسترسی ندارید.', '', array( 'response' => 403 ) );
			}
			self::render_card( $c, $format );
			exit;
		}
		if ( 'order' === $type ) {
			$order = wc_get_order( isset( $_GET['order'] ) ? (int) $_GET['order'] : 0 );
			if ( ! $order || ! $order->get_meta( '_bws_wholesale' ) ) {
				wp_die( 'سفارش یافت نشد.', '', array( 'response' => 404 ) );
			}
			$c       = BWS_Customers::get( (int) $order->get_meta( '_bws_customer_id' ) );
			$allowed = $staff && $c && BWS_Auth::can_view_customer( $c );
			if ( ! $allowed && ! empty( $_GET['t'] ) ) {
				$tc      = BWS_Auth::customer_from_token( rawurldecode( sanitize_text_field( wp_unslash( $_GET['t'] ) ) ) );
				$allowed = $tc && $c && (int) $tc->id === (int) $c->id;
			}
			if ( ! $allowed ) {
				wp_die( 'دسترسی ندارید.', '', array( 'response' => 403 ) );
			}
			self::render_order( $order, $c, $format );
			exit;
		}
	}

	protected static function head( $title, $format ) {
		$font = BWS_URL . 'assets/fonts/';
		$w    = '80' === $format ? '72mm' : '100%';
		$page = '80' === $format ? '@page{size:80mm auto;margin:3mm}' : '@page{size:A5;margin:10mm}';
		?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
		<title><?php echo esc_html( $title ); ?></title>
		<style>
		@font-face{font-family:Vazirmatn;src:url(<?php echo esc_url( $font ); ?>Vazirmatn-Regular.woff2) format('woff2');font-weight:400}
		@font-face{font-family:Vazirmatn;src:url(<?php echo esc_url( $font ); ?>Vazirmatn-Bold.woff2) format('woff2');font-weight:700}
		<?php echo $page; // phpcs:ignore ?>
		*{box-sizing:border-box}body{font-family:Vazirmatn,Tahoma,sans-serif;margin:0;color:#000;background:#fff;font-size:<?php echo '80' === $format ? '12px' : '13px'; ?>}
		.sheet{width:<?php echo esc_attr( $w ); ?>;margin:0 auto;padding:<?php echo '80' === $format ? '0' : '6mm'; ?>}
		.c{text-align:center}.logo{max-height:48px;max-width:60%}
		h1{font-size:1.35em;margin:4px 0}h2{font-size:1.1em;margin:6px 0}
		.code{font-size:<?php echo '80' === $format ? '26px' : '34px'; ?>;font-weight:700;letter-spacing:3px;border:2px dashed #000;padding:6px 4px;margin:8px 0;text-align:center;direction:ltr}
		table{width:100%;border-collapse:collapse}td,th{padding:3px 2px;vertical-align:top;text-align:right}
		.kv td:first-child{color:#444;white-space:nowrap;width:1%;padding-left:8px}
		.items th{border-bottom:1px solid #000;font-size:.92em}.items td{border-bottom:1px dotted #999}
		.tot td{font-weight:700}.hr{border-top:1px dashed #000;margin:8px 0}
		.qr{display:flex;justify-content:center;margin:6px 0}.qr img,.qr svg{width:<?php echo '80' === $format ? '120px' : '140px'; ?>;height:auto}
		.small{font-size:.85em;color:#333}.ltr{direction:ltr;unicode-bidi:embed}
		.noprint{display:flex;gap:6px;justify-content:center;padding:8px;background:#f3f3f3;margin-bottom:8px}
		.noprint button{font-family:inherit;padding:6px 14px;border:1px solid #333;background:#fff;border-radius:6px;cursor:pointer}
		@media print{.noprint{display:none}}
		</style>
		<script src="<?php echo esc_url( BWS_Frontend::js( 'qrcode' ) ); ?>"></script>
		</head><body><div class="noprint"><button onclick="window.print()">چاپ</button><button onclick="window.close()">بستن</button></div><div class="sheet">
		<?php
	}

	protected static function brand() {
		$logo = bws_opt( 'company_logo' );
		echo '<div class="c">';
		if ( $logo ) {
			echo '<img class="logo" src="' . esc_url( $logo ) . '" alt=""><br>';
		}
		echo '<h1>' . esc_html( bws_opt( 'company_name' ) ) . '</h1>';
		if ( bws_opt( 'company_phone' ) ) {
			echo '<div class="small">تلفن: <span class="ltr">' . esc_html( bws_opt( 'company_phone' ) ) . '</span></div>';
		}
		echo '</div>';
	}

	protected static function foot() {
		echo '</div><script>window.addEventListener("load",function(){document.querySelectorAll("[data-qr]").forEach(function(el){try{var q=qrcode(0,"M");q.addData(el.getAttribute("data-qr"));q.make();el.innerHTML=q.createSvgTag({cellSize:4,margin:2});}catch(e){}});setTimeout(function(){window.print()},400);});</script></body></html>';
	}

	public static function render_card( $c, $format ) {
		$s = BWS_Ledger::summary( $c );
		self::head( 'کارت مشتری ' . $c->code, $format );
		self::brand();
		echo '<div class="hr"></div><h2 class="c">کارت همکار فروش عمده</h2>';
		echo '<table class="kv">';
		echo '<tr><td>نام:</td><td><strong>' . esc_html( BWS_Customers::full_name( $c ) ) . '</strong></td></tr>';
		if ( $c->shop_name ) {
			echo '<tr><td>فروشگاه:</td><td>' . esc_html( $c->shop_name ) . '</td></tr>';
		}
		echo '<tr><td>موبایل:</td><td class="ltr" style="text-align:right">' . esc_html( $c->mobile ) . '</td></tr>';
		echo '<tr><td>آدرس:</td><td>' . esc_html( implode( '، ', array_filter( array( $c->province, $c->city, $c->address ) ) ) ) . '</td></tr>';
		echo '<tr><td>اعتبار خرید:</td><td>' . esc_html( $s['limit_text'] ) . '</td></tr>';
		echo '<tr><td>ویزیتور:</td><td>' . esc_html( bws_user_name( $c->visitor_id ) ) . '</td></tr>';
		echo '<tr><td>تاریخ ثبت:</td><td>' . esc_html( bws_jdate( $c->created_at, false ) ) . '</td></tr>';
		echo '</table>';
		echo '<div class="c small" style="margin-top:8px">کد اختصاصی شما</div><div class="code">' . esc_html( $c->code ) . '</div>';
		if ( bws_opt( 'print_qr' ) ) {
			echo '<div class="qr" data-qr="' . esc_attr( bws_customer_panel_url( $c->code ) ) . '"></div>';
		}
		echo '<div class="c small">ورود به پنل خرید عمده:<br><span class="ltr">' . esc_html( preg_replace( '#^https?://#', '', bws_customer_panel_url() ) ) . '</span></div>';
		echo '<div class="hr"></div><div class="c small">' . esc_html( bws_opt( 'print_footer' ) ) . '</div>';
		self::foot();
	}

	public static function render_order( $order, $c, $format ) {
		self::head( 'فاکتور سفارش ' . $order->get_id(), $format );
		self::brand();
		$created = $order->get_date_created();
		echo '<div class="hr"></div><h2 class="c">فاکتور فروش عمده</h2>';
		echo '<table class="kv">';
		echo '<tr><td>شماره سفارش:</td><td><strong>' . esc_html( bws_fa_digits( $order->get_id() ) ) . '</strong></td></tr>';
		echo '<tr><td>تاریخ:</td><td>' . esc_html( $created ? bws_jdate( $created->getTimestamp() ) : '' ) . '</td></tr>';
		echo '<tr><td>مشتری:</td><td>' . esc_html( $c ? BWS_Customers::full_name( $c ) . ' (کد ' . $c->code . ')' : '' ) . '</td></tr>';
		if ( $c && $c->shop_name ) {
			echo '<tr><td>فروشگاه:</td><td>' . esc_html( $c->shop_name ) . '</td></tr>';
		}
		if ( $c ) {
			echo '<tr><td>موبایل:</td><td>' . esc_html( $c->mobile ) . '</td></tr>';
			echo '<tr><td>آدرس:</td><td>' . esc_html( implode( '، ', array_filter( array( $c->city, $c->address ) ) ) ) . '</td></tr>';
		}
		echo '<tr><td>وضعیت:</td><td>' . esc_html( BWS_Orders::status_label( $order->get_status() ) ) . '</td></tr>';
		echo '</table><div class="hr"></div>';
		echo '<table class="items"><thead><tr><th>کالا</th><th>تعداد</th><th>فی</th><th>جمع</th></tr></thead><tbody>';
		$qty = 0;
		foreach ( $order->get_items() as $it ) {
			$q    = (int) $it->get_quantity();
			$qty += $q;
			echo '<tr><td>' . esc_html( $it->get_name() ) . '</td><td>' . esc_html( bws_fa_digits( $q ) ) . '</td><td>' . esc_html( number_format( $q ? $it->get_total() / $q : 0 ) ) . '</td><td>' . esc_html( number_format( $it->get_total() ) ) . '</td></tr>';
		}
		echo '</tbody></table><div class="hr"></div><table class="kv">';
		echo '<tr><td>تعداد کل:</td><td>' . esc_html( bws_fa_digits( $qty ) ) . ' عدد</td></tr>';
		echo '<tr><td>جمع به قیمت مصرف‌کننده:</td><td>' . esc_html( bws_money_text( $order->get_meta( '_bws_retail_total' ) ) ) . '</td></tr>';
		echo '<tr class="tot"><td>جمع عمده:</td><td>' . esc_html( bws_money_text( $order->get_meta( '_bws_wholesale_total' ) ) ) . '</td></tr>';
		echo '<tr><td>از اعتبار:</td><td>' . esc_html( bws_money_text( $order->get_meta( '_bws_credit_used' ) ) ) . '</td></tr>';
		$m = $order->get_meta( '_bws_excess_method' );
		echo '<tr class="tot"><td>پرداخت مستقیم:</td><td>' . esc_html( bws_money_text( $order->get_meta( '_bws_excess' ) ) ) . ( $m ? ' (' . ( 'online' === $m ? 'آنلاین' : 'حضوری' ) . ')' : '' ) . '</td></tr>';
		echo '</table>';
		if ( $order->get_customer_note() ) {
			echo '<div class="hr"></div><div class="small">توضیحات: ' . esc_html( $order->get_customer_note() ) . '</div>';
		}
		echo '<div class="hr"></div><div class="c small">امضای تحویل‌گیرنده: ....................</div>';
		self::foot();
	}
}
