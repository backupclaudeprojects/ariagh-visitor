<?php
defined( 'ABSPATH' ) || exit;

/**
 * SMS events (when a message is sent) and the variables each one can use.
 * Every variable is documented with a description and an example so the admin
 * guide, the live preview and the validator all use the same source of truth.
 */
class BWS_Events {

	/** Variable groups: name => [ label, description, example ]. */
	public static function variables() {
		return array(
			'customer' => array(
				'label' => 'اطلاعات مشتری',
				'vars'  => array(
					'name'             => array( 'نام مشتری', 'نام کوچک؛ اگر نام کوچک ثبت نشده باشد نام کامل', 'علی' ),
					'first_name'       => array( 'نام', 'نام کوچک مشتری', 'علی' ),
					'last_name'        => array( 'نام خانوادگی', 'نام خانوادگی مشتری', 'رضایی' ),
					'full_name'        => array( 'نام کامل', 'نام و نام خانوادگی', 'علی رضایی' ),
					'shop'             => array( 'نام فروشگاه', 'نام فروشگاه/شرکت مشتری (ممکن است خالی باشد)', 'سوپرمارکت آفتاب' ),
					'code'             => array( 'کد اختصاصی', 'کد ورود مشتری به پنل', '48291736' ),
					'mobile'           => array( 'موبایل مشتری', 'شماره موبایل با فرمت 09', '09121234567' ),
					'city'             => array( 'شهر', 'شهر مشتری', 'تهران' ),
					'link'             => array( 'لینک ورود مستقیم', 'آدرس پنل خرید که کد مشتری داخلش است؛ با یک لمس وارد می‌شود', 'https://example.ir/buy-panel/?code=48291736' ),
					'panel_url'        => array( 'آدرس پنل خرید', 'آدرس صفحه پنل خرید بدون کد', 'https://example.ir/buy-panel/' ),
					'credit_limit'     => array( 'سقف اعتبار', 'سقف اعتبار خرید مشتری', '10,000,000 تومان' ),
					'credit_used'      => array( 'اعتبار مصرف‌شده', 'مبلغی از اعتبار که استفاده شده و باید تسویه شود', '6,000,000 تومان' ),
					'credit_available' => array( 'اعتبار باقیمانده', 'اعتباری که هنوز برای خرید قابل استفاده است', '4,000,000 تومان' ),
					'debt'             => array( 'بدهی', 'مبلغ قابل تسویه (همان اعتبار مصرف‌شده)', '6,000,000 تومان' ),
					'visitor_name'     => array( 'نام ویزیتور', 'ویزیتور مسئول این مشتری', 'سارا کریمی' ),
					'visitor_mobile'   => array( 'موبایل ویزیتور', 'شماره ویزیتور مسئول', '09351234567' ),
				),
			),
			'general'  => array(
				'label' => 'عمومی',
				'vars'  => array(
					'company'       => array( 'نام شرکت', 'از تنظیمات ← اطلاعات شرکت', 'شرکت نمونه' ),
					'company_phone' => array( 'تلفن شرکت', 'از تنظیمات ← اطلاعات شرکت', '021-12345678' ),
					'site_url'      => array( 'آدرس سایت', 'آدرس صفحه اصلی سایت', 'https://example.ir' ),
					'date'          => array( 'تاریخ امروز', 'تاریخ شمسی', '۱۴۰۵/۰۷/۱۸' ),
					'time'          => array( 'ساعت', 'ساعت فعلی', '۱۴:۳۰' ),
				),
			),
			'order'    => array(
				'label' => 'سفارش',
				'vars'  => array(
					'order_id'      => array( 'شماره سفارش', 'شماره سفارش ووکامرس', '1250' ),
					'order_total'   => array( 'مبلغ سفارش', 'جمع سفارش به قیمت عمده', '12,000,000 تومان' ),
					'order_credit'  => array( 'کسر از اعتبار', 'مبلغی از این سفارش که از اعتبار کم شد', '10,000,000 تومان' ),
					'excess'        => array( 'مبلغ مازاد', 'مبلغی که باید مستقیم پرداخت شود', '2,000,000 تومان' ),
					'excess_method' => array( 'روش پرداخت مازاد', 'آنلاین / حضوری', 'آنلاین' ),
					'items_count'   => array( 'تعداد اقلام', 'جمع تعداد محصولات سفارش', '۲۴' ),
					'order_status'  => array( 'وضعیت سفارش', 'وضعیت فعلی سفارش', 'تکمیل شده' ),
					'pay_url'       => array( 'لینک پرداخت', 'لینک پرداخت آنلاین مبلغ مازاد', 'https://example.ir/checkout/order-pay/1250/?…' ),
					'by'            => array( 'ثبت توسط', 'خود مشتری یا نام ویزیتور/مدیر', 'سارا کریمی' ),
				),
			),
			'payment'  => array(
				'label' => 'پرداخت',
				'vars'  => array(
					'amount'    => array( 'مبلغ پرداخت', 'مبلغ دریافت‌شده', '6,000,000 تومان' ),
					'method'    => array( 'روش پرداخت', 'نقدی، کارت‌به‌کارت، چک، آنلاین …', 'کارت‌به‌کارت' ),
					'reference' => array( 'شماره پیگیری', 'شماره پیگیری یا شماره چک (اگر ثبت شده باشد)', '458712' ),
				),
			),
			'otp'      => array(
				'label' => 'رمز یک‌بار مصرف',
				'vars'  => array(
					'otp'     => array( 'رمز یک‌بار مصرف', 'کد تأیید ورود', '58213' ),
					'minutes' => array( 'مدت اعتبار', 'چند دقیقه معتبر است', '۳' ),
				),
			),
			'return'   => array(
				'label' => 'مرجوعی',
				'vars'  => array(
					'return_code'   => array( 'کد پیگیری مرجوعی', 'شماره پیگیری درخواست مرجوعی', 'R-1023' ),
					'return_status' => array( 'وضعیت مرجوعی', 'در انتظار بررسی / تأیید شد / رد شد / لغو شد', 'تأیید شد' ),
					'return_reason' => array( 'دلیل مرجوعی', 'دلیل انتخاب‌شده توسط مشتری', 'کپک‌زدگی محصول' ),
					'return_items'  => array( 'اقلام مرجوعی', 'نام و تعداد کالاها (خلاصه)', 'کیمچی ۵۰۰ گرمی × ۳' ),
					'return_order'  => array( 'شماره سفارش مرجوعی', 'سفارشی که کالا از آن مرجوع شده', '1250' ),
					'return_note'   => array( 'توضیح بررسی‌کننده', 'یادداشت ویزیتور/مدیر هنگام تأیید یا رد', 'کالای جایگزین فردا ارسال می‌شود' ),
					'return_result' => array( 'نتیجه', 'برگشت به اعتبار / ارسال کالای جایگزین / تسویه حضوری', 'برگشت به اعتبار' ),
					'return_amount' => array( 'مبلغ برگشتی', 'مبلغی که به اعتبار برگشت (در صورت برگشت به اعتبار)', '390,000 تومان' ),
				),
			),
			'visitor'  => array(
				'label' => 'حساب ویزیتور',
				'vars'  => array(
					'visitor_name'      => array( 'نام ویزیتور', 'نام نمایشی ویزیتور', 'سارا کریمی' ),
					'username'          => array( 'نام کاربری', 'نام کاربری ورود ویزیتور', 'sara' ),
					'password'          => array( 'رمز عبور', 'رمز اولیه (فقط هنگام ساخت حساب)', 'X7k2p9Qa' ),
					'visitor_panel_url' => array( 'آدرس پنل ویزیتور', 'لینک ورود ویزیتورها', 'https://example.ir/visitor-panel/' ),
				),
			),
		);
	}

	/** Flat list name => [label, desc, example]. */
	public static function flat_vars() {
		$out = array();
		foreach ( self::variables() as $g ) {
			foreach ( $g['vars'] as $k => $v ) {
				$out[ $k ] = $v;
			}
		}
		return $out;
	}

	/**
	 * Events. groups = variable groups usable in that event.
	 */
	public static function all() {
		return array(
			'welcome'        => array(
				'label'          => 'خوش‌آمد و ارسال کد',
				'desc'           => 'بلافاصله بعد از ثبت مشتری جدید (توسط ویزیتور، مدیر یا ورود گروهی)',
				'groups'         => array( 'customer', 'general' ),
				'to'             => 'customer',
				'toggle'         => 'sms_on_create',
				'toggle_default' => 1,
				'default'        => "سلام {name} عزیز.\nبه جمع همکاران {company} خوش آمدید.\nکد اختصاصی شما: {code}\nورود به پنل خرید:\n{link}",
				'pattern_hint'   => "name={name}\ncode={code}",
			),
			'login_link'     => array(
				'label'          => 'لینک ورود به پنل',
				'desc'           => 'دکمه «ارسال لینک ورود» در پرونده مشتری و پیامک گروهی',
				'groups'         => array( 'customer', 'general' ),
				'to'             => 'customer',
				'toggle'         => '',
				'toggle_default' => 0,
				'default'        => "سلام {name} عزیز.\nاین پیامک از طرف {company} برای شما ارسال شده است.\nلطفا جهت ثبت سفارش جدید وارد لینک زیر شوید\n{panel_url}\nکد شما {code}",
				'pattern_hint'   => "name={name}\ncode={code}",
			),
			'otp'            => array(
				'label'          => 'رمز یک‌بار مصرف ورود',
				'desc'           => 'وقتی ورود دومرحله‌ای یا «ورود با موبایل» فعال است',
				'groups'         => array( 'otp', 'general' ),
				'to'             => 'customer',
				'toggle'         => '',
				'toggle_default' => 0,
				'default'        => "کد ورود شما به پنل {company}: {otp}\nاین کد {minutes} دقیقه معتبر است.",
				'pattern_hint'   => 'code={otp}',
			),
			'order'          => array(
				'label'          => 'ثبت سفارش (به مشتری)',
				'desc'           => 'بعد از ثبت هر سفارش عمده',
				'groups'         => array( 'customer', 'order', 'general' ),
				'to'             => 'customer',
				'toggle'         => 'sms_on_order',
				'toggle_default' => 1,
				'default'        => "{name} عزیز، سفارش شما به شماره {order_id} به مبلغ {order_total} ثبت شد.\nاز اعتبار: {order_credit}\nپرداخت مستقیم: {excess}\nاعتبار باقیمانده: {credit_available}\n{company}",
				'pattern_hint'   => "name={name}\norder={order_id}\ntotal={order_total}",
			),
			'order_admin'    => array(
				'label'          => 'سفارش جدید (به مدیران)',
				'desc'           => 'به شماره‌های «موبایل مدیران» در تنظیمات پیامک',
				'groups'         => array( 'customer', 'order', 'general' ),
				'to'             => 'admins',
				'toggle'         => 'sms_on_order_admin',
				'toggle_default' => 1,
				'default'        => "سفارش عمده جدید #{order_id}\nمشتری: {full_name} ({code})\nمبلغ: {order_total}\nثبت توسط: {by}",
				'pattern_hint'   => "order={order_id}\ncustomer={full_name}\ntotal={order_total}",
			),
			'order_status'   => array(
				'label'          => 'تغییر وضعیت سفارش',
				'desc'           => 'وقتی وضعیت سفارش به یکی از وضعیت‌های انتخاب‌شده تغییر کند (مثلاً تکمیل شده / ارسال شد)',
				'groups'         => array( 'customer', 'order', 'general' ),
				'to'             => 'customer',
				'toggle'         => 'sms_on_order_status',
				'toggle_default' => 0,
				'default'        => "{name} عزیز، وضعیت سفارش {order_id} به «{order_status}» تغییر کرد.\n{company}",
				'pattern_hint'   => "name={name}\norder={order_id}\nstatus={order_status}",
			),
			'pay_link'       => array(
				'label'          => 'لینک پرداخت مازاد',
				'desc'           => 'وقتی ویزیتور برای مشتری سفارش ثبت کند و مازاد آنلاین پرداخت شود',
				'groups'         => array( 'customer', 'order', 'general' ),
				'to'             => 'customer',
				'toggle'         => '',
				'toggle_default' => 0,
				'default'        => "{name} عزیز، سفارش {order_id} ثبت شد.\nبرای پرداخت مبلغ مازاد ({excess}) وارد لینک زیر شوید:\n{pay_url}\n{company}",
				'pattern_hint'   => "name={name}\norder={order_id}\namount={excess}",
			),
			'payment'        => array(
				'label'          => 'ثبت پرداخت / تسویه',
				'desc'           => 'وقتی پرداخت مشتری ثبت شود (حضوری یا آنلاین)',
				'groups'         => array( 'customer', 'payment', 'general' ),
				'to'             => 'customer',
				'toggle'         => 'sms_on_payment',
				'toggle_default' => 1,
				'default'        => "{name} عزیز، پرداخت {amount} در تاریخ {date} ثبت شد.\nبدهی فعلی: {debt}\nاعتبار قابل استفاده: {credit_available}\n{company}",
				'pattern_hint'   => "name={name}\namount={amount}\ndebt={debt}",
			),
			'reminder'       => array(
				'label'          => 'یادآوری تسویه بدهی',
				'desc'           => 'خودکار روزانه برای بدهی‌های قدیمی‌تر از مدت تعیین‌شده',
				'groups'         => array( 'customer', 'general' ),
				'to'             => 'customer',
				'toggle'         => 'reminder_enabled',
				'toggle_default' => 0,
				'default'        => "{name} عزیز، مبلغ {debt} از اعتبار خرید شما استفاده شده و در انتظار تسویه است.\nاعتبار باقیمانده: {credit_available}\nپرداخت آنلاین: {link}\n{company}",
				'pattern_hint'   => "name={name}\ndebt={debt}",
			),
			'credit_change'  => array(
				'label'          => 'تغییر سقف اعتبار',
				'desc'           => 'وقتی مدیر سقف اعتبار مشتری را تغییر دهد',
				'groups'         => array( 'customer', 'general' ),
				'to'             => 'customer',
				'toggle'         => 'sms_on_credit_change',
				'toggle_default' => 0,
				'default'        => "{name} عزیز، سقف اعتبار خرید شما به {credit_limit} تغییر کرد.\nاعتبار قابل استفاده: {credit_available}\n{company}",
				'pattern_hint'   => "name={name}\nlimit={credit_limit}",
			),
			'return_new'      => array(
				'label'          => 'ثبت درخواست مرجوعی (به مشتری)',
				'desc'           => 'بعد از ثبت درخواست مرجوعی؛ کد پیگیری برای مشتری ارسال می‌شود',
				'groups'         => array( 'customer', 'return', 'general' ),
				'to'             => 'customer',
				'toggle'         => 'sms_on_return',
				'toggle_default' => 1,
				'default'        => "{name} عزیز، درخواست مرجوعی شما با کد پیگیری {return_code} ثبت شد و پس از بررسی نتیجه اطلاع داده می‌شود.
{company}",
				'pattern_hint'   => "name={name}
code={return_code}",
			),
			'return_admin'    => array(
				'label'          => 'مرجوعی جدید (به مدیران)',
				'desc'           => 'به شماره‌های «موبایل مدیران»',
				'groups'         => array( 'customer', 'return', 'general' ),
				'to'             => 'admins',
				'toggle'         => 'sms_on_return_admin',
				'toggle_default' => 1,
				'default'        => "درخواست مرجوعی جدید {return_code}
مشتری: {full_name} ({code})
سفارش: {return_order}
اقلام: {return_items}
دلیل: {return_reason}",
				'pattern_hint'   => "code={return_code}
customer={full_name}
order={return_order}",
			),
			'return_visitor'  => array(
				'label'          => 'مرجوعی جدید (به ویزیتور مشتری)',
				'desc'           => 'به موبایل ویزیتور مسئول همان مشتری',
				'groups'         => array( 'customer', 'return', 'general' ),
				'to'             => 'visitor',
				'toggle'         => 'sms_on_return_visitor',
				'toggle_default' => 0,
				'default'        => "درخواست مرجوعی {return_code} از مشتری {full_name} ({shop}) ثبت شد.
اقلام: {return_items}
لطفاً بررسی کنید.",
				'pattern_hint'   => "code={return_code}
customer={full_name}",
			),
			'return_decision' => array(
				'label'          => 'نتیجه بررسی مرجوعی (به مشتری)',
				'desc'           => 'وقتی درخواست تأیید یا رد شود',
				'groups'         => array( 'customer', 'return', 'general' ),
				'to'             => 'customer',
				'toggle'         => 'sms_on_return_decision',
				'toggle_default' => 1,
				'default'        => "{name} عزیز، درخواست مرجوعی {return_code}: {return_status}
{return_result}
{return_note}
{company}",
				'pattern_hint'   => "name={name}
code={return_code}
status={return_status}",
			),
			'visitor_account' => array(
				'label'          => 'اطلاعات ورود ویزیتور',
				'desc'           => 'هنگام ساخت حساب ویزیتور (اگر تیک ارسال پیامک زده شود)',
				'groups'         => array( 'visitor', 'general' ),
				'to'             => 'visitor',
				'toggle'         => '',
				'toggle_default' => 0,
				'default'        => "{visitor_name} عزیز، حساب ویزیتوری شما در {company} ساخته شد.\nنام کاربری: {username}\nرمز عبور: {password}\nورود: {visitor_panel_url}",
				'pattern_hint'   => "name={visitor_name}\nuser={username}\npass={password}",
			),
		);
	}

	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/** Allowed variable names for an event. */
	public static function allowed_vars( $key ) {
		$e = self::get( $key );
		if ( ! $e ) {
			return array();
		}
		$groups = self::variables();
		$out    = array();
		foreach ( $e['groups'] as $g ) {
			$out = array_merge( $out, array_keys( $groups[ $g ]['vars'] ) );
		}
		// Legacy alias used by older templates.
		if ( in_array( 'order', $e['groups'], true ) ) {
			$out[] = 'credit_used';
		}
		return array_values( array_unique( $out ) );
	}

	/** Find {placeholders} used in a text that are not available for this event. */
	public static function unknown_vars( $key, $text ) {
		preg_match_all( '/\{([a-z0-9_]+)\}/i', (string) $text, $m );
		$allowed = self::allowed_vars( $key );
		return array_values( array_unique( array_diff( $m[1], $allowed ) ) );
	}

	/** Example values for previews. */
	public static function sample_vars() {
		$out = array();
		foreach ( self::flat_vars() as $k => $v ) {
			$out[ $k ] = $v[2];
		}
		$out['company'] = bws_opt( 'company_name' );
		$out['date']    = bws_jdate( bws_now(), false );
		return $out;
	}

	/**
	 * Parse pattern parameter lines "param=value template" into [param => template].
	 */
	public static function parse_params( $lines ) {
		$out = array();
		foreach ( preg_split( '/\r?\n/', (string) $lines ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, '=' ) ) {
				continue;
			}
			list( $k, $v ) = array_map( 'trim', explode( '=', $line, 2 ) );
			if ( '' !== $k ) {
				$out[ $k ] = $v;
			}
		}
		return $out;
	}
}
