<?php
defined( 'ABSPATH' ) || exit;

/**
 * Google Drive storage (Drive API v3).
 *
 * Two connection modes:
 *  - oauth   : personal Gmail. OAuth 2.0 web flow, scope drive.file (the app only sees files it creates, so the
 *              plugin creates its own folder). The consent screen must be "In production", otherwise Google
 *              expires the refresh token after 7 days.
 *  - service : Google Workspace service account (JSON key) + a folder inside a Shared Drive; service accounts
 *              have no storage quota of their own, so a Shared Drive is required. Scope: drive.
 * Upload: POST https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true
 */
class BWS_GDrive {

	const SCOPE_OAUTH   = 'https://www.googleapis.com/auth/drive.file';
	const SCOPE_SERVICE = 'https://www.googleapis.com/auth/drive';
	const FOLDER_MIME   = 'application/vnd.google-apps.folder';

	public static function init() {
		add_action( 'admin_post_bws_gdrive_connect', array( __CLASS__, 'connect' ) );
		add_action( 'admin_post_bws_gdrive_oauth', array( __CLASS__, 'oauth_callback' ) );
		add_action( 'admin_post_bws_gdrive_disconnect', array( __CLASS__, 'disconnect' ) );
	}

	public static function redirect_uri() {
		return admin_url( 'admin-post.php?action=bws_gdrive_oauth' );
	}

	public static function mode() {
		return 'service' === bws_opt( 'gdrive_mode' ) ? 'service' : 'oauth';
	}

	public static function configured() {
		if ( 'service' === self::mode() ) {
			return (bool) self::sa() && '' !== trim( (string) bws_opt( 'gdrive_sa_folder_id' ) );
		}
		return '' !== bws_decrypt( (string) bws_opt( 'gdrive_refresh_token' ) ) && bws_opt( 'gdrive_client_id' );
	}

	protected static function sa() {
		$j = json_decode( bws_decrypt( (string) bws_opt( 'gdrive_sa_json' ) ), true );
		return is_array( $j ) && ! empty( $j['client_email'] ) && ! empty( $j['private_key'] ) ? $j : null;
	}

	protected static function b64url( $s ) {
		return rtrim( strtr( base64_encode( $s ), '+/', '-_' ), '=' );
	}

	protected static function http( $method, $url, $args = array() ) {
		$args = wp_parse_args( $args, array( 'method' => $method, 'timeout' => 45, 'redirection' => 2, 'user-agent' => 'ARIAGH.VISITOR/' . BWS_VERSION ) );
		$res  = wp_remote_request( $url, $args );
		if ( is_wp_error( $res ) ) {
			return new WP_Error( 'gd_http', 'خطای اتصال به گوگل: ' . $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$j    = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( $code >= 200 && $code < 300 ) {
			return is_array( $j ) ? $j : array();
		}
		$msg = isset( $j['error']['message'] ) ? $j['error']['message'] : ( isset( $j['error_description'] ) ? $j['error_description'] : ( isset( $j['error'] ) && is_string( $j['error'] ) ? $j['error'] : 'HTTP ' . $code ) );
		return new WP_Error( 'gd_api', self::explain( (string) $msg, $code ), array( 'status' => $code ) );
	}

	protected static function explain( $msg, $code ) {
		$m = strtolower( $msg );
		if ( false !== strpos( $m, 'invalid_grant' ) ) {
			return 'اتصال گوگل‌درایو منقضی یا لغو شده است؛ دوباره «اتصال به گوگل» را بزنید. (اگر هر ۷ روز تکرار می‌شود، وضعیت OAuth consent screen را روی In production بگذارید.)';
		}
		if ( false !== strpos( $m, 'storage quota' ) ) {
			return 'حساب سرویس فضای ذخیره ندارد؛ پوشه باید داخل یک Shared Drive باشد و حساب سرویس عضو آن باشد. (' . $msg . ')';
		}
		if ( 404 === $code ) {
			return 'پوشه یا فایل پیدا نشد یا حساب دسترسی ندارد (' . $msg . ')';
		}
		return $msg;
	}

	/** Access token (cached ~50 minutes). */
	public static function token() {
		$key    = 'bws_gd_at_' . md5( self::mode() . bws_opt( 'gdrive_client_id' ) . bws_opt( 'gdrive_sa_json' ) . bws_opt( 'gdrive_refresh_token' ) );
		$cached = get_transient( $key );
		if ( $cached ) {
			return bws_decrypt( $cached );
		}
		if ( 'service' === self::mode() ) {
			$sa = self::sa();
			if ( ! $sa ) {
				return new WP_Error( 'gd_cfg', 'فایل JSON حساب سرویس معتبر نیست.' );
			}
			$now   = time();
			$aud   = ! empty( $sa['token_uri'] ) ? $sa['token_uri'] : 'https://oauth2.googleapis.com/token';
			$head  = self::b64url( wp_json_encode( array( 'alg' => 'RS256', 'typ' => 'JWT' ) ) );
			$claim = self::b64url( wp_json_encode( array( 'iss' => $sa['client_email'], 'scope' => self::SCOPE_SERVICE, 'aud' => $aud, 'iat' => $now, 'exp' => $now + 3600 ) ) );
			$sig   = '';
			if ( ! function_exists( 'openssl_sign' ) || ! openssl_sign( $head . '.' . $claim, $sig, $sa['private_key'], 'sha256WithRSAEncryption' ) ) {
				return new WP_Error( 'gd_sign', 'امضای JWT ممکن نشد (افزونه openssl روی PHP لازم است یا کلید خصوصی JSON نامعتبر است).' );
			}
			$r = self::http( 'POST', $aud, array( 'body' => array( 'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $head . '.' . $claim . '.' . self::b64url( $sig ) ) ) );
		} else {
			$rt = bws_decrypt( (string) bws_opt( 'gdrive_refresh_token' ) );
			if ( '' === $rt ) {
				return new WP_Error( 'gd_cfg', 'گوگل‌درایو هنوز متصل نشده است.' );
			}
			$r = self::http( 'POST', 'https://oauth2.googleapis.com/token', array( 'body' => array(
				'grant_type'    => 'refresh_token',
				'refresh_token' => $rt,
				'client_id'     => trim( (string) bws_opt( 'gdrive_client_id' ) ),
				'client_secret' => bws_decrypt( (string) bws_opt( 'gdrive_client_secret' ) ),
			) ) );
		}
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		if ( empty( $r['access_token'] ) ) {
			return new WP_Error( 'gd_token', 'توکن دسترسی از گوگل دریافت نشد.' );
		}
		set_transient( $key, bws_encrypt( $r['access_token'] ), max( 60, (int) ( isset( $r['expires_in'] ) ? $r['expires_in'] : 3600 ) - 600 ) );
		return $r['access_token'];
	}

	protected static function auth( $args = array() ) {
		$t = self::token();
		if ( is_wp_error( $t ) ) {
			return $t;
		}
		$args['headers'] = array_merge( isset( $args['headers'] ) ? $args['headers'] : array(), array( 'Authorization' => 'Bearer ' . $t ) );
		return $args;
	}

	protected static function api( $method, $path, $query = array(), $json = null ) {
		$args = self::auth( null !== $json ? array( 'headers' => array( 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( $json, JSON_UNESCAPED_UNICODE ) ) : array() );
		if ( is_wp_error( $args ) ) {
			return $args;
		}
		$query['supportsAllDrives'] = 'true';
		return self::http( $method, add_query_arg( $query, 'https://www.googleapis.com/drive/v3/' . ltrim( $path, '/' ) ), $args );
	}

	/** Root folder: own folder in OAuth mode (created on first use), configured Shared Drive folder in service mode. */
	public static function root_folder() {
		if ( 'service' === self::mode() ) {
			return trim( (string) bws_opt( 'gdrive_sa_folder_id' ) );
		}
		$id = trim( (string) bws_opt( 'gdrive_folder_id' ) );
		if ( $id ) {
			return $id;
		}
		$f = self::api( 'POST', 'files', array( 'fields' => 'id' ), array( 'name' => 'ARIAGH.VISITOR — مرجوعی‌ها — ' . wp_parse_url( home_url(), PHP_URL_HOST ), 'mimeType' => self::FOLDER_MIME ) );
		if ( is_wp_error( $f ) ) {
			return $f;
		}
		bws_update_settings( array( 'gdrive_folder_id' => $f['id'] ) );
		return $f['id'];
	}

	/** Folder for uploads (monthly sub-folder "1405-08" when enabled). */
	public static function target_folder() {
		$root = self::root_folder();
		if ( is_wp_error( $root ) || ! bws_opt( 'gdrive_monthly' ) ) {
			return $root;
		}
		$name  = bws_en_digits( str_replace( '/', '-', mb_substr( bws_jdate( bws_now(), false ), 0, 7 ) ) );
		$cache = get_option( 'bws_gd_folders', array() );
		$ck    = md5( $root . '|' . $name );
		if ( is_array( $cache ) && ! empty( $cache[ $ck ] ) ) {
			return $cache[ $ck ];
		}
		$q = sprintf( "name = '%s' and mimeType = '%s' and '%s' in parents and trashed = false", $name, self::FOLDER_MIME, str_replace( "'", '', $root ) );
		$lq = array( 'q' => $q, 'fields' => 'files(id)', 'includeItemsFromAllDrives' => 'true', 'pageSize' => 1 );
		if ( 'service' === self::mode() ) {
			$lq['corpora'] = 'allDrives'; // Folder lives in a Shared Drive.
		}
		$l = self::api( 'GET', 'files', $lq );
		if ( is_wp_error( $l ) ) {
			return $l;
		}
		if ( ! empty( $l['files'][0]['id'] ) ) {
			$id = $l['files'][0]['id'];
		} else {
			$f = self::api( 'POST', 'files', array( 'fields' => 'id' ), array( 'name' => $name, 'mimeType' => self::FOLDER_MIME, 'parents' => array( $root ) ) );
			if ( is_wp_error( $f ) ) {
				return $f;
			}
			$id = $f['id'];
		}
		$cache        = is_array( $cache ) ? array_slice( $cache, -24, null, true ) : array();
		$cache[ $ck ] = $id;
		update_option( 'bws_gd_folders', $cache, false );
		return $id;
	}

	/**
	 * Upload a local file with the resumable protocol (metadata request → session URI → raw bytes PUT) and verify
	 * the MD5 checksum Google computed against the local file, so a damaged upload is never accepted.
	 * Returns [ id, link, public, md5 ] or WP_Error.
	 */
	public static function upload( $path, $name, $mime, $description = '' ) {
		$folder = self::target_folder();
		if ( is_wp_error( $folder ) ) {
			return $folder;
		}
		$bytes = file_get_contents( $path ); // phpcs:ignore
		if ( false === $bytes || '' === $bytes ) {
			return new WP_Error( 'gd_file', 'فایل محلی خوانده نشد.' );
		}
		$md5  = md5( $bytes );
		$meta = array( 'name' => $name, 'parents' => array( $folder ), 'description' => $description, 'mimeType' => $mime );
		$args = self::auth( array(
			'headers' => array( 'Content-Type' => 'application/json; charset=UTF-8', 'X-Upload-Content-Type' => $mime, 'X-Upload-Content-Length' => (string) strlen( $bytes ) ),
			'body'    => wp_json_encode( $meta, JSON_UNESCAPED_UNICODE ),
		) );
		if ( is_wp_error( $args ) ) {
			return $args;
		}
		$res = wp_remote_request( 'https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&supportsAllDrives=true&fields=id,name,size,md5Checksum,mimeType,webViewLink', array_merge( $args, array( 'method' => 'POST', 'timeout' => 45, 'redirection' => 0, 'user-agent' => 'ARIAGH.VISITOR/' . BWS_VERSION ) ) );
		if ( is_wp_error( $res ) ) {
			return new WP_Error( 'gd_http', 'خطای اتصال به گوگل: ' . $res->get_error_message() );
		}
		$code    = (int) wp_remote_retrieve_response_code( $res );
		$session = (string) wp_remote_retrieve_header( $res, 'location' );
		if ( $code < 200 || $code >= 300 || 0 !== strpos( $session, 'https://' ) ) {
			$j = json_decode( (string) wp_remote_retrieve_body( $res ), true );
			return new WP_Error( 'gd_api', self::explain( isset( $j['error']['message'] ) ? $j['error']['message'] : 'HTTP ' . $code . ' (شروع آپلود)', $code ) );
		}
		$put = wp_remote_request( $session, array(
			'method'      => 'PUT',
			'timeout'     => 120,
			'redirection' => 0,
			'headers'     => array( 'Content-Type' => $mime, 'Content-Length' => (string) strlen( $bytes ) ),
			'body'        => $bytes,
			'user-agent'  => 'ARIAGH.VISITOR/' . BWS_VERSION,
		) );
		if ( is_wp_error( $put ) ) {
			return new WP_Error( 'gd_http', 'خطای اتصال به گوگل هنگام ارسال فایل: ' . $put->get_error_message() );
		}
		$pc = (int) wp_remote_retrieve_response_code( $put );
		$f  = json_decode( (string) wp_remote_retrieve_body( $put ), true );
		if ( $pc < 200 || $pc >= 300 || empty( $f['id'] ) ) {
			return new WP_Error( 'gd_api', self::explain( isset( $f['error']['message'] ) ? $f['error']['message'] : 'HTTP ' . $pc . ' (ارسال فایل)', $pc ) );
		}
		if ( ( ! empty( $f['md5Checksum'] ) && strtolower( $f['md5Checksum'] ) !== $md5 ) || ( isset( $f['size'] ) && (int) $f['size'] !== strlen( $bytes ) ) ) {
			self::delete( $f['id'] );
			return new WP_Error( 'gd_corrupt', 'فایل در مسیر آپلود به گوگل‌درایو خراب شد (چک‌سام یکسان نبود)؛ فایل خراب حذف شد و دوباره تلاش می‌شود.' );
		}
		$public = false;
		if ( 'anyone' === bws_opt( 'gdrive_share', 'anyone' ) ) {
			$p      = self::api( 'POST', 'files/' . rawurlencode( $f['id'] ) . '/permissions', array(), array( 'role' => 'reader', 'type' => 'anyone' ) );
			$public = ! is_wp_error( $p ); // Some Workspace domains forbid public links – the file stays private.
		}
		return array( 'id' => $f['id'], 'link' => ! empty( $f['webViewLink'] ) ? $f['webViewLink'] : 'https://drive.google.com/file/d/' . rawurlencode( $f['id'] ) . '/view', 'public' => $public, 'md5' => $md5 );
	}

	/** Download the raw bytes of a Drive file (alt=media). */
	public static function download( $id ) {
		$args = self::auth( array() );
		if ( is_wp_error( $args ) ) {
			return $args;
		}
		$res = wp_remote_get( 'https://www.googleapis.com/drive/v3/files/' . rawurlencode( $id ) . '?alt=media&supportsAllDrives=true', array_merge( $args, array( 'timeout' => 45, 'redirection' => 3, 'user-agent' => 'ARIAGH.VISITOR/' . BWS_VERSION ) ) );
		if ( is_wp_error( $res ) ) {
			return new WP_Error( 'gd_http', 'خطای اتصال به گوگل: ' . $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( 200 !== $code ) {
			$j = json_decode( (string) wp_remote_retrieve_body( $res ), true );
			return new WP_Error( 'gd_api', self::explain( isset( $j['error']['message'] ) ? $j['error']['message'] : 'HTTP ' . $code, $code ) );
		}
		return (string) wp_remote_retrieve_body( $res );
	}

	/**
	 * Health check of photos already on Drive: compares size/checksum Google reports with what the site stored.
	 * Damaged files that still have a host copy are uploaded again. Returns counts.
	 */
	public static function verify_files( $limit = 100 ) {
		global $wpdb;
		$t     = BWS_Return_Files::table();
		$rows  = $wpdb->get_results( 'SELECT * FROM ' . $t . " WHERE drive_id <> '' ORDER BY id DESC LIMIT " . max( 1, (int) $limit ) );
		$out   = array( 'checked' => 0, 'ok' => 0, 'bad' => 0, 'fixed' => 0, 'missing' => 0, 'errors' => array() );
		foreach ( $rows as $f ) {
			$m = self::api( 'GET', 'files/' . rawurlencode( $f->drive_id ), array( 'fields' => 'id,size,md5Checksum,mimeType,trashed' ) );
			$out['checked']++;
			if ( is_wp_error( $m ) ) {
				$st = $m->get_error_data();
				if ( is_array( $st ) && 404 === (int) $st['status'] ) {
					$out['missing']++;
				} else {
					$out['errors'][] = $m->get_error_message();
				}
				continue;
			}
			$bad = ( $f->md5 && ! empty( $m['md5Checksum'] ) && strtolower( $m['md5Checksum'] ) !== $f->md5 ) || ( $f->size && isset( $m['size'] ) && (int) $m['size'] !== (int) $f->size ) || ( isset( $m['mimeType'] ) && 0 !== strpos( $m['mimeType'], 'image/' ) );
			if ( ! $bad ) {
				$out['ok']++;
				continue;
			}
			$out['bad']++;
			$local = $f->path ? BWS_Return_Files::abs_path( $f->path ) : '';
			if ( $local && is_readable( $local ) ) {
				$r  = BWS_Returns::get( $f->return_id );
				$up = self::upload( $local, ( $r ? $r->code : 'R' ) . '-' . $f->id . '.jpg', $f->mime ? $f->mime : 'image/jpeg', $r ? 'مرجوعی ' . $r->code : '' );
				if ( ! is_wp_error( $up ) ) {
					self::delete( $f->drive_id );
					$wpdb->update( $t, array( 'drive_id' => $up['id'], 'drive_link' => esc_url_raw( $up['link'] ), 'drive_public' => $up['public'] ? 1 : 0, 'md5' => $up['md5'], 'state' => 'uploaded', 'error' => '' ), array( 'id' => $f->id ) );
					$out['fixed']++;
					continue;
				}
			}
			$wpdb->update( $t, array( 'error' => 'فایل گوگل‌درایو خراب است (اندازه/چک‌سام متفاوت)' ), array( 'id' => $f->id ) );
		}
		$out['errors'] = array_slice( array_unique( $out['errors'] ), 0, 3 );
		return $out;
	}

	public static function delete( $id ) {
		return self::api( 'DELETE', 'files/' . rawurlencode( $id ) );
	}

	/** Connection test: token + root folder reachable. */
	public static function test() {
		$t = self::token();
		if ( is_wp_error( $t ) ) {
			return $t;
		}
		$root = self::root_folder();
		if ( is_wp_error( $root ) ) {
			return $root;
		}
		$f = self::api( 'GET', 'files/' . rawurlencode( $root ), array( 'fields' => 'id,name,webViewLink,capabilities(canAddChildren)' ) );
		if ( is_wp_error( $f ) ) {
			return $f;
		}
		if ( isset( $f['capabilities']['canAddChildren'] ) && ! $f['capabilities']['canAddChildren'] ) {
			return new WP_Error( 'gd_perm', 'به پوشه «' . $f['name'] . '» دسترسی نوشتن وجود ندارد.' );
		}
		// Real round trip: upload a small JPEG, download it again and compare bytes, then delete it.
		$tmp = wp_tempnam( 'bws-gd-test' );
		$jpg = self::test_jpeg();
		file_put_contents( $tmp, $jpg ); // phpcs:ignore
		$up = self::upload( $tmp, 'ARIAGH-test-' . gmdate( 'His' ) . '.jpg', 'image/jpeg', 'آزمایش اتصال — قابل حذف' );
		@unlink( $tmp ); // phpcs:ignore
		if ( is_wp_error( $up ) ) {
			return new WP_Error( 'gd_up', 'پوشه در دسترس است ولی آپلود آزمایشی ناموفق بود: ' . $up->get_error_message() );
		}
		$back = self::download( $up['id'] );
		self::delete( $up['id'] );
		if ( is_wp_error( $back ) ) {
			return new WP_Error( 'gd_down', 'آپلود انجام شد ولی دانلود دوباره ناموفق بود: ' . $back->get_error_message() );
		}
		if ( md5( $back ) !== md5( $jpg ) ) {
			return new WP_Error( 'gd_corrupt', 'فایل آزمایشی بعد از آپلود و دانلود یکسان نبود (احتمالاً پروکسی/فایروال هاست محتوا را تغییر می‌دهد).' );
		}
		return array( 'folder' => $f['name'], 'link' => isset( $f['webViewLink'] ) ? $f['webViewLink'] : '', 'roundtrip' => true, 'public' => $up['public'] );
	}

	/** Tiny valid JPEG for the round-trip test. */
	protected static function test_jpeg() {
		if ( function_exists( 'imagecreatetruecolor' ) ) {
			$im = imagecreatetruecolor( 16, 16 );
			imagefill( $im, 0, 0, imagecolorallocate( $im, 29, 78, 216 ) );
			ob_start();
			imagejpeg( $im, null, 90 );
			$d = ob_get_clean();
			if ( $d ) {
				return $d;
			}
		}
		return base64_decode( '/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=' ); // phpcs:ignore
	}

	/* ---------------- OAuth web flow ---------------- */

	public static function connect() {
		if ( ! bws_is_manager() || ! check_admin_referer( 'bws_gdrive_connect' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		$cid = trim( (string) bws_opt( 'gdrive_client_id' ) );
		if ( ! $cid || '' === bws_decrypt( (string) bws_opt( 'gdrive_client_secret' ) ) ) {
			wp_safe_redirect( add_query_arg( array( 'page' => 'bws-settings', 'tab' => 'returns', 'bws_err' => 1, 'bws_msg' => rawurlencode( 'ابتدا Client ID و Client Secret را وارد و ذخیره کنید.' ) ), admin_url( 'admin.php' ) ) );
			exit;
		}
		$state = bin2hex( random_bytes( 16 ) );
		set_transient( 'bws_gd_state_' . get_current_user_id(), $state, 15 * MINUTE_IN_SECONDS );
		wp_redirect( add_query_arg( array( // phpcs:ignore WordPress.Security.SafeRedirect
			'client_id'              => rawurlencode( $cid ),
			'redirect_uri'           => rawurlencode( self::redirect_uri() ),
			'response_type'          => 'code',
			'scope'                  => rawurlencode( self::SCOPE_OAUTH ),
			'access_type'            => 'offline',
			'prompt'                 => 'consent',
			'include_granted_scopes' => 'true',
			'state'                  => $state,
		), 'https://accounts.google.com/o/oauth2/v2/auth' ) );
		exit;
	}

	public static function oauth_callback() {
		$back = function ( $msg, $err = false ) {
			wp_safe_redirect( add_query_arg( array( 'page' => 'bws-settings', 'tab' => 'returns', 'bws_err' => $err ? 1 : 0, 'bws_msg' => rawurlencode( $msg ) ), admin_url( 'admin.php' ) ) );
			exit;
		};
		if ( ! bws_is_manager() ) {
			wp_die( 'دسترسی ندارید.' );
		}
		$state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : ''; // phpcs:ignore
		$saved = get_transient( 'bws_gd_state_' . get_current_user_id() );
		delete_transient( 'bws_gd_state_' . get_current_user_id() );
		if ( ! $saved || ! hash_equals( $saved, $state ) ) {
			$back( 'درخواست اتصال نامعتبر یا منقضی بود؛ دوباره «اتصال به گوگل» را بزنید.', true );
		}
		if ( ! empty( $_GET['error'] ) ) { // phpcs:ignore
			$back( 'اتصال لغو شد: ' . sanitize_text_field( wp_unslash( $_GET['error'] ) ), true ); // phpcs:ignore
		}
		$code = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : ''; // phpcs:ignore
		$r    = self::http( 'POST', 'https://oauth2.googleapis.com/token', array( 'body' => array(
			'grant_type'    => 'authorization_code',
			'code'          => $code,
			'redirect_uri'  => self::redirect_uri(),
			'client_id'     => trim( (string) bws_opt( 'gdrive_client_id' ) ),
			'client_secret' => bws_decrypt( (string) bws_opt( 'gdrive_client_secret' ) ),
		) ) );
		if ( is_wp_error( $r ) ) {
			$back( 'خطا در دریافت توکن: ' . $r->get_error_message(), true );
		}
		if ( empty( $r['refresh_token'] ) ) {
			$back( 'گوگل refresh token برنگرداند. از myaccount.google.com/permissions دسترسی برنامه را حذف و دوباره وصل کنید.', true );
		}
		bws_update_settings( array( 'gdrive_refresh_token' => bws_encrypt( $r['refresh_token'] ), 'gdrive_folder_id' => '' ) );
		$about = self::api( 'GET', 'about', array( 'fields' => 'user(emailAddress,displayName)' ) );
		$email = is_wp_error( $about ) || empty( $about['user']['emailAddress'] ) ? '' : sanitize_email( $about['user']['emailAddress'] );
		bws_update_settings( array( 'gdrive_account' => $email ) );
		$root = self::root_folder();
		BWS_Log::add( 'gdrive_connect', 'settings', 0, $email );
		$back( is_wp_error( $root ) ? 'متصل شد ولی ساخت پوشه ناموفق بود: ' . $root->get_error_message() : 'گوگل‌درایو با موفقیت متصل شد' . ( $email ? ' (' . $email . ')' : '' ) . '؛ پوشه «ARIAGH.VISITOR — مرجوعی‌ها» ساخته شد.', is_wp_error( $root ) );
	}

	public static function disconnect() {
		if ( ! bws_is_manager() || ! check_admin_referer( 'bws_gdrive_disconnect' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		$rt = bws_decrypt( (string) bws_opt( 'gdrive_refresh_token' ) );
		if ( $rt ) {
			wp_remote_post( 'https://oauth2.googleapis.com/revoke', array( 'timeout' => 15, 'body' => array( 'token' => $rt ) ) );
		}
		bws_update_settings( array( 'gdrive_refresh_token' => '', 'gdrive_account' => '', 'gdrive_folder_id' => '' ) );
		delete_option( 'bws_gd_folders' );
		wp_safe_redirect( add_query_arg( array( 'page' => 'bws-settings', 'tab' => 'returns', 'bws_msg' => rawurlencode( 'اتصال گوگل‌درایو قطع شد.' ) ), admin_url( 'admin.php' ) ) );
		exit;
	}
}
