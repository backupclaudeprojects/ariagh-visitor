<?php
defined( 'ABSPATH' ) || exit;

/**
 * Telegram & Bale bot client (Bot API).
 *
 * Both use the same request shape: POST {base}/bot<token>/<method>, JSON or multipart/form-data,
 * response { ok, result } or { ok:false, error_code, description, parameters{ retry_after } }.
 *  - Telegram (core.telegram.org/bots/api): sendMessage text 1-4096, parse_mode HTML; sendPhoto ≤10 MB,
 *    caption ≤1024; sendMediaGroup 2-10 items, files referenced with attach://<name>.
 *  - Bale (docs.bale.ai, base https://tapi.bale.ai): sendMessage text 1-4096 (no parse_mode → plain text);
 *    sendPhoto caption ≤1024, upload ≤10 MB; sendMediaGroup supported.
 * A user/group must have sent at least one message (/start) to the bot before the bot can message it.
 */
class BWS_Messenger {

	public static function platforms() {
		return array( 'telegram' => 'تلگرام', 'bale' => 'بله' );
	}

	public static function cfg( $p ) {
		$pre  = 'telegram' === $p ? 'tg_' : 'bale_';
		$base = trim( (string) bws_opt( $pre . 'api_base' ) );
		$base = $base ? untrailingslashit( esc_url_raw( $base ) ) : ( 'telegram' === $p ? 'https://api.telegram.org' : 'https://tapi.bale.ai' );
		return array(
			'enabled' => (bool) bws_opt( $pre . 'enabled' ),
			'token'   => trim( bws_decrypt( (string) bws_opt( $pre . 'token' ) ) ),
			'chats'   => self::parse_chats( bws_opt( $pre . 'chats' ) ),
			'base'    => $base,
		);
	}

	/** Chat ids: numbers (users / groups like -100…) or @channel usernames, separated by lines/commas. */
	public static function parse_chats( $raw ) {
		$out = array();
		foreach ( preg_split( '/[\s,،]+/', bws_en_digits( (string) $raw ) ) as $c ) {
			$c = trim( $c );
			if ( preg_match( '/^-?\d{3,20}$/', $c ) || preg_match( '/^@[A-Za-z0-9_]{4,64}$/', $c ) ) {
				$out[] = $c;
			}
		}
		return array_values( array_unique( $out ) );
	}

	public static function active() {
		$out = array();
		foreach ( array_keys( self::platforms() ) as $p ) {
			$c = self::cfg( $p );
			if ( $c['enabled'] && $c['token'] ) {
				$out[] = $p;
			}
		}
		return $out;
	}

	/**
	 * Call a Bot API method. $files = name => [ path, filename, mime ] (multipart upload).
	 * Returns [ ok, result, error, code, retry_after ].
	 */
	public static function call( $p, $method, array $params = array(), array $files = array(), $cfg = null ) {
		$cfg = $cfg ? $cfg : self::cfg( $p );
		if ( ! $cfg['token'] ) {
			return array( 'ok' => false, 'error' => 'توکن ربات وارد نشده است.', 'code' => 0 );
		}
		$url  = $cfg['base'] . '/bot' . $cfg['token'] . '/' . $method;
		$args = array( 'timeout' => $files ? 45 : 20, 'redirection' => 0, 'user-agent' => 'ARIAGH.VISITOR/' . BWS_VERSION );
		if ( $files ) {
			$fields = array();
			foreach ( $params as $k => $v ) {
				$fields[ $k ] = is_array( $v ) ? wp_json_encode( $v, JSON_UNESCAPED_UNICODE ) : (string) $v;
			}
			list( $body, $ctype ) = BWS_Multipart::form( $fields, $files );
			$args['headers']      = array( 'Content-Type' => $ctype );
			$args['body']         = $body;
		} else {
			$args['headers'] = array( 'Content-Type' => 'application/json' );
			$args['body']    = wp_json_encode( $params, JSON_UNESCAPED_UNICODE );
		}
		for ( $try = 0; $try < 2; $try++ ) {
			$res = wp_remote_post( $url, $args );
			if ( is_wp_error( $res ) ) {
				return array( 'ok' => false, 'error' => 'خطای اتصال: ' . str_replace( $cfg['token'], '***', $res->get_error_message() ), 'code' => 0, 'net' => true );
			}
			$j = json_decode( (string) wp_remote_retrieve_body( $res ), true );
			if ( is_array( $j ) && ! empty( $j['ok'] ) ) {
				return array( 'ok' => true, 'result' => isset( $j['result'] ) ? $j['result'] : null );
			}
			$code  = is_array( $j ) && isset( $j['error_code'] ) ? (int) $j['error_code'] : (int) wp_remote_retrieve_response_code( $res );
			$retry = is_array( $j ) && isset( $j['parameters']['retry_after'] ) ? (int) $j['parameters']['retry_after'] : 0;
			if ( 429 === $code && $retry > 0 && $retry <= 5 && 0 === $try ) {
				sleep( $retry );
				continue;
			}
			$desc = is_array( $j ) && isset( $j['description'] ) ? (string) $j['description'] : 'HTTP ' . $code;
			return array( 'ok' => false, 'error' => self::explain( $desc, $code ), 'code' => $code, 'retry_after' => $retry );
		}
		return array( 'ok' => false, 'error' => 'محدودیت تعداد درخواست (429)', 'code' => 429 );
	}

	/** Persian explanation of the most common Bot API errors. */
	public static function explain( $desc, $code ) {
		$d = strtolower( $desc );
		if ( 401 === $code || false !== strpos( $d, 'unauthorized' ) ) {
			return 'توکن ربات اشتباه است (401).';
		}
		if ( false !== strpos( $d, 'chat not found' ) ) {
			return 'گیرنده پیدا نشد؛ شناسه عددی را بررسی کنید و مطمئن شوید گیرنده یک‌بار به ربات پیام (/start) داده است.';
		}
		if ( false !== strpos( $d, "can't initiate" ) || false !== strpos( $d, 'blocked' ) || 403 === $code ) {
			return 'ربات اجازه ارسال به این گیرنده را ندارد؛ گیرنده باید ربات را Start کند (یا ربات عضو گروه/ادمین کانال باشد). ' . $desc;
		}
		if ( 429 === $code ) {
			return 'محدودیت تعداد پیام؛ کمی بعد دوباره ارسال می‌شود.';
		}
		return $desc;
	}

	public static function button_ok( $url ) {
		$h = wp_parse_url( $url, PHP_URL_HOST );
		return $url && 0 === strpos( $url, 'https://' ) && $h && false !== strpos( $h, '.' ) && ! in_array( $h, array( 'localhost', '127.0.0.1' ), true );
	}

	/**
	 * Format a structured message for a platform.
	 * $msg = [ title, rows => [ [ icon, label, value ] | '' (spacer) ], footer ].
	 */
	public static function format( array $msg, $p ) {
		$html  = 'telegram' === $p;
		$e     = function ( $s ) use ( $html ) {
			return $html ? esc_html( (string) $s ) : (string) $s;
		};
		$lines = array( $html ? '<b>' . $e( $msg['title'] ) . '</b>' : $msg['title'], '' );
		foreach ( $msg['rows'] as $r ) {
			if ( ! is_array( $r ) ) {
				$lines[] = $e( $r );
				continue;
			}
			if ( '' === trim( (string) $r[2] ) ) {
				continue;
			}
			$val     = (string) $r[2];
			$multi   = false !== strpos( $val, "\n" );
			$label   = $r[0] . ' ' . ( $html ? '<b>' . $e( $r[1] ) . ':</b>' : $r[1] . ':' );
			$lines[] = $multi ? $label . "\n" . $e( $val ) : $label . ' ' . $e( $val );
		}
		if ( ! empty( $msg['footer'] ) ) {
			$lines[] = '';
			$lines[] = $e( $msg['footer'] );
		}
		$text = implode( "\n", $lines );
		if ( mb_strlen( $text ) > 4000 ) { // Limit is 4096 characters (after entity parsing for Telegram).
			$text = mb_substr( wp_strip_all_tags( $text ), 0, 3990 ) . '…';
		}
		return $text;
	}

	/** Reply-to parameters (Telegram: reply_parameters, Bale: reply_to_message_id). */
	public static function reply_to( $p, $message_id ) {
		if ( ! $message_id ) {
			return array();
		}
		return 'telegram' === $p ? array( 'reply_parameters' => array( 'message_id' => (int) $message_id, 'allow_sending_without_reply' => true ) ) : array( 'reply_to_message_id' => (int) $message_id );
	}

	/** First message id of a send result (sendMediaGroup returns an array of messages). */
	public static function message_id( $r ) {
		if ( empty( $r['ok'] ) || empty( $r['result'] ) ) {
			return 0;
		}
		$m = $r['result'];
		if ( isset( $m[0] ) && is_array( $m[0] ) ) {
			$m = $m[0];
		}
		return is_array( $m ) && isset( $m['message_id'] ) ? (int) $m['message_id'] : 0;
	}

	/** Call; when a reply target is rejected (deleted message) retry once without it. */
	protected static function call_r( $p, $method, $params, $files, $cfg ) {
		$r = self::call( $p, $method, $params, $files, $cfg );
		if ( ! $r['ok'] && 400 === (int) $r['code'] && ( isset( $params['reply_to_message_id'] ) || isset( $params['reply_parameters'] ) ) ) {
			unset( $params['reply_to_message_id'], $params['reply_parameters'] );
			$r = self::call( $p, $method, $params, $files, $cfg );
		}
		return $r;
	}

	/** Photo with caption (+ optional inline keyboard / reply). $photo = [ path, filename, mime ]. */
	public static function send_photo( $p, $chat, $photo, $caption = '', $extra = array(), $cfg = null ) {
		$params = array_merge( array( 'chat_id' => $chat, 'caption' => $caption ), $extra );
		if ( 'telegram' === $p && '' !== $caption ) {
			$params['parse_mode'] = 'HTML';
		}
		$r = self::call_r( $p, 'sendPhoto', $params, array( 'photo' => $photo ), $cfg );
		if ( ! $r['ok'] && 'telegram' === $p && 400 === (int) $r['code'] && false !== stripos( (string) $r['error'], 'parse' ) ) {
			unset( $params['parse_mode'] );
			$params['caption'] = html_entity_decode( wp_strip_all_tags( $caption ), ENT_QUOTES, 'UTF-8' );
			$r = self::call_r( $p, 'sendPhoto', $params, array( 'photo' => $photo ), $cfg );
		}
		return $r;
	}

	/** Album (2-10 photos) with the caption under the album. Returns call result (result = messages). */
	public static function send_album( $p, $chat, array $photos, $caption = '', $extra = array(), $cfg = null ) {
		$media = array();
		$files = array();
		foreach ( array_slice( array_values( $photos ), 0, 10 ) as $i => $f ) {
			$item = array( 'type' => 'photo', 'media' => 'attach://p' . $i );
			if ( 0 === $i && '' !== $caption ) {
				$item['caption'] = $caption;
				if ( 'telegram' === $p ) {
					$item['parse_mode'] = 'HTML';
				}
			}
			$media[]           = $item;
			$files[ 'p' . $i ] = $f;
		}
		return self::call_r( $p, 'sendMediaGroup', array_merge( array( 'chat_id' => $chat, 'media' => $media ), $extra ), $files, $cfg );
	}

	public static function answer_callback( $p, $id, $text = '', $cfg = null ) {
		return self::call( $p, 'answerCallbackQuery', array_filter( array( 'callback_query_id' => (string) $id, 'text' => $text ) ), array(), $cfg );
	}

	/** Remove the inline keyboard of a message (Telegram; Bale has no such method). */
	public static function clear_keyboard( $p, $chat, $message_id, $cfg = null ) {
		if ( 'telegram' !== $p || ! $message_id ) {
			return array( 'ok' => false, 'code' => 0, 'error' => 'unsupported' );
		}
		return self::call( $p, 'editMessageReplyMarkup', array( 'chat_id' => $chat, 'message_id' => (int) $message_id, 'reply_markup' => array( 'inline_keyboard' => array() ) ), array(), $cfg );
	}

	public static function set_webhook( $p, $url, $secret ) {
		$params = array( 'url' => $url );
		if ( 'telegram' === $p ) {
			$params['secret_token']         = $secret;
			$params['allowed_updates']      = array( 'message', 'callback_query' );
			$params['drop_pending_updates'] = true;
		}
		return self::call( $p, 'setWebhook', $params );
	}

	public static function delete_webhook( $p ) {
		return 'telegram' === $p ? self::call( $p, 'deleteWebhook', array() ) : self::call( $p, 'setWebhook', array( 'url' => '' ) );
	}

	public static function send_text( $p, $chat, $text, $button = null, $cfg = null, $extra = array() ) {
		$params = array_merge( array( 'chat_id' => $chat, 'text' => $text ), $extra );
		if ( 'telegram' === $p ) {
			$params['parse_mode']           = 'HTML';
			$params['link_preview_options'] = array( 'is_disabled' => true );
		}
		if ( $button && self::button_ok( $button[1] ) ) {
			$params['reply_markup'] = array( 'inline_keyboard' => array( array( array( 'text' => $button[0], 'url' => $button[1] ) ) ) );
		}
		$r = self::call_r( $p, 'sendMessage', $params, array(), $cfg );
		if ( ! $r['ok'] && 'telegram' === $p && 400 === (int) $r['code'] && false !== stripos( (string) $r['error'], 'parse' ) ) {
			unset( $params['parse_mode'] );
			$params['text'] = html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' );
			$r              = self::call_r( $p, 'sendMessage', $params, array(), $cfg );
		}
		if ( ! $r['ok'] && isset( $params['reply_markup'] ) && 400 === (int) $r['code'] && false === stripos( (string) $r['error'], 'chat not found' ) ) {
			unset( $params['reply_markup'] ); // Some servers reject URL buttons (e.g. non-public host) – resend without it.
			$r = self::call_r( $p, 'sendMessage', $params, array(), $cfg );
		}
		return $r;
	}

	/**
	 * Send photos (local files): 1 → sendPhoto, 2..10 → sendMediaGroup (album), more → several albums.
	 * $photos = [ [ path, filename, mime ] ]. Falls back to one-by-one sendPhoto when an album is rejected.
	 */
	public static function send_photos( $p, $chat, array $photos, $caption = '', $cfg = null ) {
		$photos = array_values( array_filter( $photos, function ( $f ) {
			return is_readable( $f[0] ) && filesize( $f[0] ) <= 10 * MB_IN_BYTES;
		} ) );
		if ( ! $photos ) {
			return array( 'ok' => true, 'skipped' => true );
		}
		$last = array( 'ok' => true );
		foreach ( array_chunk( $photos, 10 ) as $ci => $chunk ) {
			$cap = 0 === $ci ? mb_substr( $caption, 0, 1000 ) : '';
			if ( 1 === count( $chunk ) ) {
				$last = self::call( $p, 'sendPhoto', array( 'chat_id' => $chat, 'caption' => $cap ), array( 'photo' => $chunk[0] ), $cfg );
				continue;
			}
			$media = array();
			$files = array();
			foreach ( $chunk as $i => $f ) {
				$item = array( 'type' => 'photo', 'media' => 'attach://p' . $i );
				if ( 0 === $i && '' !== $cap ) {
					$item['caption'] = $cap;
				}
				$media[]           = $item;
				$files[ 'p' . $i ] = $f;
			}
			$last = self::call( $p, 'sendMediaGroup', array( 'chat_id' => $chat, 'media' => $media ), $files, $cfg );
			if ( ! $last['ok'] && ! in_array( (int) $last['code'], array( 401, 403 ), true ) && empty( $last['net'] ) ) {
				foreach ( $chunk as $i => $f ) {
					$last = self::call( $p, 'sendPhoto', array( 'chat_id' => $chat, 'caption' => 0 === $i ? $cap : '' ), array( 'photo' => $f ), $cfg );
				}
			}
			if ( ! $last['ok'] ) {
				break;
			}
		}
		return $last;
	}

	/** Verify the token (getMe). */
	public static function me( $p ) {
		$r = self::call( $p, 'getMe' );
		if ( ! $r['ok'] ) {
			return $r;
		}
		$u = (array) $r['result'];
		return array( 'ok' => true, 'name' => isset( $u['first_name'] ) ? $u['first_name'] : '', 'username' => isset( $u['username'] ) ? $u['username'] : '' );
	}

	/** Send a test message to every chat id; per-chat results. */
	public static function test( $p ) {
		$me = self::me( $p );
		if ( ! $me['ok'] ) {
			return array( 'ok' => false, 'error' => $me['error'] );
		}
		$cfg   = self::cfg( $p );
		$chats = array();
		foreach ( BWS_Bot::recipients() as $rc ) {
			if ( $rc['p'] === $p ) {
				$chats[] = $rc['chat'];
			}
		}
		$chats = array_values( array_unique( $chats ) );
		if ( ! $chats ) {
			return array( 'ok' => false, 'error' => 'ربات وصل است (@' . $me['username'] . ') ولی هیچ گیرنده‌ای برای ' . self::platforms()[ $p ] . ' تعریف نشده است.' );
		}
		$out = array();
		foreach ( $chats as $chat ) {
			$r            = self::send_text( $p, $chat, self::format( array( 'title' => '✅ پیام آزمایشی ARIAGH.VISITOR', 'rows' => array( array( '🏪', 'سایت', bws_opt( 'company_name' ) ), array( '🕒', 'زمان', bws_jdate( bws_now() ) ), 'اتصال ربات برای ارسال درخواست‌های مرجوعی برقرار است.' ) ), $p ), null, $cfg );
			$out[ $chat ] = $r['ok'] ? 'ارسال شد' : $r['error'];
		}
		return array( 'ok' => true, 'bot' => '@' . $me['username'], 'results' => $out );
	}

	/**
	 * Chats that recently messaged the bot (getUpdates) – to find numeric ids easily.
	 * Note: Telegram refuses getUpdates while a webhook is set.
	 */
	public static function find_chats( $p ) {
		$chats = array();
		foreach ( (array) get_option( 'bws_bot_seen_' . $p, array() ) as $c ) {
			$chats[ (string) $c['id'] ] = $c;
		}
		$r = 'polling' === bws_opt( 'bot_mode', 'off' ) ? array( 'ok' => true, 'result' => array() ) : self::call( $p, 'getUpdates', array( 'limit' => 100, 'timeout' => 0 ) );
		if ( ! $r['ok'] ) {
			if ( $chats ) {
				return array( 'ok' => true, 'chats' => array_values( $chats ) );
			}
			if ( false !== stripos( (string) $r['error'], 'webhook' ) || 409 === (int) $r['code'] ) {
				$r['error'] = 'وب‌هوک فعال است؛ از گیرنده بخواهید به ربات /start بدهد تا شناسه‌اش اینجا ثبت شود (ربات خودش شناسه را هم به او می‌گوید).';
			}
			return $r;
		}
		foreach ( (array) $r['result'] as $u ) {
			foreach ( array( 'message', 'edited_message', 'channel_post', 'my_chat_member' ) as $k ) {
				if ( empty( $u[ $k ]['chat']['id'] ) ) {
					continue;
				}
				$c                         = $u[ $k ]['chat'];
				$name                      = isset( $c['title'] ) ? $c['title'] : trim( ( isset( $c['first_name'] ) ? $c['first_name'] : '' ) . ' ' . ( isset( $c['last_name'] ) ? $c['last_name'] : '' ) );
				$chats[ (string) $c['id'] ] = array(
					'id'       => (string) $c['id'],
					'name'     => sanitize_text_field( $name ),
					'username' => isset( $c['username'] ) ? sanitize_text_field( $c['username'] ) : '',
					'type'     => isset( $c['type'] ) ? sanitize_key( $c['type'] ) : '',
				);
			}
		}
		return array( 'ok' => true, 'chats' => array_values( $chats ) );
	}
}
