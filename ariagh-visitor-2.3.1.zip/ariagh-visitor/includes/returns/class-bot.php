<?php
defined( 'ABSPATH' ) || exit;

/**
 * Telegram / Bale bot logic for returns.
 *
 *  - Recipients: each chat id is mapped to a person (manager / visitor / anyone), with its own scope
 *    (all returns or only the customers of the linked visitor), events, and abilities
 *    (button "open returns" in the chat, approve / reject inside the chat).
 *  - Every message is built from an editable template; the panel link is personal (visitor → visitor panel,
 *    manager → wp-admin).
 *  - New request = photo(s) with the information as caption (one message). Every later message about the same
 *    request (approved / rejected / cancelled) is sent as a reply to that first message, in every chat.
 *  - Interaction (buttons, commands) works through a webhook or through polling (WP-Cron every minute).
 */
class BWS_Bot {

	const MENU_OPEN = '📋 مرجوعی‌های باز';
	const CAPTION   = 1000; // Telegram & Bale caption limit is 1024 characters (kept a safety margin).
	const TEXT      = 4000; // Message limit 4096.

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval
		add_action( 'bws_bot_poll', array( __CLASS__, 'poll' ) );
		if ( 'polling' === bws_opt( 'bot_mode', 'off' ) ) {
			if ( ! wp_next_scheduled( 'bws_bot_poll' ) ) {
				wp_schedule_event( time() + 30, 'bws_minute', 'bws_bot_poll' );
			}
		} elseif ( wp_next_scheduled( 'bws_bot_poll' ) ) {
			wp_clear_scheduled_hook( 'bws_bot_poll' );
		}
	}

	public static function schedules( $s ) {
		$s['bws_minute'] = array( 'interval' => 60, 'display' => 'هر دقیقه (ARIAGH.VISITOR)' );
		$s['bws_5min']   = array( 'interval' => 300, 'display' => 'هر ۵ دقیقه (ARIAGH.VISITOR)' );
		return $s;
	}

	/* ------------------------------------------------------------------ */
	/* Recipients                                                          */
	/* ------------------------------------------------------------------ */

	public static function events() {
		return array( 'new' => 'درخواست جدید', 'decision' => 'تأیید / رد', 'cancel' => 'لغو توسط مشتری' );
	}

	public static function sanitize_recipient( $r ) {
		$r    = is_array( $r ) ? $r : array();
		$chat = BWS_Messenger::parse_chats( isset( $r['chat'] ) ? $r['chat'] : '' );
		if ( ! $chat ) {
			return null;
		}
		$user = isset( $r['user'] ) ? absint( $r['user'] ) : 0;
		if ( $user && ! ( bws_is_manager( $user ) || bws_is_visitor( $user ) ) ) {
			$user = 0;
		}
		$ev = array_values( array_intersect( isset( $r['ev'] ) ? (array) $r['ev'] : array(), array_keys( self::events() ) ) );
		return array(
			'id'     => isset( $r['id'] ) && preg_match( '/^r[a-z0-9]{4,16}$/', $r['id'] ) ? $r['id'] : 'r' . strtolower( wp_generate_password( 8, false ) ),
			'p'      => isset( $r['p'] ) && 'bale' === $r['p'] ? 'bale' : 'telegram',
			'chat'   => $chat[0],
			'name'   => mb_substr( sanitize_text_field( isset( $r['name'] ) ? $r['name'] : '' ), 0, 60 ),
			'user'   => $user,
			'scope'  => isset( $r['scope'] ) && 'own' === $r['scope'] && $user && ! bws_is_manager( $user ) ? 'own' : 'all',
			'ev'     => $ev,
			'photos' => ! empty( $r['photos'] ) ? 1 : 0,
			'list'   => ! empty( $r['list'] ) ? 1 : 0,
			'decide' => ! empty( $r['decide'] ) && $user ? 1 : 0,
			'on'     => ! empty( $r['on'] ) ? 1 : 0,
		);
	}

	/** Enabled recipients whose platform is enabled. */
	public static function recipients( $all = false ) {
		$out = array();
		foreach ( (array) bws_opt( 'bot_recipients', array() ) as $r ) {
			$r = self::sanitize_recipient( $r );
			if ( ! $r ) {
				continue;
			}
			if ( ! $all ) {
				$cfg = BWS_Messenger::cfg( $r['p'] );
				if ( ! $r['on'] || ! $cfg['enabled'] || ! $cfg['token'] ) {
					continue;
				}
			}
			$out[] = $r;
		}
		return $out;
	}

	public static function find( $p, $chat ) {
		foreach ( self::recipients() as $r ) {
			if ( $r['p'] === $p && (string) $r['chat'] === (string) $chat ) {
				return $r;
			}
		}
		return null;
	}

	public static function in_scope( $rec, $r, $c = null ) {
		if ( 'own' !== $rec['scope'] ) {
			return true;
		}
		$c = $c ? $c : BWS_Customers::get( $r->customer_id );
		return $c && (int) $c->visitor_id === (int) $rec['user'];
	}

	/** Personal panel link: visitor → his own visitor panel, manager / unlinked → wp-admin. */
	public static function link_for( $rec, $r ) {
		if ( $rec && $rec['user'] && ! bws_is_manager( $rec['user'] ) ) {
			return bws_visitor_panel_url() . '#r' . (int) $r->id;
		}
		return BWS_Returns::panel_link( $r );
	}

	/* ------------------------------------------------------------------ */
	/* Templates                                                           */
	/* ------------------------------------------------------------------ */

	public static function templates() {
		return array(
			'new'      => array( 'درخواست جدید (زیرنویس عکس)', "🔔 **مرجوعی جدید {code}**\n👤 {customer} (کد {customer_code})\n🏪 {shop}\n📱 {mobile} ☎️ {phone}\n📍 {address}\n🗺 {map}\n🧑‍💼 ویزیتور: {visitor} {visitor_mobile}\n🧾 سفارش #{order} — {order_date}\n📦 اقلام:\n{items}\n💰 ارزش: {amount}\n❗ دلیل: {reason}\n📝 {description}\n✍️ ثبت: {by} — {date}\n🔗 {panel_link}" ),
			'approved' => array( 'تأیید شد (پاسخ روی پیام اول)', "✅ **مرجوعی {code} تأیید شد**\n⚖️ {resolution} {result_amount}\n📦 تأییدشده: {items_approved}\n💬 {note}\n👮 توسط {decided_by} — {decided_at}\n🔗 {panel_link}" ),
			'rejected' => array( 'رد شد (پاسخ روی پیام اول)', "❌ **مرجوعی {code} رد شد**\n💬 دلیل: {note}\n👮 توسط {decided_by} — {decided_at}\n🔗 {panel_link}" ),
			'cancel'   => array( 'لغو توسط مشتری (پاسخ روی پیام اول)', "↩️ **مرجوعی {code} توسط مشتری لغو شد**\n👤 {customer} — {shop}" ),
			'welcome'  => array( 'خوش‌آمد (/start)', "سلام {name} 👋\nاین گفتگو برای دریافت اعلان‌های مرجوعی **{company}** ثبت شده است.\nشناسه عددی: {chat_id}" ),
		);
	}

	public static function tpl( $key ) {
		$t   = self::templates();
		$val = trim( (string) bws_opt( 'bot_tpl_' . $key, '' ) );
		return '' !== $val ? $val : ( isset( $t[ $key ] ) ? $t[ $key ][1] : '' );
	}

	/** Variables available in the templates (name => description). */
	public static function var_help() {
		return array(
			'code' => 'کد پیگیری', 'status' => 'وضعیت', 'date' => 'تاریخ ثبت', 'customer' => 'نام مشتری', 'customer_code' => 'کد مشتری', 'shop' => 'فروشگاه',
			'mobile' => 'موبایل مشتری', 'phone' => 'تلفن', 'address' => 'آدرس کامل', 'postal_code' => 'کد پستی', 'map' => 'لینک نقشه', 'visitor' => 'ویزیتور مشتری',
			'visitor_mobile' => 'موبایل ویزیتور', 'order' => 'شماره سفارش', 'order_date' => 'تاریخ سفارش', 'items' => 'اقلام (چندخطی)', 'items_approved' => 'اقلام تأییدشده',
			'amount' => 'ارزش اقلام', 'reason' => 'دلیل', 'description' => 'توضیحات مشتری', 'by' => 'ثبت توسط', 'photos_count' => 'تعداد عکس', 'drive_links' => 'لینک‌های گوگل‌درایو',
			'resolution' => 'نوع رسیدگی', 'result_amount' => 'مبلغ/سفارش جایگزین', 'note' => 'توضیح بررسی‌کننده / دلیل رد', 'decided_by' => 'بررسی توسط', 'decided_at' => 'زمان بررسی',
			'panel_link' => 'لینک پنل همان گیرنده', 'recipient' => 'نام گیرنده', 'company' => 'نام شرکت',
		);
	}

	public static function vars( $r, $rec = null, $c = null ) {
		$c     = $c ? $c : BWS_Customers::get( $r->customer_id );
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $r->order_id ) : null;
		$items = array();
		$appr  = array();
		foreach ( BWS_Returns::items( $r->id ) as $it ) {
			$items[] = '• ' . $it->name . ' × ' . bws_fa_digits( $it->qty ) . ' — فی ' . bws_money_text( $it->unit_price );
			if ( $it->approved_qty > 0 ) {
				$appr[] = $it->name . ' × ' . bws_fa_digits( $it->approved_qty );
			}
		}
		$files = BWS_Return_Files::for_return( $r->id );
		$links = array();
		foreach ( $files as $i => $f ) {
			if ( $f->drive_link && 'uploaded' === $f->state ) {
				$links[] = $f->drive_link;
			}
		}
		$vm = $c && $c->visitor_id ? (string) get_user_meta( $c->visitor_id, 'bws_mobile', true ) : '';
		$ra = '';
		if ( 'approved' === $r->status ) {
			$ra = 'credit' === $r->resolution ? bws_money_text( $r->approved_amount ) : ( $r->replacement_order_id ? 'سفارش #' . $r->replacement_order_id : ( (float) $r->approved_amount > 0 ? bws_money_text( $r->approved_amount ) : '' ) );
		}
		return array(
			'code'           => $r->code,
			'status'         => BWS_Returns::$statuses[ $r->status ],
			'date'           => bws_jdate( $r->created_at ),
			'customer'       => $c ? BWS_Customers::full_name( $c ) : '',
			'customer_code'  => $c ? $c->code : '',
			'shop'           => $c ? (string) $c->shop_name : '',
			'mobile'         => $c ? (string) $c->mobile : '',
			'phone'          => $c ? (string) $c->phone : '',
			'address'        => $c ? implode( '، ', array_filter( array( $c->province, $c->city, $c->address ) ) ) . ( $c->postal_code ? ' — کد پستی ' . $c->postal_code : '' ) : '',
			'postal_code'    => $c ? (string) $c->postal_code : '',
			'map'            => $c && null !== $c->lat && '' !== (string) $c->lat ? 'https://www.google.com/maps?q=' . $c->lat . ',' . $c->lng : '',
			'visitor'        => $c && $c->visitor_id ? bws_user_name( $c->visitor_id ) : '',
			'visitor_mobile' => $vm,
			'order'          => (string) $r->order_id,
			'order_date'     => $order && $order->get_date_created() ? bws_jdate( $order->get_date_created()->getTimestamp(), false ) : '',
			'items'          => implode( "\n", $items ),
			'items_approved' => implode( '، ', $appr ),
			'amount'         => bws_money_text( $r->amount ),
			'reason'         => $r->reason,
			'description'    => (string) $r->description,
			'by'             => 'customer' === $r->created_by_type ? 'خود مشتری' : bws_user_name( $r->created_by ) . ( 'visitor' === $r->created_by_type ? ' (ویزیتور)' : ' (مدیر)' ),
			'photos_count'   => bws_fa_digits( count( $files ) ),
			'drive_links'    => implode( "\n", $links ),
			'resolution'     => $r->resolution ? BWS_Returns::$resolutions[ $r->resolution ] : '',
			'result_amount'  => $ra,
			'note'           => (string) $r->decision_note,
			'decided_by'     => $r->decided_by ? bws_user_name( $r->decided_by ) : '',
			'decided_at'     => $r->decided_at ? bws_jdate( $r->decided_at ) : '',
			'panel_link'     => self::link_for( $rec, $r ),
			'recipient'      => $rec ? (string) $rec['name'] : '',
			'company'        => (string) bws_opt( 'company_name' ),
		);
	}

	/** Visible length (Telegram counts the text after HTML parsing). */
	protected static function visible( $text, $p ) {
		return mb_strlen( 'telegram' === $p ? html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' ) : $text );
	}

	protected static function fill( $tpl, $vars, $p ) {
		$html = 'telegram' === $p;
		$t    = $html ? esc_html( $tpl ) : $tpl;
		$t    = preg_replace( '/\*\*(.+?)\*\*/u', $html ? '<b>$1</b>' : '$1', $t );
		return preg_replace_callback( '/\{([a-z_]+)\}/', function ( $m ) use ( $vars, $html ) {
			if ( ! array_key_exists( $m[1], $vars ) ) {
				return $m[0];
			}
			return $html ? esc_html( (string) $vars[ $m[1] ] ) : (string) $vars[ $m[1] ];
		}, $t );
	}

	/**
	 * Render a template: lines whose variables are all empty are dropped; long fields (description, address, items…)
	 * are shortened first so the text fits the platform limit (caption 1024 / message 4096).
	 */
	public static function render( $tpl, $vars, $p, $limit = self::TEXT ) {
		$keep = array();
		foreach ( preg_split( '/\r?\n/', (string) $tpl ) as $line ) {
			if ( preg_match_all( '/\{([a-z_]+)\}/', $line, $m ) && $m[1] ) {
				$any = false;
				foreach ( $m[1] as $k ) {
					if ( isset( $vars[ $k ] ) && '' !== trim( (string) $vars[ $k ] ) ) {
						$any = true;
					}
				}
				if ( ! $any ) {
					continue;
				}
			}
			$keep[] = $line;
		}
		$tpl  = trim( implode( "\n", $keep ) );
		$text = self::fill( $tpl, $vars, $p );
		foreach ( array( 'description', 'drive_links', 'address', 'items', 'note', 'map' ) as $k ) {
			$over = self::visible( $text, $p ) - $limit;
			if ( $over <= 0 ) {
				break;
			}
			if ( empty( $vars[ $k ] ) || false === strpos( $tpl, '{' . $k . '}' ) ) {
				continue;
			}
			$len        = mb_strlen( $vars[ $k ] );
			$vars[ $k ] = $len - $over - 2 > 30 ? mb_substr( $vars[ $k ], 0, $len - $over - 2 ) . '…' : mb_substr( $vars[ $k ], 0, 30 ) . '…';
			$text       = self::fill( $tpl, $vars, $p );
		}
		if ( self::visible( $text, $p ) > $limit ) {
			$plain = 'telegram' === $p ? html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' ) : $text;
			$plain = mb_substr( $plain, 0, $limit - 1 ) . '…';
			$text  = 'telegram' === $p ? esc_html( $plain ) : $plain;
		}
		return $text;
	}

	/* ------------------------------------------------------------------ */
	/* Delivery                                                            */
	/* ------------------------------------------------------------------ */

	protected static function keyboard( $rec, $r, $link ) {
		$rows = array();
		if ( $rec['decide'] && $rec['user'] && 'pending' === $r->status ) {
			$rows[] = array( array( 'text' => '✅ تأیید', 'callback_data' => 'a:' . $r->id ), array( 'text' => '❌ رد', 'callback_data' => 'r:' . $r->id ) );
		}
		if ( BWS_Messenger::button_ok( $link ) ) {
			$rows[] = array( array( 'text' => '🔗 مشاهده در پنل', 'url' => $link ) );
		}
		return $rows ? array( 'inline_keyboard' => $rows ) : null;
	}

	/**
	 * Notify every matching recipient of an event. $st is the notify_state array (updated in place).
	 * Returns true when something failed temporarily and should be retried.
	 */
	public static function deliver( $r, $event, &$st ) {
		$retry = false;
		$c     = BWS_Customers::get( $r->customer_id );
		$cache = null;
		foreach ( self::recipients() as $rec ) {
			if ( ! in_array( $event, $rec['ev'], true ) || ! self::in_scope( $rec, $r, $c ) ) {
				continue;
			}
			$k = $event . '|' . $rec['p'] . '|' . $rec['chat'];
			if ( isset( $st['bots'][ $k ] ) && 'ok' === $st['bots'][ $k ] ) {
				continue;
			}
			if ( 'new' === $event ) {
				if ( null === $cache ) {
					$cache = bws_opt( 'bot_photos', 1 ) ? BWS_Return_Files::send_list( $r->id ) : array();
				}
				$res = self::send_view( $rec, $r, $st, $rec['photos'] ? $cache : array(), 0, $c );
			} else {
				$res = self::send_update( $rec, $r, $event, $st, $c );
			}
			$st['bots'][ $k ] = $res['ok'] ? 'ok' : mb_substr( (string) $res['error'], 0, 200 );
			if ( ! $res['ok'] && ! in_array( (int) $res['code'], array( 400, 401, 403 ), true ) ) {
				$retry = true; // network / 429 / 5xx.
			}
		}
		if ( $cache ) {
			BWS_Return_Files::cleanup_tmp( $cache );
		}
		return $retry;
	}

	/**
	 * The request itself: photo(s) with the information as caption in ONE message (album caption for 2+ photos).
	 * Albums cannot carry buttons, so for 2+ photos the buttons come in a small reply under the album.
	 */
	public static function send_view( $rec, $r, &$st, $photos, $reply_to = 0, $c = null ) {
		$p      = $rec['p'];
		$cfg    = BWS_Messenger::cfg( $p );
		$link   = self::link_for( $rec, $r );
		$vars   = self::vars( $r, $rec, $c );
		$kb     = self::keyboard( $rec, $r, $link );
		$extra  = BWS_Messenger::reply_to( $p, $reply_to );
		$pc     = $p . '|' . $rec['chat'];
		$kbid   = 0;
		$mid    = 0;
		$res    = array( 'ok' => false, 'code' => 0, 'error' => '' );
		$photos = array_values( array_filter( (array) $photos, function ( $f ) {
			return is_readable( $f[0] ) && filesize( $f[0] ) <= 10 * MB_IN_BYTES;
		} ) );
		$hard   = function ( $x ) {
			// Errors where another format will not help: wrong token, user has not started the bot, network.
			return in_array( (int) $x['code'], array( 401, 403 ), true ) || ! empty( $x['net'] ) || 429 === (int) $x['code'];
		};
		if ( 1 === count( $photos ) ) {
			$res = BWS_Messenger::send_photo( $p, $rec['chat'], $photos[0], self::render( self::tpl( 'new' ), $vars, $p, self::CAPTION ), array_merge( $extra, $kb ? array( 'reply_markup' => $kb ) : array() ), $cfg );
			if ( ! $res['ok'] && $kb && ! $hard( $res ) ) {
				// Some servers refuse buttons on photos: photo + caption first, buttons as a reply.
				$res = BWS_Messenger::send_photo( $p, $rec['chat'], $photos[0], self::render( self::tpl( 'new' ), $vars, $p, self::CAPTION ), $extra, $cfg );
				$mid = BWS_Messenger::message_id( $res );
			} else {
				$mid  = BWS_Messenger::message_id( $res );
				$kbid = $kb && $res['ok'] ? $mid : 0;
			}
		} elseif ( count( $photos ) > 1 ) {
			$cap = self::render( self::tpl( 'new' ), $vars, $p, self::CAPTION );
			$res = BWS_Messenger::send_album( $p, $rec['chat'], $photos, $cap, $extra, $cfg );
			if ( ! $res['ok'] && ! $hard( $res ) ) {
				// Album rejected: first photo carries the caption, the other photos follow as replies.
				$res = BWS_Messenger::send_photo( $p, $rec['chat'], $photos[0], $cap, $extra, $cfg );
				$mid = BWS_Messenger::message_id( $res );
				if ( $res['ok'] ) {
					foreach ( array_slice( $photos, 1 ) as $f ) {
						BWS_Messenger::send_photo( $p, $rec['chat'], $f, '', BWS_Messenger::reply_to( $p, $mid ), $cfg );
					}
				}
			} else {
				$mid = BWS_Messenger::message_id( $res );
			}
		}
		if ( $photos && ! $res['ok'] && ! $hard( $res ) ) {
			// Photos could not be delivered at all: the request itself must never be lost → full text message,
			// then the photos (without caption) as replies, best effort.
			$photo_err = $res;
			$res       = BWS_Messenger::send_text( $p, $rec['chat'], self::render( self::tpl( 'new' ), $vars, $p, self::TEXT ), null, $cfg, array_merge( $extra, $kb ? array( 'reply_markup' => $kb ) : array() ) );
			$mid       = BWS_Messenger::message_id( $res );
			$kbid      = $kb && $res['ok'] ? $mid : 0;
			if ( $res['ok'] ) {
				foreach ( $photos as $f ) {
					BWS_Messenger::send_photo( $p, $rec['chat'], $f, '', BWS_Messenger::reply_to( $p, $mid ), $cfg );
				}
				$st['photo_error'][ $pc ] = mb_substr( (string) $photo_err['error'], 0, 150 );
			}
		} elseif ( ! $photos ) {
			$res  = BWS_Messenger::send_text( $p, $rec['chat'], self::render( self::tpl( 'new' ), $vars, $p, self::TEXT ), null, $cfg, array_merge( $extra, $kb ? array( 'reply_markup' => $kb ) : array() ) );
			$mid  = BWS_Messenger::message_id( $res );
			$kbid = $kb && $res['ok'] ? $mid : 0;
		}
		if ( $res['ok'] && $kb && ! $kbid ) {
			// Albums cannot carry buttons: a small reply right under the request holds them.
			$k2   = BWS_Messenger::send_text( $p, $rec['chat'], '⬆️ ' . ( 'telegram' === $p ? '<b>' . esc_html( $r->code ) . '</b>' : $r->code ) . ' — ' . ( $rec['decide'] && 'pending' === $r->status ? 'تأیید یا رد:' : 'مشاهده:' ), null, $cfg, array_merge( BWS_Messenger::reply_to( $p, $mid ), array( 'reply_markup' => $kb ) ) );
			$kbid = BWS_Messenger::message_id( $k2 );
		}
		if ( $res['ok'] && $mid ) {
			if ( empty( $st['root'][ $pc ] ) || ! $reply_to ) {
				$st['root'][ $pc ] = $mid;
			}
			if ( $kbid ) {
				$st['kb'][ $pc ][] = $kbid;
			}
		}
		return $res;
	}

	/** Approved / rejected / cancelled — always a reply on the first message of that request in that chat. */
	public static function send_update( $rec, $r, $event, &$st, $c = null ) {
		$p    = $rec['p'];
		$cfg  = BWS_Messenger::cfg( $p );
		$pc   = $p . '|' . $rec['chat'];
		$key  = 'cancel' === $event ? 'cancel' : ( 'approved' === $r->status ? 'approved' : 'rejected' );
		$text = self::render( self::tpl( $key ), self::vars( $r, $rec, $c ), $p, self::TEXT );
		$root = isset( $st['root'][ $pc ] ) ? (int) $st['root'][ $pc ] : 0;
		$res  = BWS_Messenger::send_text( $p, $rec['chat'], $text, null, $cfg, array_merge( BWS_Messenger::reply_to( $p, $root ), 'telegram' === $p ? array( 'parse_mode' => 'HTML' ) : array() ) );
		if ( $res['ok'] && ! empty( $st['kb'][ $pc ] ) ) {
			foreach ( (array) $st['kb'][ $pc ] as $kid ) {
				BWS_Messenger::clear_keyboard( $p, $rec['chat'], $kid, $cfg ); // Stale approve/reject buttons disappear.
			}
			unset( $st['kb'][ $pc ] );
		}
		return $res;
	}

	/* ------------------------------------------------------------------ */
	/* Interaction: webhook / polling                                      */
	/* ------------------------------------------------------------------ */

	public static function secret() {
		$s = (string) bws_opt( 'bot_secret', '' );
		if ( ! preg_match( '/^[a-f0-9]{32}$/', $s ) ) {
			$s = bin2hex( random_bytes( 16 ) );
			bws_update_settings( array( 'bot_secret' => $s ) );
		}
		return $s;
	}

	public static function webhook_url( $p ) {
		return rest_url( BWS_REST::NS . '/bot/' . $p . '/' . self::secret() );
	}

	public static function routes() {
		register_rest_route( BWS_REST::NS, '/bot/(?P<p>telegram|bale)/(?P<s>[a-f0-9]{32})', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'rest_webhook' ),
			'permission_callback' => '__return_true', // Authenticated by the secret in the URL (and Telegram's secret header).
		) );
	}

	public static function rest_webhook( $req ) {
		$p = (string) $req['p'];
		if ( ! hash_equals( self::secret(), (string) $req['s'] ) || 'webhook' !== bws_opt( 'bot_mode', 'off' ) ) {
			return new WP_REST_Response( array( 'ok' => false ), 403 );
		}
		$h = (string) $req->get_header( 'x_telegram_bot_api_secret_token' );
		if ( '' !== $h && ! hash_equals( self::secret(), $h ) ) {
			return new WP_REST_Response( array( 'ok' => false ), 403 );
		}
		$u = json_decode( (string) $req->get_body(), true );
		if ( is_array( $u ) ) {
			self::handle_update( $p, $u );
		}
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/** WP-Cron (every minute) when the mode is "polling": getUpdates with a stored offset. */
	public static function poll() {
		if ( 'polling' !== bws_opt( 'bot_mode', 'off' ) || ! bws_lock( 'bot_poll', 55 ) ) {
			return;
		}
		try {
			foreach ( BWS_Messenger::active() as $p ) {
				$off = (int) get_option( 'bws_bot_offset_' . $p, 0 );
				$r   = BWS_Messenger::call( $p, 'getUpdates', array_filter( array( 'offset' => $off ? $off : null, 'limit' => 50, 'timeout' => 0 ) ) );
				if ( empty( $r['ok'] ) ) {
					continue;
				}
				foreach ( (array) $r['result'] as $u ) {
					if ( isset( $u['update_id'] ) ) {
						$off = max( $off, (int) $u['update_id'] + 1 );
						update_option( 'bws_bot_offset_' . $p, $off, false );
					}
					self::handle_update( $p, $u );
				}
			}
		} finally {
			bws_unlock( 'bot_poll' );
		}
	}

	protected static function remember_chat( $p, $chat ) {
		$seen = get_option( 'bws_bot_seen_' . $p, array() );
		$seen = is_array( $seen ) ? $seen : array();
		$id   = (string) $chat['id'];
		$name = isset( $chat['title'] ) ? $chat['title'] : trim( ( isset( $chat['first_name'] ) ? $chat['first_name'] : '' ) . ' ' . ( isset( $chat['last_name'] ) ? $chat['last_name'] : '' ) );
		$seen[ $id ] = array( 'id' => $id, 'name' => sanitize_text_field( $name ), 'username' => isset( $chat['username'] ) ? sanitize_text_field( $chat['username'] ) : '', 'type' => isset( $chat['type'] ) ? sanitize_key( $chat['type'] ) : '' );
		update_option( 'bws_bot_seen_' . $p, array_slice( $seen, -50, null, true ), false );
	}

	protected static function state_key( $p, $from ) {
		return 'bws_bot_st_' . md5( $p . '|' . $from );
	}

	protected static function say( $p, $chat, $text, $extra = array() ) {
		if ( 'telegram' === $p ) {
			$extra['parse_mode'] = 'HTML';
		}
		return BWS_Messenger::send_text( $p, $chat, $text, null, null, $extra );
	}

	protected static function b( $p, $s ) {
		return 'telegram' === $p ? '<b>' . esc_html( $s ) . '</b>' : $s;
	}

	protected static function e( $p, $s ) {
		return 'telegram' === $p ? esc_html( $s ) : $s;
	}

	public static function handle_update( $p, $u ) {
		if ( isset( $u['update_id'] ) ) {
			$key  = 'bws_bot_upd_' . $p;
			$done = get_transient( $key );
			$done = is_array( $done ) ? $done : array();
			if ( in_array( (int) $u['update_id'], $done, true ) ) {
				return; // Telegram re-sends an update when the previous answer was slow.
			}
			$done[] = (int) $u['update_id'];
			set_transient( $key, array_slice( $done, -200 ), DAY_IN_SECONDS );
		}
		$prev = get_current_user_id();
		try {
			if ( ! empty( $u['callback_query'] ) ) {
				self::on_callback( $p, $u['callback_query'] );
			} elseif ( ! empty( $u['message'] ) ) {
				self::on_message( $p, $u['message'] );
			}
		} finally {
			wp_set_current_user( $prev );
		}
	}

	protected static function menu( $rec ) {
		return $rec && $rec['list'] ? array( 'reply_markup' => array( 'keyboard' => array( array( array( 'text' => self::MENU_OPEN ) ) ), 'resize_keyboard' => true ) ) : array();
	}

	protected static function on_message( $p, $m ) {
		if ( empty( $m['chat']['id'] ) ) {
			return;
		}
		self::remember_chat( $p, $m['chat'] );
		$chat = (string) $m['chat']['id'];
		$from = isset( $m['from']['id'] ) ? (string) $m['from']['id'] : $chat;
		$text = trim( isset( $m['text'] ) ? (string) $m['text'] : '' );
		$rec  = self::find( $p, $chat );
		if ( '' === $text ) {
			return;
		}
		$cmd = strtolower( preg_replace( '/@.*$/', '', strtok( $text, " \n" ) ) );
		if ( '/cancel' === $cmd ) {
			delete_transient( self::state_key( $p, $from ) );
			self::say( $p, $chat, 'لغو شد.', self::menu( $rec ) );
			return;
		}
		if ( in_array( $cmd, array( '/start', '/id', '/menu', '/help' ), true ) ) {
			self::welcome( $p, $chat, $from, $rec );
			return;
		}
		$state = get_transient( self::state_key( $p, $from ) );
		if ( is_array( $state ) && '/' !== substr( $text, 0, 1 ) && self::MENU_OPEN !== $text ) {
			self::finish_reject( $p, $chat, $from, $state, $text, isset( $m['message_id'] ) ? (int) $m['message_id'] : 0 );
			return;
		}
		if ( self::MENU_OPEN === $text || '/open' === $cmd ) {
			self::open_list( $p, $chat, $rec );
			return;
		}
		if ( 'private' === ( isset( $m['chat']['type'] ) ? $m['chat']['type'] : 'private' ) ) {
			self::welcome( $p, $chat, $from, $rec );
		}
	}

	protected static function welcome( $p, $chat, $from, $rec ) {
		if ( $rec ) {
			$t = self::render( self::tpl( 'welcome' ), array( 'name' => $rec['name'] ? $rec['name'] : ( $rec['user'] ? bws_user_name( $rec['user'] ) : '' ), 'company' => (string) bws_opt( 'company_name' ), 'chat_id' => $chat ), $p );
			$t .= $rec['list'] ? "\n\n" . 'برای دیدن درخواست‌های در انتظار بررسی، دکمه «' . self::MENU_OPEN . '» را بزنید.' : '';
			self::say( $p, $chat, $t, self::menu( $rec ) );
			return;
		}
		$t = 'شناسه عددی این گفتگو: ' . self::b( $p, $chat ) . ( $from !== $chat ? "\n" . 'شناسه عددی شما: ' . self::b( $p, $from ) : '' ) . "\n\n" . 'برای دریافت اعلان‌های مرجوعی ' . self::e( $p, (string) bws_opt( 'company_name' ) ) . '، این شناسه را به مدیر سایت بدهید تا در تنظیمات افزونه ثبت کند.';
		self::say( $p, $chat, $t );
	}

	/** Pending requests in the recipient's scope, each with a button to see it (photos + details). */
	protected static function open_list( $p, $chat, $rec ) {
		if ( ! $rec || ! $rec['list'] ) {
			self::say( $p, $chat, 'اجازه دیدن لیست مرجوعی‌ها برای این گفتگو فعال نیست.' );
			return;
		}
		$q = BWS_Returns::query( array( 'status' => 'pending', 'visitor_id' => 'own' === $rec['scope'] ? $rec['user'] : 0, 'per_page' => 25 ) );
		if ( ! $q['items'] ) {
			self::say( $p, $chat, '✅ هیچ مرجوعی در انتظار بررسی وجود ندارد.', self::menu( $rec ) );
			return;
		}
		$lines = array( self::b( $p, '📋 مرجوعی‌های در انتظار بررسی: ' . bws_fa_digits( $q['total'] ) ) . ( $q['total'] > 25 ? self::e( $p, ' (۲۵ مورد اخیر)' ) : '' ), '' );
		$kb    = array();
		foreach ( $q['items'] as $i => $r ) {
			$c       = BWS_Customers::get( $r->customer_id );
			$name    = $c ? BWS_Customers::full_name( $c ) : '—';
			$lines[] = bws_fa_digits( $i + 1 ) . ') ' . self::b( $p, $r->code ) . self::e( $p, ' — ' . $name . ( $c && $c->shop_name ? ' (' . $c->shop_name . ')' : '' ) . ' — ' . bws_jdate( $r->created_at, false ) . "\n   " . BWS_Returns::items_text( $r ) );
			$kb[]    = array( array( 'text' => '👁 ' . $r->code . ' · ' . mb_substr( $name, 0, 24 ), 'callback_data' => 'v:' . $r->id ) );
		}
		$text = implode( "\n", $lines );
		if ( self::visible( $text, $p ) > self::TEXT ) {
			$text = mb_substr( $text, 0, self::TEXT - 1 ) . '…';
		}
		self::say( $p, $chat, $text, array( 'reply_markup' => array( 'inline_keyboard' => $kb ) ) );
	}

	protected static function actor( $p, $from, $r ) {
		$a = self::find( $p, $from );
		if ( ! $a || ! $a['decide'] || ! $a['user'] || ! self::in_scope( $a, $r ) ) {
			return null;
		}
		wp_set_current_user( $a['user'] );
		if ( ! ( bws_is_manager() || ( bws_is_visitor() && bws_visitor_active( $a['user'] ) && BWS_Returns::staff_can( 'returns_decide', BWS_Customers::get( $r->customer_id ) ) ) ) ) {
			return null;
		}
		return $a;
	}

	protected static function on_callback( $p, $q ) {
		$data = isset( $q['data'] ) ? (string) $q['data'] : '';
		$from = isset( $q['from']['id'] ) ? (string) $q['from']['id'] : '';
		$chat = isset( $q['message']['chat']['id'] ) ? (string) $q['message']['chat']['id'] : $from;
		$mid  = isset( $q['message']['message_id'] ) ? (int) $q['message']['message_id'] : 0;
		$ans  = function ( $t = '' ) use ( $p, $q ) {
			BWS_Messenger::answer_callback( $p, isset( $q['id'] ) ? $q['id'] : '', $t );
		};
		$parts = explode( ':', $data );
		$act   = $parts[0];
		$r     = isset( $parts[1] ) ? BWS_Returns::get( (int) $parts[1] ) : null;
		if ( ! $r ) {
			$ans( 'درخواست پیدا نشد.' );
			return;
		}
		if ( 'v' === $act ) {
			$rec = self::find( $p, $chat );
			if ( ! $rec || ! self::in_scope( $rec, $r ) ) {
				$ans( 'دسترسی ندارید.' );
				return;
			}
			$ans();
			$st     = BWS_Returns::state( $r );
			$photos = $rec['photos'] && bws_opt( 'bot_photos', 1 ) ? BWS_Return_Files::send_list( $r->id ) : array();
			self::send_view( $rec, $r, $st, $photos, $mid );
			BWS_Return_Files::cleanup_tmp( $photos );
			BWS_Returns::save_state( $r->id, $st );
			return;
		}
		if ( 'x' === $act ) {
			$ans( 'لغو شد' );
			BWS_Messenger::clear_keyboard( $p, $chat, $mid );
			return;
		}
		$a = self::actor( $p, $from, $r );
		if ( ! $a ) {
			$ans( 'اجازه تأیید یا رد این مرجوعی را ندارید.' );
			return;
		}
		if ( 'pending' !== $r->status ) {
			$ans( 'این درخواست قبلاً «' . BWS_Returns::$statuses[ $r->status ] . '» شده است.' );
			BWS_Messenger::clear_keyboard( $p, $chat, $mid );
			return;
		}
		if ( 'a' === $act ) {
			$ans();
			$rows = array();
			foreach ( BWS_Returns::allowed_resolutions() as $res ) {
				$rows[] = array( array( 'text' => ( 'credit' === $res ? '💰 ' : ( 'replacement' === $res ? '📦 ' : '📝 ' ) ) . BWS_Returns::$resolutions[ $res ] . ( 'credit' === $res ? ' (' . bws_money_text( $r->amount ) . ')' : '' ), 'callback_data' => 'ar:' . $r->id . ':' . $res ) );
			}
			$rows[] = array( array( 'text' => 'انصراف', 'callback_data' => 'x:' . $r->id ) );
			self::say( $p, $chat, 'تأیید ' . self::b( $p, $r->code ) . self::e( $p, ' (' . BWS_Returns::items_text( $r ) . ') — نوع رسیدگی را انتخاب کنید:' ), array_merge( BWS_Messenger::reply_to( $p, $mid ), array( 'reply_markup' => array( 'inline_keyboard' => $rows ) ) ) );
			return;
		}
		if ( 'ar' === $act ) {
			$res = BWS_Returns::decide( $r->id, array( 'decision' => 'approve', 'resolution' => isset( $parts[2] ) ? sanitize_key( $parts[2] ) : 'manual', 'note' => '', 'notify' => true ), BWS_Returns::allowed_resolutions() );
			if ( is_wp_error( $res ) ) {
				$ans( mb_substr( $res->get_error_message(), 0, 190 ) );
				return;
			}
			$ans( '✅ تأیید شد' );
			BWS_Messenger::clear_keyboard( $p, $chat, $mid );
			return;
		}
		if ( 'r' === $act ) {
			$ans();
			set_transient( self::state_key( $p, $from ), array( 'id' => (int) $r->id, 'chat' => $chat ), 15 * MINUTE_IN_SECONDS );
			$fr = 'telegram' === $p ? array( 'reply_markup' => array( 'force_reply' => true, 'selective' => true, 'input_field_placeholder' => 'دلیل رد…' ) ) : array();
			self::say( $p, $chat, '✍️ دلیل رد ' . self::b( $p, $r->code ) . ' را بنویسید و بفرستید (برای مشتری پیامک می‌شود). انصراف: /cancel', array_merge( BWS_Messenger::reply_to( $p, $mid ), $fr ) );
			return;
		}
		$ans();
	}

	protected static function finish_reject( $p, $chat, $from, $state, $text, $mid ) {
		delete_transient( self::state_key( $p, $from ) );
		$r = BWS_Returns::get( (int) $state['id'] );
		if ( ! $r ) {
			return;
		}
		$a = self::actor( $p, $from, $r );
		if ( ! $a ) {
			self::say( $p, $chat, 'اجازه رد این مرجوعی را ندارید.' );
			return;
		}
		$res = BWS_Returns::decide( $r->id, array( 'decision' => 'reject', 'note' => $text, 'notify' => true ), BWS_Returns::allowed_resolutions() );
		if ( is_wp_error( $res ) ) {
			self::say( $p, $chat, '⚠️ ' . self::e( $p, $res->get_error_message() ), BWS_Messenger::reply_to( $p, $mid ) );
			return;
		}
		self::say( $p, $chat, '❌ ' . self::b( $p, $r->code ) . ' رد شد و به همه اطلاع داده شد.', array_merge( BWS_Messenger::reply_to( $p, $mid ), self::menu( self::find( $p, $chat ) ) ) );
	}

	/* ------------------------------------------------------------------ */
	/* Admin helpers                                                       */
	/* ------------------------------------------------------------------ */

	/** Apply the interaction mode to the bots (webhook / polling / off). */
	public static function apply_mode() {
		$mode = bws_opt( 'bot_mode', 'off' );
		$out  = array();
		foreach ( BWS_Messenger::active() as $p ) {
			if ( 'webhook' === $mode ) {
				$url = self::webhook_url( $p );
				$r   = 0 === strpos( $url, 'https://' ) ? BWS_Messenger::set_webhook( $p, $url, self::secret() ) : array( 'ok' => false, 'error' => 'وب‌هوک فقط با https کار می‌کند؛ گواهی SSL سایت را فعال کنید یا حالت «دریافت دوره‌ای» را انتخاب کنید.' );
			} else {
				$r = BWS_Messenger::delete_webhook( $p );
			}
			$out[ BWS_Messenger::platforms()[ $p ] ] = $r['ok'] ? ( 'webhook' === $mode ? 'وب‌هوک فعال شد' : ( 'polling' === $mode ? 'دریافت دوره‌ای (هر دقیقه) فعال شد' : 'تعامل غیرفعال شد' ) ) : $r['error'];
		}
		return $out;
	}

	/** Sample rendering for the settings preview. */
	public static function preview( $key, $tpl, $p ) {
		$r = BWS_Returns::query( array( 'per_page' => 1 ) );
		$r = $r['items'] ? $r['items'][0] : null;
		if ( 'welcome' === $key ) {
			$vars = array( 'name' => 'علی', 'company' => (string) bws_opt( 'company_name' ), 'chat_id' => '123456789' );
		} elseif ( $r ) {
			$vars = self::vars( $r, null );
			if ( in_array( $key, array( 'approved', 'rejected' ), true ) && 'pending' === $r->status ) {
				$vars = array_merge( $vars, array( 'resolution' => BWS_Returns::$resolutions['credit'], 'result_amount' => bws_money_text( $r->amount ), 'items_approved' => BWS_Returns::items_text( $r ), 'note' => 'approved' === $key ? '' : 'عکس‌ها کپک را نشان نمی‌دهد', 'decided_by' => bws_user_name( get_current_user_id() ), 'decided_at' => bws_jdate( bws_now() ) ) );
			}
		} else {
			return array( 'text' => 'برای پیش‌نمایش حداقل یک درخواست مرجوعی لازم است.', 'length' => 0, 'limit' => self::TEXT );
		}
		$limit = 'new' === $key ? self::CAPTION : self::TEXT;
		$text  = self::render( $tpl, $vars, $p, 100000 );
		$len   = self::visible( $text, $p );
		return array( 'text' => 'telegram' === $p ? html_entity_decode( wp_strip_all_tags( str_replace( array( '<b>', '</b>' ), array( '', '' ), $text ) ), ENT_QUOTES, 'UTF-8' ) : $text, 'length' => $len, 'limit' => $limit, 'over' => $len > $limit );
	}
}
