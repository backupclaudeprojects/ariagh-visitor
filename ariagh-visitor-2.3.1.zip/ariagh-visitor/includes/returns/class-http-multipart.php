<?php
defined( 'ABSPATH' ) || exit;

/**
 * Small helper to build multipart bodies for the WordPress HTTP API
 * (wp_remote_post cannot upload files by itself).
 */
class BWS_Multipart {

	/**
	 * multipart/form-data body.
	 *
	 * @param array $fields name => string value.
	 * @param array $files  name => [ path, filename, mime ].
	 * @return array [ body, content_type ]
	 */
	public static function form( array $fields, array $files = array() ) {
		$b    = 'bws' . bin2hex( random_bytes( 12 ) );
		$body = '';
		foreach ( $fields as $name => $value ) {
			$body .= '--' . $b . "\r\n";
			$body .= 'Content-Disposition: form-data; name="' . self::q( $name ) . "\"\r\n\r\n";
			$body .= (string) $value . "\r\n";
		}
		foreach ( $files as $name => $f ) {
			$data = file_get_contents( $f[0] ); // phpcs:ignore
			if ( false === $data ) {
				continue;
			}
			$body .= '--' . $b . "\r\n";
			$body .= 'Content-Disposition: form-data; name="' . self::q( $name ) . '"; filename="' . self::q( $f[1] ) . "\"\r\n";
			$body .= 'Content-Type: ' . $f[2] . "\r\n\r\n";
			$body .= $data . "\r\n";
		}
		$body .= '--' . $b . "--\r\n";
		return array( $body, 'multipart/form-data; boundary=' . $b );
	}

	/** multipart/related body (Google Drive "uploadType=multipart"): JSON metadata + raw bytes. */
	public static function related( array $meta, $bytes, $mime ) {
		$b    = 'bws' . bin2hex( random_bytes( 12 ) );
		$body = '--' . $b . "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" . wp_json_encode( $meta, JSON_UNESCAPED_UNICODE ) . "\r\n";
		$body .= '--' . $b . "\r\nContent-Type: " . $mime . "\r\n\r\n" . $bytes . "\r\n--" . $b . "--\r\n";
		return array( $body, 'multipart/related; boundary=' . $b );
	}

	protected static function q( $s ) {
		return str_replace( array( '"', "\r", "\n" ), array( '', '', '' ), (string) $s );
	}
}
