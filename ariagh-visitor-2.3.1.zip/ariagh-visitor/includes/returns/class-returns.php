<?php
defined( 'ABSPATH' ) || exit;

/**
 * Product returns (مرجوعی کالا).
 *
 * A customer (or a visitor on behalf of a customer) picks one of his orders, the defective items and quantities,
 * a reason (required), a description and at least one photo. The request is "pending" until a visitor/manager
 * with permission approves (credit back / replacement order / manual settlement) or rejects it.
 * Data always lives in the site database; photos live on the host or on Google Drive (settings).
 * Telegram / Bale bots and SMS are notified after the HTTP response is sent (no waiting for the user).
 */
class BWS_Returns {

	public static $statuses = array(
		'pending'   => 'در انتظار بررسی',
		'approved'  => 'تأیید شد',
		'rejected'  => 'رد شد',
		'cancelled' => 'لغو شده توسط مشتری',
	);

	public static $resolutions = array(
		'credit'      => 'برگشت مبلغ به اعتبار مشتری',
		'replacement' => 'ارسال کالای جایگزین',
		'manual'      => 'تسویه / پیگیری دستی',
	);

	protected static $queue      = array();
	protected static $registered = false;

	public static function init() {
		BWS_Return_Files::init();
		BWS_GDrive::init();
		BWS_Bot::init();
		add_action( 'bws_daily', array( 'BWS_Return_Files', 'autoclean' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'bws_returns_retry', array( __CLASS__, 'retry' ) );
		// Every 5 minutes: retries + safety net for requests whose notification never ran.
		if ( 'bws_5min' !== wp_get_schedule( 'bws_returns_retry' ) ) {
			wp_clear_scheduled_hook( 'bws_returns_retry' );
			wp_schedule_event( time() + 120, 'bws_5min', 'bws_returns_retry' );
		}
	}

	public static function table() {
		return BWS_Install::table( 'returns' );
	}

	public static function items_table() {
		return BWS_Install::table( 'return_items' );
	}

	public static function enabled() {
		return (bool) bws_opt( 'returns_enabled', 1 );
	}

	/** Reasons from settings (one per line). */
	public static function reasons() {
		$out = array();
		foreach ( preg_split( '/\r?\n/', (string) bws_opt( 'return_reasons', 'کپک‌زدگی محصول' ) ) as $l ) {
			$l = trim( sanitize_text_field( $l ) );
			if ( '' !== $l ) {
				$out[] = $l;
			}
		}
		return $out ? array_values( array_unique( $out ) ) : array( 'کپک‌زدگی محصول' );
	}

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ) );
	}

	public static function items( $id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::items_table() . ' WHERE return_id = %d ORDER BY id ASC', $id ) );
	}

	/* ------------------------------------------------------------------ */
	/* Eligibility                                                         */
	/* ------------------------------------------------------------------ */

	/** order_item_id => qty already requested (pending) or approved. */
	protected static function used_qty( $customer_id ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			'SELECT ri.order_item_id, SUM(CASE WHEN r.status = %s THEN ri.approved_qty ELSE ri.qty END) AS q FROM ' . self::items_table() . ' ri INNER JOIN ' . self::table() . " r ON r.id = ri.return_id WHERE r.customer_id = %d AND r.status IN ('pending','approved') GROUP BY ri.order_item_id",
			'approved',
			$customer_id
		) );
		$out = array();
		foreach ( $rows as $r ) {
			$out[ (int) $r->order_item_id ] = (int) $r->q;
		}
		return $out;
	}

	/** Orders of a customer that can still be returned, with returnable quantities. */
	public static function eligible_orders( $customer, $only_order = 0 ) {
		global $wpdb;
		$statuses = array_values( array_filter( array_map( 'sanitize_key', (array) bws_opt( 'return_statuses', array( 'processing', 'completed' ) ) ) ) );
		if ( ! $statuses ) {
			return array();
		}
		$days  = (int) bws_opt( 'return_days', 30 );
		$where = $wpdb->prepare( "customer_id = %d AND kind = 'order'", $customer->id );
		$where .= " AND status IN ('" . implode( "','", array_map( 'esc_sql', $statuses ) ) . "')";
		if ( $days > 0 ) {
			$where .= $wpdb->prepare( ' AND created_at >= %s', gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $days * DAY_IN_SECONDS ) );
		}
		if ( $only_order ) {
			$where .= $wpdb->prepare( ' AND order_id = %d', $only_order );
		}
		$rows = $wpdb->get_results( 'SELECT * FROM ' . BWS_Orders::table() . " WHERE $where ORDER BY id DESC LIMIT 40" );
		$used = self::used_qty( $customer->id );
		$out  = array();
		foreach ( $rows as $o ) {
			$order = wc_get_order( $o->order_id );
			if ( ! $order ) {
				continue;
			}
			$items = array();
			foreach ( $order->get_items( 'line_item' ) as $iid => $it ) {
				$qty  = (int) $it->get_quantity();
				$left = $qty - ( isset( $used[ $iid ] ) ? $used[ $iid ] : 0 );
				if ( $left <= 0 ) {
					continue;
				}
				$unit    = $qty ? round( (float) $it->get_total() / $qty, 2 ) : 0;
				$pid     = $it->get_variation_id() ? $it->get_variation_id() : $it->get_product_id();
				$product = $it->get_product();
				$img     = $product && $product->get_image_id() ? wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' ) : '';
				$items[] = array( 'item_id' => (int) $iid, 'product_id' => (int) $pid, 'name' => wp_strip_all_tags( $it->get_name() ), 'qty' => $qty, 'max' => $left, 'unit' => $unit, 'unit_text' => bws_money_text( $unit ), 'image' => $img ? $img : '' );
			}
			if ( $items ) {
				$out[] = array( 'order_id' => (int) $o->order_id, 'date' => bws_jdate( $o->created_at, false ), 'total_text' => bws_money_text( $o->total ), 'status' => BWS_Orders::status_label( $o->status ), 'items' => $items );
			}
		}
		return $out;
	}

	public static function options( $customer ) {
		return array(
			'enabled'      => self::enabled(),
			'reasons'      => self::reasons(),
			'orders'       => self::enabled() ? self::eligible_orders( $customer ) : array(),
			'min_photos'   => (int) bws_opt( 'return_min_photos', 1 ),
			'max_photos'   => (int) bws_opt( 'return_max_photos', 5 ),
			'max_mb'       => (int) bws_opt( 'return_max_mb', 8 ),
			'desc_required'=> (bool) bws_opt( 'return_desc_required', 1 ),
			'days'         => (int) bws_opt( 'return_days', 30 ),
		);
	}

	/* ------------------------------------------------------------------ */
	/* Create                                                              */
	/* ------------------------------------------------------------------ */

	/**
	 * @param object $customer
	 * @param array  $data  order_id, items [ [item_id, qty] ], reason (text), description
	 * @param array  $files normalised $_FILES list
	 * @param string $actor customer | visitor | admin
	 */
	public static function create( $customer, $data, $files, $actor = 'customer' ) {
		global $wpdb;
		if ( ! self::enabled() ) {
			return new WP_Error( 'bws_off', 'ثبت مرجوعی در حال حاضر غیرفعال است.' );
		}
		if ( ! $customer || 'active' !== $customer->status ) {
			return new WP_Error( 'bws_inactive', 'حساب مشتری غیرفعال است.' );
		}
		$order_id = absint( isset( $data['order_id'] ) ? $data['order_id'] : 0 );
		$reason   = trim( sanitize_text_field( isset( $data['reason'] ) ? wp_unslash( $data['reason'] ) : '' ) );
		$desc     = trim( sanitize_textarea_field( isset( $data['description'] ) ? wp_unslash( $data['description'] ) : '' ) );
		$items_in = isset( $data['items'] ) ? $data['items'] : array();
		if ( is_string( $items_in ) ) {
			$items_in = json_decode( wp_unslash( $items_in ), true );
		}
		if ( ! $order_id ) {
			return new WP_Error( 'bws_order', 'سفارش را انتخاب کنید.' );
		}
		if ( ! in_array( $reason, self::reasons(), true ) ) {
			return new WP_Error( 'bws_reason', 'دلیل مرجوعی را انتخاب کنید.' );
		}
		if ( bws_opt( 'return_desc_required', 1 ) && mb_strlen( $desc ) < 5 ) {
			return new WP_Error( 'bws_desc', 'توضیحات مشکل (نوع مشکل، تعداد معیوب و جزئیات) را بنویسید.' );
		}
		$desc = mb_substr( $desc, 0, 2000 );
		$photos = BWS_Return_Files::validate( $files );
		if ( is_wp_error( $photos ) ) {
			return $photos;
		}
		$lock = 'ret_c' . $customer->id;
		if ( ! bws_lock( $lock, 10 ) ) {
			return new WP_Error( 'bws_busy', 'درخواست دیگری در حال ثبت است؛ چند ثانیه بعد دوباره تلاش کنید.' );
		}
		try {
			$eligible = self::eligible_orders( $customer, $order_id );
			if ( ! $eligible ) {
				$days = (int) bws_opt( 'return_days', 30 );
				return new WP_Error( 'bws_not_eligible', 'این سفارش قابل مرجوعی نیست' . ( $days ? ' (فقط سفارش‌های ' . bws_fa_digits( $days ) . ' روز اخیر با وضعیت مجاز، و اقلامی که قبلاً مرجوع نشده‌اند).' : '.' ) );
			}
			$avail = array();
			foreach ( $eligible[0]['items'] as $it ) {
				$avail[ $it['item_id'] ] = $it;
			}
			$lines = array();
			foreach ( (array) $items_in as $row ) {
				$iid = absint( is_array( $row ) && isset( $row['item_id'] ) ? $row['item_id'] : 0 );
				$q   = absint( is_array( $row ) && isset( $row['qty'] ) ? $row['qty'] : 0 );
				if ( ! $iid || ! $q ) {
					continue;
				}
				if ( ! isset( $avail[ $iid ] ) ) {
					return new WP_Error( 'bws_item', 'یکی از کالاهای انتخابی در این سفارش نیست یا قبلاً مرجوع شده است.' );
				}
				if ( $q > $avail[ $iid ]['max'] ) {
					return new WP_Error( 'bws_qty', sprintf( 'حداکثر تعداد قابل مرجوعی «%s» %s عدد است.', $avail[ $iid ]['name'], bws_fa_digits( $avail[ $iid ]['max'] ) ) );
				}
				$lines[ $iid ] = array( 'item' => $avail[ $iid ], 'qty' => $q );
			}
			if ( ! $lines ) {
				return new WP_Error( 'bws_items', 'حداقل یک کالا و تعداد معیوب آن را انتخاب کنید.' );
			}
			$amount = 0;
			foreach ( $lines as $l ) {
				$amount += $l['qty'] * $l['item']['unit'];
			}
			$now = bws_now();
			$wpdb->insert( self::table(), array(
				'customer_id'     => (int) $customer->id,
				'visitor_id'      => (int) $customer->visitor_id,
				'order_id'        => $order_id,
				'reason'          => $reason,
				'description'     => $desc,
				'status'          => 'pending',
				'amount'          => $amount,
				'created_by'      => get_current_user_id(),
				'created_by_type' => $actor,
				'storage'         => BWS_Return_Files::mode(),
				'files_state'     => 'host' === BWS_Return_Files::mode() ? 'ok' : 'pending',
				'notify_state'    => '{}',
				'created_at'      => $now,
				'updated_at'      => $now,
			) );
			$id = (int) $wpdb->insert_id;
			if ( ! $id ) {
				return new WP_Error( 'bws_db', 'ثبت درخواست ممکن نشد: ' . $wpdb->last_error );
			}
			$wpdb->update( self::table(), array( 'code' => 'R-' . ( 1000 + $id ) ), array( 'id' => $id ) );
			foreach ( $lines as $iid => $l ) {
				$wpdb->insert( self::items_table(), array(
					'return_id'     => $id,
					'order_item_id' => $iid,
					'product_id'    => $l['item']['product_id'],
					'name'          => $l['item']['name'],
					'qty'           => $l['qty'],
					'approved_qty'  => 0,
					'unit_price'    => $l['item']['unit'],
				) );
			}
			$stored = BWS_Return_Files::store( $id, $photos );
			if ( count( $stored ) < max( 1, (int) bws_opt( 'return_min_photos', 1 ) ) && (int) bws_opt( 'return_min_photos', 1 ) > 0 ) {
				$wpdb->delete( self::items_table(), array( 'return_id' => $id ) );
				BWS_Return_Files::purge( $id );
				$wpdb->delete( self::table(), array( 'id' => $id ) );
				return new WP_Error( 'bws_store', 'ذخیره عکس‌ها روی هاست ممکن نشد (دسترسی نوشتن پوشه uploads را بررسی کنید).' );
			}
		} finally {
			bws_unlock( $lock );
		}
		$r = self::get( $id );
		BWS_Log::add( 'return_create', 'customer', $customer->id, array( 'return' => $r->code, 'order' => $order_id ), 'customer' === $actor ? 'customer' : '' );
		do_action( 'bws_return_created', $r );
		self::defer( $id, 'new' );
		return $r;
	}

	/* ------------------------------------------------------------------ */
	/* Decide / cancel / delete                                            */
	/* ------------------------------------------------------------------ */

	/**
	 * @param array $args decision approve|reject, resolution credit|replacement|manual, items [return_item_id => approved_qty], amount, note, notify
	 */
	public static function decide( $id, $args, $allowed_resolutions ) {
		global $wpdb;
		$lock = 'ret_' . (int) $id;
		if ( ! bws_lock( $lock, 10 ) ) {
			return new WP_Error( 'bws_busy', 'این درخواست در حال بررسی توسط شخص دیگری است.' );
		}
		try {
			$r = self::get( $id );
			if ( ! $r ) {
				return new WP_Error( 'bws_404', 'درخواست یافت نشد.' );
			}
			if ( 'pending' !== $r->status ) {
				return new WP_Error( 'bws_state', 'این درخواست قبلاً «' . self::$statuses[ $r->status ] . '» شده است.' );
			}
			$decision = isset( $args['decision'] ) && 'approve' === $args['decision'] ? 'approve' : ( isset( $args['decision'] ) && 'reject' === $args['decision'] ? 'reject' : '' );
			$note     = mb_substr( trim( sanitize_textarea_field( isset( $args['note'] ) ? wp_unslash( $args['note'] ) : '' ) ), 0, 1000 );
			if ( ! $decision ) {
				return new WP_Error( 'bws_decision', 'تأیید یا رد را انتخاب کنید.' );
			}
			$now = bws_now();
			if ( 'reject' === $decision ) {
				if ( mb_strlen( $note ) < 3 ) {
					return new WP_Error( 'bws_note', 'دلیل رد درخواست را بنویسید (برای مشتری ارسال می‌شود).' );
				}
				$wpdb->update( self::table(), array( 'status' => 'rejected', 'decision_note' => $note, 'decided_by' => get_current_user_id(), 'decided_at' => $now, 'updated_at' => $now ), array( 'id' => $r->id ) );
			} else {
				$res = isset( $args['resolution'] ) ? sanitize_key( $args['resolution'] ) : 'manual';
				if ( ! isset( self::$resolutions[ $res ] ) || ! in_array( $res, $allowed_resolutions, true ) ) {
					return new WP_Error( 'bws_res', 'این نوع رسیدگی برای شما مجاز نیست.' );
				}
				$want  = isset( $args['items'] ) ? ( is_string( $args['items'] ) ? json_decode( wp_unslash( $args['items'] ), true ) : (array) $args['items'] ) : array();
				$total = 0;
				$appr  = array();
				foreach ( self::items( $r->id ) as $it ) {
					$q = isset( $want[ $it->id ] ) ? absint( $want[ $it->id ] ) : (int) $it->qty;
					$q = min( $q, (int) $it->qty );
					$appr[ $it->id ] = $q;
					$total          += $q * (float) $it->unit_price;
				}
				if ( array_sum( $appr ) < 1 ) {
					return new WP_Error( 'bws_qty', 'تعداد تأییدشده حداقل باید یک عدد باشد؛ در غیر این صورت درخواست را رد کنید.' );
				}
				$amount = isset( $args['amount'] ) && '' !== (string) $args['amount'] ? min( $total, max( 0, bws_parse_amount( $args['amount'] ) ) ) : $total;
				$repl   = 0;
				if ( 'replacement' === $res ) {
					$repl = self::replacement_order( $r, $appr );
					if ( is_wp_error( $repl ) ) {
						return $repl;
					}
				}
				foreach ( $appr as $iid => $q ) {
					$wpdb->update( self::items_table(), array( 'approved_qty' => $q ), array( 'id' => $iid ) );
				}
				if ( 'credit' === $res && $amount > 0 ) {
					BWS_Ledger::add( $r->customer_id, 'return', -$amount, array( 'order_id' => $r->order_id, 'reference' => $r->code, 'note' => 'برگشت مرجوعی ' . $r->code . ' (' . $r->reason . ')' ) );
				}
				$wpdb->update( self::table(), array( 'status' => 'approved', 'resolution' => $res, 'approved_amount' => 'credit' === $res ? $amount : ( 'replacement' === $res ? 0 : $amount ), 'replacement_order_id' => $repl, 'decision_note' => $note, 'decided_by' => get_current_user_id(), 'decided_at' => $now, 'updated_at' => $now ), array( 'id' => $r->id ) );
			}
		} finally {
			bws_unlock( $lock );
		}
		$r = self::get( $id );
		BWS_Log::add( 'return_' . ( 'approved' === $r->status ? 'approve' : 'reject' ), 'customer', $r->customer_id, array( 'return' => $r->code, 'resolution' => $r->resolution, 'amount' => (float) $r->approved_amount ) );
		if ( ! isset( $args['notify'] ) || filter_var( $args['notify'], FILTER_VALIDATE_BOOLEAN ) ) {
			BWS_SMS::send_event( 'return_decision', BWS_Customers::get( $r->customer_id ), self::sms_vars( $r ) );
		}
		do_action( 'bws_return_decided', $r );
		self::defer( $r->id, 'decision' );
		return $r;
	}

	/** Free replacement order with the approved quantities. Returns order id or WP_Error. */
	protected static function replacement_order( $r, $approved ) {
		global $wpdb;
		$c     = BWS_Customers::get( $r->customer_id );
		$order = wc_create_order( array( 'created_via' => 'bws_return', 'status' => 'pending' ) );
		if ( is_wp_error( $order ) ) {
			return $order;
		}
		$n = 0;
		foreach ( self::items( $r->id ) as $it ) {
			$q = isset( $approved[ $it->id ] ) ? (int) $approved[ $it->id ] : 0;
			$p = $q ? wc_get_product( $it->product_id ) : null;
			if ( $p ) {
				$order->add_product( $p, $q, array( 'subtotal' => 0, 'total' => 0 ) );
				$n++;
			}
		}
		if ( ! $n ) {
			$order->delete( true );
			return new WP_Error( 'bws_repl', 'محصولات این مرجوعی دیگر در فروشگاه وجود ندارند؛ روش دیگری را انتخاب کنید.' );
		}
		$address = array( 'first_name' => $c->first_name, 'last_name' => $c->last_name, 'company' => $c->shop_name, 'phone' => $c->mobile, 'state' => $c->province, 'city' => $c->city, 'address_1' => $c->address, 'postcode' => $c->postal_code, 'country' => 'IR' );
		$order->set_address( $address, 'billing' );
		$order->set_address( $address, 'shipping' );
		$order->set_payment_method_title( 'جایگزین مرجوعی ' . $r->code );
		$order->update_meta_data( '_bws_replacement', (int) $r->id );
		$order->update_meta_data( '_bws_customer_id', (int) $c->id );
		$order->update_meta_data( '_bws_customer_code', $c->code );
		$order->update_meta_data( '_bws_visitor_id', (int) $c->visitor_id );
		$order->update_meta_data( '_bws_placed_by', bws_is_manager() ? 'admin' : 'visitor' );
		$order->update_meta_data( '_bws_placed_by_user', get_current_user_id() );
		BWS_Orders::set_origin( $order, 'جایگزین مرجوعی' );
		$order->calculate_totals( false );
		$order->add_order_note( 'ارسال کالای جایگزین برای مرجوعی ' . $r->code . ' (سفارش اصلی #' . $r->order_id . ') — تأیید توسط ' . bws_user_name( get_current_user_id() ) );
		$order->save();
		$order->update_status( bws_opt( 'new_order_status', 'processing' ) );
		$wpdb->insert( BWS_Orders::table(), array(
			'order_id' => $order->get_id(), 'customer_id' => (int) $c->id, 'visitor_id' => (int) $c->visitor_id, 'placed_by' => bws_is_manager() ? 'admin' : 'visitor', 'placed_by_user' => get_current_user_id(),
			'kind' => 'replacement', 'items_qty' => array_sum( $approved ), 'total' => 0, 'status' => $order->get_status(), 'created_at' => bws_now(),
		) );
		return $order->get_id();
	}

	public static function cancel( $id, $customer_id ) {
		global $wpdb;
		$r = self::get( $id );
		if ( ! $r || (int) $r->customer_id !== (int) $customer_id ) {
			return new WP_Error( 'bws_404', 'درخواست یافت نشد.' );
		}
		if ( 'pending' !== $r->status ) {
			return new WP_Error( 'bws_state', 'فقط درخواست‌های در انتظار بررسی قابل لغو هستند.' );
		}
		$wpdb->update( self::table(), array( 'status' => 'cancelled', 'updated_at' => bws_now() ), array( 'id' => $r->id ) );
		BWS_Log::add( 'return_cancel', 'customer', $r->customer_id, $r->code, 'customer' );
		self::defer( $r->id, 'cancel' );
		return self::get( $id );
	}

	public static function delete( $id ) {
		global $wpdb;
		$r = self::get( $id );
		if ( ! $r ) {
			return new WP_Error( 'bws_404', 'درخواست یافت نشد.' );
		}
		if ( 'approved' === $r->status ) {
			return new WP_Error( 'bws_state', 'درخواست تأییدشده برای حفظ سوابق مالی قابل حذف نیست.' );
		}
		BWS_Return_Files::purge( $r->id );
		$wpdb->delete( self::items_table(), array( 'return_id' => $r->id ) );
		$wpdb->delete( self::table(), array( 'id' => $r->id ) );
		BWS_Log::add( 'return_delete', 'customer', $r->customer_id, $r->code );
		return true;
	}

	/* ------------------------------------------------------------------ */
	/* Background processing: storage + bots + SMS                         */
	/* ------------------------------------------------------------------ */

	/** Run after the response has been sent (PHP-FPM) so the user never waits for Telegram/Drive. */
	public static function defer( $id, $event ) {
		self::$queue[] = array( (int) $id, $event );
		if ( self::$registered ) {
			return;
		}
		self::$registered = true;
		add_action( 'shutdown', array( __CLASS__, 'run_queue' ), 1 );
	}

	public static function run_queue() {
		if ( ! self::$queue ) {
			return;
		}
		ignore_user_abort( true );
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore
		}
		if ( function_exists( 'fastcgi_finish_request' ) && 'cli' !== PHP_SAPI ) {
			fastcgi_finish_request();
		}
		$q           = self::$queue;
		self::$queue = array();
		foreach ( $q as $job ) {
			self::process( $job[0], $job[1] );
		}
	}

	public static function state( $r ) {
		$s = json_decode( (string) $r->notify_state, true );
		return is_array( $s ) ? $s : array();
	}

	public static function save_state( $id, $st ) {
		global $wpdb;
		$wpdb->update( self::table(), array( 'notify_state' => wp_json_encode( $st, JSON_UNESCAPED_UNICODE ) ), array( 'id' => (int) $id ) );
	}

	/**
	 * Process one event for a return: SMS (once), bots (per chat, retried until ok), Drive upload.
	 * Safe to call repeatedly.
	 */
	public static function process( $id, $event ) {
		global $wpdb;
		$r = self::get( $id );
		if ( ! $r ) {
			return;
		}
		$st = self::state( $r );
		$c  = BWS_Customers::get( $r->customer_id );

		// SMS for a new request (only once).
		if ( 'new' === $event && empty( $st['sms_new'] ) && $c ) {
			$vars = self::sms_vars( $r );
			BWS_SMS::send_event( 'return_new', $c, $vars );
			BWS_SMS::send_event( 'return_admin', $c, $vars );
			$vm = $c->visitor_id ? bws_normalize_mobile( get_user_meta( $c->visitor_id, 'bws_mobile', true ) ) : '';
			if ( $vm ) {
				BWS_SMS::send_event( 'return_visitor', $c, $vars, array( 'to' => $vm ) );
			}
			$st['sms_new'] = 1;
		}

		// Bots: one message per recipient (photo + caption), later events as replies on it.
		$retry = BWS_Bot::deliver( $r, $event, $st );

		// Storage: move photos to Google Drive (keep local copy while bots still need it for a retry).
		$files_state = $r->files_state;
		if ( in_array( $r->storage, array( 'gdrive', 'both' ), true ) && 'ok' !== $files_state ) {
			$files_state = BWS_GDrive::configured() ? BWS_Return_Files::push_to_drive( $r, $retry || 'both' === $r->storage ) : 'pending';
			if ( 'pending' === $files_state ) {
				$retry = true;
			}
		}

		$attempts = (int) $r->attempts + 1;
		$wpdb->update( self::table(), array( 'notify_state' => wp_json_encode( $st, JSON_UNESCAPED_UNICODE ), 'files_state' => $files_state, 'attempts' => $attempts ), array( 'id' => $r->id ) );
		$list = get_option( 'bws_returns_retry', array() );
		$list = is_array( $list ) ? $list : array();
		$key  = $r->id . '|' . $event;
		if ( $retry && $attempts < 8 ) {
			$list[ $key ] = time();
		} else {
			unset( $list[ $key ] );
			if ( 'gdrive' === $r->storage && 'ok' === $files_state ) {
				BWS_Return_Files::push_to_drive( self::get( $r->id ), false ); // Bots are done → remove local copies.
			}
		}
		update_option( 'bws_returns_retry', $list, false );
	}

	/** Every 5 minutes: retry failed bot messages / Drive uploads. */
	public static function retry() {
		global $wpdb;
		// Safety net: a new request is ALWAYS announced, even if the background job of that request never ran
		// (host killed the process, fatal error elsewhere, …).
		$ids = $wpdb->get_col( $wpdb->prepare(
			'SELECT id FROM ' . self::table() . " WHERE attempts = 0 AND status = 'pending' AND created_at BETWEEN %s AND %s ORDER BY id ASC LIMIT 20",
			gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - 3 * DAY_IN_SECONDS ),
			gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - 3 * MINUTE_IN_SECONDS )
		) );
		foreach ( $ids as $id ) {
			self::process( (int) $id, 'new' );
		}
		$list = get_option( 'bws_returns_retry', array() );
		if ( ! is_array( $list ) || ! $list ) {
			return;
		}
		foreach ( array_slice( array_keys( $list ), 0, 20 ) as $key ) {
			list( $id, $event ) = array_pad( explode( '|', $key ), 2, 'new' );
			self::process( (int) $id, $event );
		}
	}

	/** Manager "resend": forget delivery state for an event and process again now. */
	public static function resend( $id ) {
		global $wpdb;
		$r = self::get( $id );
		if ( ! $r ) {
			return new WP_Error( 'bws_404', 'درخواست یافت نشد.' );
		}
		$st = self::state( $r );
		$ev = 'pending' === $r->status ? 'new' : ( 'cancelled' === $r->status ? 'cancel' : 'decision' );
		foreach ( isset( $st['bots'] ) ? array_keys( $st['bots'] ) : array() as $k ) {
			if ( 0 === strpos( $k, $ev . '|' ) ) {
				unset( $st['bots'][ $k ] );
			}
		}
		$wpdb->update( self::table(), array( 'notify_state' => wp_json_encode( $st, JSON_UNESCAPED_UNICODE ), 'attempts' => 0 ), array( 'id' => $r->id ) );
		self::process( $r->id, $ev );
		return self::get( $r->id );
	}

	public static function panel_link( $r ) {
		return admin_url( 'admin.php?page=bws-customers&tab=returns#r' . (int) $r->id );
	}

	/* ------------------------------------------------------------------ */
	/* Texts                                                               */
	/* ------------------------------------------------------------------ */

	public static function items_text( $r, $sep = '، ', $approved = false ) {
		$out = array();
		foreach ( self::items( $r->id ) as $it ) {
			$q = $approved ? (int) $it->approved_qty : (int) $it->qty;
			if ( $q > 0 ) {
				$out[] = $it->name . ' × ' . bws_fa_digits( $q );
			}
		}
		return implode( $sep, $out );
	}

	public static function result_text( $r ) {
		if ( 'approved' !== $r->status ) {
			return '';
		}
		if ( 'credit' === $r->resolution ) {
			return 'مبلغ ' . bws_money_text( $r->approved_amount ) . ' به اعتبار شما برگشت.';
		}
		if ( 'replacement' === $r->resolution ) {
			return 'کالای جایگزین (سفارش #' . $r->replacement_order_id . ') برای شما ارسال می‌شود.';
		}
		return 'برای تسویه با شما تماس گرفته می‌شود.';
	}

	public static function sms_vars( $r ) {
		return array(
			'return_code'   => $r->code,
			'return_status' => self::$statuses[ $r->status ],
			'return_reason' => $r->reason,
			'return_items'  => self::items_text( $r ),
			'return_order'  => $r->order_id,
			'return_note'   => (string) $r->decision_note,
			'return_result' => self::result_text( $r ),
			'return_amount' => bws_money_text( $r->approved_amount ),
		);
	}

	/* ------------------------------------------------------------------ */
	/* Query & arrays                                                      */
	/* ------------------------------------------------------------------ */

	public static function query( $args = array() ) {
		global $wpdb;
		$t     = self::table();
		$ct    = BWS_Customers::table();
		$where = array( '1=1' );
		$vals  = array();
		foreach ( array( 'customer_id' => 'r.customer_id', 'visitor_id' => 'c.visitor_id', 'order_id' => 'r.order_id' ) as $k => $col ) {
			if ( ! empty( $args[ $k ] ) ) {
				$where[] = $col . ' = %d';
				$vals[]  = (int) $args[ $k ];
			}
		}
		if ( ! empty( $args['status'] ) && isset( self::$statuses[ $args['status'] ] ) ) {
			$where[] = 'r.status = %s';
			$vals[]  = $args['status'];
		}
		if ( ! empty( $args['search'] ) ) {
			$s       = '%' . $wpdb->esc_like( trim( bws_en_digits( $args['search'] ) ) ) . '%';
			$where[] = '(r.code LIKE %s OR c.first_name LIKE %s OR c.last_name LIKE %s OR c.shop_name LIKE %s OR c.mobile LIKE %s OR c.code LIKE %s OR r.order_id LIKE %s)';
			array_push( $vals, $s, $s, $s, $s, $s, $s, $s );
		}
		$per    = isset( $args['per_page'] ) ? max( 1, min( 500, (int) $args['per_page'] ) ) : 20;
		$page   = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
		$offset = ( $page - 1 ) * $per;
		$w      = implode( ' AND ', $where );
		$sql    = "SELECT r.* FROM $t r LEFT JOIN $ct c ON c.id = r.customer_id WHERE $w ORDER BY (r.status = 'pending') DESC, r.id DESC LIMIT $offset, $per";
		$csql   = "SELECT COUNT(*) FROM $t r LEFT JOIN $ct c ON c.id = r.customer_id WHERE $w";
		$total  = (int) ( $vals ? $wpdb->get_var( $wpdb->prepare( $csql, $vals ) ) : $wpdb->get_var( $csql ) );
		return array( 'items' => $vals ? $wpdb->get_results( $wpdb->prepare( $sql, $vals ) ) : $wpdb->get_results( $sql ), 'total' => $total, 'pages' => (int) ceil( $total / $per ) );
	}

	public static function count_pending( $visitor_id = 0 ) {
		global $wpdb;
		if ( $visitor_id ) {
			return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::table() . ' r INNER JOIN ' . BWS_Customers::table() . " c ON c.id = r.customer_id WHERE r.status = 'pending' AND c.visitor_id = %d", $visitor_id ) );
		}
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table() . " WHERE status = 'pending'" );
	}

	public static function to_array( $r, $full = false ) {
		$c   = BWS_Customers::get( $r->customer_id );
		$arr = array(
			'id'            => (int) $r->id,
			'code'          => $r->code,
			'status'        => $r->status,
			'status_label'  => self::$statuses[ $r->status ],
			'order_id'      => (int) $r->order_id,
			'reason'        => $r->reason,
			'description'   => (string) $r->description,
			'items_text'    => self::items_text( $r ),
			'amount_text'   => bws_money_text( $r->amount ),
			'date'          => bws_jdate( $r->created_at ),
			'customer_id'   => (int) $r->customer_id,
			'customer'      => $c ? BWS_Customers::full_name( $c ) : '—',
			'shop'          => $c ? $c->shop_name : '',
			'customer_code' => $c ? $c->code : '',
			'visitor'       => $c ? bws_user_name( $c->visitor_id ) : '—',
			'by'            => 'customer' === $r->created_by_type ? 'مشتری' : bws_user_name( $r->created_by ),
			'resolution'    => $r->resolution,
			'resolution_label' => $r->resolution ? self::$resolutions[ $r->resolution ] : '',
			'result_text'   => self::result_text( $r ),
			'approved_amount_text' => bws_money_text( $r->approved_amount ),
			'replacement_order_id' => (int) $r->replacement_order_id,
			'decision_note' => (string) $r->decision_note,
			'decided_by'    => $r->decided_by ? bws_user_name( $r->decided_by ) : '',
			'decided_at'    => $r->decided_at ? bws_jdate( $r->decided_at ) : '',
			'photos_count'  => count( BWS_Return_Files::for_return( $r->id ) ),
		);
		if ( $full ) {
			$arr['items'] = array();
			foreach ( self::items( $r->id ) as $it ) {
				$arr['items'][] = array( 'id' => (int) $it->id, 'name' => $it->name, 'qty' => (int) $it->qty, 'approved_qty' => (int) $it->approved_qty, 'unit' => (float) $it->unit_price, 'unit_text' => bws_money_text( $it->unit_price ), 'total_text' => bws_money_text( $it->unit_price * $it->qty ) );
			}
			$arr['amount'] = (float) $r->amount;
			$arr['photos'] = array_map( array( 'BWS_Return_Files', 'to_array' ), BWS_Return_Files::for_return( $r->id ) );
			$arr['mobile'] = $c ? $c->mobile : '';
		}
		return $arr;
	}

	/** Delivery report for managers. */
	public static function delivery( $r ) {
		$st  = self::state( $r );
		$out = array();
		foreach ( isset( $st['bots'] ) ? $st['bots'] : array() as $k => $v ) {
			list( $ev, $p, $chat ) = array_pad( explode( '|', $k ), 3, '' );
			$pl    = BWS_Messenger::platforms();
			$msg   = 'ok' === $v ? 'ارسال شد' : $v;
			if ( 'ok' === $v && 'new' === $ev && ! empty( $st['photo_error'][ $p . '|' . $chat ] ) ) {
				$msg = 'متن ارسال شد؛ عکس‌ها به‌صورت جداگانه فرستاده شدند (خطای پیام‌رسان برای عکس + زیرنویس: ' . $st['photo_error'][ $p . '|' . $chat ] . ')';
			}
			$out[] = array( 'event' => $ev, 'platform' => isset( $pl[ $p ] ) ? $pl[ $p ] : $p, 'chat' => $chat, 'ok' => 'ok' === $v, 'message' => $msg );
		}
		return array( 'bots' => $out, 'files' => $r->files_state, 'storage' => $r->storage );
	}

	public static function stats() {
		global $wpdb;
		$t      = self::table();
		$counts = array_fill_keys( array_keys( self::$statuses ), 0 );
		foreach ( $wpdb->get_results( "SELECT status, COUNT(*) n FROM $t GROUP BY status" ) as $row ) {
			$counts[ $row->status ] = (int) $row->n;
		}
		$from   = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - 90 * DAY_IN_SECONDS );
		$credit = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(approved_amount),0) FROM $t WHERE status = 'approved' AND resolution = 'credit' AND decided_at >= %s", $from ) );
		$top    = $wpdb->get_results( $wpdb->prepare( 'SELECT ri.name, SUM(ri.qty) q, COUNT(DISTINCT r.id) n FROM ' . self::items_table() . " ri INNER JOIN $t r ON r.id = ri.return_id WHERE r.status IN ('pending','approved') AND r.created_at >= %s GROUP BY ri.product_id, ri.name ORDER BY q DESC LIMIT 5", $from ) );
		return array(
			'counts'      => $counts,
			'credit_90'   => bws_money_text( $credit ),
			'top_products'=> array_map( function ( $x ) {
				return array( 'name' => $x->name, 'qty' => (int) $x->q, 'requests' => (int) $x->n );
			}, $top ),
		);
	}

	/* ------------------------------------------------------------------ */
	/* REST                                                                */
	/* ------------------------------------------------------------------ */

	public static function routes() {
		$ns = BWS_REST::NS;
		$r  = function ( $route, $methods, $cb, $perm ) use ( $ns ) {
			register_rest_route( $ns, $route, array( 'methods' => $methods, 'callback' => array( __CLASS__, $cb ), 'permission_callback' => array( 'BWS_REST', $perm ) ) );
		};
		$r( '/customer/returns', 'GET', 'rest_customer_list', 'is_customer' );
		$r( '/customer/returns', 'POST', 'rest_customer_create', 'is_customer' );
		$r( '/customer/returns/(?P<id>\d+)', 'GET', 'rest_customer_get', 'is_customer' );
		$r( '/customer/returns/(?P<id>\d+)/cancel', 'POST', 'rest_customer_cancel', 'is_customer' );
		$r( '/staff/returns', 'GET', 'rest_staff_list', 'is_staff' );
		$r( '/staff/returns/(?P<id>\d+)', 'GET', 'rest_staff_get', 'is_staff' );
		$r( '/staff/returns/(?P<id>\d+)/decide', 'POST', 'rest_staff_decide', 'is_staff' );
		$r( '/staff/returns/(?P<id>\d+)/resend', 'POST', 'rest_staff_resend', 'is_manager' );
		$r( '/staff/returns/(?P<id>\d+)/delete', 'POST', 'rest_staff_delete', 'is_manager' );
		$r( '/staff/returns/export', 'GET', 'rest_staff_export', 'is_manager' );
		$r( '/staff/customers/(?P<id>\d+)/returns', 'GET', 'rest_staff_options', 'is_staff' );
		$r( '/staff/customers/(?P<id>\d+)/returns', 'POST', 'rest_staff_create', 'is_staff' );
		$r( '/admin/returns/bot-test', 'POST', 'rest_bot_test', 'is_manager' );
		$r( '/admin/returns/bot-chats', 'POST', 'rest_bot_chats', 'is_manager' );
		$r( '/admin/returns/drive-test', 'POST', 'rest_drive_test', 'is_manager' );
		$r( '/admin/returns/drive-verify', 'POST', 'rest_drive_verify', 'is_manager' );
		$r( '/admin/returns/bot-preview', 'POST', 'rest_bot_preview', 'is_manager' );
		$r( '/admin/returns/bot-mode', 'POST', 'rest_bot_mode', 'is_manager' );
		$r( '/admin/returns/cleanup', 'POST', 'rest_cleanup', 'is_manager' );
	}

	protected static function ok( $data = array() ) {
		return new WP_REST_Response( array_merge( array( 'ok' => true ), $data ), 200 );
	}

	protected static function err( $e, $status = 400 ) {
		return new WP_REST_Response( array( 'ok' => false, 'code' => $e->get_error_code(), 'message' => $e->get_error_message() ), $status );
	}

	protected static function files_from( $req ) {
		$f = $req->get_file_params();
		return BWS_Return_Files::normalize( isset( $f['photos'] ) ? $f['photos'] : ( isset( $f['photos[]'] ) ? $f['photos[]'] : array() ) );
	}

	/* --- customer --- */

	public static function rest_customer_list( $req ) {
		$c   = BWS_Auth::current_customer( $req );
		$res = self::query( array( 'customer_id' => $c->id, 'per_page' => 50 ) );
		return self::ok( array( 'returns' => array_map( function ( $r ) {
			return self::to_array( $r, true );
		}, $res['items'] ), 'options' => self::options( $c ) ) );
	}

	public static function rest_customer_get( $req ) {
		$c = BWS_Auth::current_customer( $req );
		$r = self::get( (int) $req['id'] );
		if ( ! $r || (int) $r->customer_id !== (int) $c->id ) {
			return self::err( new WP_Error( 'bws_404', 'درخواست یافت نشد.' ), 404 );
		}
		return self::ok( array( 'return' => self::to_array( $r, true ) ) );
	}

	public static function rest_customer_create( $req ) {
		if ( bws_rate_limited( 'ret_new', 30, HOUR_IN_SECONDS ) ) {
			return self::err( new WP_Error( 'bws_rate', 'تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره تلاش کنید.' ), 429 );
		}
		$c = BWS_Auth::current_customer( $req );
		$r = self::create( $c, $req->get_body_params(), self::files_from( $req ), 'customer' );
		if ( is_wp_error( $r ) ) {
			return self::err( $r );
		}
		return self::ok( array( 'return' => self::to_array( $r, true ), 'message' => 'درخواست مرجوعی با کد پیگیری ' . $r->code . ' ثبت شد و پس از بررسی نتیجه اطلاع داده می‌شود.' ) );
	}

	public static function rest_customer_cancel( $req ) {
		$c = BWS_Auth::current_customer( $req );
		$r = self::cancel( (int) $req['id'], $c->id );
		return is_wp_error( $r ) ? self::err( $r ) : self::ok( array( 'return' => self::to_array( $r, true ), 'message' => 'درخواست مرجوعی لغو شد.' ) );
	}

	/* --- staff --- */

	public static function staff_can( $perm, $customer ) {
		return bws_is_manager() || ( $customer && BWS_Perms::scope_allows( $perm, $customer ) );
	}

	/** Allowed resolutions for the current user. */
	public static function allowed_resolutions() {
		if ( bws_is_manager() ) {
			return array( 'credit', 'replacement', 'manual' );
		}
		$p   = BWS_Perms::for_user();
		$out = array( 'manual' );
		if ( ! empty( $p['returns_credit'] ) ) {
			$out[] = 'credit';
		}
		if ( ! empty( $p['returns_replace'] ) ) {
			$out[] = 'replacement';
		}
		return $out;
	}

	protected static function staff_array( $r ) {
		$c              = BWS_Customers::get( $r->customer_id );
		$a              = self::to_array( $r, true );
		$a['can_decide'] = 'pending' === $r->status && self::staff_can( 'returns_decide', $c );
		$a['resolutions'] = $a['can_decide'] ? array_values( array_intersect( array( 'credit', 'replacement', 'manual' ), self::allowed_resolutions() ) ) : array();
		if ( bws_is_manager() ) {
			$a['delivery']   = self::delivery( $r );
			$a['can_delete'] = 'approved' !== $r->status;
			$a['admin_order'] = str_replace( '__ID__', $r->order_id, BWS_Frontend::admin_order_url_tpl() );
		}
		return $a;
	}

	public static function rest_staff_list( $req ) {
		$p    = BWS_Perms::for_user();
		$args = array( 'status' => sanitize_key( (string) $req->get_param( 'status' ) ), 'search' => (string) $req->get_param( 'search' ), 'page' => (int) $req->get_param( 'page' ), 'customer_id' => (int) $req->get_param( 'customer' ) );
		if ( ! $p['manager'] ) {
			if ( empty( $p['returns_view'] ) || 'none' === $p['returns_view'] ) {
				return self::err( new WP_Error( 'bws_forbidden', 'دسترسی به مرجوعی‌ها برای شما فعال نیست.' ), 403 );
			}
			if ( 'all' !== $p['returns_view'] ) {
				$args['visitor_id'] = get_current_user_id();
			}
		}
		$res = self::query( $args );
		$out = array();
		foreach ( $res['items'] as $r ) {
			$a               = self::to_array( $r );
			$a['can_decide'] = 'pending' === $r->status && self::staff_can( 'returns_decide', BWS_Customers::get( $r->customer_id ) );
			$out[]           = $a;
		}
		return self::ok( array( 'returns' => $out, 'total' => $res['total'], 'pages' => $res['pages'], 'stats' => $p['manager'] ? self::stats() : null, 'pending' => self::count_pending( $p['manager'] || 'all' === $p['returns_view'] ? 0 : get_current_user_id() ) ) );
	}

	protected static function staff_load( $req ) {
		$r = self::get( (int) $req['id'] );
		if ( ! $r ) {
			return new WP_Error( 'bws_404', 'درخواست یافت نشد.' );
		}
		if ( ! self::staff_can( 'returns_view', BWS_Customers::get( $r->customer_id ) ) ) {
			return new WP_Error( 'bws_forbidden', 'به این درخواست دسترسی ندارید.' );
		}
		return $r;
	}

	public static function rest_staff_get( $req ) {
		$r = self::staff_load( $req );
		return is_wp_error( $r ) ? self::err( $r, 403 ) : self::ok( array( 'return' => self::staff_array( $r ) ) );
	}

	public static function rest_staff_decide( $req ) {
		$r = self::staff_load( $req );
		if ( is_wp_error( $r ) ) {
			return self::err( $r, 403 );
		}
		if ( ! self::staff_can( 'returns_decide', BWS_Customers::get( $r->customer_id ) ) ) {
			return self::err( new WP_Error( 'bws_forbidden', 'اجازه تأیید یا رد مرجوعی را ندارید.' ), 403 );
		}
		$res = self::decide( $r->id, $req->get_params(), self::allowed_resolutions() );
		if ( is_wp_error( $res ) ) {
			return self::err( $res );
		}
		return self::ok( array( 'return' => self::staff_array( $res ), 'message' => 'approved' === $res->status ? 'درخواست تأیید شد. ' . self::result_text( $res ) : 'درخواست رد شد.' ) );
	}

	public static function rest_staff_resend( $req ) {
		$r = self::resend( (int) $req['id'] );
		return is_wp_error( $r ) ? self::err( $r ) : self::ok( array( 'return' => self::staff_array( $r ), 'message' => 'دوباره ارسال شد؛ نتیجه را در «وضعیت ارسال» ببینید.' ) );
	}

	public static function rest_staff_delete( $req ) {
		$r = self::delete( (int) $req['id'] );
		return is_wp_error( $r ) ? self::err( $r ) : self::ok( array( 'message' => 'درخواست و عکس‌هایش حذف شد.' ) );
	}

	public static function rest_staff_options( $req ) {
		$c = BWS_Customers::get( (int) $req['id'] );
		if ( ! $c || ! BWS_Auth::can_view_customer( $c ) || ! self::staff_can( 'returns_create', $c ) ) {
			return self::err( new WP_Error( 'bws_forbidden', 'اجازه ثبت مرجوعی برای این مشتری را ندارید.' ), 403 );
		}
		return self::ok( array( 'options' => self::options( $c ) ) );
	}

	public static function rest_staff_create( $req ) {
		$c = BWS_Customers::get( (int) $req['id'] );
		if ( ! $c || ! BWS_Auth::can_view_customer( $c ) || ! self::staff_can( 'returns_create', $c ) ) {
			return self::err( new WP_Error( 'bws_forbidden', 'اجازه ثبت مرجوعی برای این مشتری را ندارید.' ), 403 );
		}
		$r = self::create( $c, $req->get_body_params(), self::files_from( $req ), bws_is_manager() ? 'admin' : 'visitor' );
		if ( is_wp_error( $r ) ) {
			return self::err( $r );
		}
		return self::ok( array( 'return' => self::staff_array( $r ), 'message' => 'درخواست مرجوعی ' . $r->code . ' ثبت شد.' ) );
	}

	public static function rest_staff_export() {
		$res  = self::query( array( 'per_page' => 500 ) );
		$rows = array( array( 'کد', 'تاریخ', 'وضعیت', 'مشتری', 'کد مشتری', 'فروشگاه', 'ویزیتور', 'سفارش', 'اقلام', 'دلیل', 'توضیحات', 'ارزش', 'نتیجه', 'مبلغ برگشتی', 'سفارش جایگزین', 'توضیح بررسی', 'بررسی توسط', 'تاریخ بررسی' ) );
		foreach ( $res['items'] as $r ) {
			$a      = self::to_array( $r );
			$rows[] = array( $a['code'], $a['date'], $a['status_label'], $a['customer'], $a['customer_code'], $a['shop'], $a['visitor'], $a['order_id'], $a['items_text'], $a['reason'], $a['description'], (float) $r->amount, $a['resolution_label'], (float) $r->approved_amount, $a['replacement_order_id'] ? $a['replacement_order_id'] : '', $a['decision_note'], $a['decided_by'], $a['decided_at'] );
		}
		return self::ok( array( 'csv' => bws_csv( $rows ), 'filename' => 'returns-' . gmdate( 'Ymd' ) . '.csv' ) );
	}

	/* --- admin tools --- */

	public static function rest_bot_test( $req ) {
		$p = sanitize_key( (string) $req->get_param( 'platform' ) );
		if ( ! isset( BWS_Messenger::platforms()[ $p ] ) ) {
			return self::err( new WP_Error( 'bws_p', 'پیام‌رسان نامعتبر است.' ) );
		}
		$r = BWS_Messenger::test( $p );
		return $r['ok'] ? self::ok( $r ) : self::err( new WP_Error( 'bws_bot', $r['error'] ) );
	}

	public static function rest_bot_chats( $req ) {
		$p = sanitize_key( (string) $req->get_param( 'platform' ) );
		if ( ! isset( BWS_Messenger::platforms()[ $p ] ) ) {
			return self::err( new WP_Error( 'bws_p', 'پیام‌رسان نامعتبر است.' ) );
		}
		$r = BWS_Messenger::find_chats( $p );
		return $r['ok'] ? self::ok( $r ) : self::err( new WP_Error( 'bws_bot', $r['error'] ) );
	}

	public static function rest_drive_test() {
		$r = BWS_GDrive::test();
		return is_wp_error( $r ) ? self::err( $r ) : self::ok( array( 'message' => 'اتصال سالم است: یک عکس آزمایشی آپلود، دوباره دانلود و بایت‌به‌بایت مقایسه شد (پوشه: ' . $r['folder'] . ( $r['public'] ? '، لینک عمومی فعال' : '، لینک عمومی مجاز نیست' ) . ').', 'link' => $r['link'] ) );
	}

	public static function rest_drive_verify() {
		if ( ! BWS_GDrive::configured() ) {
			return self::err( new WP_Error( 'gd', 'گوگل‌درایو متصل نیست.' ) );
		}
		$r = BWS_GDrive::verify_files( 150 );
		$m = sprintf( '%s فایل بررسی شد: %s سالم، %s خراب (%s با نسخه هاست دوباره آپلود شد)، %s در درایو پیدا نشد.', bws_fa_digits( $r['checked'] ), bws_fa_digits( $r['ok'] ), bws_fa_digits( $r['bad'] ), bws_fa_digits( $r['fixed'] ), bws_fa_digits( $r['missing'] ) );
		return self::ok( array( 'message' => $m . ( $r['errors'] ? ' خطا: ' . implode( ' | ', $r['errors'] ) : '' ), 'result' => $r ) );
	}

	public static function rest_bot_preview( $req ) {
		$key = sanitize_key( (string) $req->get_param( 'key' ) );
		if ( ! isset( BWS_Bot::templates()[ $key ] ) ) {
			return self::err( new WP_Error( 'k', 'قالب نامعتبر است.' ) );
		}
		$tpl = (string) $req->get_param( 'tpl' );
		$tpl = '' !== trim( $tpl ) ? sanitize_textarea_field( $tpl ) : BWS_Bot::templates()[ $key ][1];
		return self::ok( BWS_Bot::preview( $key, $tpl, 'bale' === $req->get_param( 'platform' ) ? 'bale' : 'telegram' ) );
	}

	public static function rest_bot_mode() {
		$out = BWS_Bot::apply_mode();
		return $out ? self::ok( array( 'results' => $out ) ) : self::err( new WP_Error( 'b', 'هیچ رباتی (تلگرام/بله) فعال و دارای توکن نیست.' ) );
	}

	public static function rest_cleanup( $req ) {
		$a = array(
			'days'     => absint( $req->get_param( 'days' ) ),
			'statuses' => array_map( 'sanitize_key', (array) $req->get_param( 'statuses' ) ),
			'backed'   => filter_var( $req->get_param( 'backed' ), FILTER_VALIDATE_BOOLEAN ),
		);
		if ( 'run' === $req->get_param( 'mode' ) ) {
			$r = BWS_Return_Files::cleanup_run( $a, 300 );
			BWS_Log::add( 'return_cleanup', 'settings', 0, $r['deleted'] . ' files, ' . $r['size'] );
			return self::ok( array_merge( $r, array( 'usage' => BWS_Return_Files::host_usage(), 'message' => bws_fa_digits( $r['deleted'] ) . ' عکس (' . $r['size'] . ') از هاست حذف شد' . ( $r['left'] ? '؛ ' . bws_fa_digits( $r['left'] ) . ' مورد دیگر باقی است، دوباره بزنید.' : '.' ) ) ) );
		}
		$s = BWS_Return_Files::cleanup_scan( $a );
		return self::ok( array_merge( $s, array( 'usage' => BWS_Return_Files::host_usage(), 'message' => bws_fa_digits( $s['files'] ) . ' عکس از ' . bws_fa_digits( $s['returns'] ) . ' درخواست — حدود ' . $s['size'] . ' قابل حذف است.' ) ) );
	}
}
