<?php
defined( 'ABSPATH' ) || exit;

/**
 * Return photos: validation, re-encoding (strips EXIF/GPS and anything hidden in the file), private host storage,
 * signed short-lived URLs, and moving to Google Drive.
 */
class BWS_Return_Files {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'serve' ), 1 );
	}

	public static function table() {
		return BWS_Install::table( 'return_files' );
	}

	/** Private base folder inside uploads (blocked by .htaccess; random names everywhere else). */
	public static function base_dir() {
		$u   = wp_upload_dir( null, false );
		$dir = trailingslashit( $u['basedir'] ) . 'ariagh-visitor-private';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			@file_put_contents( $dir . '/.htaccess', "Options -Indexes\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tOrder allow,deny\n\tDeny from all\n</IfModule>\n" ); // phpcs:ignore
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			@file_put_contents( $dir . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore
		}
		return $dir;
	}

	public static function abs_path( $rel ) {
		$rel = ltrim( str_replace( array( '..', '\\' ), '', (string) $rel ), '/' );
		return trailingslashit( self::base_dir() ) . $rel;
	}

	/** Normalise PHP's $_FILES[name] (single or multiple) into a list. */
	public static function normalize( $f ) {
		if ( empty( $f ) || ! isset( $f['name'] ) ) {
			return array();
		}
		if ( ! is_array( $f['name'] ) ) {
			return array( $f );
		}
		$out = array();
		foreach ( array_keys( $f['name'] ) as $i ) {
			$out[] = array( 'name' => $f['name'][ $i ], 'type' => $f['type'][ $i ], 'tmp_name' => $f['tmp_name'][ $i ], 'error' => $f['error'][ $i ], 'size' => $f['size'][ $i ] );
		}
		return $out;
	}

	/** Validate the uploaded photos. Returns list or WP_Error. */
	public static function validate( array $files ) {
		$min = max( 0, (int) bws_opt( 'return_min_photos', 1 ) );
		$max = max( 1, (int) bws_opt( 'return_max_photos', 5 ) );
		$mb  = max( 1, (int) bws_opt( 'return_max_mb', 8 ) );
		$files = array_values( array_filter( $files, function ( $f ) {
			return isset( $f['error'] ) && UPLOAD_ERR_NO_FILE !== (int) $f['error'];
		} ) );
		if ( count( $files ) < $min ) {
			return new WP_Error( 'bws_photo_min', sprintf( 'ارسال حداقل %s عکس از محصول و مشکل آن الزامی است.', bws_fa_digits( $min ) ) );
		}
		if ( count( $files ) > $max ) {
			return new WP_Error( 'bws_photo_max', sprintf( 'حداکثر %s عکس می‌توانید ارسال کنید.', bws_fa_digits( $max ) ) );
		}
		$ok = array();
		foreach ( $files as $f ) {
			if ( UPLOAD_ERR_OK !== (int) $f['error'] ) {
				return new WP_Error( 'bws_photo_err', in_array( (int) $f['error'], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ? 'حجم عکس بیشتر از حد مجاز هاست است.' : 'آپلود عکس ناقص بود؛ دوباره تلاش کنید.' );
			}
			if ( (int) $f['size'] > $mb * MB_IN_BYTES ) {
				return new WP_Error( 'bws_photo_size', sprintf( 'حجم هر عکس حداکثر %s مگابایت است.', bws_fa_digits( $mb ) ) );
			}
			if ( ! is_uploaded_file( $f['tmp_name'] ) && ! ( defined( 'BWS_TESTING' ) && BWS_TESTING ) ) {
				return new WP_Error( 'bws_photo_err', 'فایل نامعتبر است.' );
			}
			$info = @getimagesize( $f['tmp_name'] ); // phpcs:ignore
			$mime = $info && ! empty( $info['mime'] ) ? $info['mime'] : '';
			if ( ! in_array( $mime, array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ), true ) ) {
				return new WP_Error( 'bws_photo_type', 'فقط عکس با فرمت JPG، PNG، WEBP یا GIF قابل ارسال است.' );
			}
			$f['mime']   = $mime;
			$f['width']  = (int) $info[0];
			$f['height'] = (int) $info[1];
			$ok[]        = $f;
		}
		return $ok;
	}

	/**
	 * Save validated uploads to private host storage (re-encoded JPEG, max 2000px).
	 * Returns list of inserted file rows ids.
	 */
	public static function store( $return_id, array $files ) {
		global $wpdb;
		$sub    = gmdate( 'Y/m', current_time( 'timestamp' ) );
		$target = self::mode();
		$dir = self::abs_path( $sub );
		wp_mkdir_p( $dir );
		foreach ( array( $dir, dirname( $dir ) ) as $d ) {
			if ( ! file_exists( $d . '/index.php' ) ) {
				@file_put_contents( $d . '/index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore -- no directory listing on Nginx.
			}
		}
		$ids = array();
		foreach ( $files as $f ) {
			$name = bin2hex( random_bytes( 16 ) );
			$dest = $dir . '/' . $name . '.jpg';
			$mime = 'image/jpeg';
			$ed   = function_exists( 'wp_get_image_editor' ) ? wp_get_image_editor( $f['tmp_name'] ) : null;
			$done = false;
			if ( $ed && ! is_wp_error( $ed ) ) {
				$ed->resize( 2000, 2000, false );
				$ed->set_quality( 82 );
				$saved = $ed->save( $dest, 'image/jpeg' );
				if ( ! is_wp_error( $saved ) ) {
					$dest = $saved['path'];
					$done = true;
				}
			}
			if ( ! $done ) {
				// No image library on the host: keep the validated original.
				$ext  = array( 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif' );
				$dest = $dir . '/' . $name . '.' . $ext[ $f['mime'] ];
				$mime = $f['mime'];
				if ( ! @copy( $f['tmp_name'], $dest ) ) { // phpcs:ignore
					continue;
				}
			}
			$info = @getimagesize( $dest ); // phpcs:ignore
			$wpdb->insert( self::table(), array(
				'return_id'  => (int) $return_id,
				'storage'    => $target,
				'path'       => $sub . '/' . basename( $dest ),
				'mime'       => $mime,
				'size'       => (int) filesize( $dest ),
				'md5'        => (string) md5_file( $dest ),
				'width'      => $info ? (int) $info[0] : 0,
				'height'     => $info ? (int) $info[1] : 0,
				'state'      => 'local',
				'created_at' => bws_now(),
			) );
			$ids[] = (int) $wpdb->insert_id;
		}
		return $ids;
	}

	/** Storage mode from settings: host | gdrive | both. */
	public static function mode() {
		$m = (string) bws_opt( 'return_storage', 'host' );
		return in_array( $m, array( 'host', 'gdrive', 'both' ), true ) ? $m : 'host';
	}

	public static function get( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ) );
	}

	/**
	 * Photos ready to send to a bot: local copies, or (Drive-only) temporary downloads.
	 * Returns [ [ path, filename, mime, tmp(bool) ] ]; call cleanup_tmp() afterwards.
	 */
	public static function send_list( $return_id ) {
		$out = array();
		foreach ( self::for_return( $return_id ) as $i => $f ) {
			$name = 'photo-' . ( $i + 1 ) . '.jpg';
			$p    = $f->path ? self::abs_path( $f->path ) : '';
			if ( $p && is_readable( $p ) ) {
				$out[] = array( $p, $name, $f->mime, false );
				continue;
			}
			if ( $f->drive_id && BWS_GDrive::configured() ) {
				$bytes = BWS_GDrive::download( $f->drive_id );
				if ( ! is_wp_error( $bytes ) && '' !== $bytes ) {
					$tmp = wp_tempnam( 'bws-ret' );
					if ( $tmp && false !== file_put_contents( $tmp, $bytes ) ) { // phpcs:ignore
						$out[] = array( $tmp, $name, $f->mime ? $f->mime : 'image/jpeg', true );
					}
				}
			}
		}
		return $out;
	}

	public static function cleanup_tmp( $list ) {
		foreach ( (array) $list as $f ) {
			if ( ! empty( $f[3] ) && is_file( $f[0] ) ) {
				@unlink( $f[0] ); // phpcs:ignore
			}
		}
	}

	public static function for_return( $return_id ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE return_id = %d ORDER BY id ASC', $return_id ) );
	}

	/** Local copies still on the host (used for bot photos and Drive upload). */
	public static function local_list( $return_id ) {
		$out = array();
		foreach ( self::for_return( $return_id ) as $i => $f ) {
			if ( $f->path ) {
				$p = self::abs_path( $f->path );
				if ( is_readable( $p ) ) {
					$out[] = array( $p, 'photo-' . ( $i + 1 ) . '.' . pathinfo( $p, PATHINFO_EXTENSION ), $f->mime );
				}
			}
		}
		return $out;
	}

	/** Signed URL for a host file (valid 2 hours). */
	public static function signed_url( $file_id ) {
		$exp = time() + 2 * HOUR_IN_SECONDS;
		$sig = hash_hmac( 'sha256', $file_id . '|' . $exp, wp_salt( 'auth' ) . 'bws_rfile' );
		return add_query_arg( array( 'bws_rfile' => (int) $file_id, 'e' => $exp, 's' => substr( $sig, 0, 32 ) ), home_url( '/' ) );
	}

	/** Stream a host file for a valid signed URL. */
	public static function serve() {
		if ( empty( $_GET['bws_rfile'] ) ) { // phpcs:ignore
			return;
		}
		global $wpdb;
		$id  = absint( $_GET['bws_rfile'] ); // phpcs:ignore
		$exp = isset( $_GET['e'] ) ? (int) $_GET['e'] : 0; // phpcs:ignore
		$sig = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$ok  = $exp > time() && hash_equals( substr( hash_hmac( 'sha256', $id . '|' . $exp, wp_salt( 'auth' ) . 'bws_rfile' ), 0, 32 ), $sig );
		$f   = $ok ? $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ) ) : null;
		$p   = $f && $f->path ? self::abs_path( $f->path ) : '';
		if ( ( ! $p || ! is_readable( $p ) ) && $f && $f->drive_id && BWS_GDrive::configured() ) {
			// Photo lives only on Google Drive: stream it through the site (works for private files too).
			$bytes = BWS_GDrive::download( $f->drive_id );
			if ( ! is_wp_error( $bytes ) && '' !== $bytes ) {
				header( 'Content-Type: ' . ( in_array( $f->mime, array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ), true ) ? $f->mime : 'image/jpeg' ) );
				header( 'Content-Length: ' . strlen( $bytes ) );
				header( 'Cache-Control: private, max-age=3600' );
				header( 'X-Content-Type-Options: nosniff' );
				header( "Content-Security-Policy: default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox" );
				echo $bytes; // phpcs:ignore
				exit;
			}
		}
		if ( ! $p || ! is_readable( $p ) ) {
			status_header( $ok ? 404 : 403 );
			nocache_headers();
			exit( $ok ? 'Not found' : 'Link expired' );
		}
		header( 'Content-Type: ' . ( in_array( $f->mime, array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ), true ) ? $f->mime : 'application/octet-stream' ) );
		header( 'Content-Length: ' . filesize( $p ) );
		header( 'Cache-Control: private, max-age=3600' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Content-Disposition: inline; filename="return-' . (int) $f->return_id . '-' . (int) $f->id . '.' . pathinfo( $p, PATHINFO_EXTENSION ) . '"' );
		header( "Content-Security-Policy: default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox" );
		readfile( $p ); // phpcs:ignore
		exit;
	}

	/**
	 * Array for the panels.
	 *  - local copy on host  → opens inside the panel (signed URL); 'drive' = Drive link when also backed up.
	 *  - only on Drive        → 'url' opens Google Drive; thumbnail is streamed through the site (private files work).
	 *  - deleted from host    → storage 'deleted'.
	 */
	public static function to_array( $f ) {
		$local = $f->path && is_readable( self::abs_path( $f->path ) );
		$base  = array( 'id' => (int) $f->id, 'width' => (int) $f->width, 'height' => (int) $f->height, 'drive' => 'uploaded' === $f->state ? (string) $f->drive_link : '' );
		if ( $local ) {
			$u = self::signed_url( $f->id );
			return array_merge( $base, array( 'storage' => 'host', 'url' => $u, 'thumb' => $u, 'pending' => in_array( $f->storage, array( 'gdrive', 'both' ), true ) && 'uploaded' !== $f->state ) );
		}
		if ( $f->drive_id && 'uploaded' === $f->state ) {
			return array_merge( $base, array( 'storage' => 'gdrive', 'url' => $f->drive_link ? $f->drive_link : 'https://drive.google.com/file/d/' . rawurlencode( $f->drive_id ) . '/view', 'thumb' => self::signed_url( $f->id ) ) );
		}
		return array_merge( $base, array( 'storage' => 'deleted', 'url' => '', 'thumb' => '' ) );
	}

	/* ---------------- Host clean-up (free disk space) ---------------- */

	/** WHERE for clean-up candidates. $a: days, statuses[], backed (only files also on Drive). */
	protected static function cleanup_where( $a ) {
		global $wpdb;
		$w = array( "f.path <> ''" );
		// Never delete files still waiting for their Drive upload.
		$w[] = "( f.storage = 'host' OR f.state = 'uploaded' )";
		if ( ! empty( $a['backed'] ) ) {
			$w[] = "f.state = 'uploaded'";
		}
		$days = isset( $a['days'] ) ? max( 0, (int) $a['days'] ) : 0;
		if ( $days > 0 ) {
			$w[] = $wpdb->prepare( 'r.created_at < %s', gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $days * DAY_IN_SECONDS ) );
		}
		$st = array_values( array_intersect( isset( $a['statuses'] ) ? (array) $a['statuses'] : array(), array_keys( BWS_Returns::$statuses ) ) );
		if ( ! $st ) {
			return '1=0';
		}
		$w[] = "r.status IN ('" . implode( "','", array_map( 'esc_sql', $st ) ) . "')";
		return implode( ' AND ', $w );
	}

	public static function host_usage() {
		global $wpdb;
		$row = $wpdb->get_row( 'SELECT COUNT(*) n, COALESCE(SUM(size),0) b FROM ' . self::table() . " WHERE path <> ''" );
		return array( 'files' => (int) $row->n, 'bytes' => (int) $row->b, 'size' => size_format( (int) $row->b, 1 ) );
	}

	public static function cleanup_scan( $a ) {
		global $wpdb;
		$row = $wpdb->get_row( 'SELECT COUNT(*) n, COALESCE(SUM(f.size),0) b, COUNT(DISTINCT f.return_id) r FROM ' . self::table() . ' f INNER JOIN ' . BWS_Returns::table() . ' r ON r.id = f.return_id WHERE ' . self::cleanup_where( $a ) );
		return array( 'files' => (int) $row->n, 'returns' => (int) $row->r, 'bytes' => (int) $row->b, 'size' => size_format( (int) $row->b, 1 ) );
	}

	/** Delete host copies in batches. Data, descriptions and Drive copies are kept. */
	public static function cleanup_run( $a, $limit = 300 ) {
		global $wpdb;
		$rows  = $wpdb->get_results( 'SELECT f.* FROM ' . self::table() . ' f INNER JOIN ' . BWS_Returns::table() . ' r ON r.id = f.return_id WHERE ' . self::cleanup_where( $a ) . ' ORDER BY f.id ASC LIMIT ' . max( 1, (int) $limit ) );
		$n     = 0;
		$bytes = 0;
		foreach ( $rows as $f ) {
			$bytes += (int) $f->size;
			self::delete_local( $f );
			if ( 'uploaded' !== $f->state ) {
				$wpdb->update( self::table(), array( 'state' => 'purged' ), array( 'id' => $f->id ) );
			}
			$n++;
		}
		$left = self::cleanup_scan( $a );
		return array( 'deleted' => $n, 'bytes' => $bytes, 'size' => size_format( $bytes, 1 ), 'left' => $left['files'] );
	}

	/** Daily automatic clean-up (setting: days after creation, decided requests only). */
	public static function autoclean() {
		$days = (int) bws_opt( 'return_autoclean_days', 0 );
		if ( $days <= 0 ) {
			return;
		}
		self::cleanup_run( array( 'days' => $days, 'statuses' => array( 'approved', 'rejected', 'cancelled' ), 'backed' => (bool) bws_opt( 'return_autoclean_backed', 0 ) ), 1000 );
	}

	/**
	 * Move local photos of a return to Google Drive (when storage = gdrive).
	 * $keep_local = true keeps the host copy (bots still need it). Returns 'ok' | 'pending' | 'failed'.
	 */
	public static function push_to_drive( $r, $keep_local = false ) {
		global $wpdb;
		$state = 'ok';
		foreach ( self::for_return( $r->id ) as $i => $f ) {
			if ( ! in_array( $f->storage, array( 'gdrive', 'both' ), true ) || 'uploaded' === $f->state ) {
				if ( 'uploaded' === $f->state && $f->path && ! $keep_local && 'gdrive' === $f->storage ) {
					self::delete_local( $f );
				}
				continue;
			}
			$p = $f->path ? self::abs_path( $f->path ) : '';
			if ( ! $p || ! is_readable( $p ) ) {
				$wpdb->update( self::table(), array( 'state' => 'failed', 'error' => 'فایل محلی وجود ندارد' ), array( 'id' => $f->id ) );
				$state = 'failed';
				continue;
			}
			$up = BWS_GDrive::upload( $p, $r->code . '-' . ( $i + 1 ) . '.' . pathinfo( $p, PATHINFO_EXTENSION ), $f->mime, 'مرجوعی ' . $r->code . ' — سفارش #' . $r->order_id );
			if ( is_wp_error( $up ) ) {
				$wpdb->update( self::table(), array( 'state' => 'pending', 'error' => mb_substr( $up->get_error_message(), 0, 500 ) ), array( 'id' => $f->id ) );
				$state = 'pending';
				continue;
			}
			$wpdb->update( self::table(), array( 'state' => 'uploaded', 'drive_id' => $up['id'], 'drive_link' => esc_url_raw( $up['link'] ), 'drive_public' => $up['public'] ? 1 : 0, 'md5' => $up['md5'], 'error' => '' ), array( 'id' => $f->id ) );
			if ( ! $keep_local && 'both' !== $f->storage ) {
				self::delete_local( $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $f->id ) ) );
			}
		}
		return $state;
	}

	public static function delete_local( $f ) {
		global $wpdb;
		if ( $f && $f->path ) {
			$p = self::abs_path( $f->path );
			if ( is_file( $p ) ) {
				@unlink( $p ); // phpcs:ignore
			}
			$wpdb->update( self::table(), array( 'path' => '' ), array( 'id' => $f->id ) );
		}
	}

	/** Delete all files of a return (host + Drive, best effort). */
	public static function purge( $return_id ) {
		global $wpdb;
		foreach ( self::for_return( $return_id ) as $f ) {
			self::delete_local( $f );
			if ( $f->drive_id && BWS_GDrive::configured() ) {
				BWS_GDrive::delete( $f->drive_id );
			}
		}
		$wpdb->delete( self::table(), array( 'return_id' => (int) $return_id ) );
	}
}
