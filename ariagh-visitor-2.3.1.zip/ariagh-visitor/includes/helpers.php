<?php
defined( 'ABSPATH' ) || exit;

/**
 * Default settings. Money values are in the store currency unit (Toman when WooCommerce is set to IRT).
 */
function bws_default_settings() {
	$currency    = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'IRT';
	$credit_unit = ( 'IRR' === $currency ) ? 100000000 : 10000000; // 10M Toman.

	$defaults = array(
		// Pages & display.
		'customer_page_id'         => 0,
		'visitor_page_id'          => 0,
		'panel_mode'               => 'app',     // app (full screen) | theme (inside theme layout, follows theme) | elementor.
		'ui_follow_theme'          => 1,         // in theme mode: use theme / Elementor global colours and font.
		'panel_fullscreen'         => 1,         // legacy flag, kept in sync with panel_mode.
		'ui_primary'               => '#1D4ED8',
		'ui_navy'                  => '#0B1B3F',
		'ui_radius'                => 16,
		'ui_font'                  => 'vazirmatn', // vazirmatn | inherit.
		'ui_logo_mode'             => 'brand',   // brand (ARIAGH.VISITOR) | company (company logo/name).
		'notice_customer'          => '',
		'notice_visitor'           => '',
		// Pricing.
		'discount_percent'         => 20,
		'price_base'               => 'regular', // regular | active.
		'price_rounding'           => 0,          // 0 = none, or 10/100/1000 ...
		'show_retail_price'        => 1,
		'wholesale_label'          => 'قیمت خرید عمده همکاران:',
		'retail_label'             => 'قیمت مصرف‌کننده:',
		'hide_out_of_stock'        => 0,
		// Order rules.
		'min_qty'                  => 20,
		'max_qty'                  => 0,
		'min_amount'               => 0,
		'new_order_status'         => 'processing',
		'allow_customer_note'      => 1,
		'allow_reorder'            => 1,
		'customer_cancel'          => 'processing', // none | pending | processing (pending + on-hold + processing).
		'order_label_customer'     => '* سفارش از پنل مشتری *',
		'order_label_visitor'      => '* سفارش از پنل عمده — ویزیتور: {visitor} *',
		'order_label_admin'        => '* سفارش از پنل عمده *',
		'order_label_settlement'   => '* تسویه بدهی از پنل مشتری *',
		'customer_about_show'      => 1,
		'customer_about_label'     => '',        // empty = "درباره {company}".
		'customer_about_url'       => '',        // empty = the site's /about-us/ (or /about/) page.
		// Credit.
		'default_credit'           => $credit_unit,
		'settle_before_order'      => 0,
		'excess_online'            => 1,
		'excess_offline'           => 1,
		'allow_online_settlement'  => 1,
		'pending_cancel_hours'     => 48,
		'payment_terms_days'       => 30,
		// Codes & login security.
		'code_length'              => 8,
		'code_type'                => 'numeric', // numeric | alnum.
		'code_prefix'              => '',
		'login_max_attempts'       => 10,
		'session_days'             => 30,
		'customer_otp'             => 0,          // 1 = after code, verify with SMS one-time password.
		'customer_mobile_login'    => 1,          // forgot code: log in with mobile + OTP.
		'otp_length'               => 5,
		'otp_minutes'              => 3,
		// Visitors.
		'visitor_perms'            => array(),    // default permissions, see BWS_Perms.
		'visitor_default_target'   => 0,
		// Company / print.
		'company_name'             => get_bloginfo( 'name' ),
		'company_phone'            => '',
		'company_site'             => home_url(),
		'company_logo'             => '',
		'print_footer'             => 'با کد اختصاصی خود وارد پنل همکاران شوید و سفارش ثبت کنید.',
		'print_qr'                 => 1,
		// SMS.
		'sms_enabled'              => 0,
		'sms_test_mode'            => 1,
		'sms_provider'             => 'smsir',
		'sms_providers'            => array(),
		'admin_mobiles'            => '',
		'reminder_days'            => 30,
		'reminder_repeat_days'     => 7,
		'sms_batch_size'           => 25,
		'order_status_sms'         => array( 'completed' ),
		// Returns (مرجوعی).
		'returns_enabled'          => 1,
		'return_reasons'           => 'کپک‌زدگی محصول',
		'return_days'              => 30,         // 0 = no time limit (counted from the order date).
		'return_statuses'          => array( 'processing', 'completed' ),
		'return_min_photos'        => 1,
		'return_max_photos'        => 5,
		'return_max_mb'            => 8,
		'return_desc_required'     => 1,
		'return_storage'           => 'host',     // host | gdrive | both.
		'gdrive_mode'              => 'oauth',    // oauth (personal Gmail) | service (Workspace service account).
		'gdrive_client_id'         => '',
		'gdrive_client_secret'     => '',
		'gdrive_refresh_token'     => '',
		'gdrive_account'           => '',
		'gdrive_folder_id'         => '',
		'gdrive_sa_json'           => '',
		'gdrive_sa_folder_id'      => '',
		'gdrive_share'             => 'anyone',   // anyone (link) | private.
		'gdrive_monthly'           => 1,
		'tg_enabled'               => 0,
		'tg_token'                 => '',
		'tg_chats'                 => '',
		'tg_api_base'              => 'https://api.telegram.org',
		'bale_enabled'             => 0,
		'bale_token'               => '',
		'bale_chats'               => '',
		'bale_api_base'            => 'https://tapi.bale.ai',
		'bot_events'               => array( 'new', 'decision', 'cancel' ),
		'bot_photos'               => 1,
		'bot_recipients'           => array(),
		'bot_mode'                 => 'off',      // off | webhook | polling.
		'bot_secret'               => '',
		'bot_tpl_new'              => '',
		'bot_tpl_approved'         => '',
		'bot_tpl_rejected'         => '',
		'bot_tpl_cancel'           => '',
		'bot_tpl_welcome'          => '',
		'return_autoclean_days'    => 0,
		'return_autoclean_backed'  => 1,
		// Data.
		'delete_data_on_uninstall' => 0,
	);
	foreach ( BWS_Events::all() as $key => $e ) {
		$defaults[ 'tpl_' . $key ]           = $e['default'];
		$defaults[ 'tpl_' . $key . '_mode' ] = 'text';
		$defaults[ 'tpl_' . $key . '_code' ] = '';
		$defaults[ 'tpl_' . $key . '_params' ] = $e['pattern_hint'];
		if ( $e['toggle'] ) {
			$defaults[ $e['toggle'] ] = $e['toggle_default'];
		}
	}
	return $defaults;
}

function bws_settings() {
	if ( empty( $GLOBALS['bws_settings_cache'] ) ) {
		$saved                         = get_option( 'bws_settings', array() );
		$GLOBALS['bws_settings_cache'] = wp_parse_args( is_array( $saved ) ? $saved : array(), bws_default_settings() );
	}
	return $GLOBALS['bws_settings_cache'];
}

function bws_opt( $key, $default = null ) {
	$s = bws_settings();
	return array_key_exists( $key, $s ) ? $s[ $key ] : $default;
}

/** Settings are autoloaded (one small option) so normal page views never pay an extra query. */
function bws_update_settings( $new ) {
	$current = get_option( 'bws_settings', array() );
	$current = is_array( $current ) ? $current : array();
	update_option( 'bws_settings', array_merge( $current, $new ), true );
	$GLOBALS['bws_settings_cache'] = null;
	do_action( 'bws_settings_saved' );
}

/* ------------------------------------------------------------------ */
/* Secrets: API keys / passwords are stored encrypted at rest.          */
/* ------------------------------------------------------------------ */

function bws_crypto_key() {
	return hash( 'sha256', wp_salt( 'secure_auth' ) . 'ariagh-visitor', true );
}

function bws_encrypt( $plain ) {
	$plain = (string) $plain;
	if ( '' === $plain || 0 === strpos( $plain, 'enc:' ) ) {
		return $plain;
	}
	if ( function_exists( 'sodium_crypto_secretbox' ) ) {
		$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		return 'enc:s:' . base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, bws_crypto_key() ) );
	}
	if ( function_exists( 'openssl_encrypt' ) ) {
		$iv = random_bytes( 16 );
		$ct = openssl_encrypt( $plain, 'aes-256-cbc', bws_crypto_key(), OPENSSL_RAW_DATA, $iv );
		$mac = hash_hmac( 'sha256', $iv . $ct, bws_crypto_key(), true );
		return 'enc:o:' . base64_encode( $iv . $mac . $ct );
	}
	return $plain;
}

function bws_decrypt( $value ) {
	$value = (string) $value;
	if ( 0 !== strpos( $value, 'enc:' ) ) {
		return $value;
	}
	$raw = base64_decode( substr( $value, 6 ), true );
	if ( false === $raw ) {
		return '';
	}
	if ( 'enc:s:' === substr( $value, 0, 6 ) && function_exists( 'sodium_crypto_secretbox_open' ) ) {
		$nonce = substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$plain = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), $nonce, bws_crypto_key() );
		return false === $plain ? '' : $plain;
	}
	if ( 'enc:o:' === substr( $value, 0, 6 ) && function_exists( 'openssl_decrypt' ) ) {
		$iv  = substr( $raw, 0, 16 );
		$mac = substr( $raw, 16, 32 );
		$ct  = substr( $raw, 48 );
		if ( ! hash_equals( hash_hmac( 'sha256', $iv . $ct, bws_crypto_key(), true ), $mac ) ) {
			return '';
		}
		$plain = openssl_decrypt( $ct, 'aes-256-cbc', bws_crypto_key(), OPENSSL_RAW_DATA, $iv );
		return false === $plain ? '' : $plain;
	}
	return '';
}

/** Placeholder shown instead of a stored secret in forms. */
function bws_secret_mask() {
	return '••••••••';
}

/** Convert Persian/Arabic digits to English digits. */
function bws_en_digits( $str ) {
	$fa = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' );
	$en = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
	return str_replace( $fa, $en, (string) $str );
}

function bws_fa_digits( $str ) {
	return str_replace( array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' ), array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' ), (string) $str );
}

/** Normalize Iranian mobile to 09xxxxxxxxx. Returns '' if invalid. */
function bws_normalize_mobile( $mobile ) {
	$m = preg_replace( '/\D+/', '', bws_en_digits( $mobile ) );
	if ( 0 === strpos( $m, '0098' ) ) {
		$m = '0' . substr( $m, 4 );
	} elseif ( 0 === strpos( $m, '98' ) && strlen( $m ) === 12 ) {
		$m = '0' . substr( $m, 2 );
	} elseif ( strlen( $m ) === 10 && '9' === $m[0] ) {
		$m = '0' . $m;
	}
	return preg_match( '/^09\d{9}$/', $m ) ? $m : '';
}

/** Parse money input (accepts Persian digits and separators). */
function bws_parse_amount( $val ) {
	$v = preg_replace( '/[^\d.\-]/', '', bws_en_digits( $val ) );
	return (float) $v;
}

/** Plain money text for SMS / print: "۱۲,۰۰۰,۰۰۰ تومان". */
function bws_money_text( $amount ) {
	$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'IRT';
	$labels   = array( 'IRT' => 'تومان', 'IRR' => 'ریال', 'IRHT' => 'هزار تومان', 'IRHR' => 'هزار ریال' );
	$label    = isset( $labels[ $currency ] ) ? $labels[ $currency ] : $currency;
	$neg      = $amount < 0 ? '-' : '';
	return $neg . number_format( abs( round( (float) $amount ) ) ) . ' ' . $label;
}

function bws_money_html( $amount ) {
	return '<span class="bws-money">' . esc_html( bws_money_text( $amount ) ) . '</span>';
}

/* ------------------------------------------------------------------ */
/* Jalali date                                                         */
/* ------------------------------------------------------------------ */

function bws_g2j( $gy, $gm, $gd ) {
	$g_d_m = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );
	$gy2   = ( $gm > 2 ) ? ( $gy + 1 ) : $gy;
	$days  = 355666 + ( 365 * $gy ) + (int) ( ( $gy2 + 3 ) / 4 ) - (int) ( ( $gy2 + 99 ) / 100 ) + (int) ( ( $gy2 + 399 ) / 400 ) + $gd + $g_d_m[ $gm - 1 ];
	$jy    = -1595 + ( 33 * (int) ( $days / 12053 ) );
	$days %= 12053;
	$jy   += 4 * (int) ( $days / 1461 );
	$days %= 1461;
	if ( $days > 365 ) {
		$jy   += (int) ( ( $days - 1 ) / 365 );
		$days  = ( $days - 1 ) % 365;
	}
	if ( $days < 186 ) {
		$jm = 1 + (int) ( $days / 31 );
		$jd = 1 + ( $days % 31 );
	} else {
		$jm = 7 + (int) ( ( $days - 186 ) / 30 );
		$jd = 1 + ( ( $days - 186 ) % 30 );
	}
	return array( $jy, $jm, $jd );
}

/**
 * Format a MySQL datetime (stored in site local time) or timestamp as Jalali.
 */
function bws_jdate( $datetime, $with_time = true ) {
	if ( empty( $datetime ) || '0000-00-00 00:00:00' === $datetime ) {
		return '—';
	}
	$ts = is_numeric( $datetime ) ? (int) $datetime : strtotime( $datetime );
	if ( ! $ts ) {
		return '—';
	}
	if ( is_numeric( $datetime ) ) {
		// Unix timestamps are UTC – convert to site local.
		$ts += (int) ( get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
	}
	list( $jy, $jm, $jd ) = bws_g2j( (int) gmdate( 'Y', $ts ), (int) gmdate( 'n', $ts ), (int) gmdate( 'j', $ts ) );
	$out = sprintf( '%04d/%02d/%02d', $jy, $jm, $jd );
	if ( $with_time ) {
		$out .= ' ' . gmdate( 'H:i', $ts );
	}
	return bws_fa_digits( $out );
}

function bws_now() {
	return current_time( 'mysql' );
}

/* ------------------------------------------------------------------ */
/* Misc                                                                */
/* ------------------------------------------------------------------ */

function bws_customer_panel_url( $code = '' ) {
	$page = (int) bws_opt( 'customer_page_id' );
	$url  = $page ? get_permalink( $page ) : home_url( '/buy-panel/' );
	if ( $code ) {
		$url = add_query_arg( 'code', rawurlencode( $code ), $url );
	}
	return $url;
}

function bws_visitor_panel_url() {
	$page = (int) bws_opt( 'visitor_page_id' );
	return $page ? get_permalink( $page ) : home_url( '/visitor-panel/' );
}

function bws_is_visitor( $user_id = null ) {
	$user = $user_id ? get_userdata( $user_id ) : wp_get_current_user();
	return $user && $user->exists() && in_array( 'bws_visitor', (array) $user->roles, true );
}

function bws_is_manager( $user_id = null ) {
	return $user_id ? user_can( $user_id, 'bws_manage' ) : current_user_can( 'bws_manage' );
}

function bws_visitor_active( $user_id ) {
	return '0' !== (string) get_user_meta( $user_id, 'bws_active', true );
}

function bws_user_name( $user_id ) {
	if ( ! $user_id ) {
		return '—';
	}
	$u = get_userdata( $user_id );
	return $u ? ( $u->display_name ? $u->display_name : $u->user_login ) : '—';
}

/** Replace {placeholders} in a template. */
function bws_render_template( $tpl, $vars ) {
	$rep = array();
	foreach ( $vars as $k => $v ) {
		$rep[ '{' . $k . '}' ] = (string) $v;
	}
	return trim( strtr( (string) $tpl, $rep ) );
}

/** Simple named lock to avoid double-spending credit on concurrent requests. */
function bws_lock( $name, $timeout = 10 ) {
	global $wpdb;
	if ( isset( $wpdb->is_mysql ) && $wpdb->is_mysql && ! defined( 'DB_ENGINE' ) ) {
		$r = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', 'bws_' . $name, $timeout ) );
		if ( null !== $r ) {
			return (bool) $r;
		}
	}
	$key   = 'bws_lock_' . md5( $name );
	$start = time();
	while ( get_transient( $key ) ) {
		if ( time() - $start >= $timeout ) {
			return false;
		}
		usleep( 200000 );
	}
	set_transient( $key, 1, 30 );
	return true;
}

function bws_unlock( $name ) {
	global $wpdb;
	if ( isset( $wpdb->is_mysql ) && $wpdb->is_mysql && ! defined( 'DB_ENGINE' ) ) {
		$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', 'bws_' . $name ) );
	}
	delete_transient( 'bws_lock_' . md5( $name ) );
}

function bws_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0.0.0.0';
	return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
}

/** Cheap, cache-friendly rate limiter (per IP + bucket). Returns true when the limit is exceeded. */
function bws_rate_limited( $bucket, $limit, $window = 60 ) {
	$key = 'bws_rl2_' . md5( $bucket . '|' . bws_client_ip() );
	$hit = get_transient( $key );
	if ( ! is_array( $hit ) || $hit['t'] < time() - $window ) {
		$hit = array( 't' => time(), 'n' => 0 );
	}
	$hit['n']++;
	set_transient( $key, $hit, $window );
	return $hit['n'] > $limit;
}

/** Brand / product name shown in the UI. */
function bws_brand() {
	return 'ARIAGH.VISITOR';
}

/** SMS character/part counter (Persian = UCS2: 70 / 67 per part; Latin = GSM: 160 / 153). */
function bws_sms_parts( $text ) {
	$len     = mb_strlen( (string) $text, 'UTF-8' );
	$unicode = (bool) preg_match( '/[^\x00-\x7F]/', (string) $text );
	$single  = $unicode ? 70 : 160;
	$multi   = $unicode ? 67 : 153;
	return array( 'chars' => $len, 'parts' => $len <= $single ? 1 : (int) ceil( $len / $multi ), 'unicode' => $unicode );
}

/** Iranian provinces list for forms. */
function bws_provinces() {
	return array( 'تهران', 'البرز', 'اصفهان', 'فارس', 'خراسان رضوی', 'آذربایجان شرقی', 'آذربایجان غربی', 'اردبیل', 'ایلام', 'بوشهر', 'چهارمحال و بختیاری', 'خراسان جنوبی', 'خراسان شمالی', 'خوزستان', 'زنجان', 'سمنان', 'سیستان و بلوچستان', 'قزوین', 'قم', 'کردستان', 'کرمان', 'کرمانشاه', 'کهگیلویه و بویراحمد', 'گلستان', 'گیلان', 'لرستان', 'مازندران', 'مرکزی', 'هرمزگان', 'همدان', 'یزد' );
}

function bws_j2g( $jy, $jm, $jd ) {
	$jy  += 1595;
	$days = -355668 + ( 365 * $jy ) + ( (int) ( $jy / 33 ) * 8 ) + (int) ( ( ( $jy % 33 ) + 3 ) / 4 ) + $jd + ( ( $jm < 7 ) ? ( $jm - 1 ) * 31 : ( ( $jm - 7 ) * 30 ) + 186 );
	$gy   = 400 * (int) ( $days / 146097 );
	$days %= 146097;
	if ( $days > 36524 ) {
		$gy  += 100 * (int) ( --$days / 36524 );
		$days %= 36524;
		if ( $days >= 365 ) {
			$days++;
		}
	}
	$gy  += 4 * (int) ( $days / 1461 );
	$days %= 1461;
	if ( $days > 365 ) {
		$gy  += (int) ( ( $days - 1 ) / 365 );
		$days = ( $days - 1 ) % 365;
	}
	$gd   = $days + 1;
	$kab  = ( ( 0 === $gy % 4 && 0 !== $gy % 100 ) || 0 === $gy % 400 ) ? 29 : 28;
	$months = array( 0, 31, $kab, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );
	for ( $gm = 1; $gm <= 12 && $gd > $months[ $gm ]; $gm++ ) {
		$gd -= $months[ $gm ];
	}
	return array( $gy, $gm, $gd );
}

/** Build a UTF-8 CSV (with BOM so Excel shows Persian correctly). Cells starting with = + - @ are escaped (CSV injection). */
function bws_csv( $rows ) {
	$fh = fopen( 'php://temp', 'r+' );
	fwrite( $fh, "\xEF\xBB\xBF" );
	foreach ( $rows as $r ) {
		$r = array_map( function ( $v ) {
			$v = (string) $v;
			return ( '' !== $v && in_array( $v[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) && ! is_numeric( $v ) ) ? "'" . $v : $v;
		}, (array) $r );
		fputcsv( $fh, $r );
	}
	rewind( $fh );
	$csv = stream_get_contents( $fh );
	fclose( $fh );
	return $csv;
}

/** "About us" link for the customer panel bottom bar. Returns [label, url] or null. */
function bws_about_link() {
	if ( ! bws_opt( 'customer_about_show', 1 ) ) {
		return null;
	}
	$url = trim( (string) bws_opt( 'customer_about_url' ) );
	if ( '' === $url ) {
		$cached = get_transient( 'bws_about_url' );
		if ( false === $cached ) {
			$cached = '';
			foreach ( array( 'about-us', 'about', 'درباره-ما', 'aboutus' ) as $slug ) {
				$pg = get_page_by_path( $slug );
				if ( $pg && 'publish' === $pg->post_status ) {
					$cached = get_permalink( $pg );
					break;
				}
			}
			set_transient( 'bws_about_url', $cached, DAY_IN_SECONDS );
		}
		$url = $cached;
	}
	if ( ! $url ) {
		return null;
	}
	$label = trim( (string) bws_opt( 'customer_about_label' ) );
	return array( $label ? $label : 'درباره ' . bws_opt( 'company_name' ), esc_url_raw( $url ) );
}
