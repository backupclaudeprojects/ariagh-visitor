<?php
defined( 'ABSPATH' ) || exit;

class BWS_Admin {

	/** slug => [ label, icon, group, spa-tab ] */
	public static function sections() {
		return array(
			'bws-dashboard' => array( 'داشبورد', 'dashboard', 'اصلی', '' ),
			'bws-top'       => array( 'برترین‌ها', 'trophy', 'اصلی', '' ),
			'customers'     => array( 'مشتریان', 'users', 'مشتریان و فروش', 'customers' ),
			'new'           => array( 'ثبت مشتری جدید', 'user-plus', 'مشتریان و فروش', 'new' ),
			'orders'        => array( 'سفارش‌ها', 'package', 'مشتریان و فروش', 'orders' ),
			'returns'       => array( 'مرجوعی‌ها', 'return', 'مشتریان و فروش', 'returns' ),
			'bws-ledger'    => array( 'دفتر اعتبار', 'wallet', 'مشتریان و فروش', '' ),
			'bws-visitors'  => array( 'ویزیتورها و دسترسی‌ها', 'shield', 'تیم و محصولات', '' ),
			'bws-products'  => array( 'محصولات و قیمت', 'package', 'تیم و محصولات', '' ),
			'bulk'          => array( 'پیامک گروهی', 'send', 'پیامک و پرداخت', 'sms' ),
			'bws-sms'       => array( 'پنل پیامک', 'message', 'پیامک و پرداخت', '' ),
			'snapppay'      => array( 'اسنپ‌پی (اقساطی)', 'cash', 'پیامک و پرداخت', '' ),
			'bws-settings'  => array( 'تنظیمات', 'settings', 'سیستم', '' ),
			'bws-activity'  => array( 'گزارش فعالیت‌ها', 'activity', 'سیستم', '' ),
			'bws-help'      => array( 'راهنمای کامل', 'info', 'سیستم', '' ),
		);
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_bws_save_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_bws_save_visitor', array( __CLASS__, 'save_visitor' ) );
		add_action( 'admin_post_bws_export', array( __CLASS__, 'export' ) );
		add_action( 'admin_post_bws_import', array( __CLASS__, 'import' ) );
		add_action( 'admin_post_bws_settings_export', array( __CLASS__, 'settings_export' ) );
		add_action( 'admin_post_bws_settings_import', array( __CLASS__, 'settings_import' ) );
	}

	/** Menu icon (monochrome SVG, follows the admin colour scheme). */
	protected static function menu_icon() {
		$f = BWS_DIR . 'assets/img/menu-icon.svg';
		return file_exists( $f ) ? 'data:image/svg+xml;base64,' . base64_encode( file_get_contents( $f ) ) : 'dashicons-groups'; // phpcs:ignore
	}

	public static function menu() {
		$cap = 'bws_manage';
		add_menu_page( 'ARIAGH.VISITOR — ویزیتور', 'ویزیتور', $cap, 'bws-dashboard', array( __CLASS__, 'render' ), self::menu_icon(), 56 );
		$pages = array(
			'bws-dashboard' => 'داشبورد',
			'bws-customers' => 'مشتریان و سفارش‌ها',
			'bws-top'       => 'برترین‌ها',
			'bws-visitors'  => 'ویزیتورها و دسترسی‌ها',
			'bws-products'  => 'محصولات و قیمت',
			'bws-ledger'    => 'دفتر اعتبار',
			'bws-sms'       => 'پنل پیامک',
			'bws-settings'  => 'تنظیمات',
			'bws-activity'  => 'گزارش فعالیت‌ها',
			'bws-help'      => 'راهنما',
		);
		foreach ( $pages as $slug => $label ) {
			add_submenu_page( 'bws-dashboard', $label . ' — ویزیتور', $label, $cap, $slug, array( __CLASS__, 'render' ) );
		}
	}

	protected static function current_page() {
		return isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : 'bws-dashboard'; // phpcs:ignore
	}

	protected static function spa_tab() {
		$t = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'customers'; // phpcs:ignore
		return in_array( $t, array( 'customers', 'new', 'orders', 'sms', 'returns' ), true ) ? $t : 'customers';
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'bws-' ) ) {
			return;
		}
		$min = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
		$css = file_exists( BWS_DIR . 'assets/css/bws' . $min . '.css' ) ? 'bws' . $min . '.css' : 'bws.css';
		wp_enqueue_style( 'bws-ui', BWS_URL . 'assets/css/' . $css, array(), BWS_VERSION );
		wp_add_inline_style( 'bws-ui', BWS_Frontend::font_css() . BWS_Frontend::appearance_css() );
		wp_enqueue_script( 'bws-admin', BWS_Frontend::js( 'admin' ), array(), BWS_VERSION, true );
		wp_localize_script( 'bws-admin', 'BWSA', array(
			'rest'  => esc_url_raw( rest_url( BWS_REST::NS ) ),
			'nonce' => wp_create_nonce( 'wp_rest' ),
		) );
		if ( 'bws-customers' === self::current_page() ) {
			wp_enqueue_script( 'bws-core', BWS_Frontend::js( 'bws-core' ), array(), BWS_VERSION, true );
			wp_enqueue_script( 'bws-visitor', BWS_Frontend::js( 'visitor-panel' ), array( 'bws-core' ), BWS_VERSION, true );
			wp_localize_script( 'bws-core', 'BWS', array(
				'rest'       => esc_url_raw( rest_url( BWS_REST::NS ) ),
				'nonce'      => wp_create_nonce( 'wp_rest' ),
				'mode'       => 'visitor',
				'company'    => bws_opt( 'company_name' ),
				'logo'       => bws_opt( 'company_logo' ),
				'logoMode'   => bws_opt( 'ui_logo_mode', 'brand' ),
				'markSvg'    => BWS_URL . 'assets/img/mark.svg',
				'home'       => home_url( '/' ),
				'admin'      => '',
				'inAdmin'    => true,
				'startTab'   => self::spa_tab(),
				'printOrder' => add_query_arg( array( 'bws_print' => 'order', '_bwsn' => wp_create_nonce( 'bws_print' ) ), home_url( '/' ) ),
				'adminOrder' => BWS_Frontend::admin_order_url_tpl(),
				'icons'      => BWS_Icons::paths(),
			) );
		}
	}

	/* ================= Shell & UI helpers ================= */

	protected static function ic( $n, $s = 18 ) {
		return BWS_Icons::get( $n, $s );
	}

	public static function render() {
		$page = self::current_page();
		$spa  = 'bws-customers' === $page;
		$cur  = $spa ? array( 'customers' => 'customers', 'new' => 'new', 'orders' => 'orders', 'sms' => 'bulk', 'returns' => 'returns' )[ self::spa_tab() ] : $page;
		$sms  = ! bws_opt( 'sms_enabled' ) ? array( 'is-bad', 'پیامک خاموش' ) : ( bws_opt( 'sms_test_mode' ) ? array( 'is-warn', 'پیامک: حالت تست' ) : array( 'is-ok', 'پیامک فعال' ) );
		$tot  = BWS_Ledger::totals();
		$grp  = '';
		?>
		<div class="bws-ui bws-admin-app" dir="rtl">
			<header class="bws-top">
				<a class="bws-brand bws-brand-logo" href="<?php echo esc_url( admin_url( 'admin.php?page=bws-dashboard' ) ); ?>">
					<img src="<?php echo esc_url( BWS_URL . 'assets/img/logo.svg' ); ?>" alt="ARIAGH.VISITOR" class="bws-brand-svg" width="190" height="31">
					<div><small><?php echo esc_html( bws_opt( 'company_name' ) ); ?> · نسخه <?php echo esc_html( BWS_VERSION ); ?></small></div>
				</a>
				<div class="bws-top-status">
					<a class="bws-chip <?php echo esc_attr( $sms[0] ); ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=bws-sms' ) ); ?>"><?php BWS_Icons::e( 'message', 15 ); ?> <?php echo esc_html( $sms[1] ); ?></a>
					<a class="bws-chip <?php echo $tot['outstanding'] > 0 ? 'is-warn' : 'is-ok'; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=bws-ledger' ) ); ?>"><?php BWS_Icons::e( 'wallet', 15 ); ?> مطالبات: <?php echo esc_html( bws_money_text( $tot['outstanding'] ) ); ?></a>
					<a class="bws-chip" href="<?php echo esc_url( bws_visitor_panel_url() ); ?>" target="_blank"><?php BWS_Icons::e( 'external', 15 ); ?> پنل ویزیتور</a>
					<a class="bws-chip" href="<?php echo esc_url( bws_customer_panel_url() ); ?>" target="_blank"><?php BWS_Icons::e( 'external', 15 ); ?> پنل مشتری</a>
					<a class="bws-btn bws-btn-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=bws-customers&tab=new' ) ); ?>" <?php echo $spa ? 'data-spa-tab="new"' : ''; ?>><?php BWS_Icons::e( 'user-plus', 16 ); ?> ثبت مشتری جدید</a>
				</div>
			</header>
			<div class="bws-shell">
				<nav class="bws-nav" aria-label="بخش‌ها">
					<?php
					foreach ( self::sections() as $key => $s ) {
						if ( $grp !== $s[2] ) {
							$grp = $s[2];
							echo '<div class="bws-nav-group">' . esc_html( $grp ) . '</div>';
						}
						$href   = $s[3] ? admin_url( 'admin.php?page=bws-customers&tab=' . $s[3] ) : ( 'snapppay' === $key ? admin_url( 'admin.php?page=wc-settings&tab=checkout&section=bws_snapppay' ) : admin_url( 'admin.php?page=' . $key ) );
						$attr   = ( $spa && $s[3] ) ? ' data-spa-tab="' . esc_attr( $s[3] ) . '"' : '';
						$active = $cur === $key ? ' class="is-active"' : '';
						$count  = '';
						if ( 'bws-ledger' === $key && $tot['debtors'] ) {
							$count = '<em class="bws-count is-red">' . esc_html( number_format_i18n( $tot['debtors'] ) ) . '</em>';
						}
						if ( 'returns' === $key ) {
							$rp    = BWS_Returns::count_pending();
							$count = '<em class="bws-count is-red" data-returns-count' . ( $rp ? '' : ' hidden' ) . '>' . esc_html( number_format_i18n( $rp ) ) . '</em>';
						}
						echo '<a href="' . esc_url( $href ) . '"' . $active . $attr . '>' . self::ic( $s[1] ) . '<span>' . esc_html( $s[0] ) . '</span>' . $count . '</a>'; // phpcs:ignore
					}
					?>
					<div class="bws-nav-foot">لینک پنل مشتری:<br><code dir="ltr"><?php echo esc_html( wp_parse_url( bws_customer_panel_url(), PHP_URL_PATH ) ); ?></code></div>
				</nav>
				<main class="bws-main">
					<?php
					self::notice();
					$map = array(
						'bws-dashboard' => 'page_dashboard',
						'bws-customers' => 'page_customers',
						'bws-top'       => 'page_top',
						'bws-visitors'  => 'page_visitors',
						'bws-products'  => 'page_products',
						'bws-ledger'    => 'page_ledger',
						'bws-settings'  => 'page_settings',
						'bws-activity'  => 'page_activity',
					);
					if ( 'bws-sms' === $page ) {
						BWS_Admin_SMS::page();
					} elseif ( 'bws-help' === $page ) {
						BWS_Admin_Help::page();
					} else {
						call_user_func( array( __CLASS__, isset( $map[ $page ] ) ? $map[ $page ] : 'page_dashboard' ) );
					}
					?>
				</main>
			</div>
		</div>
		<?php
	}

	protected static function notice() {
		if ( ! empty( $_GET['bws_msg'] ) ) { // phpcs:ignore
			$err = ! empty( $_GET['bws_err'] ); // phpcs:ignore
			echo '<div class="bws-alert ' . ( $err ? 'bws-alert-error' : 'bws-alert-ok' ) . '">' . self::ic( $err ? 'alert' : 'check-circle' ) . '<div>' . esc_html( wp_unslash( $_GET['bws_msg'] ) ) . '</div></div>'; // phpcs:ignore
		}
	}

	protected static function back( $page, $msg, $err = false, $extra = array() ) {
		wp_safe_redirect( add_query_arg( array_merge( array( 'page' => $page, 'bws_msg' => rawurlencode( $msg ), 'bws_err' => $err ? 1 : 0 ), $extra ), admin_url( 'admin.php' ) ) );
		exit;
	}

	protected static function head( $title, $desc = '', $icon = '', $actions = '' ) {
		echo '<div class="bws-page-head"><div><h1>' . ( $icon ? self::ic( $icon, 22 ) : '' ) . esc_html( $title ) . '</h1>' . ( $desc ? '<p>' . esc_html( $desc ) . '</p>' : '' ) . '</div>'; // phpcs:ignore
		if ( $actions ) {
			echo '<div class="bws-page-actions">' . $actions . '</div>'; // phpcs:ignore
		}
		echo '</div>';
	}

	protected static function card_open( $title = '', $desc = '', $icon = '', $cls = '', $side = '' ) {
		echo '<section class="bws-card ' . esc_attr( $cls ) . '">';
		if ( $title ) {
			echo '<div class="bws-card-head"><div class="bws-card-title">' . ( $icon ? '<span class="bws-card-ic">' . self::ic( $icon ) . '</span>' : '' ) . '<div><h2>' . esc_html( $title ) . '</h2>' . ( $desc ? '<p>' . esc_html( $desc ) . '</p>' : '' ) . '</div></div>' . $side . '</div>'; // phpcs:ignore
		}
		echo '<div class="bws-card-body">';
	}

	protected static function card_close() {
		echo '</div></section>';
	}

	protected static function stat( $icon, $color, $label, $value, $sub = '', $href = '' ) {
		$tag = $href ? 'a' : 'div';
		echo '<' . $tag . ' class="bws-stat"' . ( $href ? ' href="' . esc_url( $href ) . '"' : '' ) . '><span class="bws-stat-ic is-' . esc_attr( $color ) . '">' . self::ic( $icon, 20 ) . '</span><div><small>' . esc_html( $label ) . '</small><strong>' . esc_html( $value ) . '</strong>' . ( $sub ? '<em>' . esc_html( $sub ) . '</em>' : '' ) . '</div></' . $tag . '>'; // phpcs:ignore
	}

	protected static function row( $label, $help, $control ) {
		echo '<div class="bws-row"><div class="bws-row-label"><b>' . esc_html( $label ) . '</b>' . ( $help ? '<small>' . esc_html( $help ) . '</small>' : '' ) . '</div><div class="bws-row-ctl">' . $control . '</div></div>'; // phpcs:ignore
	}

	protected static function sw( $name, $label, $checked = null ) {
		$checked = null === $checked ? bws_opt( $name ) : $checked;
		return '<label class="bws-switch"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( (bool) $checked, true, false ) . '><span></span> ' . esc_html( $label ) . '</label>';
	}

	/** Permission editor (toggles / scope selects / amount) – used for defaults and per visitor. */
	protected static function perm_controls( $values, $prefix ) {
		$h     = '';
		$group = '';
		foreach ( BWS_Perms::schema() as $k => $sc ) {
			if ( $group !== $sc[5] ) {
				$h    .= ( $group ? '</div>' : '' ) . '<div class="bws-perm-group"><h4>' . esc_html( $sc[5] ) . '</h4>';
				$group = $sc[5];
			}
			$v    = isset( $values[ $k ] ) ? $values[ $k ] : $sc[2];
			$name = $prefix . '[' . $k . ']';
			if ( 'bool' === $sc[1] ) {
				$ctl = '<label class="bws-switch"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( (bool) $v, true, false ) . '><span></span></label>';
			} elseif ( 'scope' === $sc[1] ) {
				$ctl = '<select name="' . esc_attr( $name ) . '">';
				foreach ( $sc[4] as $ok => $ol ) {
					$ctl .= '<option value="' . esc_attr( $ok ) . '" ' . selected( (string) $v, (string) $ok, false ) . '>' . esc_html( $ol ) . '</option>';
				}
				$ctl .= '</select>';
			} else {
				$ctl = '<input name="' . esc_attr( $name ) . '" dir="ltr" inputmode="numeric" value="' . esc_attr( (float) $v > 0 ? number_format( (float) $v ) : '' ) . '" placeholder="0">';
			}
			$h .= '<div class="bws-perm"><div><b>' . esc_html( $sc[0] ) . '</b><small>' . esc_html( $sc[3] ) . '</small></div><div>' . $ctl . '</div></div>';
		}
		return $h . ( $group ? '</div>' : '' );
	}

	protected static function empty_box( $text, $icon = 'inbox' ) {
		return '<div class="bws-empty">' . self::ic( $icon, 30 ) . esc_html( $text ) . '</div>';
	}

	protected static function cust_link( $id, $name ) {
		return '<a href="' . esc_url( admin_url( 'admin.php?page=bws-customers#c' . (int) $id ) ) . '">' . esc_html( $name ? $name : '#' . $id ) . '</a>';
	}

	protected static function pager( $total, $per, $page ) {
		$pages = (int) ceil( $total / $per );
		if ( $pages < 2 ) {
			return;
		}
		echo '<div class="tablenav-pages">' . paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $page, 'total' => $pages, 'prev_text' => 'قبلی', 'next_text' => 'بعدی' ) ) . '</div>'; // phpcs:ignore
	}

	/* ---------- leaderboard renderers ---------- */

	protected static function lb_hero( $r, $kind ) {
		if ( ! $r ) {
			return '';
		}
		$is_c = 'customer' === $kind;
		$sub  = $is_c ? ( $r['shop'] ? $r['shop'] . ' · ' : '' ) . bws_fa_digits( $r['orders'] ) . ' سفارش · ویزیتور: ' . $r['visitor'] : bws_fa_digits( $r['orders'] ) . ' سفارش · ' . bws_fa_digits( $r['new_customers'] ) . ' مشتری جدید · ' . bws_fa_digits( $r['buyers'] ) . ' مشتری خریدار';
		return '<div class="bws-hero ' . ( $is_c ? 'is-blue' : '' ) . '"><span class="bws-hero-ic">' . self::ic( $is_c ? 'crown' : 'trophy', 28 ) . '</span><div><small>' . ( $is_c ? 'مشتری برتر' : 'ویزیتور برتر' ) . '</small><b>' . esc_html( $r['name'] ) . '</b><span>' . esc_html( $sub ) . '</span></div><div class="bws-hero-val"><small>' . ( $is_c ? 'مجموع خرید' : 'مجموع فروش' ) . '</small><strong>' . esc_html( $r['sales_text'] ) . '</strong></div></div>';
	}

	protected static function lb_list( $rows, $kind ) {
		if ( ! $rows ) {
			return self::empty_box( 'در این بازه فروشی ثبت نشده است.', 'trophy' );
		}
		$max = max( 1, $rows[0]['sales'] );
		$h   = '<ol class="bws-lb">';
		foreach ( $rows as $r ) {
			if ( 'customer' === $kind ) {
				$name = self::cust_link( $r['id'], $r['name'] );
				$sub  = ( $r['shop'] ? $r['shop'] . ' · ' : '' ) . bws_fa_digits( $r['orders'] ) . ' سفارش · ' . bws_fa_digits( $r['qty'] ) . ' عدد · ' . $r['visitor'];
			} else {
				$name = '<a href="' . esc_url( admin_url( 'admin.php?page=bws-visitors&edit=' . $r['id'] ) ) . '">' . esc_html( $r['name'] ) . '</a>';
				$sub  = bws_fa_digits( $r['orders'] ) . ' سفارش · ' . bws_fa_digits( $r['buyers'] ) . ' خریدار · ' . bws_fa_digits( $r['new_customers'] ) . ' مشتری جدید';
			}
			$h .= '<li><span class="bws-rank r' . (int) $r['rank'] . '">' . esc_html( bws_fa_digits( $r['rank'] ) ) . '</span><div class="bws-lb-main"><b>' . $name . '</b><small>' . esc_html( $sub ) . '</small><div class="bws-lb-bar"><i style="width:' . max( 4, round( $r['sales'] / $max * 100 ) ) . '%"></i></div></div><div class="bws-lb-val"><b>' . esc_html( $r['sales_text'] ) . '</b>' . ( ! empty( $r['debt_text'] ) ? '<small class="bws-red">بدهی ' . esc_html( $r['debt_text'] ) . '</small>' : '' ) . '</div></li>';
		}
		return $h . '</ol>';
	}

	protected static function period_seg( $period, $page ) {
		$h = '<div class="bws-seg">';
		foreach ( BWS_Stats::$periods as $k => $l ) {
			$h .= '<a class="' . ( (string) $k === (string) $period ? 'is-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . $page . '&period=' . $k ) ) . '">' . esc_html( $l ) . '</a>';
		}
		return $h . '</div>';
	}

	/* ================= Dashboard ================= */

	public static function page_dashboard() {
		global $wpdb;
		$ct     = BWS_Customers::table();
		$ot     = BWS_Orders::table();
		$tot    = BWS_Ledger::totals();
		$cust   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ct" );
		$m30    = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - 30 * DAY_IN_SECONDS );
		$new30  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ct WHERE created_at >= %s", $m30 ) );
		$s_all  = BWS_Orders::stats();
		$s_30   = BWS_Orders::stats( 0, $m30 );
		$vis    = BWS_Auth::visitors();
		$paid30 = (float) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(-amount),0) FROM ' . BWS_Ledger::table() . " WHERE type='payment' AND created_at >= %s", $m30 ) );
		$period = isset( $_GET['period'] ) ? BWS_Stats::period_key( sanitize_key( $_GET['period'] ) ) : 'month'; // phpcs:ignore
		$tv     = BWS_Stats::top_visitors( $period, 5 );
		$tc     = BWS_Stats::top_customers( $period, 5 );

		self::head( 'داشبورد', 'وضعیت کلی فروش عمده، ویزیتورها و اعتبار مشتریان', 'dashboard', '<a class="bws-btn" href="' . esc_url( admin_url( 'admin.php?page=bws-customers&tab=sms' ) ) . '">' . self::ic( 'send', 16 ) . ' ارسال لینک ورود به همه</a>' );

		$checks = array(
			array( (bool) get_option( 'bws_last_sync' ), 'بارگذاری محصولات از ووکامرس', 'bws-products' ),
			array( bws_opt( 'sms_enabled' ) && ! bws_opt( 'sms_test_mode' ), 'اتصال پنل پیامک و خاموش کردن حالت تست', 'bws-sms' ),
			array( count( $vis ) > 0, 'تعریف ویزیتورها', 'bws-visitors' ),
			array( $cust > 0, 'ثبت اولین مشتری عمده', 'bws-customers&tab=new' ),
		);
		$done = count( array_filter( wp_list_pluck( $checks, 0 ) ) );
		if ( $done < count( $checks ) ) {
			self::card_open( 'راه‌اندازی سیستم', sprintf( '%s از %s مرحله انجام شده', bws_fa_digits( $done ), bws_fa_digits( count( $checks ) ) ), 'zap' );
			echo '<div class="bws-progress"><div class="bws-bar-track"><span style="width:' . (int) round( $done / count( $checks ) * 100 ) . '%"></span></div></div><div class="bws-actions">';
			foreach ( $checks as $c ) {
				echo '<a class="bws-btn bws-btn-sm ' . ( $c[0] ? 'bws-btn-ghost' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . $c[2] ) ) . '">' . self::ic( $c[0] ? 'check-circle' : 'alert', 15 ) . ' ' . esc_html( $c[1] ) . '</a>'; // phpcs:ignore
			}
			echo '</div>';
			self::card_close();
		}

		echo '<div class="bws-stats">';
		self::stat( 'users', 'violet', 'مشتریان عمده', number_format_i18n( $cust ), 'جدید در ۳۰ روز: ' . number_format_i18n( $new30 ), admin_url( 'admin.php?page=bws-customers' ) );
		self::stat( 'trending', 'green', 'فروش عمده ۳۰ روز', bws_money_text( $s_30->total ), number_format_i18n( $s_30->cnt ) . ' سفارش · ' . number_format_i18n( $s_30->qty ) . ' عدد', admin_url( 'admin.php?page=bws-customers&tab=orders' ) );
		self::stat( 'wallet', 'amber', 'مطالبات (اعتبار مصرف‌شده)', bws_money_text( $tot['outstanding'] ), number_format_i18n( $tot['debtors'] ) . ' مشتری بدهکار', admin_url( 'admin.php?page=bws-ledger' ) );
		self::stat( 'cash', 'blue', 'وصولی ۳۰ روز', bws_money_text( $paid30 ), 'پرداخت‌های ثبت‌شده', admin_url( 'admin.php?page=bws-ledger&type=payment' ) );
		echo '</div>';

		echo '<div class="bws-grid bws-grid-2-1"><div>';
		// Chart.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT DATE_FORMAT(created_at, '%%Y-%%m') m, SUM(total) t, COUNT(*) c FROM $ot WHERE kind='order' AND status NOT IN ('cancelled','refunded','failed') AND created_at >= %s GROUP BY m ORDER BY m", gmdate( 'Y-m-01 00:00:00', strtotime( '-5 months', current_time( 'timestamp' ) ) ) ) );
		self::card_open( 'فروش ماهانه', 'مجموع مبلغ سفارش‌های عمده در ۶ ماه اخیر', 'activity' );
		if ( $rows ) {
			$max = max( array_map( function ( $r ) { return (float) $r->t; }, $rows ) );
			echo '<div class="bws-chart">';
			foreach ( $rows as $r ) {
				list( $jy, $jm ) = bws_g2j( (int) substr( $r->m, 0, 4 ), (int) substr( $r->m, 5, 2 ), 15 );
				$h = $max > 0 ? max( 3, round( (float) $r->t / $max * 100 ) ) : 0;
				echo '<div class="bws-bar" title="' . esc_attr( bws_money_text( $r->t ) . ' — ' . $r->c . ' سفارش' ) . '"><b>' . esc_html( number_format( $r->t / 1000000, 1 ) ) . 'M</b><i style="height:' . (int) $h . '%"></i><span>' . esc_html( bws_fa_digits( $jy . '/' . $jm ) ) . '</span></div>';
			}
			echo '</div>';
		} else {
			echo self::empty_box( 'هنوز سفارشی ثبت نشده است.', 'activity' ); // phpcs:ignore
		}
		echo '<div class="bws-mini-stats"><div><small>کل فروش عمده</small><b>' . esc_html( bws_money_text( $s_all->total ) ) . '</b></div><div><small>کل سفارش‌ها</small><b>' . esc_html( number_format_i18n( $s_all->cnt ) ) . '</b></div><div><small>ویزیتورها</small><b>' . esc_html( number_format_i18n( count( $vis ) ) ) . '</b></div><div><small>مصرف سقف اعتبار</small><b>' . esc_html( $tot['limit_total'] > 0 ? bws_fa_digits( round( $tot['outstanding'] / $tot['limit_total'] * 100 ) ) . '٪' : '—' ) . '</b></div></div>';
		self::card_close();

		// Recent orders.
		$recent = BWS_Orders::query( array( 'kind' => 'order', 'per_page' => 8 ) );
		$tpl    = BWS_Frontend::admin_order_url_tpl();
		self::card_open( 'آخرین سفارش‌های عمده', '', 'package', 'bws-card-flush', '<a class="bws-btn bws-btn-sm" style="margin:0 0 0 0" href="' . esc_url( admin_url( 'admin.php?page=bws-customers&tab=orders' ) ) . '">همه سفارش‌ها</a>' );
		echo '<div class="bws-table-wrap" style="margin-top:12px"><table class="bws-table"><thead><tr><th>#</th><th>مشتری</th><th>ویزیتور</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th></tr></thead><tbody>';
		foreach ( $recent['items'] as $o ) {
			echo '<tr><td><a href="' . esc_url( str_replace( '__ID__', $o->order_id, $tpl ) ) . '">' . (int) $o->order_id . '</a></td><td>' . self::cust_link( $o->customer_id, trim( $o->first_name . ' ' . $o->last_name ) ) . '</td><td>' . esc_html( bws_user_name( $o->visitor_id ) ) . '</td><td><b>' . esc_html( bws_money_text( $o->total ) ) . '</b></td><td><span class="bws-badge bws-st-' . esc_attr( $o->status ) . '">' . esc_html( BWS_Orders::status_label( $o->status ) ) . '</span></td><td>' . esc_html( bws_jdate( $o->created_at ) ) . '</td></tr>'; // phpcs:ignore
		}
		if ( ! $recent['items'] ) {
			echo '<tr><td colspan="6">' . self::empty_box( 'سفارشی ثبت نشده است.', 'package' ) . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table></div>';
		self::card_close();
		echo '</div><div>';

		$seg = self::period_seg( $period, 'bws-dashboard' );
		self::card_open( 'ویزیتور برتر', BWS_Stats::$periods[ $period ], 'trophy', '', '' );
		echo '<div style="margin-bottom:12px">' . $seg . '</div>'; // phpcs:ignore
		echo self::lb_hero( $tv ? $tv[0] : null, 'visitor' ) . self::lb_list( $tv, 'visitor' ); // phpcs:ignore
		self::card_close();
		self::card_open( 'مشتری برتر', BWS_Stats::$periods[ $period ], 'crown' );
		echo self::lb_hero( $tc ? $tc[0] : null, 'customer' ) . self::lb_list( $tc, 'customer' ); // phpcs:ignore
		echo '<a class="bws-btn bws-btn-sm bws-btn-block" style="margin-top:12px" href="' . esc_url( admin_url( 'admin.php?page=bws-top&period=' . $period ) ) . '">' . self::ic( 'trophy', 15 ) . ' رتبه‌بندی کامل</a>'; // phpcs:ignore
		self::card_close();

		$debtors = BWS_Customers::query( array( 'debt' => 1, 'orderby' => 'balance', 'per_page' => 6 ) );
		self::card_open( 'بیشترین بدهی', 'اعتبار مصرف‌شده در انتظار تسویه', 'alert' );
		if ( $debtors['items'] ) {
			echo '<ol class="bws-lb">';
			foreach ( $debtors['items'] as $c ) {
				echo '<li><span class="bws-avatar" style="width:32px;height:32px;font-size:13px;border-radius:9px">' . esc_html( mb_substr( $c->first_name ? $c->first_name : '؟', 0, 1 ) ) . '</span><div class="bws-lb-main"><b>' . self::cust_link( $c->id, BWS_Customers::full_name( $c ) ) . '</b><small>از ' . esc_html( bws_jdate( BWS_Ledger::oldest_unpaid_date( $c->id ), false ) ) . ' · سقف ' . esc_html( bws_money_text( $c->credit_limit ) ) . '</small></div><div class="bws-lb-val"><b class="bws-red">' . esc_html( bws_money_text( $c->balance ) ) . '</b></div></li>'; // phpcs:ignore
			}
			echo '</ol>';
		} else {
			echo self::empty_box( 'بدهکاری وجود ندارد.', 'check-circle' ); // phpcs:ignore
		}
		self::card_close();
		echo '</div></div>';
	}

	/* ================= Customers (SPA) ================= */

	public static function page_customers() {
		$exp = wp_nonce_url( admin_url( 'admin-post.php?action=bws_export&what=customers' ), 'bws_export' );
		?>
		<div class="bws-actions" style="margin-top:0;justify-content:flex-end">
			<a class="bws-btn bws-btn-sm" href="<?php echo esc_url( $exp ); ?>"><?php BWS_Icons::e( 'download', 15 ); ?> خروجی Excel (CSV)</a>
			<button type="button" class="bws-btn bws-btn-sm" onclick="document.getElementById('bws-import').hidden=!document.getElementById('bws-import').hidden"><?php BWS_Icons::e( 'upload', 15 ); ?> ورود گروهی از CSV</button>
		</div>
		<div id="bws-import" hidden>
			<?php self::card_open( 'ورود گروهی مشتریان از فایل CSV', 'ردیف اول عنوان است؛ فایل را با کدگذاری UTF-8 ذخیره کنید. شماره‌های تکراری رد می‌شوند.', 'upload' ); ?>
			<p class="bws-muted">ترتیب ستون‌ها: <code dir="ltr">first_name, last_name, mobile, shop_name, province, city, address, phone, credit_limit, visitor_username</code></p>
			<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bws-inline">
				<input type="hidden" name="action" value="bws_import"><?php wp_nonce_field( 'bws_import' ); ?>
				<input type="file" name="file" accept=".csv,text/csv" required>
				<label class="bws-switch"><input type="checkbox" name="send_sms" value="1"><span></span> ارسال پیامک خوش‌آمد</label>
				<button class="bws-btn bws-btn-primary"><?php BWS_Icons::e( 'upload', 16 ); ?> بارگذاری</button>
			</form>
			<?php self::card_close(); ?>
		</div>
		<div id="bws-app" class="bws-app bws-in-admin" dir="rtl"><div class="bws-loading"><span class="bws-spinner"></span> در حال بارگذاری…</div></div>
		<?php
	}

	/* ================= Top performers ================= */

	public static function page_top() {
		global $wpdb;
		$period = isset( $_GET['period'] ) ? BWS_Stats::period_key( sanitize_key( $_GET['period'] ) ) : 'month'; // phpcs:ignore
		$tv     = BWS_Stats::top_visitors( $period, 20 );
		$tc     = BWS_Stats::top_customers( $period, 20 );
		self::head( 'برترین‌ها', 'رتبه‌بندی ویزیتورها و مشتریان بر اساس مبلغ خرید — ' . BWS_Stats::$periods[ $period ], 'trophy', self::period_seg( $period, 'bws-top' ) );
		echo '<div class="bws-grid bws-grid-2"><div>';
		self::card_open( 'ویزیتورهای برتر', 'مجموع مبلغ سفارش‌های مشتریان هر ویزیتور', 'trophy' );
		echo self::lb_hero( $tv ? $tv[0] : null, 'visitor' ) . self::lb_list( $tv, 'visitor' ); // phpcs:ignore
		self::card_close();
		echo '</div><div>';
		self::card_open( 'مشتریان برتر', 'بیشترین مبلغ خرید عمده', 'crown' );
		echo self::lb_hero( $tc ? $tc[0] : null, 'customer' ) . self::lb_list( $tc, 'customer' ); // phpcs:ignore
		self::card_close();
		echo '</div></div>';

		// Full visitor performance table.
		$from = BWS_Stats::from( $period );
		$ct   = BWS_Customers::table();
		$byid = array();
		foreach ( BWS_Stats::top_visitors( $period, 1000 ) as $v ) {
			$byid[ $v['id'] ] = $v;
		}
		self::card_open( 'عملکرد همه ویزیتورها', BWS_Stats::$periods[ $period ], 'users', 'bws-card-flush' );
		echo '<div class="bws-table-wrap" style="margin-top:12px"><table class="bws-table"><thead><tr><th>رتبه</th><th>ویزیتور</th><th>منطقه</th><th>مشتری جدید</th><th>کل مشتریان</th><th>سفارش</th><th>تعداد اقلام</th><th>فروش</th><th>مطالبات فعلی</th></tr></thead><tbody>';
		$vis = BWS_Auth::visitors();
		usort( $vis, function ( $a, $b ) use ( $byid ) {
			$sa = isset( $byid[ $a->ID ] ) ? $byid[ $a->ID ]['sales'] : 0;
			$sb = isset( $byid[ $b->ID ] ) ? $byid[ $b->ID ]['sales'] : 0;
			return $sb <=> $sa;
		} );
		foreach ( $vis as $v ) {
			$d     = isset( $byid[ $v->ID ] ) ? $byid[ $v->ID ] : null;
			$all   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ct WHERE visitor_id=%d", $v->ID ) );
			$new   = $from ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ct WHERE visitor_id=%d AND created_at >= %s", $v->ID, $from ) ) : $all;
			$debt  = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(balance),0) FROM $ct WHERE visitor_id=%d AND balance>0", $v->ID ) );
			$rank  = $d ? '<span class="bws-rank r' . (int) $d['rank'] . '">' . esc_html( bws_fa_digits( $d['rank'] ) ) . '</span>' : '<span class="bws-rank">–</span>';
			echo '<tr><td>' . $rank . '</td><td><a href="' . esc_url( admin_url( 'admin.php?page=bws-visitors&edit=' . $v->ID ) ) . '"><b>' . esc_html( $v->display_name ) . '</b></a>' . ( bws_visitor_active( $v->ID ) ? '' : ' <span class="bws-badge bws-st-inactive">غیرفعال</span>' ) . '</td><td>' . esc_html( get_user_meta( $v->ID, 'bws_region', true ) ) . '</td><td>' . esc_html( number_format_i18n( $new ) ) . '</td><td>' . esc_html( number_format_i18n( $all ) ) . '</td><td>' . esc_html( number_format_i18n( $d ? $d['orders'] : 0 ) ) . '</td><td>' . esc_html( number_format_i18n( $d ? $d['qty'] : 0 ) ) . '</td><td><b>' . esc_html( bws_money_text( $d ? $d['sales'] : 0 ) ) . '</b></td><td class="' . ( $debt > 0 ? 'bws-red' : '' ) . '">' . esc_html( bws_money_text( $debt ) ) . '</td></tr>'; // phpcs:ignore
		}
		if ( ! $vis ) {
			echo '<tr><td colspan="9">' . self::empty_box( 'ویزیتوری تعریف نشده است.', 'user' ) . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table></div>';
		self::card_close();
	}

	/* ================= Visitors ================= */

	public static function page_visitors() {
		global $wpdb;
		$edit = isset( $_GET['edit'] ) ? (int) $_GET['edit'] : 0; // phpcs:ignore
		$user = $edit ? get_userdata( $edit ) : null;
		$ct   = BWS_Customers::table();
		$m    = function ( $k ) use ( $user ) {
			return $user ? get_user_meta( $user->ID, 'bws_' . $k, true ) : '';
		};
		self::head( 'ویزیتورها', 'تعریف حساب ویزیتورها؛ هر ویزیتور با نام کاربری و رمز خودش وارد پنل ویزیتور می‌شود.', 'user', $edit ? '<a class="bws-btn bws-btn-primary" href="' . esc_url( admin_url( 'admin.php?page=bws-visitors' ) ) . '">' . self::ic( 'plus', 16 ) . ' ویزیتور جدید</a>' : '' );
		echo '<div class="bws-grid bws-grid-2"><div>';

		self::card_open( 'لیست ویزیتورها', 'لینک ورود: ' . bws_visitor_panel_url(), 'users', 'bws-card-flush' );
		echo '<div class="bws-table-wrap" style="margin-top:12px"><table class="bws-table"><thead><tr><th>ویزیتور</th><th>نام کاربری</th><th>موبایل</th><th>مشتریان</th><th>مطالبات</th><th>وضعیت</th><th></th></tr></thead><tbody>';
		$vis = BWS_Auth::visitors();
		foreach ( $vis as $v ) {
			$cnt  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ct WHERE visitor_id=%d", $v->ID ) );
			$debt = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(balance),0) FROM $ct WHERE visitor_id=%d AND balance>0", $v->ID ) );
			$act  = bws_visitor_active( $v->ID );
			echo '<tr' . ( $edit === $v->ID ? ' style="background:var(--bws-primary-50)"' : '' ) . '><td><b>' . esc_html( $v->display_name ) . '</b><br><small class="bws-muted">' . esc_html( get_user_meta( $v->ID, 'bws_region', true ) ) . '</small></td><td dir="ltr">' . esc_html( $v->user_login ) . '</td><td dir="ltr">' . esc_html( get_user_meta( $v->ID, 'bws_mobile', true ) ) . '</td><td>' . esc_html( number_format_i18n( $cnt ) ) . '</td><td class="' . ( $debt > 0 ? 'bws-red' : '' ) . '">' . esc_html( bws_money_text( $debt ) ) . '</td><td><span class="bws-badge bws-st-' . ( $act ? 'active' : 'inactive' ) . '">' . ( $act ? 'فعال' : 'غیرفعال' ) . '</span></td><td><a class="bws-btn bws-btn-sm" href="' . esc_url( admin_url( 'admin.php?page=bws-visitors&edit=' . $v->ID ) ) . '">' . self::ic( 'edit', 14 ) . ' ویرایش</a></td></tr>'; // phpcs:ignore
		}
		if ( ! $vis ) {
			echo '<tr><td colspan="7">' . self::empty_box( 'هنوز ویزیتوری ثبت نشده است. از فرم کنار، اولین ویزیتور را بسازید.', 'user-plus' ) . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table></div>';
		self::card_close();

		if ( $user ) {
			self::card_open( 'آخرین فعالیت‌های ' . $user->display_name, '', 'activity', 'bws-card-flush' );
			echo '<div style="margin-top:12px">';
			self::activity_table( BWS_Log::query( array( 'user_id' => $user->ID, 'limit' => 20 ) ) );
			echo '</div>';
			self::card_close();
		}
		echo '</div><div>';

		self::card_open( $user ? 'ویرایش: ' . $user->display_name : 'افزودن ویزیتور جدید', $user ? '' : 'اطلاعات ورود را می‌توانید برای موبایل ویزیتور پیامک کنید', $user ? 'edit' : 'user-plus' );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" autocomplete="off">
			<input type="hidden" name="action" value="bws_save_visitor"><input type="hidden" name="user_id" value="<?php echo (int) $edit; ?>">
			<?php wp_nonce_field( 'bws_visitor' ); ?>
			<?php if ( $user ) : ?>
				<label class="bws-field"><span>نام کاربری</span><input value="<?php echo esc_attr( $user->user_login ); ?>" dir="ltr" disabled></label>
			<?php else : ?>
				<label class="bws-field"><span>نام کاربری *</span><input name="username" dir="ltr" required autocomplete="off"><small>حروف انگلیسی یا عدد</small></label>
			<?php endif; ?>
			<label class="bws-field"><span>رمز عبور <?php echo $user ? '(برای تغییر وارد کنید)' : '*'; ?></span><input name="password" type="text" dir="ltr" autocomplete="new-password" <?php echo $user ? '' : 'required'; ?> value="<?php echo $user ? '' : esc_attr( wp_generate_password( 8, false ) ); ?>"></label>
			<div class="bws-form-grid">
				<label class="bws-field"><span>نام *</span><input name="first_name" required value="<?php echo esc_attr( $user ? $user->first_name : '' ); ?>"></label>
				<label class="bws-field"><span>نام خانوادگی *</span><input name="last_name" required value="<?php echo esc_attr( $user ? $user->last_name : '' ); ?>"></label>
				<label class="bws-field"><span>موبایل</span><input name="mobile" dir="ltr" value="<?php echo esc_attr( $m( 'mobile' ) ); ?>"></label>
				<label class="bws-field"><span>منطقه / مسیر</span><input name="region" value="<?php echo esc_attr( $m( 'region' ) ); ?>"></label>
				<label class="bws-field"><span>کد ملی</span><input name="national_id" dir="ltr" value="<?php echo esc_attr( $m( 'national_id' ) ); ?>"></label>
				<label class="bws-field"><span>ایمیل (اختیاری)</span><input name="email" type="email" dir="ltr" value="<?php echo esc_attr( $user ? $user->user_email : '' ); ?>"></label>
			</div>
			<label class="bws-field"><span>یادداشت</span><input name="note" value="<?php echo esc_attr( $m( 'note' ) ); ?>"></label>
			<div class="bws-form-grid">
				<label class="bws-field"><span>هدف فروش ماهانه (<?php echo esc_html( trim( str_replace( '0', '', bws_money_text( 0 ) ) ) ); ?>)</span><input name="target" dir="ltr" inputmode="numeric" value="<?php echo esc_attr( $m( 'target' ) ? number_format( (float) $m( 'target' ) ) : '' ); ?>" placeholder="<?php echo esc_attr( bws_opt( 'visitor_default_target' ) ? number_format( (float) bws_opt( 'visitor_default_target' ) ) : 'بدون هدف' ); ?>"></label>
				<label class="bws-field"><span>پورسانت از فروش (٪)</span><input name="commission" dir="ltr" inputmode="decimal" value="<?php echo esc_attr( $m( 'commission' ) ); ?>" placeholder="0"></label>
			</div>
			<?php echo self::sw( 'active', 'فعال (اجازه ورود به پنل)', ! $user || bws_visitor_active( $user->ID ) ); // phpcs:ignore ?><br>
			<?php if ( ! $user ) { echo self::sw( 'send_sms', 'نام کاربری، رمز و لینک پنل برای ویزیتور پیامک شود', true ); } // phpcs:ignore ?>
			<?php $pm = $user && 'custom' === get_user_meta( $user->ID, 'bws_perm_mode', true ) ? 'custom' : 'inherit'; ?>
			<div class="bws-perm-box">
				<h3><?php BWS_Icons::e( 'shield', 18 ); ?> دسترسی‌های این ویزیتور</h3>
				<div class="bws-seg bws-perm-mode"><label><input type="radio" name="perm_mode" value="inherit" <?php checked( $pm, 'inherit' ); ?>> طبق دسترسی پیش‌فرض</label><label><input type="radio" name="perm_mode" value="custom" <?php checked( $pm, 'custom' ); ?>> اختصاصی</label></div>
				<p class="bws-muted">دسترسی پیش‌فرض همه ویزیتورها: <a href="<?php echo esc_url( admin_url( 'admin.php?page=bws-settings&tab=visitors' ) ); ?>">تنظیمات ← دسترسی ویزیتورها</a></p>
				<div class="bws-perm-custom" <?php echo 'custom' === $pm ? '' : 'hidden'; ?>>
					<?php echo self::perm_controls( $user && 'custom' === $pm ? BWS_Perms::for_user( $user->ID ) : BWS_Perms::defaults(), 'perms' ); // phpcs:ignore ?>
				</div>
			</div>
			<div class="bws-actions"><button class="bws-btn bws-btn-primary bws-btn-lg bws-btn-block"><?php BWS_Icons::e( 'save', 17 ); ?> <?php echo $user ? 'ذخیره تغییرات' : 'ایجاد ویزیتور'; ?></button></div>
		</form>
		<?php
		self::card_close();
		if ( $user ) {
			$ps = BWS_Stats::visitor_period( $user->ID, 'month' );
			$tg = (float) $m( 'target' ) > 0 ? (float) $m( 'target' ) : (float) bws_opt( 'visitor_default_target' );
			$cm = (float) $m( 'commission' );
			self::card_open( 'عملکرد این ماه', '', 'target' );
			echo '<div class="bws-kv"><div><span>فروش</span><b>' . esc_html( bws_money_text( $ps['sales'] ) ) . '</b></div><div><span>سفارش</span><b>' . esc_html( number_format_i18n( $ps['orders'] ) ) . '</b></div>' . ( $tg ? '<div><span>تحقق هدف</span><b>' . esc_html( bws_fa_digits( min( 999, round( $ps['sales'] / $tg * 100 ) ) ) ) . '٪</b></div>' : '' ) . ( $cm ? '<div><span>پورسانت (' . esc_html( bws_fa_digits( $cm ) ) . '٪)</span><b class="bws-green">' . esc_html( bws_money_text( $ps['sales'] * $cm / 100 ) ) . '</b></div>' : '' ) . '</div>';
			self::card_close();
		}
		echo '</div></div>';
	}

	/* ================= Products ================= */

	public static function page_products() {
		$rows = BWS_Products::rows( false );
		$last = get_option( 'bws_last_sync' );
		self::head( 'محصولات و قیمت عمده', 'محصولات ووکامرس را بارگذاری کنید و برای پنل همکاران قیمت عمده تعیین کنید. قیمت مصرف‌کننده همیشه زنده از ووکامرس خوانده می‌شود.', 'package', '<button type="button" class="bws-btn bws-btn-primary" id="bws-sync">' . self::ic( 'refresh', 16 ) . ' بارگذاری همه محصولات از ووکامرس</button>' );
		echo '<div class="bws-grid bws-grid-3">';
		self::stat( 'package', 'violet', 'محصولات در پنل عمده', number_format_i18n( count( array_filter( wp_list_pluck( $rows, 'enabled' ) ) ) ), 'از ' . number_format_i18n( count( $rows ) ) . ' محصول بارگذاری‌شده' );
		self::stat( 'target', 'green', 'تخفیف عمده پیش‌فرض', bws_fa_digits( (float) bws_opt( 'discount_percent' ) ) . '٪', 'قابل تغییر برای هر محصول' );
		self::stat( 'clock', 'blue', 'آخرین بارگذاری', $last ? bws_jdate( $last ) : 'هرگز', '' );
		echo '</div>';

		self::card_open( 'تنظیم سریع قیمت', '', 'zap' );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bws-inline">
			<input type="hidden" name="action" value="bws_save_settings"><input type="hidden" name="tab" value="pricing_quick"><?php wp_nonce_field( 'bws_settings' ); ?>
			<span>تخفیف پیش‌فرض همه محصولات</span><input type="number" step="0.5" min="0" max="100" name="discount_percent" value="<?php echo esc_attr( bws_opt( 'discount_percent' ) ); ?>" class="bws-num"><span class="bws-suffix">٪</span>
			<span style="margin-right:14px">حداقل تعداد سفارش</span><input type="number" min="1" name="min_qty" value="<?php echo esc_attr( bws_opt( 'min_qty' ) ); ?>" class="bws-num"><span class="bws-suffix">عدد</span>
			<button class="bws-btn"><?php BWS_Icons::e( 'save', 16 ); ?> ذخیره</button>
		</form>
		<?php
		self::card_close();

		self::card_open( 'لیست محصولات', 'درصد اختصاصی یا قیمت ثابت را خالی بگذارید تا تخفیف پیش‌فرض اعمال شود. تغییرات خودکار ذخیره می‌شوند.', 'list', 'bws-card-flush', '<div class="bws-searchbox" style="max-width:260px">' . self::ic( 'search', 16 ) . '<input type="search" id="bws-psearch" placeholder="جستجوی محصول…"></div>' );
		echo '<div class="bws-table-wrap" style="margin-top:12px"><table class="bws-table bws-ptable"><thead><tr><th>فعال</th><th></th><th>محصول</th><th>قیمت مصرف‌کننده</th><th>تخفیف اختصاصی ٪</th><th>قیمت عمده ثابت</th><th>قیمت عمده نهایی</th><th>موجودی</th><th>ترتیب</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="9">' . self::empty_box( 'هنوز محصولی بارگذاری نشده است. دکمه «بارگذاری همه محصولات» را بزنید.', 'package' ) . '</td></tr>'; // phpcs:ignore
		}
		foreach ( $rows as $pid => $r ) {
			$p = function_exists( 'wc_get_product' ) ? wc_get_product( $pid ) : null;
			if ( ! $p ) {
				continue;
			}
			$img_id = $p->get_image_id();
			if ( ! $img_id && $r->parent_id ) {
				$pp     = wc_get_product( $r->parent_id );
				$img_id = $pp ? $pp->get_image_id() : 0;
			}
			$img = $img_id ? wp_get_attachment_image_url( $img_id, 'thumbnail' ) : wc_placeholder_img_src( 'thumbnail' );
			?>
			<tr data-pid="<?php echo (int) $pid; ?>" data-name="<?php echo esc_attr( mb_strtolower( BWS_Products::display_name( $p ) . ' ' . $p->get_sku() ) ); ?>">
				<td><label class="bws-switch"><input type="checkbox" data-k="enabled" <?php checked( $r->enabled ); ?>><span></span></label></td>
				<td><img class="bws-thumb" src="<?php echo esc_url( $img ); ?>" alt=""></td>
				<td><a href="<?php echo esc_url( get_edit_post_link( $r->parent_id ? $r->parent_id : $pid ) ); ?>" target="_blank"><b><?php echo esc_html( BWS_Products::display_name( $p ) ); ?></b></a><?php echo $p->get_sku() ? '<br><small class="bws-muted">' . esc_html( $p->get_sku() ) . '</small>' : ''; ?></td>
				<td><?php echo esc_html( bws_money_text( BWS_Products::retail_price( $p ) ) ); ?></td>
				<td><input type="text" data-k="discount_percent" value="<?php echo null !== $r->discount_percent ? esc_attr( (float) $r->discount_percent ) : ''; ?>" placeholder="<?php echo esc_attr( bws_opt( 'discount_percent' ) ); ?>" style="width:80px" dir="ltr"></td>
				<td><input type="text" data-k="fixed_price" value="<?php echo null !== $r->fixed_price ? esc_attr( (float) $r->fixed_price ) : ''; ?>" style="width:120px" dir="ltr"></td>
				<td class="bws-wprice"><b style="color:var(--bws-primary)"><?php echo esc_html( bws_money_text( BWS_Products::wholesale_price( $p, $r ) ) ); ?></b></td>
				<td><?php echo $p->managing_stock() ? esc_html( number_format_i18n( (int) $p->get_stock_quantity() ) ) : ( $p->is_in_stock() ? '<span class="bws-badge bws-st-active">موجود</span>' : '<span class="bws-badge bws-st-inactive">ناموجود</span>' ); ?></td>
				<td><input type="number" data-k="sort_order" value="<?php echo (int) $r->sort_order; ?>" style="width:70px"></td>
			</tr>
			<?php
		}
		echo '</tbody></table></div>';
		self::card_close();
	}

	/* ================= Ledger ================= */

	public static function page_ledger() {
		$type = isset( $_GET['type'] ) ? sanitize_key( $_GET['type'] ) : ''; // phpcs:ignore
		$vis  = isset( $_GET['visitor'] ) ? (int) $_GET['visitor'] : 0; // phpcs:ignore
		$page = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore
		$res  = BWS_Ledger::entries( array( 'type' => $type, 'visitor_id' => $vis, 'page' => $page, 'per_page' => 50 ) );
		$exp  = wp_nonce_url( admin_url( 'admin-post.php?action=bws_export&what=ledger' ), 'bws_export' );
		$tot  = BWS_Ledger::totals();
		self::head( 'دفتر اعتبار و پرداخت‌ها', 'همه خریدهای اعتباری، پرداخت‌ها، برگشت‌ها و اصلاحیه‌ها', 'wallet', '<a class="bws-btn" href="' . esc_url( $exp ) . '">' . self::ic( 'download', 16 ) . ' خروجی CSV</a>' );
		echo '<div class="bws-grid bws-grid-3">';
		self::stat( 'wallet', 'amber', 'کل مطالبات', bws_money_text( $tot['outstanding'] ), number_format_i18n( $tot['debtors'] ) . ' مشتری بدهکار' );
		self::stat( 'shield', 'blue', 'جمع سقف اعتبار فعال', bws_money_text( $tot['limit_total'] ), '' );
		self::stat( 'trending', 'green', 'آزاد (قابل خرید)', bws_money_text( max( 0, $tot['limit_total'] - $tot['outstanding'] ) ), '' );
		echo '</div>';
		$tpl = BWS_Frontend::admin_order_url_tpl();
		ob_start();
		echo '<form method="get" class="bws-inline"><input type="hidden" name="page" value="bws-ledger"><select name="type" class="bws-w-auto"><option value="">همه نوع‌ها</option>';
		foreach ( BWS_Ledger::$types as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '" ' . selected( $type, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select><select name="visitor" class="bws-w-auto"><option value="0">همه ویزیتورها</option>';
		foreach ( BWS_Auth::visitors() as $v ) {
			echo '<option value="' . (int) $v->ID . '" ' . selected( $vis, $v->ID, false ) . '>' . esc_html( $v->display_name ) . '</option>';
		}
		echo '</select><button class="bws-btn bws-btn-sm">' . self::ic( 'filter', 15 ) . ' فیلتر</button></form>'; // phpcs:ignore
		$side = ob_get_clean();
		self::card_open( 'گردش حساب', number_format_i18n( $res['total'] ) . ' ردیف', 'receipt', 'bws-card-flush', $side );
		echo '<div class="bws-table-wrap" style="margin-top:12px"><table class="bws-table"><thead><tr><th>تاریخ</th><th>مشتری</th><th>نوع</th><th>بدهکار</th><th>بستانکار</th><th>مانده</th><th>روش / پیگیری</th><th>سفارش</th><th>توضیح</th><th>ثبت توسط</th></tr></thead><tbody>';
		foreach ( $res['items'] as $e ) {
			$a = BWS_Ledger::entry_to_array( $e );
			echo '<tr><td>' . esc_html( $a['date'] ) . '</td><td>' . self::cust_link( $e->customer_id, trim( $e->first_name . ' ' . $e->last_name ) ) . '<br><small class="bws-muted" dir="ltr">' . esc_html( $e->code ) . '</small></td><td><span class="bws-badge">' . esc_html( $a['type_label'] ) . '</span></td><td class="bws-red">' . ( 'debit' === $a['direction'] ? esc_html( $a['amount_text'] ) : '' ) . '</td><td class="bws-green">' . ( 'credit' === $a['direction'] ? esc_html( $a['amount_text'] ) : '' ) . '</td><td><b>' . esc_html( $a['balance_text'] ) . '</b></td><td>' . esc_html( trim( $a['method'] . ' ' . $a['reference'] ) ) . '</td><td>' . ( $e->order_id ? '<a href="' . esc_url( str_replace( '__ID__', $e->order_id, $tpl ) ) . '">#' . (int) $e->order_id . '</a>' : '' ) . '</td><td>' . esc_html( $a['note'] ) . '</td><td>' . esc_html( $a['by'] ) . '</td></tr>'; // phpcs:ignore
		}
		if ( ! $res['items'] ) {
			echo '<tr><td colspan="10">' . self::empty_box( 'موردی ثبت نشده است.', 'receipt' ) . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table></div>';
		self::pager( $res['total'], 50, $page );
		self::card_close();
	}

	/* ================= Settings ================= */

	public static function settings_tabs() {
		return array(
			'general'    => array( 'قیمت و سفارش', 'target' ),
			'credit'     => array( 'اعتبار و پرداخت', 'wallet' ),
			'login'      => array( 'کد و ورود', 'key' ),
			'visitors'   => array( 'دسترسی ویزیتورها', 'shield' ),
			'appearance' => array( 'ظاهر و نمایش', 'sparkles' ),
			'company'    => array( 'شرکت و چاپ', 'printer' ),
			'notices'    => array( 'اطلاعیه‌ها', 'bell' ),
			'returns'    => array( 'مرجوعی و ربات‌ها', 'return' ),
			'data'       => array( 'داده‌ها و پشتیبان', 'database' ),
		);
	}

	public static function page_settings() {
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'general'; // phpcs:ignore
		$tabs = self::settings_tabs();
		$tab  = isset( $tabs[ $tab ] ) ? $tab : 'general';
		self::head( 'تنظیمات', 'همه تنظیمات افزونه — هر بخش جداگانه ذخیره می‌شود', 'settings' );
		echo '<div class="bws-tabs">';
		foreach ( $tabs as $k => $t ) {
			echo '<a class="' . ( $k === $tab ? 'is-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=bws-settings&tab=' . $k ) ) . '">' . self::ic( $t[1], 16 ) . ' ' . esc_html( $t[0] ) . '</a>'; // phpcs:ignore
		}
		echo '</div>';
		$pages = get_pages();
		$sel   = function ( $name ) use ( $pages ) {
			$h = '<select name="' . esc_attr( $name ) . '"><option value="0">—</option>';
			foreach ( $pages as $p ) {
				$h .= '<option value="' . (int) $p->ID . '" ' . selected( (int) bws_opt( $name ), $p->ID, false ) . '>' . esc_html( $p->post_title ) . '</option>';
			}
			return $h . '</select>';
		};
		$num = function ( $name, $suffix = '', $step = '1' ) {
			return '<div class="bws-inline"><input type="number" step="' . esc_attr( $step ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( bws_opt( $name ) ) . '" class="bws-num" dir="ltr">' . ( $suffix ? '<span class="bws-suffix">' . esc_html( $suffix ) . '</span>' : '' ) . '</div>';
		};
		$money = function ( $name ) {
			return '<div class="bws-inline"><input type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( (float) bws_opt( $name ) > 0 ? number_format( (float) bws_opt( $name ), 0, '.', ',' ) : '0' ) . '" dir="ltr" inputmode="numeric" style="max-width:200px"><span class="bws-suffix">' . esc_html( trim( str_replace( '0', '', bws_money_text( 0 ) ) ) ) . '</span></div>';
		};
		$txt = function ( $name, $dir = 'rtl' ) {
			return '<input type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( bws_opt( $name ) ) . '" dir="' . esc_attr( $dir ) . '">';
		};
		$opt = function ( $name, $choices ) {
			$h = '<select name="' . esc_attr( $name ) . '">';
			foreach ( $choices as $k => $l ) {
				$h .= '<option value="' . esc_attr( $k ) . '" ' . selected( (string) bws_opt( $name ), (string) $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			return $h . '</select>';
		};
		$statuses = array();
		if ( function_exists( 'wc_get_order_statuses' ) ) {
			foreach ( wc_get_order_statuses() as $k => $l ) {
				$k = str_replace( 'wc-', '', $k );
				if ( ! in_array( $k, array( 'pending', 'cancelled', 'refunded', 'failed', 'checkout-draft' ), true ) ) {
					$statuses[ $k ] = $l;
				}
			}
		}
		if ( 'data' === $tab ) {
			self::settings_data_tab();
			return;
		}
		if ( 'returns' === $tab ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="bws-returns-form"><input type="hidden" name="action" value="bws_save_settings"><input type="hidden" name="tab" value="returns">';
			wp_nonce_field( 'bws_settings' );
			BWS_Admin_Returns::render();
			echo '<div class="bws-save-bar"><button class="bws-btn bws-btn-primary bws-btn-lg">' . self::ic( 'save', 17 ) . ' ذخیره تنظیمات</button></div></form>'; // phpcs:ignore
			return;
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="bws_save_settings"><input type="hidden" name="tab" value="' . esc_attr( $tab ) . '">';
		wp_nonce_field( 'bws_settings' );
		echo '<div class="bws-grid bws-grid-2"><div>';
		switch ( $tab ) {
			case 'general':
				self::card_open( 'قیمت‌گذاری همکاری (عمده)', 'قیمتی که مشتری همکار واقعاً پرداخت می‌کند', 'target' );
				self::row( 'تخفیف پیش‌فرض', 'برای هر محصول و هر مشتری جداگانه هم قابل تغییر است', $num( 'discount_percent', '٪', '0.5' ) );
				self::row( 'مبنای قیمت مصرف‌کننده', '', $opt( 'price_base', array( 'regular' => 'قیمت اصلی (Regular)', 'active' => 'قیمت فعلی (با احتساب حراج)' ) ) );
				self::row( 'گرد کردن قیمت', '', $opt( 'price_rounding', array( 0 => 'بدون گرد کردن', 10 => '۱۰', 100 => '۱۰۰', 500 => '۵۰۰', 1000 => '۱,۰۰۰', 5000 => '۵,۰۰۰', 10000 => '۱۰,۰۰۰' ) ) );
				self::row( 'برچسب قیمت همکاری', '', $txt( 'wholesale_label' ) );
				self::row( 'برچسب قیمت مصرف‌کننده', '', $txt( 'retail_label' ) . '<div style="margin-top:8px">' . self::sw( 'show_retail_price', 'نمایش قیمت مصرف‌کننده (خط‌خورده) کنار قیمت همکاری' ) . '</div>' );
				self::row( 'محصولات ناموجود', '', self::sw( 'hide_out_of_stock', 'در پنل مشتری نمایش داده نشوند' ) );
				self::card_close();
				echo '</div><div>';
				self::card_open( 'قوانین سفارش', '', 'cart' );
				self::row( 'حداقل تعداد در هر سفارش', 'جمع همه محصولات، از هر نوعی — ۰ = بدون حداقل', $num( 'min_qty', 'عدد' ) );
				self::row( 'حداکثر تعداد', '۰ = نامحدود', $num( 'max_qty', 'عدد' ) );
				self::row( 'حداقل مبلغ سفارش', '۰ = بدون حداقل', $money( 'min_amount' ) );
				self::row( 'وضعیت سفارش جدید', 'برای سفارش‌های اعتباری و حضوری', $opt( 'new_order_status', $statuses ) );
				self::row( 'توضیحات مشتری', '', self::sw( 'allow_customer_note', 'مشتری بتواند برای سفارش توضیح بنویسد' ) );
				self::row( 'تکرار سفارش', '', self::sw( 'allow_reorder', 'دکمه «تکرار این سفارش» برای مشتری و ویزیتور' ) );
				self::row( 'لغو سفارش توسط مشتری', 'لغو، اعتبار و موجودی انبار را خودکار برمی‌گرداند. ویزیتورها طبق دسترسی «لغو سفارش» و مدیر همیشه می‌توانند لغو کنند.', $opt( 'customer_cancel', array( 'processing' => 'تا قبل از ارسال (در انتظار پرداخت، در انتظار بررسی، در حال انجام)', 'pending' => 'فقط سفارش‌های پرداخت‌نشده', 'none' => 'مشتری نتواند لغو کند' ) ) );
				self::card_close();
				self::card_open( 'برچسب سفارش‌ها در ووکامرس', 'کنار نام خریدار در لیست سفارش‌ها و در عنوان ایمیل «سفارش جدید» مدیر نمایش داده می‌شود تا با سفارش‌های عادی سایت قاطی نشود. {visitor} = نام ویزیتور، {code} = کد مشتری', 'package' );
				self::row( 'ثبت توسط خود مشتری', '', $txt( 'order_label_customer' ) );
				self::row( 'ثبت توسط ویزیتور', '', $txt( 'order_label_visitor' ) );
				self::row( 'ثبت توسط مدیر', '', $txt( 'order_label_admin' ) );
				self::row( 'تسویه بدهی', '', $txt( 'order_label_settlement' ) );
				self::card_close();
				break;
			case 'credit':
				self::card_open( 'اعتبار خرید', '', 'wallet' );
				self::row( 'اعتبار پیش‌فرض هر مشتری جدید', 'برای هر مشتری جداگانه قابل تغییر است', $money( 'default_credit' ) );
				self::row( 'مهلت تسویه', 'بعد از این تعداد روز، بدهی «سررسید گذشته» نمایش داده می‌شود (۰ = خاموش)', $num( 'payment_terms_days', 'روز' ) );
				self::row( 'الزام تسویه', 'اگر خاموش باشد، مشتری از باقیمانده اعتبار می‌تواند خرید کند', self::sw( 'settle_before_order', 'تا بدهی قبلی تسویه نشده، سفارش جدید ثبت نشود' ) );
				self::card_close();
				echo '</div><div>';
				self::card_open( 'پرداخت', '', 'cash' );
				self::row( 'پرداخت مازاد بر اعتبار', 'وقتی مبلغ سفارش از اعتبار بیشتر است', self::sw( 'excess_online', 'پرداخت آنلاین (درگاه‌های ووکامرس، از جمله اسنپ‌پی)' ) . '<br>' . self::sw( 'excess_offline', 'پرداخت حضوری/نقدی به ویزیتور' ) );
				self::row( 'تسویه آنلاین', '', self::sw( 'allow_online_settlement', 'مشتری بدهی را از پنل خودش آنلاین پرداخت کند' ) );
				self::row( 'لغو خودکار سفارش پرداخت‌نشده', '۰ = خاموش؛ اعتبار رزروشده برمی‌گردد', $num( 'pending_cancel_hours', 'ساعت' ) );
				self::row( 'اسنپ‌پی', '', '<a class="bws-btn bws-btn-sm" href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=bws_snapppay' ) ) . '">' . self::ic( 'settings', 15 ) . ' تنظیمات اسنپ‌پی</a> <a class="bws-btn bws-btn-sm bws-btn-ghost" href="' . esc_url( admin_url( 'admin.php?page=bws-help#snapppay' ) ) . '">راهنما</a>' );
				self::card_close();
				break;
			case 'login':
				self::card_open( 'کد اختصاصی مشتری', '', 'key' );
				self::row( 'نوع کد', '', $opt( 'code_type', array( 'numeric' => 'فقط عدد (راحت‌تر برای مشتری)', 'alnum' => 'حروف و عدد (امن‌تر)' ) ) );
				self::row( 'طول کد', '۴ تا ۱۶ کاراکتر', $num( 'code_length', 'کاراکتر' ) );
				self::row( 'پیشوند کد', 'اختیاری، مثل AV', $txt( 'code_prefix', 'ltr' ) );
				self::row( 'حداکثر تلاش ناموفق', 'در ۱۵ دقیقه — ضد حدس زدن کد', $num( 'login_max_attempts', 'بار' ) );
				self::row( 'ماندگاری ورود مشتری', '', $num( 'session_days', 'روز' ) );
				self::card_close();
				echo '</div><div>';
				self::card_open( 'رمز یک‌بار مصرف (پیامکی)', 'پیامک «رمز یک‌بار مصرف ورود» را در پنل پیامک تنظیم کنید (ترجیحاً با الگو)', 'lock' );
				self::row( 'ورود با موبایل', 'برای مشتری‌ای که کدش را گم کرده', self::sw( 'customer_mobile_login', 'دکمه «ورود با شماره موبایل» در صفحه ورود' ) );
				self::row( 'ورود دومرحله‌ای', 'امنیت بیشتر', self::sw( 'customer_otp', 'بعد از وارد کردن کد، رمز یک‌بار مصرف هم پرسیده شود' ) );
				self::row( 'طول رمز', '', $num( 'otp_length', 'رقم' ) );
				self::row( 'مدت اعتبار رمز', '', $num( 'otp_minutes', 'دقیقه' ) );
				self::card_close();
				break;
			case 'visitors':
				self::card_open( 'دسترسی پیش‌فرض همه ویزیتورها', 'برای هر ویزیتور می‌توانید در صفحه ویرایش او دسترسی اختصاصی تعیین کنید', 'shield' );
				echo self::perm_controls( BWS_Perms::defaults(), 'visitor_perms' ); // phpcs:ignore
				self::card_close();
				echo '</div><div>';
				self::card_open( 'هدف فروش', '', 'target' );
				self::row( 'هدف ماهانه پیش‌فرض هر ویزیتور', '۰ = بدون هدف؛ برای هر ویزیتور جداگانه قابل تغییر است', $money( 'visitor_default_target' ) );
				self::card_close();
				break;
			case 'appearance':
				self::card_open( 'حالت نمایش پنل‌ها', '', 'sparkles' );
				self::row( 'نمایش', '', $opt( 'panel_mode', array( 'app' => 'اپلیکیشن تمام‌صفحه (بدون هدر و فوتر قالب) — پیشنهادی', 'theme' => 'داخل قالب سایت', 'elementor' => 'طراحی‌شده با المنتور (قالب برگه تغییر نکند)' ) ) );
				self::row( 'پیروی از قالب', 'فقط در حالت «داخل قالب سایت»', self::sw( 'ui_follow_theme', 'رنگ اصلی/ثانویه و فونت از قالب یا المنتور گرفته شود' ) );
				self::row( 'صفحه پنل مشتری', 'شورت‌کد [bws_customer_panel] یا ویجت المنتور', $sel( 'customer_page_id' ) );
				self::row( 'صفحه پنل ویزیتور', 'شورت‌کد [bws_visitor_panel] یا ویجت المنتور', $sel( 'visitor_page_id' ) );
				self::card_close();
				$about = bws_about_link();
				self::card_open( 'تب «درباره ما» در پنل مشتری', 'کنار «سفارش جدید، سفارش‌ها و اعتبار» در منوی پایین پنل مشتری', 'info' );
				self::row( 'نمایش', '', self::sw( 'customer_about_show', 'تب درباره ما نمایش داده شود' ) );
				self::row( 'عنوان', 'خالی = «درباره ' . bws_opt( 'company_name' ) . '»', $txt( 'customer_about_label' ) );
				self::row( 'آدرس صفحه', 'خالی = برگه about-us سایت به‌صورت خودکار' . ( $about ? ' (الان: ' . $about[1] . ')' : '' ), $txt( 'customer_about_url', 'ltr' ) );
				self::card_close();
				echo '</div><div>';
				self::card_open( 'رنگ و فونت', 'در المنتور برای هر ویجت جداگانه هم قابل تغییر است', 'edit' );
				self::row( 'رنگ اصلی', '', '<input type="color" name="ui_primary" value="' . esc_attr( bws_opt( 'ui_primary' ) ) . '">' );
				self::row( 'رنگ تیره', '', '<input type="color" name="ui_navy" value="' . esc_attr( bws_opt( 'ui_navy' ) ) . '">' );
				self::row( 'گردی گوشه‌ها', '', $num( 'ui_radius', 'px' ) );
				self::row( 'فونت', '', $opt( 'ui_font', array( 'vazirmatn' => 'وزیرمتن (داخلی افزونه، بدون اتصال به اینترنت)', 'inherit' => 'فونت قالب سایت' ) ) );
				self::row( 'لوگوی بالای پنل', '', $opt( 'ui_logo_mode', array( 'brand' => 'لوگوی ARIAGH.VISITOR', 'company' => 'لوگوی شرکت (از تب شرکت و چاپ)' ) ) );
				self::card_close();
				break;
			case 'company':
				self::card_open( 'اطلاعات شرکت', 'در پیامک‌ها ({company}، {company_phone}) و چاپ استفاده می‌شود', 'store' );
				self::row( 'نام شرکت / فروشگاه', '', $txt( 'company_name' ) );
				self::row( 'تلفن', '', $txt( 'company_phone', 'ltr' ) );
				self::row( 'آدرس لوگو', 'لینک تصویر از کتابخانه رسانه', $txt( 'company_logo', 'ltr' ) );
				self::card_close();
				echo '</div><div>';
				self::card_open( 'چاپ کارت مشتری و فاکتور', '', 'printer' );
				self::row( 'متن پایین کارت', '', $txt( 'print_footer' ) );
				self::row( 'QR کد', '', self::sw( 'print_qr', 'چاپ QR لینک ورود مستقیم روی کارت' ) );
				self::card_close();
				break;
			case 'notices':
				self::card_open( 'اطلاعیه پنل مشتری', 'بالای صفحه سفارش مشتری نمایش داده می‌شود (خالی = بدون اطلاعیه)', 'bell' );
				echo '<textarea name="notice_customer" rows="5" style="width:100%">' . esc_textarea( bws_opt( 'notice_customer' ) ) . '</textarea><p class="bws-muted">HTML ساده (لینک، پررنگ) مجاز است.</p>';
				self::card_close();
				echo '</div><div>';
				self::card_open( 'اطلاعیه پنل ویزیتور', 'بالای داشبورد ویزیتورها نمایش داده می‌شود', 'bell' );
				echo '<textarea name="notice_visitor" rows="5" style="width:100%">' . esc_textarea( bws_opt( 'notice_visitor' ) ) . '</textarea>';
				self::card_close();
				break;
		}
		echo '</div></div><div class="bws-save-bar"><button class="bws-btn bws-btn-primary bws-btn-lg">' . self::ic( 'save', 17 ) . ' ذخیره تنظیمات</button></div></form>'; // phpcs:ignore
	}

	protected static function settings_data_tab() {
		echo '<div class="bws-grid bws-grid-2"><div>';
		self::card_open( 'پشتیبان تنظیمات', 'انتقال تنظیمات به سایت دیگر یا نگهداری نسخه پشتیبان (کلیدهای محرمانه منتقل نمی‌شوند)', 'download' );
		echo '<a class="bws-btn" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=bws_settings_export' ), 'bws_settings_export' ) ) . '">' . self::ic( 'download', 16 ) . ' دانلود فایل تنظیمات (JSON)</a>'; // phpcs:ignore
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="bws-inline" style="margin-top:14px"><input type="hidden" name="action" value="bws_settings_import">';
		wp_nonce_field( 'bws_settings_import' );
		echo '<input type="file" name="file" accept=".json,application/json" required><button class="bws-btn">' . self::ic( 'upload', 16 ) . ' بارگذاری تنظیمات</button></form>'; // phpcs:ignore
		self::card_close();
		echo '</div><div>';
		self::card_open( 'حذف افزونه', '', 'trash' );
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="bws_save_settings"><input type="hidden" name="tab" value="data">';
		wp_nonce_field( 'bws_settings' );
		self::row( 'هنگام پاک کردن افزونه', 'غیرفعال کردن افزونه هیچ‌وقت داده‌ای پاک نمی‌کند', self::sw( 'delete_data_on_uninstall', 'همه جداول و تنظیمات افزونه هم پاک شوند (غیرقابل بازگشت)' ) );
		echo '<button class="bws-btn bws-btn-primary">' . self::ic( 'save', 16 ) . ' ذخیره</button></form>'; // phpcs:ignore
		self::card_close();
		echo '</div></div>';
	}

	/* ================= Activity ================= */

	public static function page_activity() {
		$page = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore
		self::head( 'گزارش فعالیت‌ها', 'چه کسی، چه کاری، چه زمانی انجام داده است', 'activity' );
		self::card_open( '', '', '', 'bws-card-flush' );
		self::activity_table( BWS_Log::query( array( 'limit' => 100, 'offset' => ( $page - 1 ) * 100 ) ) );
		self::card_close();
		echo '<div class="bws-pager">';
		if ( $page > 1 ) {
			echo '<a class="bws-btn bws-btn-sm" href="' . esc_url( add_query_arg( 'paged', $page - 1 ) ) . '">قبلی</a>';
		}
		echo '<span>صفحه ' . esc_html( bws_fa_digits( $page ) ) . '</span><a class="bws-btn bws-btn-sm" href="' . esc_url( add_query_arg( 'paged', $page + 1 ) ) . '">بعدی</a></div>';
	}

	protected static function activity_table( $rows ) {
		$actors = array( 'admin' => 'مدیر', 'visitor' => 'ویزیتور', 'customer' => 'مشتری' );
		echo '<div class="bws-table-wrap"><table class="bws-table"><thead><tr><th>تاریخ</th><th>کاربر</th><th>عملیات</th><th>موضوع</th><th>جزئیات</th><th>IP</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$obj = ( 'customer' === $r->object_type && $r->object_id ) ? self::cust_link( $r->object_id, 'مشتری #' . $r->object_id ) : esc_html( $r->object_type . ( $r->object_id ? ' #' . $r->object_id : '' ) );
			echo '<tr><td>' . esc_html( bws_jdate( $r->created_at ) ) . '</td><td>' . esc_html( $r->user_id ? bws_user_name( $r->user_id ) : '—' ) . ' <span class="bws-badge">' . esc_html( $actors[ $r->actor ] ?? $r->actor ) . '</span></td><td>' . esc_html( BWS_Log::$labels[ $r->action ] ?? $r->action ) . '</td><td>' . $obj . '</td><td><code>' . esc_html( mb_substr( (string) $r->details, 0, 140 ) ) . '</code></td><td dir="ltr">' . esc_html( $r->ip ) . '</td></tr>'; // phpcs:ignore
		}
		if ( ! $rows ) {
			echo '<tr><td colspan="6">' . self::empty_box( 'فعالیتی ثبت نشده است.', 'activity' ) . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table></div>';
	}

	/* ================= Handlers ================= */

	public static function save_visitor() {
		if ( ! bws_is_manager() || ! check_admin_referer( 'bws_visitor' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		$uid = isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0;
		if ( $uid && ! bws_is_visitor( $uid ) ) {
			self::back( 'bws-visitors', 'کاربر ویزیتور نیست.', true );
		}
		$r = BWS_Auth::save_visitor( $_POST, $uid );
		if ( is_wp_error( $r ) ) {
			self::back( 'bws-visitors', $r->get_error_message(), true, $uid ? array( 'edit' => $uid ) : array() );
		}
		if ( ! $uid && ! empty( $_POST['send_sms'] ) ) {
			$mobile = bws_normalize_mobile( wp_unslash( isset( $_POST['mobile'] ) ? $_POST['mobile'] : '' ) ); // phpcs:ignore
			if ( $mobile ) {
				$u = get_userdata( $r );
				BWS_SMS::send_event( 'visitor_account', null, array(
					'visitor_name'      => $u->display_name,
					'username'          => $u->user_login,
					'password'          => (string) wp_unslash( isset( $_POST['password'] ) ? $_POST['password'] : '' ), // phpcs:ignore
					'visitor_panel_url' => bws_visitor_panel_url(),
				), array( 'force' => true, 'to' => $mobile ) );
			}
		}
		self::back( 'bws-visitors', $uid ? 'ویزیتور به‌روزرسانی شد.' : 'ویزیتور ایجاد شد.', false, array( 'edit' => $r ) );
	}

	public static function save_settings() {
		if ( ! bws_is_manager() || ! check_admin_referer( 'bws_settings' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		$tab = sanitize_key( isset( $_POST['tab'] ) ? $_POST['tab'] : 'general' );
		$p   = wp_unslash( $_POST ); // phpcs:ignore
		$new = array();
		$def = array(
			'general'    => array(
				'bool' => array( 'show_retail_price', 'hide_out_of_stock', 'allow_customer_note', 'allow_reorder' ),
				'int'  => array( 'price_rounding', 'min_qty', 'max_qty' ),
				'text' => array( 'price_base', 'wholesale_label', 'retail_label', 'new_order_status', 'customer_cancel', 'order_label_customer', 'order_label_visitor', 'order_label_admin', 'order_label_settlement' ),
			),
			'credit'     => array(
				'bool' => array( 'excess_online', 'excess_offline', 'allow_online_settlement', 'settle_before_order' ),
				'int'  => array( 'pending_cancel_hours', 'payment_terms_days' ),
			),
			'login'      => array(
				'bool' => array( 'customer_mobile_login', 'customer_otp' ),
				'int'  => array( 'code_length', 'login_max_attempts', 'session_days', 'otp_length', 'otp_minutes' ),
				'text' => array( 'code_type', 'code_prefix' ),
			),
			'appearance' => array(
				'bool' => array( 'ui_follow_theme', 'customer_about_show' ),
				'int'  => array( 'customer_page_id', 'visitor_page_id', 'ui_radius' ),
				'text' => array( 'panel_mode', 'ui_font', 'ui_logo_mode', 'customer_about_label' ),
			),
			'company'    => array(
				'bool' => array( 'print_qr' ),
				'text' => array( 'company_name', 'company_phone', 'print_footer' ),
			),
			'data'       => array( 'bool' => array( 'delete_data_on_uninstall' ) ),
		);
		if ( 0 === strpos( $tab, 'sms_' ) ) {
			$new = BWS_Admin_SMS::save( $tab, $p );
		} elseif ( 'returns' === $tab ) {
			$old_mode = bws_opt( 'bot_mode', 'off' );
			$new      = BWS_Admin_Returns::save( $p );
			if ( is_wp_error( $new ) ) {
				self::back( 'bws-settings', $new->get_error_message(), true, array( 'tab' => 'returns' ) );
			}
			if ( $old_mode !== $new['bot_mode'] ) {
				add_action( 'bws_settings_saved', function () {
					static $done = false;
					if ( ! $done ) {
						$done = true;
						BWS_Bot::apply_mode(); // Register / remove the webhook right away.
					}
				} );
			}
		} elseif ( 'pricing_quick' === $tab ) {
			$new['discount_percent'] = max( 0, min( 100, (float) bws_en_digits( isset( $p['discount_percent'] ) ? $p['discount_percent'] : 20 ) ) );
			$new['min_qty']          = max( 0, (int) bws_en_digits( isset( $p['min_qty'] ) ? $p['min_qty'] : 20 ) );
		} else {
			$d = isset( $def[ $tab ] ) ? $def[ $tab ] : array();
			foreach ( isset( $d['bool'] ) ? $d['bool'] : array() as $k ) {
				$new[ $k ] = ! empty( $p[ $k ] ) ? 1 : 0;
			}
			foreach ( isset( $d['int'] ) ? $d['int'] : array() as $k ) {
				$new[ $k ] = isset( $p[ $k ] ) ? max( 0, (int) bws_en_digits( $p[ $k ] ) ) : 0;
			}
			foreach ( isset( $d['text'] ) ? $d['text'] : array() as $k ) {
				$new[ $k ] = sanitize_text_field( isset( $p[ $k ] ) ? $p[ $k ] : '' );
			}
			if ( 'general' === $tab ) {
				$new['discount_percent'] = max( 0, min( 100, (float) bws_en_digits( isset( $p['discount_percent'] ) ? $p['discount_percent'] : 20 ) ) );
				$new['min_amount']       = max( 0, bws_parse_amount( isset( $p['min_amount'] ) ? $p['min_amount'] : 0 ) );
				$new['price_base']       = 'active' === $new['price_base'] ? 'active' : 'regular';
				$new['customer_cancel']  = in_array( $new['customer_cancel'], array( 'processing', 'pending', 'none' ), true ) ? $new['customer_cancel'] : 'processing';
			}
			if ( 'credit' === $tab ) {
				$new['default_credit'] = max( 0, bws_parse_amount( isset( $p['default_credit'] ) ? $p['default_credit'] : 0 ) );
			}
			if ( 'login' === $tab ) {
				$new['code_length'] = max( 4, min( 16, $new['code_length'] ) );
				$new['code_type']   = 'alnum' === $new['code_type'] ? 'alnum' : 'numeric';
				$new['code_prefix'] = strtoupper( preg_replace( '/[^A-Za-z0-9\-]/', '', $new['code_prefix'] ) );
				$new['otp_length']  = max( 4, min( 8, $new['otp_length'] ) );
				$new['otp_minutes'] = max( 1, min( 15, $new['otp_minutes'] ) );
				$new['login_max_attempts'] = max( 3, $new['login_max_attempts'] );
				$new['session_days']       = max( 1, $new['session_days'] );
			}
			if ( 'visitors' === $tab ) {
				$new['visitor_perms']          = BWS_Perms::sanitize( isset( $p['visitor_perms'] ) ? (array) $p['visitor_perms'] : array() );
				$new['visitor_default_target'] = max( 0, bws_parse_amount( isset( $p['visitor_default_target'] ) ? $p['visitor_default_target'] : 0 ) );
			}
			if ( 'appearance' === $tab ) {
				$new['panel_mode']       = in_array( $new['panel_mode'], array( 'app', 'theme', 'elementor' ), true ) ? $new['panel_mode'] : 'app';
				$new['panel_fullscreen'] = 'app' === $new['panel_mode'] ? 1 : 0;
				$new['ui_primary']       = sanitize_hex_color( isset( $p['ui_primary'] ) ? $p['ui_primary'] : '' ) ? sanitize_hex_color( $p['ui_primary'] ) : '#1D4ED8';
				$new['ui_navy']          = sanitize_hex_color( isset( $p['ui_navy'] ) ? $p['ui_navy'] : '' ) ? sanitize_hex_color( $p['ui_navy'] ) : '#0B1B3F';
				$new['ui_radius']        = min( 32, $new['ui_radius'] );
				$new['ui_font']          = 'inherit' === $new['ui_font'] ? 'inherit' : 'vazirmatn';
				$new['ui_logo_mode']     = 'company' === $new['ui_logo_mode'] ? 'company' : 'brand';
				$new['customer_about_url'] = esc_url_raw( isset( $p['customer_about_url'] ) ? trim( $p['customer_about_url'] ) : '' );
				delete_transient( 'bws_about_url' );
			}
			if ( 'company' === $tab ) {
				$new['company_logo'] = esc_url_raw( isset( $p['company_logo'] ) ? $p['company_logo'] : '' );
			}
			if ( 'notices' === $tab ) {
				$new['notice_customer'] = wp_kses_post( isset( $p['notice_customer'] ) ? $p['notice_customer'] : '' );
				$new['notice_visitor']  = wp_kses_post( isset( $p['notice_visitor'] ) ? $p['notice_visitor'] : '' );
			}
		}
		bws_update_settings( $new );
		update_option( 'bws_catalog_ver', time(), false );
		BWS_Log::add( 'settings_save', 'settings', 0, $tab );
		if ( 0 === strpos( $tab, 'sms_' ) ) {
			wp_safe_redirect( add_query_arg( array( 'page' => 'bws-sms', 'sub' => substr( $tab, 4 ), 'bws_msg' => rawurlencode( 'تنظیمات پیامک ذخیره شد.' ) ), admin_url( 'admin.php' ) ) );
			exit;
		}
		if ( 'pricing_quick' === $tab ) {
			self::back( 'bws-products', 'تنظیمات ذخیره شد.' );
		}
		self::back( 'bws-settings', 'تنظیمات ذخیره شد.', false, array( 'tab' => $tab ) );
	}

	/** Settings that are never exported (secrets / site-specific ids). */
	protected static function private_keys() {
		return array( 'sms_providers', 'customer_page_id', 'visitor_page_id', 'tg_token', 'bale_token', 'tg_chats', 'bale_chats', 'gdrive_client_secret', 'gdrive_refresh_token', 'gdrive_sa_json', 'gdrive_account', 'gdrive_folder_id', 'gdrive_sa_folder_id', 'bot_recipients', 'bot_secret' );
	}

	public static function settings_export() {
		if ( ! bws_is_manager() || ! check_admin_referer( 'bws_settings_export' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		$s = array_diff_key( bws_settings(), array_flip( self::private_keys() ) );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=ariagh-visitor-settings-' . gmdate( 'Ymd' ) . '.json' );
		echo wp_json_encode( array( 'plugin' => 'ariagh-visitor', 'version' => BWS_VERSION, 'settings' => $s ), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ); // phpcs:ignore
		exit;
	}

	public static function settings_import() {
		if ( ! bws_is_manager() || ! check_admin_referer( 'bws_settings_import' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		$f    = isset( $_FILES['file']['tmp_name'] ) ? $_FILES['file']['tmp_name'] : ''; // phpcs:ignore
		$data = $f && is_uploaded_file( $f ) && filesize( $f ) < 512000 ? json_decode( (string) file_get_contents( $f ), true ) : null; // phpcs:ignore
		if ( ! is_array( $data ) || empty( $data['settings'] ) || 'ariagh-visitor' !== ( isset( $data['plugin'] ) ? $data['plugin'] : '' ) ) {
			self::back( 'bws-settings', 'فایل تنظیمات معتبر نیست.', true, array( 'tab' => 'data' ) );
		}
		$allowed = array_diff_key( bws_default_settings(), array_flip( self::private_keys() ) );
		$clean   = array();
		foreach ( array_intersect_key( (array) $data['settings'], $allowed ) as $k => $v ) {
			if ( 'visitor_perms' === $k ) {
				$clean[ $k ] = BWS_Perms::sanitize( (array) $v );
			} elseif ( is_array( $v ) ) {
				$clean[ $k ] = array_map( 'sanitize_text_field', $v );
			} elseif ( 0 === strpos( $k, 'notice_' ) ) {
				$clean[ $k ] = wp_kses_post( $v );
			} elseif ( 0 === strpos( $k, 'tpl_' ) ) {
				$clean[ $k ] = sanitize_textarea_field( $v );
			} else {
				$clean[ $k ] = ( is_int( $allowed[ $k ] ) || is_float( $allowed[ $k ] ) ) && is_numeric( $v ) ? $v + 0 : sanitize_text_field( (string) $v );
			}
		}
		bws_update_settings( $clean );
		BWS_Log::add( 'settings_import', 'settings', 0, count( $clean ) );
		self::back( 'bws-settings', sprintf( '%s تنظیم درون‌ریزی شد.', number_format_i18n( count( $clean ) ) ), false, array( 'tab' => 'data' ) );
	}

	public static function export() {
		if ( ! bws_is_manager() || ! check_admin_referer( 'bws_export' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		$what = sanitize_key( $_GET['what'] ?? 'customers' );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=ariagh-visitor-' . $what . '-' . gmdate( 'Ymd-His' ) . '.csv' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" ); // UTF-8 BOM for Excel.
		if ( 'ledger' === $what ) {
			fputcsv( $out, array( 'تاریخ', 'کد مشتری', 'نام', 'نوع', 'مبلغ', 'مانده', 'روش', 'پیگیری', 'سفارش', 'توضیح', 'ثبت توسط' ) );
			$page = 1;
			do {
				$res = BWS_Ledger::entries( array( 'page' => $page, 'per_page' => 500 ) );
				foreach ( $res['items'] as $e ) {
					$a = BWS_Ledger::entry_to_array( $e );
					fputcsv( $out, array( $a['date'], $e->code, trim( $e->first_name . ' ' . $e->last_name ), $a['type_label'], $e->amount, $e->balance_after, $a['method'], $e->reference, $e->order_id, $e->note, $a['by'] ) );
				}
				$page++;
			} while ( count( $res['items'] ) === 500 );
		} else {
			fputcsv( $out, array( 'کد', 'نام', 'نام خانوادگی', 'فروشگاه', 'موبایل', 'تلفن', 'استان', 'شهر', 'آدرس', 'کد پستی', 'ویزیتور', 'وضعیت', 'سقف اعتبار', 'بدهی', 'اعتبار باقیمانده', 'تاریخ ثبت', 'آخرین سفارش', 'لینک ورود' ) );
			$page = 1;
			do {
				$res = BWS_Customers::query( array( 'page' => $page, 'per_page' => 500, 'order' => 'asc' ) );
				foreach ( $res['items'] as $c ) {
					$s = BWS_Ledger::summary( $c );
					fputcsv( $out, array( $c->code, $c->first_name, $c->last_name, $c->shop_name, $c->mobile, $c->phone, $c->province, $c->city, $c->address, $c->postal_code, bws_user_name( $c->visitor_id ), 'active' === $c->status ? 'فعال' : 'غیرفعال', $s['limit'], max( 0, $s['debt'] ), $s['available'], bws_jdate( $c->created_at ), bws_jdate( $c->last_order_at ), bws_customer_panel_url( $c->code ) ) );
				}
				$page++;
			} while ( count( $res['items'] ) === 500 );
		}
		fclose( $out );
		exit;
	}

	public static function import() {
		if ( ! bws_is_manager() || ! check_admin_referer( 'bws_import' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}
		if ( empty( $_FILES['file']['tmp_name'] ) ) {
			self::back( 'bws-customers', 'فایلی انتخاب نشده.', true );
		}
		$fh = fopen( $_FILES['file']['tmp_name'], 'r' ); // phpcs:ignore
		if ( ! $fh ) {
			self::back( 'bws-customers', 'خواندن فایل ممکن نشد.', true );
		}
		$ok     = 0;
		$errors = array();
		$line   = 0;
		$send   = ! empty( $_POST['send_sms'] );
		while ( ( $row = fgetcsv( $fh ) ) !== false ) {
			$line++;
			if ( 1 === $line ) {
				continue;
			}
			if ( ! array_filter( $row ) ) {
				continue;
			}
			$row = array_map( function ( $v ) {
				return trim( str_replace( "\xEF\xBB\xBF", '', (string) $v ) );
			}, $row );
			$vid = 0;
			if ( ! empty( $row[9] ) ) {
				$u   = get_user_by( 'login', $row[9] );
				$vid = $u ? $u->ID : 0;
			}
			$data = array(
				'first_name'   => $row[0] ?? '',
				'last_name'    => $row[1] ?? '',
				'mobile'       => $row[2] ?? '',
				'shop_name'    => $row[3] ?? '',
				'province'     => $row[4] ?? '',
				'city'         => $row[5] ?? '',
				'address'      => ( $row[6] ?? '' ) ? $row[6] : '-',
				'phone'        => $row[7] ?? '',
				'credit_limit' => $row[8] ?? '',
				'send_sms'     => $send,
			);
			$r = BWS_Customers::create( $data, $vid );
			if ( is_wp_error( $r ) ) {
				$errors[] = 'ردیف ' . $line . ': ' . $r->get_error_message();
			} else {
				$ok++;
			}
		}
		fclose( $fh );
		$msg = sprintf( '%d مشتری وارد شد.', $ok ) . ( $errors ? ' خطاها: ' . implode( ' | ', array_slice( $errors, 0, 15 ) ) : '' );
		self::back( 'bws-customers', $msg, (bool) $errors && ! $ok );
	}

}
