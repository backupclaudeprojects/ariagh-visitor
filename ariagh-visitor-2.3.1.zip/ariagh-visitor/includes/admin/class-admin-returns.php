<?php
defined( 'ABSPATH' ) || exit;

/** Settings tab «مرجوعی و ربات‌ها»: rules, photo storage (host / Google Drive), Telegram & Bale bots, guides. */
class BWS_Admin_Returns extends BWS_Admin {

	protected static function card_open( $title = '', $desc = '', $icon = '', $cls = '', $side = '' ) {
		if ( 0 === strpos( $cls, ' id=' ) ) {
			echo '<div' . $cls . '>'; // phpcs:ignore -- anchor wrapper.
			parent::card_open( $title, $desc, $icon );
			return;
		}
		parent::card_open( $title, $desc, $icon, $cls, $side );
	}

	protected static function num( $name, $suffix = '', $min = 0, $max = 999 ) {
		return '<div class="bws-inline"><input type="number" min="' . (int) $min . '" max="' . (int) $max . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( bws_opt( $name ) ) . '" class="bws-num" dir="ltr">' . ( $suffix ? '<span class="bws-suffix">' . esc_html( $suffix ) . '</span>' : '' ) . '</div>';
	}

	protected static function txt( $name, $dir = 'ltr', $ph = '' ) {
		return '<input type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( bws_opt( $name ) ) . '" dir="' . esc_attr( $dir ) . '" placeholder="' . esc_attr( $ph ) . '" autocomplete="off">';
	}

	protected static function secret( $name, $ph = '' ) {
		$has = '' !== (string) bws_opt( $name );
		return '<input type="password" name="' . esc_attr( $name ) . '" value="' . esc_attr( $has ? bws_secret_mask() : '' ) . '" dir="ltr" placeholder="' . esc_attr( $ph ) . '" autocomplete="new-password" data-secret>' . ( $has ? '<small class="bws-muted">ذخیره شده (رمزنگاری‌شده). برای تغییر، مقدار جدید را وارد کنید؛ برای حذف، خالی کنید.</small>' : '' );
	}

	protected static function to_bytes( $v ) {
		$v = trim( (string) $v );
		$n = (float) $v;
		switch ( strtolower( substr( $v, -1 ) ) ) {
			case 'g':
				$n *= 1024;
				// no break.
			case 'm':
				$n *= 1024;
				// no break.
			case 'k':
				$n *= 1024;
		}
		return (int) $n;
	}

	public static function render() {
		$wc = array();
		if ( function_exists( 'wc_get_order_statuses' ) ) {
			foreach ( wc_get_order_statuses() as $k => $l ) {
				$k = str_replace( 'wc-', '', $k );
				if ( ! in_array( $k, array( 'pending', 'cancelled', 'refunded', 'failed', 'checkout-draft' ), true ) ) {
					$wc[ $k ] = $l;
				}
			}
		}
		$st      = (array) bws_opt( 'return_statuses', array( 'processing', 'completed' ) );
		$up_max  = self::to_bytes( ini_get( 'upload_max_filesize' ) );
		$post    = self::to_bytes( ini_get( 'post_max_size' ) );
		$mb      = (int) bws_opt( 'return_max_mb', 8 );
		$maxp    = (int) bws_opt( 'return_max_photos', 5 );
		$storage = BWS_Return_Files::mode();
		$mode    = BWS_GDrive::mode();

		echo '<div class="bws-grid bws-grid-2 bws-returns-settings"><div>';

		/* --- Rules --- */
		self::card_open( 'ثبت مرجوعی کالا', 'مشتری (یا ویزیتور برای مشتری) از روی یکی از سفارش‌هایش، کالا و تعداد معیوب را انتخاب می‌کند؛ تعداد هرگز از مقدار خریداری‌شده بیشتر نمی‌شود.', 'return' );
		self::row( 'وضعیت', '', self::sw( 'returns_enabled', 'ثبت مرجوعی در پنل مشتری و ویزیتور فعال باشد' ) );
		self::row( 'دلایل مجاز مرجوعی', 'هر خط یک دلیل. انتخاب دلیل هنگام ثبت اجباری است.', '<textarea name="return_reasons" rows="3" style="width:100%">' . esc_textarea( bws_opt( 'return_reasons', 'کپک‌زدگی محصول' ) ) . '</textarea>' );
		self::row( 'مهلت ثبت', 'چند روز بعد از ثبت سفارش، مرجوعی قابل ثبت است (۰ = بدون محدودیت)', self::num( 'return_days', 'روز', 0, 3650 ) );
		$h = '';
		foreach ( $wc as $k => $l ) {
			$h .= '<label class="bws-check"><input type="checkbox" name="return_statuses[]" value="' . esc_attr( $k ) . '" ' . checked( in_array( $k, $st, true ), true, false ) . '> ' . esc_html( $l ) . '</label> ';
		}
		self::row( 'وضعیت سفارش‌های قابل مرجوعی', '', $h );
		self::row( 'توضیحات', 'نوع مشکل، تعداد معیوب و جزئیات', self::sw( 'return_desc_required', 'نوشتن توضیحات اجباری باشد' ) );
		self::card_close();

		self::card_open( 'عکس‌ها', 'عکس‌ها قبل از ذخیره بازسازی می‌شوند (حداکثر ۲۰۰۰ پیکسل، اطلاعات EXIF/GPS حذف می‌شود) و در مرورگر هم فشرده می‌شوند تا آپلود با اینترنت موبایل سریع باشد.', 'camera' );
		self::row( 'حداقل تعداد عکس', 'حداقل ۱ پیشنهاد می‌شود', self::num( 'return_min_photos', 'عکس', 0, 10 ) );
		self::row( 'حداکثر تعداد عکس', '', self::num( 'return_max_photos', 'عکس', 1, 10 ) );
		self::row( 'حداکثر حجم هر عکس', '', self::num( 'return_max_mb', 'مگابایت', 1, 20 ) );
		$warn = '';
		if ( $up_max && $up_max < $mb * MB_IN_BYTES ) {
			$warn .= '<div class="bws-alert bws-alert-warn">' . self::ic( 'alert' ) . '<div>upload_max_filesize هاست (' . esc_html( ini_get( 'upload_max_filesize' ) ) . ') از حجم مجاز تنظیم‌شده کمتر است.</div></div>';
		}
		if ( $post && $post < $maxp * 2 * MB_IN_BYTES ) {
			$warn .= '<div class="bws-alert bws-alert-warn">' . self::ic( 'alert' ) . '<div>post_max_size هاست (' . esc_html( ini_get( 'post_max_size' ) ) . ') ممکن است برای ' . esc_html( bws_fa_digits( $maxp ) ) . ' عکس کم باشد.</div></div>';
		}
		self::row( 'محدودیت‌های هاست', 'از php.ini / cPanel قابل تغییر است', '<code dir="ltr">upload_max_filesize=' . esc_html( ini_get( 'upload_max_filesize' ) ) . ' · post_max_size=' . esc_html( ini_get( 'post_max_size' ) ) . ' · max_file_uploads=' . esc_html( ini_get( 'max_file_uploads' ) ) . '</code>' . $warn );
		self::card_close();

		/* --- Storage --- */
		self::card_open( 'محل ذخیره عکس‌ها', 'اطلاعات درخواست (کالاها، تعداد، دلیل، توضیحات، تصمیم‌ها) همیشه در دیتابیس سایت ذخیره می‌شود؛ این تنظیم فقط مربوط به خود عکس‌هاست.', 'cloud' );
		echo '<div class="bws-radio-cards">';
		foreach ( array(
			'host'   => array( 'فقط هاست سایت', 'عکس‌ها در پوشه محافظت‌شده هاست ذخیره و با لینک امضاشده و موقت (۲ ساعته) در خود پنل باز می‌شوند.', 'database' ),
			'gdrive' => array( 'فقط گوگل‌درایو', 'عکس‌ها به گوگل‌درایو منتقل و از هاست پاک می‌شوند؛ با کلیک روی عکس، مستقیم در گوگل‌درایو باز می‌شود.', 'cloud' ),
			'both'   => array( 'هم هاست و هم گوگل‌درایو', 'نسخه اصلی روی هاست می‌ماند (نمایش سریع در پنل) و یک نسخه پشتیبان در گوگل‌درایو ذخیره می‌شود.', 'layers' ),
		) as $k => $o ) {
			echo '<label class="bws-radio-card"><input type="radio" name="return_storage" value="' . esc_attr( $k ) . '" ' . checked( $storage, $k, false ) . ' data-toggle-storage><span>' . self::ic( $o[2], 22 ) . '<b>' . esc_html( $o[0] ) . '</b><small>' . esc_html( $o[1] ) . '</small></span></label>'; // phpcs:ignore
		}
		echo '</div>';
		echo '<div class="bws-gdrive-box" data-storage-drive' . ( 'host' !== $storage ? '' : ' hidden' ) . '>';
		echo '<div class="bws-alert bws-alert-info">' . self::ic( 'info' ) . '<div>آپلود به گوگل‌درایو بعد از ثبت درخواست و در پس‌زمینه انجام می‌شود (مشتری منتظر نمی‌ماند). اگر گوگل در دسترس نباشد، عکس‌ها موقتاً روی هاست می‌مانند و هر ساعت دوباره تلاش می‌شود.</div></div>'; // phpcs:ignore
		self::row( 'روش اتصال', '', '<label class="bws-check"><input type="radio" name="gdrive_mode" value="oauth" ' . checked( $mode, 'oauth', false ) . ' data-toggle-gmode> جیمیل شخصی (OAuth)</label> <label class="bws-check"><input type="radio" name="gdrive_mode" value="service" ' . checked( $mode, 'service', false ) . ' data-toggle-gmode> گوگل ورک‌اسپیس (Service Account + Shared Drive)</label>' );

		echo '<div data-gmode-box="oauth"' . ( 'oauth' === $mode ? '' : ' hidden' ) . '>';
		self::row( 'Client ID', 'از Google Cloud Console', self::txt( 'gdrive_client_id', 'ltr', 'xxxxxxxx.apps.googleusercontent.com' ) );
		self::row( 'Client Secret', '', self::secret( 'gdrive_client_secret', 'GOCSPX-...' ) );
		self::row( 'Authorized redirect URI', 'دقیقاً همین آدرس را در تنظیمات OAuth Client وارد کنید', '<div class="bws-inline"><input type="text" readonly dir="ltr" value="' . esc_attr( BWS_GDrive::redirect_uri() ) . '" id="bws-gd-redirect"><button type="button" class="bws-btn bws-btn-sm" data-copy="#bws-gd-redirect">' . self::ic( 'copy', 15 ) . ' کپی</button></div>' ); // phpcs:ignore
		$connected = '' !== bws_decrypt( (string) bws_opt( 'gdrive_refresh_token' ) );
		if ( $connected ) {
			$st_html = '<span class="bws-badge bws-st-active">' . self::ic( 'check', 14 ) . ' متصل' . ( bws_opt( 'gdrive_account' ) ? ': <span dir="ltr">' . esc_html( bws_opt( 'gdrive_account' ) ) . '</span>' : '' ) . '</span> ';
			$st_html .= '<a class="bws-btn bws-btn-sm bws-btn-ghost" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=bws_gdrive_disconnect' ), 'bws_gdrive_disconnect' ) ) . '" onclick="return confirm(\'اتصال گوگل‌درایو قطع شود؟ عکس‌های قبلی در درایو باقی می‌مانند.\')">قطع اتصال</a>';
			if ( bws_opt( 'gdrive_folder_id' ) ) {
				$st_html .= ' <a class="bws-btn bws-btn-sm bws-btn-ghost" target="_blank" rel="noopener" href="https://drive.google.com/drive/folders/' . esc_attr( rawurlencode( bws_opt( 'gdrive_folder_id' ) ) ) . '">' . self::ic( 'external', 15 ) . ' باز کردن پوشه</a>';
			}
		} else {
			$st_html = '<span class="bws-badge bws-st-pending">متصل نیست</span> <a class="bws-btn bws-btn-sm bws-btn-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=bws_gdrive_connect' ), 'bws_gdrive_connect' ) ) . '" data-need-saved>' . self::ic( 'link', 15 ) . ' اتصال به گوگل‌درایو</a><small class="bws-muted" style="display:block;margin-top:6px">ابتدا Client ID و Secret را ذخیره کنید، سپس این دکمه را بزنید.</small>';
		}
		self::row( 'وضعیت اتصال', '', $st_html );
		echo '</div>';

		echo '<div data-gmode-box="service"' . ( 'service' === $mode ? '' : ' hidden' ) . '>';
		$sa  = json_decode( bws_decrypt( (string) bws_opt( 'gdrive_sa_json' ) ), true );
		$sae = is_array( $sa ) && ! empty( $sa['client_email'] ) ? $sa['client_email'] : '';
		self::row( 'کلید JSON حساب سرویس', $sae ? 'ذخیره شده — برای تغییر، محتوای فایل جدید را بچسبانید' : 'کل محتوای فایل JSON را اینجا بچسبانید', '<textarea name="gdrive_sa_json" rows="4" dir="ltr" style="width:100%;font-family:monospace;font-size:12px" placeholder="{ &quot;type&quot;: &quot;service_account&quot;, ... }"></textarea>' . ( $sae ? '<div style="margin-top:6px"><span class="bws-badge bws-st-active">حساب: <span dir="ltr">' . esc_html( $sae ) . '</span></span> <input type="text" readonly dir="ltr" value="' . esc_attr( $sae ) . '" id="bws-sa-email" style="position:absolute;left:-9999px"><button type="button" class="bws-btn bws-btn-sm" data-copy="#bws-sa-email">' . self::ic( 'copy', 15 ) . ' کپی ایمیل</button> <label class="bws-check"><input type="checkbox" name="gdrive_sa_clear" value="1"> حذف کلید</label></div>' : '' ) ); // phpcs:ignore
		self::row( 'شناسه پوشه در Shared Drive', 'از آدرس پوشه: drive.google.com/drive/folders/شناسه', self::txt( 'gdrive_sa_folder_id', 'ltr', '0AbCdEf...' ) );
		echo '</div>';

		self::row( 'دسترسی به عکس‌ها', '', '<select name="gdrive_share"><option value="anyone" ' . selected( bws_opt( 'gdrive_share', 'anyone' ), 'anyone', false ) . '>هر کس لینک را داشته باشد ببیند (پیشنهادی؛ پیش‌نمایش در پنل)</option><option value="private" ' . selected( bws_opt( 'gdrive_share', 'anyone' ), 'private', false ) . '>خصوصی (فقط حساب‌های دارای دسترسی به پوشه)</option></select>' );
		self::row( 'پوشه‌بندی', '', self::sw( 'gdrive_monthly', 'برای هر ماه (شمسی) یک زیرپوشه ساخته شود، مثل 1405-08' ) );
		self::row( 'آزمایش', 'بعد از ذخیره — یک عکس آزمایشی آپلود، دوباره دانلود و بایت‌به‌بایت مقایسه می‌شود', '<button type="button" class="bws-btn" id="bws-drive-test">' . self::ic( 'zap', 16 ) . ' آزمایش کامل گوگل‌درایو</button> <button type="button" class="bws-btn bws-btn-ghost" id="bws-drive-verify">' . self::ic( 'check-circle', 16 ) . ' بررسی سلامت عکس‌های درایو</button><div class="bws-test-out" id="bws-drive-out" hidden></div>' ); // phpcs:ignore
		echo '</div>';
		self::card_close();

		self::cleanup_card();

		echo '</div><div>';

		/* --- Bots --- */
		foreach ( array( 'telegram' => array( 'tg_', 'تلگرام', 'https://api.telegram.org' ), 'bale' => array( 'bale_', 'بله', 'https://tapi.bale.ai' ) ) as $p => $m ) {
			self::card_open( 'ربات ' . $m[1], 'اختیاری — اتصال ربات؛ گیرندگان و دسترسی هر نفر در بخش «گیرندگان ربات» تعیین می‌شود.', 'bot', ' id="bws-bot-' . $p . '"' );
			self::row( 'وضعیت', '', self::sw( $m[0] . 'enabled', 'ارسال به ربات ' . $m[1] . ' فعال باشد' ) );
			self::row( 'توکن ربات', 'telegram' === $p ? 'از @BotFather تلگرام' : 'از @botfather در بله', self::secret( $m[0] . 'token', '123456789:AA...' ) );
			self::row( 'آدرس API', 'پیش‌فرض: ' . $m[2] . ' — فقط اگر از واسط (Relay / Proxy) استفاده می‌کنید تغییر دهید', self::txt( $m[0] . 'api_base', 'ltr', $m[2] ) );
			self::row( 'ابزارها', 'بعد از ذخیره', '<button type="button" class="bws-btn" data-bot-test="' . esc_attr( $p ) . '">' . self::ic( 'send', 16 ) . ' ارسال پیام آزمایشی</button> <button type="button" class="bws-btn bws-btn-ghost" data-bot-chats="' . esc_attr( $p ) . '">' . self::ic( 'search', 16 ) . ' یافتن شناسه‌ها</button><div class="bws-test-out" data-bot-out="' . esc_attr( $p ) . '" hidden></div>' ); // phpcs:ignore
			self::card_close();
			echo '</div>';
		}

		self::recipients_card();
		self::mode_card();
		self::templates_card();
		self::guides();
		echo '</div></div>';
	}

	protected static function users_options( $sel ) {
		$h   = '<option value="0">— بدون اتصال به کاربر —</option>';
		$mgr = get_users( array( 'capability' => 'bws_manage', 'fields' => array( 'ID', 'display_name', 'user_login' ) ) );
		if ( $mgr ) {
			$h .= '<optgroup label="مدیران">';
			foreach ( $mgr as $u ) {
				$h .= '<option value="' . (int) $u->ID . '" data-manager="1" ' . selected( (int) $sel, (int) $u->ID, false ) . '>' . esc_html( $u->display_name ? $u->display_name : $u->user_login ) . '</option>';
			}
			$h .= '</optgroup>';
		}
		$vis = BWS_Auth::visitors();
		if ( $vis ) {
			$h .= '<optgroup label="ویزیتورها">';
			foreach ( $vis as $u ) {
				$h .= '<option value="' . (int) $u->ID . '" ' . selected( (int) $sel, (int) $u->ID, false ) . '>' . esc_html( $u->display_name ? $u->display_name : $u->user_login ) . '</option>';
			}
			$h .= '</optgroup>';
		}
		return $h;
	}

	protected static function recipient_row( $i, $r ) {
		$n  = function ( $k ) use ( $i ) {
			return 'rcp[' . $i . '][' . $k . ']';
		};
		$ch = function ( $k, $label, $title = '' ) use ( $n, $r ) {
			return '<label class="bws-check" title="' . esc_attr( $title ) . '"><input type="checkbox" name="' . esc_attr( $n( $k ) ) . '" value="1" ' . checked( ! empty( $r[ $k ] ), true, false ) . '> ' . esc_html( $label ) . '</label>';
		};
		$ev = '';
		foreach ( BWS_Bot::events() as $k => $l ) {
			$ev .= '<label class="bws-check"><input type="checkbox" name="' . esc_attr( $n( 'ev' ) ) . '[]" value="' . esc_attr( $k ) . '" ' . checked( in_array( $k, (array) $r['ev'], true ), true, false ) . '> ' . esc_html( $l ) . '</label>';
		}
		return '<div class="bws-rcp' . ( empty( $r['on'] ) ? ' is-off' : '' ) . '" data-rcp><input type="hidden" name="' . esc_attr( $n( 'id' ) ) . '" value="' . esc_attr( $r['id'] ) . '">' .
			'<div class="bws-rcp-grid">' .
			'<label class="bws-field"><span>پیام‌رسان</span><select name="' . esc_attr( $n( 'p' ) ) . '"><option value="telegram" ' . selected( $r['p'], 'telegram', false ) . '>تلگرام</option><option value="bale" ' . selected( $r['p'], 'bale', false ) . '>بله</option></select></label>' .
			'<label class="bws-field"><span>شناسه عددی (Chat ID)</span><input name="' . esc_attr( $n( 'chat' ) ) . '" value="' . esc_attr( $r['chat'] ) . '" dir="ltr" placeholder="123456789"></label>' .
			'<label class="bws-field"><span>نام / عنوان</span><input name="' . esc_attr( $n( 'name' ) ) . '" value="' . esc_attr( $r['name'] ) . '" placeholder="مثلاً علی — ویزیتور شمال"></label>' .
			'<label class="bws-field"><span>متصل به کاربر سایت</span><select name="' . esc_attr( $n( 'user' ) ) . '" data-rcp-user>' . self::users_options( $r['user'] ) . '</select></label>' .
			'<label class="bws-field"><span>محدوده مرجوعی‌ها</span><select name="' . esc_attr( $n( 'scope' ) ) . '" data-rcp-scope><option value="all" ' . selected( $r['scope'], 'all', false ) . '>همه مرجوعی‌ها</option><option value="own" ' . selected( $r['scope'], 'own', false ) . '>فقط مشتریان همین ویزیتور</option></select></label>' .
			'</div><div class="bws-rcp-opts"><b>اعلان‌ها:</b> ' . $ev . '</div>' .
			'<div class="bws-rcp-opts"><b>امکانات:</b> ' . $ch( 'photos', 'دریافت عکس‌ها' ) . $ch( 'list', 'دکمه «مرجوعی‌های باز» در ربات' ) . $ch( 'decide', 'تأیید / رد از داخل ربات', 'نیازمند اتصال به کاربر سایت و دسترسی تأیید/رد' ) . $ch( 'on', 'فعال' ) .
			'<button type="button" class="bws-btn bws-btn-sm bws-btn-ghost" data-rcp-del>' . self::ic( 'trash', 14 ) . ' حذف</button></div></div>';
	}

	protected static function recipients_card() {
		self::card_open( 'گیرندگان ربات و دسترسی هر نفر', 'برای هر شناسه مشخص کنید متعلق به کیست. پیام‌های هر ویزیتور فقط مربوط به مشتریان خودش است و لینک آن به پنل همان ویزیتور می‌رود؛ مدیر لینک پیشخوان مدیریت را می‌گیرد.', 'users' );
		$rows = BWS_Bot::recipients( true );
		echo '<div class="bws-rcps" data-rcps>';
		foreach ( $rows as $i => $r ) {
			echo self::recipient_row( $i, $r ); // phpcs:ignore
		}
		echo '</div>';
		$blank = array( 'id' => 'r__new__', 'p' => 'telegram', 'chat' => '', 'name' => '', 'user' => 0, 'scope' => 'all', 'ev' => array_keys( BWS_Bot::events() ), 'photos' => 1, 'list' => 1, 'decide' => 0, 'on' => 1 );
		echo '<template id="bws-rcp-tpl">' . self::recipient_row( '__i__', $blank ) . '</template>'; // phpcs:ignore
		echo '<div class="bws-actions"><button type="button" class="bws-btn bws-btn-primary" data-rcp-add>' . self::ic( 'plus', 16 ) . ' افزودن گیرنده</button></div>'; // phpcs:ignore
		echo '<p class="bws-muted" style="font-size:12.5px;line-height:2">' . esc_html( 'نکته: هر گیرنده باید یک‌بار ربات را Start کند. اگر حالت تعامل (بخش بعد) روشن باشد، ربات بعد از /start شناسه عددی را خودش به آن شخص می‌گوید. برای «تأیید / رد از داخل ربات» گیرنده باید به کاربر سایت متصل باشد و همان دسترسی‌های پنل (مثلاً فقط مشتریان خودش) اعمال می‌شود؛ در گروه‌ها فقط کسی می‌تواند دکمه را بزند که شناسه شخصی‌اش با این امکان ثبت شده باشد.' ) . '</p>';
		self::row( 'عکس‌ها', 'یک پیام: عکس + اطلاعات به‌عنوان زیرنویس (آلبوم تا ۱۰ عکس)', self::sw( 'bot_photos', 'عکس‌های ارسالی مشتری همراه اطلاعات فرستاده شود' ) );
		self::row( 'پیامک', '', '<a class="bws-btn bws-btn-sm" href="' . esc_url( admin_url( 'admin.php?page=bws-sms&sub=templates' ) ) . '">' . self::ic( 'message', 15 ) . ' متن پیامک‌های مرجوعی (مشتری، مدیر، ویزیتور)</a>' ); // phpcs:ignore
		self::card_close();
	}

	protected static function mode_card() {
		$mode = bws_opt( 'bot_mode', 'off' );
		self::card_open( 'تعامل با ربات (دکمه‌ها و دستورات)', 'برای دکمه «مرجوعی‌های باز»، تأیید/رد داخل ربات و پاسخ به /start، ربات باید پیام‌ها را از تلگرام/بله دریافت کند.', 'zap' );
		$o = '';
		foreach ( array(
			'off'     => array( 'خاموش', 'فقط ارسال اعلان؛ ربات به پیام‌ها و دکمه‌ها جواب نمی‌دهد.' ),
			'webhook' => array( 'وب‌هوک (پیشنهادی، آنی)', 'تلگرام/بله پیام‌ها را مستقیم به سایت می‌فرستند. سایت باید https معتبر داشته باشد.' ),
			'polling' => array( 'دریافت دوره‌ای (هر دقیقه)', 'سایت هر دقیقه پیام‌ها را می‌گیرد (WP-Cron)؛ اگر سایت کم‌بازدید است، کران واقعی هاست را روی wp-cron.php تنظیم کنید.' ),
		) as $k => $l ) {
			$o .= '<label class="bws-check" style="display:flex;align-items:flex-start"><input type="radio" name="bot_mode" value="' . esc_attr( $k ) . '" ' . checked( $mode, $k, false ) . '> <span><b>' . esc_html( $l[0] ) . '</b><br><small class="bws-muted">' . esc_html( $l[1] ) . '</small></span></label>';
		}
		self::row( 'حالت', '', $o );
		$urls = '';
		foreach ( BWS_Messenger::platforms() as $p => $l ) {
			$urls .= '<div><small>' . esc_html( $l ) . ':</small> <code dir="ltr">' . esc_html( BWS_Bot::webhook_url( $p ) ) . '</code></div>';
		}
		self::row( 'آدرس وب‌هوک', 'به‌صورت خودکار ثبت می‌شود؛ محرمانه است', $urls );
		self::row( 'اعمال', 'بعد از ذخیره، این دکمه را بزنید تا حالت روی ربات‌ها اعمال شود', '<button type="button" class="bws-btn" id="bws-bot-mode">' . self::ic( 'refresh', 16 ) . ' اعمال روی ربات‌ها</button><div class="bws-test-out" id="bws-bot-mode-out" hidden></div>' ); // phpcs:ignore
		self::card_close();
	}

	protected static function templates_card() {
		self::card_open( 'متن پیام‌های ربات', 'متن‌ها کاملاً قابل تغییرند. **متن** = پررنگ. خطی که همه متغیرهایش خالی باشد خودکار حذف می‌شود. زیرنویس عکس حداکثر ۱۰۲۴ حرف است و فیلدهای طولانی (توضیحات، آدرس) خودکار کوتاه می‌شوند.', 'edit' );
		$vars = '';
		foreach ( BWS_Bot::var_help() as $k => $l ) {
			$vars .= '<code data-var title="' . esc_attr( $l ) . '">{' . esc_html( $k ) . '}</code> ';
		}
		echo '<div class="bws-vars-list" style="margin-bottom:12px">' . $vars . '</div>'; // phpcs:ignore
		foreach ( BWS_Bot::templates() as $k => $t ) {
			$val = BWS_Bot::tpl( $k );
			echo '<div class="bws-tpl-bot" data-tpl-key="' . esc_attr( $k ) . '"><label class="bws-field"><span>' . esc_html( $t[0] ) . '</span><textarea name="bot_tpl_' . esc_attr( $k ) . '" rows="' . ( 'new' === $k ? 12 : 6 ) . '" data-default="' . esc_attr( $t[1] ) . '">' . esc_textarea( $val ) . '</textarea></label>' .
				'<div class="bws-inline" style="gap:6px;flex-wrap:wrap"><button type="button" class="bws-btn bws-btn-sm" data-tpl-prev="telegram">' . self::ic( 'eye', 14 ) . ' پیش‌نمایش تلگرام</button><button type="button" class="bws-btn bws-btn-sm" data-tpl-prev="bale">' . self::ic( 'eye', 14 ) . ' پیش‌نمایش بله</button><button type="button" class="bws-btn bws-btn-sm bws-btn-ghost" data-tpl-reset>' . self::ic( 'refresh', 14 ) . ' متن پیش‌فرض</button></div>' . // phpcs:ignore
				'<div class="bws-pre-out bws-tpl-prev-out" dir="rtl" hidden></div></div>';
		}
		self::card_close();
	}

	protected static function cleanup_card() {
		$u = BWS_Return_Files::host_usage();
		self::card_open( 'پاک‌سازی عکس‌های هاست', 'برای خالی شدن فضای هاست. اطلاعات، توضیحات و تصمیم‌ها حذف نمی‌شوند؛ نسخه گوگل‌درایو (اگر هست) هم باقی می‌ماند. عکس‌هایی که هنوز به درایو منتقل نشده‌اند هرگز حذف نمی‌شوند.', 'trash' );
		self::row( 'فضای فعلی', '', '<b data-usage>' . esc_html( bws_fa_digits( $u['files'] ) ) . ' عکس — ' . esc_html( $u['size'] ) . '</b>' );
		$st = '';
		foreach ( array( 'approved' => 'تأییدشده', 'rejected' => 'ردشده', 'cancelled' => 'لغوشده', 'pending' => 'در انتظار بررسی' ) as $k => $l ) {
			$st .= '<label class="bws-check"><input type="checkbox" data-cl-st value="' . esc_attr( $k ) . '" ' . checked( 'pending' !== $k, true, false ) . '> ' . esc_html( $l ) . '</label>';
		}
		self::row( 'کدام عکس‌ها', '', '<div class="bws-inline" style="margin-bottom:8px">قدیمی‌تر از <input type="number" class="bws-num" data-cl-days value="30" min="0" dir="ltr"> روز (۰ = همه)</div>' . $st . '<br><label class="bws-check"><input type="checkbox" data-cl-backed> فقط عکس‌هایی که نسخه گوگل‌درایو دارند</label>' );
		self::row( 'اجرا', '', '<button type="button" class="bws-btn" data-cl="scan">' . self::ic( 'search', 16 ) . ' بررسی (بدون حذف)</button> <button type="button" class="bws-btn bws-btn-danger" data-cl="run">' . self::ic( 'trash', 16 ) . ' حذف از هاست</button><div class="bws-test-out" id="bws-cl-out" hidden></div>' ); // phpcs:ignore
		self::row( 'پاک‌سازی خودکار', 'روزانه، فقط درخواست‌های بررسی‌شده یا لغوشده (۰ = خاموش)', '<div class="bws-inline">' . self::num( 'return_autoclean_days', 'روز بعد از ثبت', 0, 3650 ) . '</div><div style="margin-top:8px">' . self::sw( 'return_autoclean_backed', 'فقط عکس‌هایی که در گوگل‌درایو هم هستند' ) . '</div>' );
		self::card_close();
	}

	protected static function guides() {
		$redirect = BWS_GDrive::redirect_uri();
		self::card_open( 'راهنمای قدم‌به‌قدم', 'روی هر عنوان بزنید', 'info' );
		echo '<div class="bws-guides">';
		echo '<details><summary>' . self::ic( 'bot', 16 ) . ' ساخت ربات تلگرام و گرفتن شناسه عددی</summary><ol>'; // phpcs:ignore
		echo '<li>در تلگرام <b dir="ltr">@BotFather</b> را باز کنید و دستور <code>/newbot</code> را بفرستید.</li>';
		echo '<li>یک نام و یک یوزرنیم (باید به <code>bot</code> ختم شود) بدهید. BotFather توکنی مثل <code dir="ltr">123456789:AAH...</code> می‌دهد؛ آن را در «توکن ربات» وارد و ذخیره کنید.</li>';
		echo '<li><b>مهم:</b> ربات نمی‌تواند اول به کسی پیام بدهد. هر گیرنده (مدیر، ویزیتور) باید ربات را باز کند و <b>Start</b> بزند.</li>';
		echo '<li>بعد از Start، دکمه «یافتن شناسه‌ها» را بزنید؛ افرادی که به ربات پیام داده‌اند با شناسه عددی نمایش داده می‌شوند و با یک کلیک به «گیرندگان ربات» اضافه می‌شوند. اگر حالت تعامل روشن باشد، ربات بعد از /start شناسه را خودش به آن شخص هم می‌گوید.</li><li>در «گیرندگان ربات» برای هر شناسه مشخص کنید متعلق به کدام ویزیتور یا مدیر است، چه اعلان‌هایی بگیرد و آیا دکمه «مرجوعی‌های باز» و تأیید/رد داخل ربات را داشته باشد.</li>';
		echo '<li>برای گروه: ربات را به گروه اضافه کنید، یک پیام در گروه بفرستید و «یافتن شناسه‌ها» را بزنید (شناسه گروه منفی است، مثل <code dir="ltr">-1001234567890</code>). برای کانال: ربات را ادمین کانال کنید و <code dir="ltr">@channel</code> یا شناسه عددی کانال را وارد کنید.</li>';
		echo '<li>اگر این ربات قبلاً به سرویس دیگری (وب‌هوک) وصل است، «یافتن شناسه‌ها» کار نمی‌کند؛ برای این کار ربات جدا بسازید یا شناسه را از <b dir="ltr">@userinfobot</b> بگیرید.</li>';
		echo '<li>«ارسال پیام آزمایشی» را بزنید؛ نتیجه برای هر گیرنده جداگانه نمایش داده می‌شود.</li></ol></details>';

		echo '<details><summary>' . self::ic( 'bot', 16 ) . ' ساخت ربات بله و گرفتن شناسه عددی</summary><ol>'; // phpcs:ignore
		echo '<li>در پیام‌رسان بله، بات <b dir="ltr">@botfather</b> (بات‌فادر بله) را باز کنید و ربات جدید بسازید.</li>';
		echo '<li>توکن ربات (مثل <code dir="ltr">123456789:abc...</code>) را در «توکن ربات» بخش بله وارد و ذخیره کنید. آدرس API بله <code dir="ltr">https://tapi.bale.ai</code> است.</li>';
		echo '<li>هر گیرنده باید ربات را در بله باز کند و <b>شروع</b> را بزند؛ سپس «یافتن شناسه‌ها» را بزنید.</li>';
		echo '<li>پیام‌های بله به‌صورت متن ساده ارسال می‌شوند و عکس‌ها به‌صورت آلبوم (تا ۱۰ عکس) می‌روند.</li></ol></details>';

		echo '<details><summary>' . self::ic( 'cloud', 16 ) . ' اتصال گوگل‌درایو با جیمیل شخصی (OAuth)</summary><ol>'; // phpcs:ignore
		echo '<li>به <a href="https://console.cloud.google.com/" target="_blank" rel="noopener" dir="ltr">console.cloud.google.com</a> بروید و یک پروژه جدید بسازید.</li>';
		echo '<li>از منوی <b dir="ltr">APIs &amp; Services → Library</b>، سرویس <b dir="ltr">Google Drive API</b> را پیدا و <b>Enable</b> کنید.</li>';
		echo '<li>در <b dir="ltr">Google Auth Platform</b> (یا OAuth consent screen)، نوع کاربر را <b dir="ltr">External</b> بگذارید، نام برنامه و ایمیل پشتیبانی را وارد کنید.</li>';
		echo '<li><b>بسیار مهم:</b> در بخش <b dir="ltr">Audience</b> وضعیت برنامه را با دکمه <b dir="ltr">Publish app</b> روی <b dir="ltr">In production</b> بگذارید؛ در حالت Testing گوگل اتصال را هر ۷ روز قطع می‌کند. چون افزونه فقط دسترسی <code dir="ltr">drive.file</code> (فقط فایل‌هایی که خودش می‌سازد) می‌گیرد، نیازی به تأیید (Verification) گوگل نیست.</li>';
		echo '<li>در <b dir="ltr">Clients</b> (یا Credentials → Create credentials → OAuth client ID)، نوع <b dir="ltr">Web application</b> را انتخاب و در <b dir="ltr">Authorized redirect URIs</b> این آدرس را وارد کنید:<br><code dir="ltr" style="user-select:all">' . esc_html( $redirect ) . '</code></li>';
		echo '<li>Client ID و Client Secret را اینجا وارد و ذخیره کنید، سپس «اتصال به گوگل‌درایو» را بزنید، با جیمیل موردنظر وارد شوید و <b dir="ltr">Allow</b> را بزنید.</li>';
		echo '<li>افزونه در My Drive پوشه «ARIAGH.VISITOR — مرجوعی‌ها» را می‌سازد و عکس‌ها را ماه‌به‌ماه در آن ذخیره می‌کند. اگر صفحه «Google hasn\'t verified this app» آمد، Advanced → Go to … را بزنید (برنامه متعلق به خود شماست).</li></ol></details>';

		echo '<details><summary>' . self::ic( 'cloud', 16 ) . ' اتصال گوگل ورک‌اسپیس (Service Account + Shared Drive)</summary><ol>'; // phpcs:ignore
		echo '<li>در Google Cloud Console پروژه بسازید و <b dir="ltr">Google Drive API</b> را Enable کنید.</li>';
		echo '<li><b dir="ltr">IAM &amp; Admin → Service Accounts → Create service account</b>؛ نقش (Role) لازم نیست. سپس در تب <b dir="ltr">Keys → Add key → Create new key → JSON</b> فایل کلید را دانلود کنید.</li>';
		echo '<li>حساب سرویس فضای ذخیره ندارد، پس در گوگل‌درایو ورک‌اسپیس یک <b dir="ltr">Shared Drive</b> (درایو مشترک) بسازید و از <b dir="ltr">Manage members</b>، ایمیل حساب سرویس (client_email داخل JSON) را با نقش <b dir="ltr">Content manager</b> اضافه کنید.</li>';
		echo '<li>یک پوشه داخل Shared Drive بسازید و شناسه آن را از آدرس مرورگر (بعد از <code dir="ltr">/folders/</code>) کپی کنید.</li>';
		echo '<li>محتوای فایل JSON و شناسه پوشه را اینجا وارد، ذخیره و «آزمایش اتصال» را بزنید.</li>';
		echo '<li>اگر مدیر ورک‌اسپیس اشتراک‌گذاری عمومی را بسته باشد، عکس‌ها فقط برای اعضای دارای دسترسی باز می‌شوند (پیش‌نمایش در پنل نمایش داده نمی‌شود ولی لینک کار می‌کند).</li></ol></details>';

		echo '<details><summary>' . self::ic( 'info', 16 ) . ' روند کامل مرجوعی</summary><ol>'; // phpcs:ignore
		echo '<li>مشتری در پنل خود (تب «مرجوعی» یا دکمه «ثبت مرجوعی» در جزئیات سفارش) سفارش، کالاها و تعداد معیوب، دلیل، توضیحات و عکس‌ها را ثبت می‌کند. ویزیتور هم (با دسترسی «ثبت مرجوعی») می‌تواند برای مشتری ثبت کند.</li>';
		echo '<li>درخواست با وضعیت «در انتظار بررسی» و کد پیگیری (مثل R-1001) ثبت می‌شود؛ پیامک به مشتری/مدیر/ویزیتور و پیام کامل با عکس به ربات‌ها می‌رود.</li>';
		echo '<li>مدیر یا ویزیتور دارای دسترسی «تأیید / رد مرجوعی» درخواست را بررسی می‌کند: تعداد تأییدشده هر کالا، و نوع رسیدگی: برگشت مبلغ به اعتبار مشتری (در دفتر اعتبار ثبت می‌شود)، ارسال کالای جایگزین (سفارش رایگان خودکار با کسر موجودی) یا تسویه دستی. رد کردن، نوشتن دلیل را لازم دارد.</li>';
		echo '<li>دسترسی هر ویزیتور در «ویزیتورها و دسترسی‌ها» قابل تنظیم است: دیدن، ثبت، تأیید/رد (مشتریان خودش / همه / هیچ)، و مجاز بودن برگشت اعتبار یا ارسال جایگزین.</li></ol></details>';
		echo '</div>';
		self::card_close();
	}

	/** Sanitize the posted tab. Returns settings array or WP_Error. */
	public static function save( $p ) {
		$new = array();
		foreach ( array( 'returns_enabled', 'return_desc_required', 'gdrive_monthly', 'tg_enabled', 'bale_enabled', 'bot_photos' ) as $k ) {
			$new[ $k ] = ! empty( $p[ $k ] ) ? 1 : 0;
		}
		$reasons = array();
		foreach ( preg_split( '/\r?\n/', isset( $p['return_reasons'] ) ? (string) $p['return_reasons'] : '' ) as $l ) {
			$l = trim( sanitize_text_field( $l ) );
			if ( '' !== $l ) {
				$reasons[] = mb_substr( $l, 0, 120 );
			}
		}
		$new['return_reasons']    = $reasons ? implode( "\n", array_unique( $reasons ) ) : 'کپک‌زدگی محصول';
		$new['return_days']       = max( 0, min( 3650, (int) bws_en_digits( isset( $p['return_days'] ) ? $p['return_days'] : 30 ) ) );
		$new['return_min_photos'] = max( 0, min( 10, (int) bws_en_digits( isset( $p['return_min_photos'] ) ? $p['return_min_photos'] : 1 ) ) );
		$new['return_max_photos'] = max( 1, min( 10, (int) bws_en_digits( isset( $p['return_max_photos'] ) ? $p['return_max_photos'] : 5 ) ) );
		$new['return_max_photos'] = max( $new['return_max_photos'], $new['return_min_photos'] );
		$new['return_max_mb']     = max( 1, min( 20, (int) bws_en_digits( isset( $p['return_max_mb'] ) ? $p['return_max_mb'] : 8 ) ) );
		$new['return_statuses']   = array_values( array_intersect( array_map( 'sanitize_key', isset( $p['return_statuses'] ) ? (array) $p['return_statuses'] : array() ), array_map( function ( $k ) {
			return str_replace( 'wc-', '', $k );
		}, array_keys( function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array() ) ) ) );
		$new['return_storage']    = isset( $p['return_storage'] ) && in_array( $p['return_storage'], array( 'gdrive', 'both' ), true ) ? $p['return_storage'] : 'host';
		$new['return_autoclean_days']   = max( 0, min( 3650, (int) bws_en_digits( isset( $p['return_autoclean_days'] ) ? $p['return_autoclean_days'] : 0 ) ) );
		$new['return_autoclean_backed'] = ! empty( $p['return_autoclean_backed'] ) ? 1 : 0;
		$new['bot_mode']                = isset( $p['bot_mode'] ) && in_array( $p['bot_mode'], array( 'webhook', 'polling' ), true ) ? $p['bot_mode'] : 'off';
		// Recipients.
		$rcp  = array();
		$seen = array();
		foreach ( isset( $p['rcp'] ) && is_array( $p['rcp'] ) ? $p['rcp'] : array() as $row ) {
			if ( is_array( $row ) && isset( $row['id'] ) && 'r__new__' === $row['id'] ) {
				unset( $row['id'] );
			}
			$r = BWS_Bot::sanitize_recipient( $row );
			if ( ! $r ) {
				if ( is_array( $row ) && '' !== trim( (string) ( isset( $row['chat'] ) ? $row['chat'] : '' ) ) ) {
					return new WP_Error( 'bws_chat', 'شناسه «' . sanitize_text_field( $row['chat'] ) . '» معتبر نیست؛ شناسه عددی (مثل 123456789 یا -100…) یا @نام‌کانال وارد کنید.' );
				}
				continue;
			}
			$key = $r['p'] . '|' . $r['chat'];
			if ( isset( $seen[ $key ] ) ) {
				return new WP_Error( 'bws_chat_dup', 'شناسه ' . $r['chat'] . ' دو بار برای ' . BWS_Messenger::platforms()[ $r['p'] ] . ' تعریف شده است.' );
			}
			$seen[ $key ] = 1;
			$rcp[]        = $r;
		}
		$new['bot_recipients'] = $rcp;
		foreach ( array_keys( BWS_Bot::templates() ) as $k ) {
			$v = isset( $p[ 'bot_tpl_' . $k ] ) ? trim( str_replace( "\r", '', sanitize_textarea_field( $p[ 'bot_tpl_' . $k ] ) ) ) : '';
			$new[ 'bot_tpl_' . $k ] = trim( str_replace( "\r", '', BWS_Bot::templates()[ $k ][1] ) ) === $v ? '' : mb_substr( $v, 0, 3000 ); // Default kept empty → future improvements apply.
		}
		$new['gdrive_mode']       = isset( $p['gdrive_mode'] ) && 'service' === $p['gdrive_mode'] ? 'service' : 'oauth';
		$new['gdrive_share']      = isset( $p['gdrive_share'] ) && 'private' === $p['gdrive_share'] ? 'private' : 'anyone';
		$old_cid                  = (string) bws_opt( 'gdrive_client_id' );
		$new['gdrive_client_id']  = preg_replace( '/[^A-Za-z0-9\.\-_]/', '', isset( $p['gdrive_client_id'] ) ? trim( $p['gdrive_client_id'] ) : '' );
		$new['gdrive_sa_folder_id'] = preg_replace( '/[^A-Za-z0-9\-_]/', '', isset( $p['gdrive_sa_folder_id'] ) ? trim( $p['gdrive_sa_folder_id'] ) : '' );
		if ( $old_cid && $old_cid !== $new['gdrive_client_id'] ) {
			// Another OAuth client → the old refresh token is useless.
			$new['gdrive_refresh_token'] = '';
			$new['gdrive_account']       = '';
			$new['gdrive_folder_id']     = '';
		}
		foreach ( array( 'gdrive_client_secret', 'tg_token', 'bale_token' ) as $k ) {
			$v = isset( $p[ $k ] ) ? trim( (string) $p[ $k ] ) : '';
			if ( bws_secret_mask() === $v ) {
				continue; // Unchanged.
			}
			if ( in_array( $k, array( 'tg_token', 'bale_token' ), true ) ) {
				$v = preg_replace( '/^bot/i', '', preg_replace( '/\s+/', '', $v ) );
				if ( '' !== $v && ! preg_match( '/^\d{3,20}:[A-Za-z0-9_\-]{10,}$/', $v ) ) {
					return new WP_Error( 'bws_token', 'توکن ربات ' . ( 'tg_token' === $k ? 'تلگرام' : 'بله' ) . ' معتبر نیست؛ باید شبیه 123456789:ABC... باشد.' );
				}
			} else {
				$v = sanitize_text_field( $v );
			}
			$new[ $k ] = '' === $v ? '' : bws_encrypt( $v );
		}
		if ( ! empty( $p['gdrive_sa_clear'] ) ) {
			$new['gdrive_sa_json'] = '';
		} elseif ( isset( $p['gdrive_sa_json'] ) && '' !== trim( (string) $p['gdrive_sa_json'] ) ) {
			$j = json_decode( trim( (string) $p['gdrive_sa_json'] ), true );
			if ( ! is_array( $j ) || empty( $j['client_email'] ) || empty( $j['private_key'] ) || ( isset( $j['type'] ) && 'service_account' !== $j['type'] ) ) {
				return new WP_Error( 'bws_sa', 'محتوای JSON حساب سرویس معتبر نیست؛ کل فایل کلید (type: service_account) را بچسبانید.' );
			}
			$keep                  = array_intersect_key( $j, array_flip( array( 'type', 'project_id', 'private_key_id', 'private_key', 'client_email', 'client_id', 'token_uri' ) ) );
			$new['gdrive_sa_json'] = bws_encrypt( wp_json_encode( $keep ) );
		}
		foreach ( array( 'tg_' => 'https://api.telegram.org', 'bale_' => 'https://tapi.bale.ai' ) as $pre => $def ) {
			$base               = isset( $p[ $pre . 'api_base' ] ) ? trim( (string) $p[ $pre . 'api_base' ] ) : '';
			$base               = $base ? untrailingslashit( esc_url_raw( $base, array( 'https', 'http' ) ) ) : $def;
			$new[ $pre . 'api_base' ] = $base ? preg_replace( '#/bot.*$#i', '', $base ) : $def;
		}
		delete_option( 'bws_gd_folders' );
		return $new;
	}
}
