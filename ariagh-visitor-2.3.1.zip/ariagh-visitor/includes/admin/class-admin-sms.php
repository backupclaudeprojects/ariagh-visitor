<?php
defined( 'ABSPATH' ) || exit;

/**
 * Admin: SMS connection (all Iranian SMS panels with step-by-step guides), automatic messages
 * (plain text or provider pattern), variable reference, test tools and the send log.
 */
class BWS_Admin_SMS extends BWS_Admin {

	public static function page() {
		$drivers = BWS_SMS::drivers();
		$current = BWS_SMS::driver()->id;
		$all     = (array) bws_opt( 'sms_providers', array() );
		$mode    = BWS_SMS::mode();
		$tab     = isset( $_GET['sub'] ) ? sanitize_key( $_GET['sub'] ) : 'connect'; // phpcs:ignore
		$tabs    = array( 'connect' => array( 'اتصال سامانه پیامکی', 'key' ), 'templates' => array( 'پیامک‌های خودکار', 'edit' ), 'vars' => array( 'راهنمای متغیرها', 'info' ), 'log' => array( 'گزارش ارسال', 'inbox' ) );

		self::head( 'پنل پیامک', 'اتصال به هر سامانه پیامکی ایران، متن یا الگوی پیامک‌های خودکار و گزارش ارسال', 'message', '<a class="bws-btn" href="' . esc_url( admin_url( 'admin.php?page=bws-customers&tab=sms' ) ) . '">' . self::ic( 'send', 16 ) . ' ارسال پیامک گروهی</a>' );
		echo '<div class="bws-tabs">';
		foreach ( $tabs as $k => $t ) {
			echo '<a class="' . ( $k === $tab ? 'is-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=bws-sms&sub=' . $k ) ) . '">' . self::ic( $t[1], 16 ) . ' ' . esc_html( $t[0] ) . '</a>'; // phpcs:ignore
		}
		echo '</div>';

		if ( 'log' === $tab ) {
			self::log_table();
			return;
		}
		if ( 'vars' === $tab ) {
			self::vars_reference();
			return;
		}
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="bws-sms-form" autocomplete="off">
		<input type="hidden" name="action" value="bws_save_settings"><input type="hidden" name="tab" value="sms_<?php echo esc_attr( $tab ); ?>"><?php wp_nonce_field( 'bws_settings' ); ?>
		<?php
		if ( 'templates' === $tab ) {
			self::templates( BWS_SMS::driver() );
		} else {
			self::connect( $drivers, $current, $all, $mode );
		}
		?>
		<div class="bws-save-bar"><button class="bws-btn bws-btn-primary bws-btn-lg"><?php BWS_Icons::e( 'save', 17 ); ?> ذخیره</button></div>
		</form>
		<?php
	}

	protected static function connect( $drivers, $current, $all, $mode ) {
		$labels = array( 'live' => array( 'is-ok', 'فعال — پیامک واقعی ارسال می‌شود' ), 'test' => array( 'is-warn', 'حالت تست — فقط در گزارش ثبت می‌شود' ), 'disabled' => array( 'is-bad', 'ارسال پیامک خاموش است' ) );
		echo '<div class="bws-grid bws-grid-2-1"><div>';
		self::card_open( 'سامانه پیامکی', 'از بین ' . bws_fa_digits( count( $drivers ) ) . ' اتصال آماده انتخاب کنید (بیش از ۶۰ برند پنل پیامکی ایران). اگر پنل شما در لیست نیست، «اتصال دستی» را انتخاب کنید.', 'key', '', '<span class="bws-chip ' . esc_attr( $labels[ $mode ][0] ) . '">' . esc_html( $labels[ $mode ][1] ) . '</span>' );
		self::row( 'وضعیت ارسال', 'تا پایان تنظیم و تست، حالت تست را روشن نگه دارید', self::sw( 'sms_enabled', 'ارسال پیامک فعال باشد' ) . '<br>' . self::sw( 'sms_test_mode', 'حالت تست (پیامک واقعی ارسال نشود؛ فقط در گزارش ثبت شود)' ) );

		$groups = array();
		foreach ( $drivers as $d ) {
			$groups[ $d->family ][] = $d;
		}
		$sel = '<div class="bws-searchbox" style="margin-bottom:8px">' . self::ic( 'search', 16 ) . '<input type="search" id="bws-provider-search" placeholder="جستجوی نام پنل… (مثلاً فراز، ملی پیامک، مدیانا)"></div><select name="sms_provider" id="bws-provider" size="1">';
		foreach ( BWS_SMS::$families as $fk => $fl ) {
			if ( empty( $groups[ $fk ] ) ) {
				continue;
			}
			$sel .= '<optgroup label="' . esc_attr( $fl ) . '">';
			foreach ( $groups[ $fk ] as $d ) {
				$extra = $d->brands ? ' — ' . implode( '، ', array_slice( $d->brands, 0, 4 ) ) : '';
				$sel  .= '<option value="' . esc_attr( $d->id ) . '" data-pattern="' . esc_attr( $d->pattern ? '1' : '0' ) . '" data-search="' . esc_attr( mb_strtolower( $d->label . ' ' . implode( ' ', $d->brands ) . ' ' . $d->id ) ) . '" ' . selected( $current, $d->id, false ) . '>' . esc_html( $d->label . $extra ) . '</option>';
			}
			$sel .= '</optgroup>';
		}
		$sel .= '</select>';
		self::row( 'انتخاب پنل', 'بعد از انتخاب، راهنمای گام‌به‌گام همان پنل پایین نمایش داده می‌شود', $sel );

		foreach ( $drivers as $d ) {
			$cfg = isset( $all[ $d->id ] ) ? (array) $all[ $d->id ] : array();
			echo '<div class="bws-driver" data-driver="' . esc_attr( $d->id ) . '" ' . ( $current === $d->id ? '' : 'hidden' ) . '>';
			echo '<div class="bws-driver-meta">';
			echo '<span class="bws-badge ' . ( $d->pattern ? 'bws-st-completed' : '' ) . '">' . ( $d->pattern ? 'ارسال با الگو (پترن) پشتیبانی می‌شود' : 'فقط ارسال متنی' ) . '</span> ';
			if ( $d->soap ) {
				echo '<span class="bws-badge ' . ( class_exists( 'SoapClient' ) ? 'bws-st-completed' : 'bws-st-failed' ) . '">' . ( class_exists( 'SoapClient' ) ? 'SOAP روی هاست فعال است' : 'SOAP روی هاست فعال نیست' ) . '</span> ';
			}
			if ( $d->site ) {
				echo '<a class="bws-badge" href="' . esc_url( $d->site ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( wp_parse_url( $d->site, PHP_URL_HOST ) ) . ' ↗</a>';
			}
			if ( $d->brands ) {
				echo '<div class="bws-muted" style="margin-top:6px">برندهای سازگار: ' . esc_html( implode( '، ', $d->brands ) ) . '</div>';
			}
			echo '</div>';
			foreach ( $d->fields() as $k => $f ) {
				$name = 'sms_providers[' . $d->id . '][' . $k . ']';
				$val  = isset( $cfg[ $k ] ) ? (string) $cfg[ $k ] : '';
				if ( 'select' === $f[1] ) {
					$ctl = '<select name="' . esc_attr( $name ) . '">';
					foreach ( (array) $f[3] as $ok => $ol ) {
						$ctl .= '<option value="' . esc_attr( $ok ) . '" ' . selected( $val, (string) $ok, false ) . '>' . esc_html( $ol ) . '</option>';
					}
					$ctl .= '</select>';
				} elseif ( 'textarea' === $f[1] ) {
					$ctl = '<textarea name="' . esc_attr( $name ) . '" rows="3" dir="ltr" spellcheck="false">' . esc_textarea( $val ) . '</textarea>';
				} elseif ( 'password' === $f[1] ) {
					$ctl = '<input type="password" name="' . esc_attr( $name ) . '" value="' . esc_attr( '' !== $val ? bws_secret_mask() : '' ) . '" dir="ltr" autocomplete="new-password" spellcheck="false"><small>' . ( '' !== $val ? 'ذخیره شده (رمزنگاری‌شده). برای تغییر، مقدار جدید را وارد کنید.' : 'به‌صورت رمزنگاری‌شده ذخیره می‌شود.' ) . '</small>';
				} else {
					$ctl = '<input type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '" dir="ltr" autocomplete="off" spellcheck="false">';
				}
				self::row( $f[0], ! empty( $f[2] ) ? wp_strip_all_tags( $f[2] ) : '', $ctl );
			}
			echo '<details class="bws-guide" open><summary>' . self::ic( 'info', 16 ) . ' راهنمای گام‌به‌گام اتصال ' . esc_html( $d->label ) . '</summary><div class="bws-guide-body">' . wp_kses_post( $d->guide() ) . '</div></details>'; // phpcs:ignore
			echo '</div>';
		}
		self::row( 'موبایل مدیران', 'برای پیامک «سفارش جدید» — چند شماره را با کاما جدا کنید', '<input name="admin_mobiles" dir="ltr" value="' . esc_attr( bws_opt( 'admin_mobiles' ) ) . '" placeholder="09121234567, 09351234567">' );
		self::row( 'تعداد در هر مرحله ارسال گروهی', 'عدد کمتر = فشار کمتر روی سرور', '<div class="bws-inline"><input type="number" name="sms_batch_size" min="1" max="200" value="' . esc_attr( bws_opt( 'sms_batch_size' ) ) . '" class="bws-num"><span class="bws-suffix">پیامک</span></div>' );
		self::card_close();
		echo '</div><div>';

		self::card_open( 'تست اتصال', 'اول «ذخیره» بزنید، بعد تست کنید', 'zap' );
		echo '<div class="bws-actions" style="margin-top:0"><button type="button" class="bws-btn" id="bws-sms-credit">' . self::ic( 'wallet', 16 ) . ' استعلام اعتبار پنل</button></div><div id="bws-sms-credit-out" class="bws-muted" style="margin-bottom:10px"></div>'; // phpcs:ignore
		echo '<label class="bws-field"><span>شماره موبایل برای تست</span><input id="bws-test-mobile" placeholder="09xxxxxxxxx" dir="ltr"></label>';
		echo '<label class="bws-field"><span>چه چیزی ارسال شود؟</span><select id="bws-test-event"><option value="">یک پیام متنی ساده</option>';
		foreach ( BWS_Events::all() as $k => $e ) {
			echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $e['label'] ) . ' (' . ( 'pattern' === bws_opt( 'tpl_' . $k . '_mode' ) ? 'الگو' : 'متن' ) . ' — با مقادیر نمونه)</option>';
		}
		echo '</select></label>';
		echo '<button type="button" class="bws-btn bws-btn-primary bws-btn-block" id="bws-sms-test">' . self::ic( 'send', 16 ) . ' ارسال پیامک تست</button>'; // phpcs:ignore
		echo '<pre id="bws-sms-test-out" class="bws-pre-out" hidden></pre>';
		echo '<p class="bws-muted">اگر «حالت تست» روشن باشد پیامک واقعی ارسال نمی‌شود؛ پاسخ واقعی سامانه را فقط وقتی حالت تست خاموش است می‌بینید.</p>';
		self::card_close();

		self::card_open( 'نکات مهم', '', 'shield' );
		echo '<ul class="bws-list-tips">';
		echo '<li><b>لینک در پیامک:</b> مخابرات ارسال لینک را روی خطوط عمومی/تبلیغاتی محدود کرده است. برای «لینک ورود»، «کد ورود» و پیام‌های اطلاع‌رسانی از <b>خط خدماتی</b> یا <b>ارسال با الگو (پترن)</b> استفاده کنید.</li>';
		echo '<li><b>رمز یک‌بار مصرف (OTP):</b> فقط با الگو (پترن) سریع و مطمئن ارسال می‌شود.</li>';
		echo '<li><b>امنیت:</b> کلیدها و رمزها رمزنگاری‌شده ذخیره می‌شوند و هرگز به مرورگر ارسال نمی‌شوند.</li>';
		echo '<li><b>IP مجاز:</b> اگر پنل شما محدودیت IP دارد، IP سرور سایت را در پنل ثبت کنید' . ( ! empty( $_SERVER['SERVER_ADDR'] ) ? ': <code dir="ltr">' . esc_html( sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) ) ) . '</code>' : '' ) . '.</li>';
		echo '<li><b>هر پیامک فارسی</b> تا ۷۰ حرف یک پیامک حساب می‌شود و بعد از آن هر ۶۷ حرف یک پیامک (انگلیسی: ۱۶۰ و ۱۵۳).</li>';
		echo '</ul>';
		self::card_close();
		echo '</div></div>';
	}

	protected static function templates( $driver ) {
		$vars   = BWS_Events::variables();
		$events = BWS_Events::all();
		$recip  = array( 'customer' => 'مشتری', 'admins' => 'موبایل مدیران', 'visitor' => 'ویزیتور' );
		$ph     = $driver->pattern_help();
		echo '<div class="bws-alert bws-alert-info">' . self::ic( 'info', 18 ) . '<div><b>دو روش ارسال برای هر پیامک:</b><br>• <b>متن</b>: متن پایین با جایگزینی متغیرها ارسال می‌شود (مناسب خط خدماتی).<br>• <b>الگو (پترن)</b>: متن را یک‌بار در پنل پیامک خود ثبت و تأیید می‌کنید؛ این‌جا فقط «کد الگو» و مقدار پارامترها را می‌نویسید. سریع‌ترین و مطمئن‌ترین روش، مخصوصاً برای لینک و رمز یک‌بار مصرف.<br>سامانه فعلی: <b>' . esc_html( $driver->label ) . '</b> — ' . ( $driver->pattern ? 'از الگو پشتیبانی می‌کند.' : '<span class="bws-red">از الگو پشتیبانی نمی‌کند؛ پیامک‌های حالت «الگو» به‌صورت متنی ارسال می‌شوند.</span>' ) . '</div></div>'; // phpcs:ignore

		foreach ( $events as $key => $e ) {
			$allowed = BWS_Events::allowed_vars( $key );
			$mode    = bws_opt( 'tpl_' . $key . '_mode', 'text' );
			echo '<section class="bws-card bws-tpl-card" data-event="' . esc_attr( $key ) . '"><div class="bws-card-head"><div class="bws-card-title"><span class="bws-card-ic">' . self::ic( 'message', 18 ) . '</span><div><h2>' . esc_html( $e['label'] ) . '</h2><p>' . esc_html( $e['desc'] ) . ' — گیرنده: ' . esc_html( $recip[ $e['to'] ] ) . '</p></div></div>'; // phpcs:ignore
			echo $e['toggle'] ? self::sw( $e['toggle'], 'ارسال خودکار' ) : '<span class="bws-badge">' . ( 'otp' === $key ? 'هنگام ورود با رمز یک‌بار مصرف' : 'هنگام نیاز / دستی' ) . '</span>'; // phpcs:ignore
			echo '</div><div class="bws-card-body">';
			echo '<div class="bws-seg bws-mode-seg"><label><input type="radio" name="tpl_' . esc_attr( $key ) . '_mode" value="text" ' . checked( $mode, 'text', false ) . '> متن</label><label><input type="radio" name="tpl_' . esc_attr( $key ) . '_mode" value="pattern" ' . checked( $mode, 'pattern', false ) . '> الگو (پترن)</label></div>';

			echo '<div class="bws-tpl-text"><label class="bws-field"><span>متن پیامک ' . ( 'pattern' === $mode ? '(وقتی الگو تنظیم نشده یا پنل الگو ندارد، همین متن ارسال می‌شود)' : '' ) . '</span><textarea name="tpl_' . esc_attr( $key ) . '" rows="5" data-tpl>' . esc_textarea( bws_opt( 'tpl_' . $key ) ) . '</textarea></label>';
			echo '<div class="bws-tpl-preview"><div class="bws-tpl-meta"></div><div class="bws-tpl-out"></div><div class="bws-tpl-warn"></div></div></div>';

			echo '<div class="bws-tpl-pattern" ' . ( 'pattern' === $mode ? '' : 'hidden' ) . '><div class="bws-form-grid"><label class="bws-field"><span>کد الگو / شناسه قالب</span><input name="tpl_' . esc_attr( $key ) . '_code" dir="ltr" value="' . esc_attr( bws_opt( 'tpl_' . $key . '_code' ) ) . '" placeholder="مثلاً 123456"></label>';
			echo '<label class="bws-field"><span>پارامترهای الگو (هر خط: نام=مقدار)</span><textarea name="tpl_' . esc_attr( $key ) . '_params" rows="4" dir="ltr" data-params spellcheck="false">' . esc_textarea( bws_opt( 'tpl_' . $key . '_params' ) ) . '</textarea></label></div>';
			if ( $ph ) {
				echo '<div class="bws-hint">' . wp_kses_post( $ph ) . '</div>';
			}
			echo '<div class="bws-muted">متن پیشنهادی برای ثبت الگو در پنل پیامک (علامت دور متغیر را طبق پنل خود بنویسید؛ مثلاً %name% یا #name#):</div><div class="bws-suggest">' . esc_html( self::pattern_suggestion( $e, bws_opt( 'tpl_' . $key . '_params' ), bws_opt( 'tpl_' . $key ) ) ) . '</div>';
			echo '</div>';

			echo '<div class="bws-vars-list" title="روی متغیر کلیک کنید تا در کادر فعال درج شود">';
			foreach ( $allowed as $v ) {
				$info = BWS_Events::flat_vars();
				$t    = isset( $info[ $v ] ) ? $info[ $v ][0] . ' — ' . $info[ $v ][1] . ' (مثال: ' . $info[ $v ][2] . ')' : $v;
				echo '<code data-var title="' . esc_attr( $t ) . '">{' . esc_html( $v ) . '}</code>';
			}
			echo '</div>';

			if ( 'order_status' === $key && function_exists( 'wc_get_order_statuses' ) ) {
				echo '<div class="bws-field"><span>برای کدام وضعیت‌ها پیامک ارسال شود؟</span><div class="bws-checks">';
				foreach ( wc_get_order_statuses() as $sk => $sl ) {
					$sk = str_replace( 'wc-', '', $sk );
					if ( 'checkout-draft' === $sk ) {
						continue;
					}
					echo '<label class="bws-switch"><input type="checkbox" name="order_status_sms[]" value="' . esc_attr( $sk ) . '" ' . checked( in_array( $sk, (array) bws_opt( 'order_status_sms' ), true ), true, false ) . '><span></span> ' . esc_html( $sl ) . '</label>';
				}
				echo '</div></div>';
			}
			if ( 'reminder' === $key ) {
				self::row( 'زمان‌بندی', 'برای بدهی‌های قدیمی‌تر از', '<div class="bws-inline"><input type="number" name="reminder_days" min="1" value="' . esc_attr( bws_opt( 'reminder_days' ) ) . '" class="bws-num"><span class="bws-suffix">روز، هر</span><input type="number" name="reminder_repeat_days" min="1" value="' . esc_attr( bws_opt( 'reminder_repeat_days' ) ) . '" class="bws-num"><span class="bws-suffix">روز یک‌بار</span></div>' );
			}
			echo '</div></section>';
		}
	}

	/** Suggested provider pattern text for an event, built from its default text and parameter names. */
	protected static function pattern_suggestion( $e, $params = '', $text = '' ) {
		$map = BWS_Events::parse_params( $params ? $params : $e['pattern_hint'] );
		$txt = $text ? $text : $e['default'];
		foreach ( $map as $param => $tpl ) {
			if ( '' !== $tpl ) {
				$txt = str_replace( $tpl, '%' . $param . '%', $txt );
			}
		}
		// Variables not covered by a parameter must be written as fixed text in the provider's pattern.
		return preg_replace( '/\{[a-z0-9_]+\}/', '…', $txt );
	}

	/** Full variable reference: which variable, what it means, example, which messages. */
	protected static function vars_reference() {
		$events = BWS_Events::all();
		self::card_open( 'راهنمای کامل متغیرها', 'متغیرها را بین آکولاد {} بنویسید. هر متغیر فقط در پیامک‌هایی که ستون آخر نشان می‌دهد مقدار دارد؛ اگر در جای دیگری استفاده شود، ویرایشگر هشدار می‌دهد.', 'info', 'bws-card-flush' );
		foreach ( BWS_Events::variables() as $gk => $g ) {
			echo '<h3 class="bws-vars-h">' . esc_html( $g['label'] ) . '</h3><div class="bws-table-wrap"><table class="bws-table"><thead><tr><th>متغیر</th><th>عنوان</th><th>توضیح</th><th>مثال خروجی</th><th>قابل استفاده در</th></tr></thead><tbody>';
			foreach ( $g['vars'] as $k => $v ) {
				$where = array();
				foreach ( $events as $ek => $e ) {
					if ( in_array( $k, BWS_Events::allowed_vars( $ek ), true ) ) {
						$where[] = $e['label'];
					}
				}
				echo '<tr><td><code dir="ltr">{' . esc_html( $k ) . '}</code></td><td><b>' . esc_html( $v[0] ) . '</b></td><td>' . esc_html( $v[1] ) . '</td><td dir="auto">' . esc_html( $v[2] ) . '</td><td><small>' . esc_html( implode( '، ', $where ) ) . '</small></td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '<div class="bws-card-body">';
		echo '<h3>نکات</h3><ul class="bws-list-tips">';
		echo '<li>متغیرها به حروف کوچک انگلیسی حساس‌اند: <code>{name}</code> درست است، <code>{Name}</code> یا <code>{ name }</code> جایگزین نمی‌شود.</li>';
		echo '<li>مبالغ با جداکننده هزارگان و واحد پول فروشگاه نوشته می‌شوند (مثلاً «۱۰,۰۰۰,۰۰۰ تومان»).</li>';
		echo '<li>در حالت <b>الگو</b>، مقدار هر پارامتر را با همین متغیرها بسازید؛ مثلاً <code dir="ltr">name={name}</code> یا ترکیبی: <code dir="ltr">info={order_id} - {order_total}</code>. پارامتر خالی با «-» ارسال می‌شود چون پنل‌ها مقدار خالی را رد می‌کنند.</li>';
		echo '<li>در کاوه‌نگار، پارامترهای token / token2 / token3 نباید فاصله داشته باشند؛ افزونه فاصله‌ها را خودکار با نیم‌فاصله جایگزین می‌کند. token10 و token20 فاصله را مجاز می‌دانند.</li>';
		echo '<li>در ملی پیامک (ارسال با بدنه/BodyId)، ترتیب خطوط پارامتر مهم است: خط اول = {0}، خط دوم = {1} و …؛ نام سمت چپ = اختیاری است ولی برای خوانایی بنویسید (مثل <code dir="ltr">0={name}</code>).</li>';
		echo '<li>{link} لینک مستقیم ورود است و کد مشتری داخل آن قرار دارد؛ مشتری با یک لمس وارد پنل می‌شود. اگر نمی‌خواهید کد در لینک باشد از {panel_url} و {code} جداگانه استفاده کنید.</li>';
		echo '</ul></div>';
		self::card_close();
	}

	protected static function log_table() {
		$page   = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$status = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : ''; // phpcs:ignore
		$ctx    = isset( $_GET['ctx'] ) ? sanitize_key( $_GET['ctx'] ) : ''; // phpcs:ignore
		$log    = BWS_SMS::log_query( array( 'page' => $page, 'search' => $search, 'status' => $status, 'context' => $ctx ) );
		$st     = array( 'sent' => array( 'ارسال شد', 'completed' ), 'failed' => array( 'ناموفق', 'failed' ), 'test' => array( 'تست', 'pending' ), 'disabled' => array( 'غیرفعال', 'pending' ) );
		$form   = '<form method="get" class="bws-inline"><input type="hidden" name="page" value="bws-sms"><input type="hidden" name="sub" value="log"><select name="status" class="bws-w-auto"><option value="">همه وضعیت‌ها</option>';
		foreach ( $st as $k => $v ) {
			$form .= '<option value="' . esc_attr( $k ) . '" ' . selected( $status, $k, false ) . '>' . esc_html( $v[0] ) . '</option>';
		}
		$form .= '</select><select name="ctx" class="bws-w-auto"><option value="">همه نوع‌ها</option>';
		foreach ( BWS_SMS::contexts() as $k => $v ) {
			$form .= '<option value="' . esc_attr( $k ) . '" ' . selected( $ctx, $k, false ) . '>' . esc_html( $v ) . '</option>';
		}
		$form .= '</select><div class="bws-searchbox" style="max-width:220px">' . self::ic( 'search', 16 ) . '<input type="search" name="s" value="' . esc_attr( $search ) . '" placeholder="شماره یا متن"></div><button class="bws-btn bws-btn-sm">فیلتر</button></form>';
		self::card_open( 'گزارش پیامک‌ها', number_format_i18n( $log['total'] ) . ' پیامک', 'inbox', 'bws-card-flush', $form );
		echo '<div class="bws-table-wrap" style="margin-top:12px"><table class="bws-table"><thead><tr><th>تاریخ</th><th>موبایل</th><th>نوع</th><th>متن</th><th>وضعیت</th><th>پنل / پاسخ سامانه</th><th>ارسال‌کننده</th></tr></thead><tbody>';
		foreach ( $log['items'] as $l ) {
			$s = isset( $st[ $l->status ] ) ? $st[ $l->status ] : array( $l->status, '' );
			echo '<tr><td>' . esc_html( bws_jdate( $l->created_at ) ) . '</td><td dir="ltr">' . esc_html( $l->mobile ) . '</td><td>' . esc_html( BWS_SMS::context_label( $l->context ) ) . '</td><td style="white-space:pre-line;max-width:340px;font-size:12.5px">' . esc_html( $l->message ) . '</td><td><span class="bws-badge bws-st-' . esc_attr( $s[1] ) . '">' . esc_html( $s[0] ) . '</span></td><td><small>' . esc_html( $l->provider ) . '</small><br><code style="word-break:break-all">' . esc_html( mb_substr( (string) $l->response, 0, 200 ) ) . '</code></td><td>' . esc_html( $l->created_by ? bws_user_name( $l->created_by ) : 'سیستم' ) . '</td></tr>';
		}
		if ( ! $log['items'] ) {
			echo '<tr><td colspan="7">' . self::empty_box( 'پیامکی ارسال نشده است.', 'message' ) . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table></div>';
		self::pager( $log['total'], 50, $page );
		self::card_close();
	}

	/** Save handler for both SMS tabs. Secrets: mask = keep stored value; new value = encrypt. */
	public static function save( $tab, $p ) {
		$new = array();
		if ( 'sms_connect' === $tab ) {
			$new['sms_enabled']    = ! empty( $p['sms_enabled'] ) ? 1 : 0;
			$new['sms_test_mode']  = ! empty( $p['sms_test_mode'] ) ? 1 : 0;
			$drivers               = BWS_SMS::drivers();
			$prov                  = isset( $p['sms_provider'] ) ? sanitize_key( $p['sms_provider'] ) : 'smsir';
			$new['sms_provider']   = isset( $drivers[ $prov ] ) ? $prov : 'smsir';
			$new['admin_mobiles']  = implode( ', ', array_filter( array_map( 'bws_normalize_mobile', preg_split( '/[\s,،]+/', (string) ( isset( $p['admin_mobiles'] ) ? $p['admin_mobiles'] : '' ) ) ) ) );
			$new['sms_batch_size'] = max( 1, min( 200, (int) bws_en_digits( isset( $p['sms_batch_size'] ) ? $p['sms_batch_size'] : 25 ) ) );
			$stored                = (array) bws_opt( 'sms_providers', array() );
			$out                   = $stored;
			foreach ( (array) ( isset( $p['sms_providers'] ) ? $p['sms_providers'] : array() ) as $id => $fields ) {
				$id = sanitize_key( $id );
				if ( ! isset( $drivers[ $id ] ) ) {
					continue;
				}
				$schema = $drivers[ $id ]->fields();
				$row    = isset( $stored[ $id ] ) ? (array) $stored[ $id ] : array();
				foreach ( $schema as $k => $f ) {
					if ( ! isset( $fields[ $k ] ) ) {
						continue;
					}
					$v = (string) $fields[ $k ];
					if ( 'password' === $f[1] ) {
						if ( bws_secret_mask() === $v ) {
							continue; // unchanged.
						}
						$row[ $k ] = '' === trim( $v ) ? '' : bws_encrypt( trim( $v ) );
					} elseif ( 'textarea' === $f[1] ) {
						$row[ $k ] = trim( str_replace( "\r", '', $v ) );
					} elseif ( 'url' === $f[1] ) {
						$row[ $k ] = esc_url_raw( trim( $v ) );
					} else {
						$row[ $k ] = sanitize_text_field( $v );
					}
				}
				$out[ $id ] = $row;
			}
			$new['sms_providers'] = $out;
		} else {
			foreach ( BWS_Events::all() as $key => $e ) {
				if ( isset( $p[ 'tpl_' . $key ] ) ) {
					$new[ 'tpl_' . $key ] = sanitize_textarea_field( $p[ 'tpl_' . $key ] );
				}
				$new[ 'tpl_' . $key . '_mode' ]   = isset( $p[ 'tpl_' . $key . '_mode' ] ) && 'pattern' === $p[ 'tpl_' . $key . '_mode' ] ? 'pattern' : 'text';
				$new[ 'tpl_' . $key . '_code' ]   = sanitize_text_field( isset( $p[ 'tpl_' . $key . '_code' ] ) ? bws_en_digits( $p[ 'tpl_' . $key . '_code' ] ) : '' );
				$new[ 'tpl_' . $key . '_params' ] = sanitize_textarea_field( isset( $p[ 'tpl_' . $key . '_params' ] ) ? $p[ 'tpl_' . $key . '_params' ] : '' );
				if ( $e['toggle'] ) {
					$new[ $e['toggle'] ] = ! empty( $p[ $e['toggle'] ] ) ? 1 : 0;
				}
			}
			$new['reminder_days']        = max( 1, (int) bws_en_digits( isset( $p['reminder_days'] ) ? $p['reminder_days'] : 30 ) );
			$new['reminder_repeat_days'] = max( 1, (int) bws_en_digits( isset( $p['reminder_repeat_days'] ) ? $p['reminder_repeat_days'] : 7 ) );
			$new['order_status_sms']     = array_values( array_map( 'sanitize_key', (array) ( isset( $p['order_status_sms'] ) ? $p['order_status_sms'] : array() ) ) );
		}
		return $new;
	}
}
