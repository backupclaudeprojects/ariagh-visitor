<?php
defined( 'ABSPATH' ) || exit;

/**
 * Visit log: every time a visitor goes to a shop they can record the result and set a follow-up date.
 * Follow-ups due today (or overdue) appear on the visitor dashboard.
 */
class BWS_Visits {

	public static $results = array(
		'order'     => 'سفارش گرفت',
		'later'     => 'بعداً سفارش می‌دهد',
		'no_need'   => 'فعلاً نیاز ندارد',
		'closed'    => 'مغازه بسته بود',
		'payment'   => 'دریافت وجه',
		'complaint' => 'شکایت / مشکل',
		'new'       => 'معرفی و ثبت مشتری جدید',
		'other'     => 'سایر',
	);

	public static function table() {
		return BWS_Install::table( 'visits' );
	}

	public static function add( $customer_id, $data ) {
		global $wpdb;
		$result = isset( $data['result'] ) && isset( self::$results[ $data['result'] ] ) ? $data['result'] : 'other';
		$follow = isset( $data['follow_up'] ) ? self::parse_date( $data['follow_up'] ) : null;
		$lat    = isset( $data['lat'] ) && '' !== $data['lat'] ? (float) bws_en_digits( $data['lat'] ) : null;
		$lng    = isset( $data['lng'] ) && '' !== $data['lng'] ? (float) bws_en_digits( $data['lng'] ) : null;
		if ( null !== $lat && ( $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180 ) ) {
			$lat = null;
			$lng = null;
		}
		$wpdb->insert( self::table(), array(
			'customer_id' => (int) $customer_id,
			'visitor_id'  => get_current_user_id(),
			'result'      => $result,
			'note'        => isset( $data['note'] ) ? sanitize_textarea_field( wp_unslash( $data['note'] ) ) : '',
			'follow_up'   => $follow,
			'follow_done' => 0,
			'lat'         => $lat,
			'lng'         => $lng,
			'created_at'  => bws_now(),
		) );
		$id = (int) $wpdb->insert_id;
		// A new visit closes the previous open follow-ups of this customer by this visitor.
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . ' SET follow_done = 1 WHERE customer_id = %d AND visitor_id = %d AND id <> %d AND follow_done = 0', $customer_id, get_current_user_id(), $id ) );
		BWS_Log::add( 'visit_add', 'customer', $customer_id, self::$results[ $result ] );
		return $id;
	}

	/** Accepts Jalali (1405/07/20) or Gregorian (2026-10-12) or "+N" days. Returns Y-m-d or null. */
	public static function parse_date( $v ) {
		$v = trim( bws_en_digits( (string) $v ) );
		if ( '' === $v ) {
			return null;
		}
		if ( preg_match( '/^\+(\d{1,3})$/', $v, $m ) ) {
			return gmdate( 'Y-m-d', current_time( 'timestamp' ) + (int) $m[1] * DAY_IN_SECONDS );
		}
		if ( preg_match( '#^(\d{4})[/\-](\d{1,2})[/\-](\d{1,2})$#', $v, $m ) ) {
			$y = (int) $m[1];
			if ( $y < 1700 ) {
				list( $y, $mo, $d ) = bws_j2g( $y, (int) $m[2], (int) $m[3] );
				return sprintf( '%04d-%02d-%02d', $y, $mo, $d );
			}
			return checkdate( (int) $m[2], (int) $m[3], $y ) ? sprintf( '%04d-%02d-%02d', $y, $m[2], $m[3] ) : null;
		}
		return null;
	}

	public static function done( $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ) );
		if ( ! $row ) {
			return new WP_Error( 'bws_404', 'پیگیری یافت نشد.' );
		}
		if ( ! bws_is_manager() && (int) $row->visitor_id !== get_current_user_id() ) {
			return new WP_Error( 'bws_forbidden', 'این پیگیری متعلق به شما نیست.' );
		}
		$wpdb->update( self::table(), array( 'follow_done' => 1 ), array( 'id' => $id ) );
		return true;
	}

	public static function for_customer( $customer_id, $limit = 30 ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE customer_id = %d ORDER BY id DESC LIMIT %d', $customer_id, $limit ) );
		return array_map( array( __CLASS__, 'to_array' ), $rows );
	}

	/** Due follow-ups (today and overdue) for a visitor (0 = all, manager). */
	public static function due( $visitor_id = 0, $limit = 50 ) {
		global $wpdb;
		$t     = self::table();
		$ct    = BWS_Customers::table();
		$today = current_time( 'Y-m-d' );
		$sql   = "SELECT v.*, c.first_name, c.last_name, c.shop_name, c.code, c.mobile, c.city FROM $t v JOIN $ct c ON c.id = v.customer_id WHERE v.follow_done = 0 AND v.follow_up IS NOT NULL AND v.follow_up <= %s";
		$vals  = array( $today );
		if ( $visitor_id ) {
			$sql   .= ' AND v.visitor_id = %d';
			$vals[] = (int) $visitor_id;
		}
		$sql   .= ' ORDER BY v.follow_up ASC LIMIT %d';
		$vals[] = (int) $limit;
		$out    = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( $sql, $vals ) ) as $r ) {
			$a             = self::to_array( $r );
			$a['customer'] = trim( $r->first_name . ' ' . $r->last_name );
			$a['shop']     = $r->shop_name;
			$a['code']     = $r->code;
			$a['mobile']   = $r->mobile;
			$a['city']     = $r->city;
			$a['overdue']  = $r->follow_up < $today;
			$out[]         = $a;
		}
		return $out;
	}

	public static function count_today( $visitor_id ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE visitor_id = %d AND created_at >= %s', $visitor_id, current_time( 'Y-m-d' ) . ' 00:00:00' ) );
	}

	public static function to_array( $r ) {
		$fu = null;
		if ( $r->follow_up ) {
			list( $y, $m, $d ) = array_map( 'intval', explode( '-', $r->follow_up ) );
			list( $jy, $jm, $jd ) = bws_g2j( $y, $m, $d );
			$fu = bws_fa_digits( sprintf( '%04d/%02d/%02d', $jy, $jm, $jd ) );
		}
		return array(
			'id'           => (int) $r->id,
			'customer_id'  => (int) $r->customer_id,
			'visitor'      => bws_user_name( $r->visitor_id ),
			'result'       => $r->result,
			'result_label' => isset( self::$results[ $r->result ] ) ? self::$results[ $r->result ] : $r->result,
			'note'         => $r->note,
			'follow_up'    => $fu,
			'follow_done'  => (int) $r->follow_done,
			'map'          => null !== $r->lat ? 'https://www.google.com/maps?q=' . $r->lat . ',' . $r->lng : '',
			'date'         => bws_jdate( $r->created_at ),
		);
	}
}
