<?php
defined( 'ABSPATH' ) || exit;

class BWS_Frontend {

	public static $login_error = '';

	public static function init() {
		add_shortcode( 'bws_customer_panel', array( __CLASS__, 'customer_panel' ) );
		add_shortcode( 'bws_visitor_panel', array( __CLASS__, 'visitor_panel' ) );
		add_shortcode( 'bws_code_login', array( __CLASS__, 'code_login' ) );
		add_shortcode( 'bws_leaderboard', array( __CLASS__, 'leaderboard' ) );
		add_action( 'template_redirect', array( __CLASS__, 'handle_visitor_login' ), 5 );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 1 );
		add_filter( 'template_include', array( __CLASS__, 'template' ), 99 );
		foreach ( array( 'woocommerce_update_product', 'woocommerce_update_product_variation', 'woocommerce_product_set_stock', 'woocommerce_variation_set_stock' ) as $h ) {
			add_action( $h, array( __CLASS__, 'bump_catalog' ) );
		}
	}

	public static function bump_catalog() {
		update_option( 'bws_catalog_ver', time(), false );
	}

	public static function is_panel_page() {
		if ( ! is_singular() ) {
			return false;
		}
		$ids = array( (int) bws_opt( 'customer_page_id' ), (int) bws_opt( 'visitor_page_id' ) );
		if ( in_array( get_queried_object_id(), $ids, true ) ) {
			return true;
		}
		$post = get_post( get_queried_object_id() );
		return $post && ( has_shortcode( $post->post_content, 'bws_customer_panel' ) || has_shortcode( $post->post_content, 'bws_visitor_panel' ) );
	}

	/**
	 * Display mode (settings → appearance):
	 *  app       full-screen app, no theme header/footer (default)
	 *  theme     inside the theme layout, follows theme fonts/colours
	 *  elementor the page is designed with Elementor; we never replace the template
	 */
	public static function template( $template ) {
		if ( ! self::is_panel_page() || 'app' !== bws_opt( 'panel_mode', 'app' ) ) {
			return $template;
		}
		// Pages built with Elementor keep Elementor's own template choice (Canvas / Full width / theme).
		if ( class_exists( '\Elementor\Plugin' ) && 'builder' === get_post_meta( get_queried_object_id(), '_elementor_edit_mode', true ) ) {
			return $template;
		}
		return BWS_DIR . 'templates/panel.php';
	}

	public static function head() {
		if ( self::is_panel_page() ) {
			echo '<meta name="robots" content="noindex,nofollow">' . "\n";
			echo '<meta name="referrer" content="same-origin">' . "\n";
		}
	}

	/** Colours, radius and font from settings (or from the theme / Elementor global colours). */
	public static function appearance_css() {
		$follow  = 'theme' === bws_opt( 'panel_mode' ) && bws_opt( 'ui_follow_theme', 1 );
		$primary = sanitize_hex_color( bws_opt( 'ui_primary', '#1D4ED8' ) );
		$primary = $primary ? $primary : '#1D4ED8';
		$navy    = sanitize_hex_color( bws_opt( 'ui_navy', '#0B1B3F' ) );
		$navy    = $navy ? $navy : '#0B1B3F';
		$radius  = max( 0, min( 32, (int) bws_opt( 'ui_radius', 16 ) ) );
		$css     = '.bws-ui,.bws-modal-wrap,.bws-toasts{';
		if ( $follow ) {
			$css .= '--bws-primary:var(--e-global-color-primary,var(--wp--preset--color--primary,' . $primary . '));';
			$css .= '--bws-navy:var(--e-global-color-secondary,var(--wp--preset--color--secondary,' . $navy . '));';
		} else {
			$css .= '--bws-primary:' . $primary . ';--bws-navy:' . $navy . ';';
			$css .= '--bws-primary-600:' . self::mix( $primary, '#000000', .18 ) . ';--bws-primary-50:' . self::mix( $primary, '#ffffff', .93 ) . ';--bws-primary-100:' . self::mix( $primary, '#ffffff', .84 ) . ';--bws-violet:' . self::mix( $primary, '#ffffff', .25 ) . ';';
		}
		$css .= '--bws-radius:' . $radius . 'px;--bws-radius-sm:' . max( 0, round( $radius * .62 ) ) . 'px;';
		if ( 'inherit' === bws_opt( 'ui_font' ) || $follow ) {
			$css .= '--bws-font:inherit;';
		}
		$css .= '}';
		return $css;
	}

	/** Mix two hex colours: $w = weight of $b. */
	public static function mix( $a, $b, $w ) {
		$a   = ltrim( $a, '#' );
		$b   = ltrim( $b, '#' );
		$out = '#';
		for ( $i = 0; $i < 3; $i++ ) {
			$x    = hexdec( substr( $a, $i * 2, 2 ) );
			$y    = hexdec( substr( $b, $i * 2, 2 ) );
			$out .= str_pad( dechex( (int) round( $x * ( 1 - $w ) + $y * $w ) ), 2, '0', STR_PAD_LEFT );
		}
		return $out;
	}

	protected static function base_assets() {
		$min = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
		$css = file_exists( BWS_DIR . 'assets/css/bws' . $min . '.css' ) ? 'bws' . $min . '.css' : 'bws.css';
		wp_enqueue_style( 'bws-panel', BWS_URL . 'assets/css/' . $css, array(), BWS_VERSION );
		$font = 'inherit' === bws_opt( 'ui_font' ) || ( 'theme' === bws_opt( 'panel_mode' ) && bws_opt( 'ui_follow_theme', 1 ) ) ? '' : self::font_css();
		wp_add_inline_style( 'bws-panel', $font . self::appearance_css() );
		wp_enqueue_script( 'bws-core', self::js( 'bws-core' ), array(), BWS_VERSION, true );
	}

	public static function js( $name ) {
		$min = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
		return BWS_URL . 'assets/js/' . ( file_exists( BWS_DIR . 'assets/js/' . $name . $min . '.js' ) ? $name . $min : $name ) . '.js';
	}

	public static function font_css() {
		$f = esc_url( BWS_URL . 'assets/fonts/' );
		return "@font-face{font-family:BWSVazir;src:url({$f}Vazirmatn-Regular.woff2) format('woff2');font-weight:400;font-display:swap}@font-face{font-family:BWSVazir;src:url({$f}Vazirmatn-Medium.woff2) format('woff2');font-weight:500 600;font-display:swap}@font-face{font-family:BWSVazir;src:url({$f}Vazirmatn-Bold.woff2) format('woff2');font-weight:700 900;font-display:swap}";
	}

	protected static function wrap_class( $extra ) {
		$mode = bws_opt( 'panel_mode', 'app' );
		return 'bws-app bws-ui bws-front ' . $extra . ' bws-mode-' . esc_attr( $mode );
	}

	protected static function brand() {
		return array(
			'brand'    => bws_brand(),
			'logoMode' => bws_opt( 'ui_logo_mode', 'brand' ),
			'brandSvg' => BWS_URL . 'assets/img/logo.svg',
			'markSvg'  => BWS_URL . 'assets/img/mark.svg',
		);
	}

	public static function customer_panel( $atts = array() ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return '';
		}
		self::base_assets();
		wp_enqueue_script( 'bws-customer', self::js( 'customer-panel' ), array( 'bws-core' ), BWS_VERSION, true );
		wp_localize_script( 'bws-core', 'BWS', array_merge( self::brand(), array(
			'rest'        => esc_url_raw( rest_url( BWS_REST::NS ) ),
			'mode'        => 'customer',
			'company'     => bws_opt( 'company_name' ),
			'logo'        => bws_opt( 'company_logo' ),
			'phone'       => bws_opt( 'company_phone' ),
			'home'        => home_url( '/' ),
			'printUrl'    => add_query_arg( 'bws_print', 'order', home_url( '/' ) ),
			'codeType'    => bws_opt( 'code_type' ),
			'otpLogin'    => (bool) bws_opt( 'customer_mobile_login' ),
			'icons'       => BWS_Icons::paths(),
			'visitorUrl'  => bws_visitor_panel_url(),
			'about'       => bws_about_link(),
		) ) );
		return '<div id="bws-app" class="' . esc_attr( self::wrap_class( 'bws-customer' ) ) . '" dir="rtl"><div class="bws-loading"><span class="bws-spinner"></span> در حال بارگذاری پنل…</div></div>';
	}

	public static function handle_visitor_login() {
		if ( empty( $_POST['bws_visitor_login'] ) ) {
			return;
		}
		if ( ! isset( $_POST['_bwsl'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_bwsl'] ) ), 'bws_visitor_login' ) ) {
			self::$login_error = 'نشست منقضی شده؛ صفحه را تازه کنید.';
			return;
		}
		if ( BWS_Auth::too_many( 'visitor' ) ) {
			self::$login_error = 'تلاش‌های ناموفق زیاد بود. ۱۵ دقیقه بعد امتحان کنید.';
			return;
		}
		$login = BWS_Auth::find_login( sanitize_text_field( wp_unslash( isset( $_POST['log'] ) ? $_POST['log'] : '' ) ) );
		$user  = wp_signon( array(
			'user_login'    => sanitize_user( $login ),
			'user_password' => (string) wp_unslash( isset( $_POST['pwd'] ) ? $_POST['pwd'] : '' ), // phpcs:ignore
			'remember'      => ! empty( $_POST['rememberme'] ),
		), is_ssl() );
		if ( is_wp_error( $user ) ) {
			BWS_Auth::hit( 'visitor' );
			BWS_Log::add( 'login_failed', 'visitor', 0, mb_substr( $login, 0, 40 ), 'guest' );
			self::$login_error = 'bws_inactive' === $user->get_error_code() ? $user->get_error_message() : 'نام کاربری/موبایل یا رمز عبور اشتباه است.';
			return;
		}
		if ( ! in_array( 'bws_visitor', (array) $user->roles, true ) && ! user_can( $user, 'bws_manage' ) ) {
			wp_logout();
			self::$login_error = 'این حساب دسترسی پنل ویزیتور ندارد.';
			return;
		}
		BWS_Auth::clear( 'visitor' );
		wp_set_current_user( $user->ID );
		BWS_Log::add( 'visitor_login', 'visitor', $user->ID );
		wp_safe_redirect( bws_visitor_panel_url() );
		exit;
	}

	public static function admin_order_url_tpl() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			return admin_url( 'admin.php?page=wc-orders&action=edit&id=__ID__' );
		}
		return admin_url( 'post.php?post=__ID__&action=edit' );
	}

	protected static function login_brand() {
		if ( bws_opt( 'company_logo' ) && 'company' === bws_opt( 'ui_logo_mode' ) ) {
			return '<img class="bws-login-logo" src="' . esc_url( bws_opt( 'company_logo' ) ) . '" alt="' . esc_attr( bws_opt( 'company_name' ) ) . '">';
		}
		return '<img class="bws-login-brand" src="' . esc_url( BWS_URL . 'assets/img/logo.svg' ) . '" alt="ARIAGH.VISITOR" width="210" height="34">';
	}

	public static function visitor_panel( $atts = array() ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return '';
		}
		self::base_assets();
		$ok = is_user_logged_in() && ( bws_is_manager() || ( bws_is_visitor() && bws_visitor_active( get_current_user_id() ) ) );
		if ( ! $ok ) {
			ob_start();
			?>
			<div class="<?php echo esc_attr( self::wrap_class( 'bws-visitor-login' ) ); ?>" dir="rtl"><div class="bws-login-wrap">
				<form class="bws-card bws-login" method="post" action="<?php echo esc_url( bws_visitor_panel_url() ); ?>" autocomplete="on">
					<?php echo self::login_brand(); // phpcs:ignore ?>
					<h2>ورود ویزیتور</h2>
					<p class="bws-muted"><?php echo esc_html( bws_opt( 'company_name' ) ); ?> — پنل ثبت و مدیریت مشتریان</p>
					<?php if ( self::$login_error ) : ?><div class="bws-alert bws-alert-error" role="alert"><?php BWS_Icons::e( 'alert', 18 ); ?><div><?php echo esc_html( self::$login_error ); ?></div></div><?php endif; ?>
					<?php if ( is_user_logged_in() ) : ?><div class="bws-alert bws-alert-error"><?php BWS_Icons::e( 'lock', 18 ); ?><div>حساب فعلی شما دسترسی ویزیتور ندارد. <a href="<?php echo esc_url( wp_logout_url( bws_visitor_panel_url() ) ); ?>">خروج</a></div></div><?php endif; ?>
					<label class="bws-field"><span>نام کاربری یا شماره موبایل</span><input type="text" name="log" autocomplete="username" required dir="ltr" maxlength="60"></label>
					<label class="bws-field"><span>رمز عبور</span><input type="password" name="pwd" autocomplete="current-password" required dir="ltr" maxlength="200"></label>
					<label class="bws-switch"><input type="checkbox" name="rememberme" value="1" checked><span></span> مرا به خاطر بسپار</label>
					<input type="hidden" name="bws_visitor_login" value="1">
					<?php wp_nonce_field( 'bws_visitor_login', '_bwsl' ); ?>
					<button class="bws-btn bws-btn-primary bws-btn-lg bws-btn-block" type="submit" style="margin-top:14px"><?php BWS_Icons::e( 'lock', 18 ); ?> ورود به پنل</button>
					<p class="bws-muted bws-center" style="margin-top:12px"><a href="<?php echo esc_url( wp_lostpassword_url( bws_visitor_panel_url() ) ); ?>">رمز را فراموش کرده‌ام</a></p>
				</form>
			</div></div>
			<?php
			return ob_get_clean();
		}
		wp_enqueue_script( 'bws-visitor', self::js( 'visitor-panel' ), array( 'bws-core' ), BWS_VERSION, true );
		wp_localize_script( 'bws-core', 'BWS', array_merge( self::brand(), array(
			'rest'       => esc_url_raw( rest_url( BWS_REST::NS ) ),
			'nonce'      => wp_create_nonce( 'wp_rest' ),
			'mode'       => 'visitor',
			'company'    => bws_opt( 'company_name' ),
			'logo'       => bws_opt( 'company_logo' ),
			'home'       => home_url( '/' ),
			'admin'      => bws_is_manager() ? admin_url( 'admin.php?page=bws-dashboard' ) : '',
			'printOrder' => add_query_arg( array( 'bws_print' => 'order', '_bwsn' => wp_create_nonce( 'bws_print' ) ), home_url( '/' ) ),
			'adminOrder' => self::admin_order_url_tpl(),
			'inAdmin'    => false,
			'icons'      => BWS_Icons::paths(),
		) ) );
		return '<div id="bws-app" class="' . esc_attr( self::wrap_class( 'bws-visitor' ) ) . '" dir="rtl"><div class="bws-loading"><span class="bws-spinner"></span> در حال بارگذاری پنل…</div></div>';
	}

	/** [bws_code_login] small "enter your code" form for any page (header, landing, Elementor). */
	public static function code_login( $atts = array() ) {
		$a = shortcode_atts( array( 'title' => 'ورود همکاران', 'button' => 'ورود به پنل خرید', 'placeholder' => 'کد اختصاصی خود را وارد کنید', 'visitor_link' => 'yes' ), $atts, 'bws_code_login' );
		self::base_assets();
		ob_start();
		?>
		<div class="bws-ui bws-code-login" dir="rtl">
			<form class="bws-card bws-card-pad" method="get" action="<?php echo esc_url( bws_customer_panel_url() ); ?>">
				<?php if ( $a['title'] ) : ?><h3 class="bws-code-login-title"><?php echo esc_html( $a['title'] ); ?></h3><?php endif; ?>
				<div class="bws-code-login-row">
					<input type="text" name="code" required inputmode="<?php echo 'numeric' === bws_opt( 'code_type' ) ? 'numeric' : 'text'; ?>" maxlength="32" autocomplete="one-time-code" placeholder="<?php echo esc_attr( $a['placeholder'] ); ?>" dir="ltr">
					<button class="bws-btn bws-btn-primary" type="submit"><?php echo esc_html( $a['button'] ); ?></button>
				</div>
				<?php if ( 'yes' === $a['visitor_link'] ) : ?><p class="bws-muted" style="margin:8px 0 0">ویزیتور هستید؟ <a href="<?php echo esc_url( bws_visitor_panel_url() ); ?>">ورود ویزیتورها</a></p><?php endif; ?>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * [bws_leaderboard type="visitors|customers" period="month|30|90|year|all" limit="5" sales="no" public="no"]
	 * Customers list is shown only to logged-in staff unless public="yes" (then only shop/first names).
	 */
	public static function leaderboard( $atts = array() ) {
		$a     = shortcode_atts( array( 'type' => 'visitors', 'period' => 'month', 'limit' => 5, 'sales' => 'no', 'public' => 'no', 'title' => '' ), $atts, 'bws_leaderboard' );
		$staff = is_user_logged_in() && ( bws_is_manager() || bws_is_visitor() );
		if ( 'customers' === $a['type'] && ! $staff && 'yes' !== $a['public'] ) {
			return '';
		}
		self::base_assets();
		$period = BWS_Stats::period_key( $a['period'] );
		$limit  = max( 1, min( 20, (int) $a['limit'] ) );
		$rows   = 'customers' === $a['type'] ? BWS_Stats::top_customers( $period, $limit ) : BWS_Stats::top_visitors( $period, $limit );
		$sales  = 'yes' === $a['sales'] && ( $staff || 'yes' === $a['public'] );
		$title  = $a['title'] ? $a['title'] : ( 'customers' === $a['type'] ? 'مشتریان برتر' : 'ویزیتورهای برتر' ) . ' — ' . BWS_Stats::$periods[ $period ];
		ob_start();
		echo '<div class="bws-ui bws-lb-widget" dir="rtl"><div class="bws-card"><div class="bws-card-head"><h3>' . esc_html( $title ) . '</h3></div><ol class="bws-lb">';
		if ( ! $rows ) {
			echo '<li class="bws-muted" style="justify-content:center">هنوز فروشی در این بازه ثبت نشده است.</li>';
		}
		foreach ( $rows as $r ) {
			$name = 'customers' === $a['type'] ? ( $r['shop'] ? $r['shop'] : $r['name'] ) : $r['name'];
			echo '<li><span class="bws-rank bws-rank-' . (int) $r['rank'] . '">' . esc_html( bws_fa_digits( $r['rank'] ) ) . '</span><span class="bws-lb-name">' . esc_html( $name ) . '</span>';
			if ( $sales ) {
				echo '<span class="bws-lb-val">' . esc_html( $r['sales_text'] ) . '</span>';
			}
			echo '</li>';
		}
		echo '</ol></div></div>';
		return ob_get_clean();
	}
}
