<?php
defined( 'ABSPATH' ) || exit;

/**
 * Visitor permissions. The manager sets default permissions for all visitors and can
 * override every single permission for each visitor. Everything is enforced on the server;
 * the panel only hides what the visitor is not allowed to use.
 */
class BWS_Perms {

	/** key => [ label, type (bool|scope), default, help, scope choices ]. */
	public static function schema() {
		$own_all  = array( 'own' => 'فقط مشتریان خودش', 'all' => 'همه مشتریان' );
		$none_own = array( 'none' => 'غیرمجاز', 'own' => 'فقط مشتریان خودش', 'all' => 'همه مشتریان' );
		return array(
			'customers_create'  => array( 'ثبت مشتری جدید', 'bool', 1, 'فرم ثبت مشتری و صدور کد اختصاصی', null, 'مشتریان' ),
			'customers_view'    => array( 'مشاهده مشتریان', 'scope', 'all', 'لیست، جستجو و پرونده مشتریان', $own_all, 'مشتریان' ),
			'customers_edit'    => array( 'ویرایش اطلاعات مشتری', 'scope', 'own', 'نام، موبایل، آدرس و یادداشت', $none_own, 'مشتریان' ),
			'customers_status'  => array( 'فعال/غیرفعال کردن مشتری', 'bool', 0, 'برای مشتریانی که اجازه ویرایش دارد', null, 'مشتریان' ),
			'credit_set'        => array( 'تعیین سقف اعتبار', 'bool', 0, 'هنگام ثبت/ویرایش مشتری؛ حداکثر تا سقف مجاز پایین', null, 'اعتبار و مالی' ),
			'credit_max'        => array( 'حداکثر سقف اعتباری که می‌تواند بدهد', 'amount', 0, '۰ = همان اعتبار پیش‌فرض', null, 'اعتبار و مالی' ),
			'payments_record'   => array( 'ثبت دریافت وجه / تسویه', 'scope', 'own', 'نقدی، کارت‌به‌کارت، چک و …', $none_own, 'اعتبار و مالی' ),
			'ledger_view'       => array( 'مشاهده گردش حساب', 'scope', 'all', 'بدهکار/بستانکار و مانده هر مشتری', $none_own, 'اعتبار و مالی' ),
			'orders_place'      => array( 'ثبت سفارش برای مشتری', 'scope', 'own', 'انتخاب محصولات و ثبت سفارش از طرف مشتری', $none_own, 'سفارش‌ها' ),
			'orders_view'       => array( 'مشاهده سفارش‌ها', 'scope', 'all', 'لیست و جزئیات سفارش‌ها', $own_all, 'سفارش‌ها' ),
			'orders_cancel'     => array( 'لغو سفارش', 'scope', 'own', 'لغو سفارش‌های در انتظار/در حال انجام (اعتبار و موجودی خودکار برمی‌گردد)', $none_own, 'سفارش‌ها' ),
			'returns_view'      => array( 'مشاهده مرجوعی‌ها', 'scope', 'own', 'لیست و جزئیات درخواست‌های مرجوعی و عکس‌ها', $own_all, 'مرجوعی' ),
			'returns_create'    => array( 'ثبت مرجوعی برای مشتری', 'scope', 'own', 'ثبت درخواست مرجوعی از طرف مشتری با عکس', $none_own, 'مرجوعی' ),
			'returns_decide'    => array( 'تأیید / رد مرجوعی', 'scope', 'own', 'بررسی و تأیید یا رد درخواست‌های در انتظار', $none_own, 'مرجوعی' ),
			'returns_credit'    => array( 'برگشت مبلغ مرجوعی به اعتبار', 'bool', 0, 'هنگام تأیید، مبلغ کالای معیوب از بدهی مشتری کم شود', null, 'مرجوعی' ),
			'returns_replace'   => array( 'ارسال کالای جایگزین', 'bool', 1, 'هنگام تأیید، سفارش جایگزین رایگان ساخته شود', null, 'مرجوعی' ),
			'print'             => array( 'چاپ کارت مشتری و فاکتور', 'bool', 1, 'فیش ۸۰ میلی‌متری و A5', null, 'ابزارها' ),
			'sms_single'        => array( 'ارسال پیامک تکی', 'bool', 1, 'لینک ورود، یادآوری و پیام دلخواه به یک مشتری', null, 'پیامک' ),
			'sms_custom'        => array( 'نوشتن پیام دلخواه', 'bool', 1, 'اگر خاموش باشد فقط قالب‌های آماده قابل ارسال است', null, 'پیامک' ),
			'sms_bulk'          => array( 'پیامک گروهی', 'scope', 'own', 'ارسال گروهی لینک ورود و پیام‌ها', $none_own, 'پیامک' ),
			'code_regenerate'   => array( 'تغییر کد مشتری', 'bool', 0, 'ساخت کد جدید و باطل کردن کد قبلی', null, 'ابزارها' ),
			'visits'            => array( 'ثبت ویزیت و پیگیری', 'bool', 1, 'ثبت نتیجه مراجعه و تاریخ پیگیری بعدی', null, 'ابزارها' ),
			'location'          => array( 'ثبت موقعیت مکانی مشتری', 'bool', 1, 'ذخیره لوکیشن GPS فروشگاه مشتری', null, 'ابزارها' ),
			'export'            => array( 'خروجی Excel مشتریان خودش', 'bool', 0, 'دانلود CSV مشتریان ثبت‌شده توسط خودش', null, 'ابزارها' ),
			'leaderboard'       => array( 'مشاهده برترین‌ها', 'bool', 1, 'رتبه‌بندی ویزیتورها و مشتریان برتر', null, 'گزارش' ),
			'see_others_stats'  => array( 'دیدن فروش سایر ویزیتورها', 'bool', 1, 'مبالغ فروش سایر ویزیتورها در رتبه‌بندی', null, 'گزارش' ),
		);
	}

	public static function defaults() {
		$out = array();
		foreach ( self::schema() as $k => $s ) {
			$out[ $k ] = $s[2];
		}
		$saved = bws_opt( 'visitor_perms', array() );
		return array_merge( $out, is_array( $saved ) ? array_intersect_key( $saved, $out ) : array() );
	}

	/** Manager gets everything. */
	public static function full() {
		$out = array();
		foreach ( self::schema() as $k => $s ) {
			$out[ $k ] = 'bool' === $s[1] ? 1 : ( 'scope' === $s[1] ? 'all' : 0 );
		}
		$out['manager'] = true;
		return $out;
	}

	/** Effective permissions for a user. */
	public static function for_user( $user_id = 0 ) {
		$user_id = $user_id ? $user_id : get_current_user_id();
		if ( bws_is_manager( $user_id ) ) {
			return self::full();
		}
		$perms = self::defaults();
		if ( 'custom' === get_user_meta( $user_id, 'bws_perm_mode', true ) ) {
			$own = get_user_meta( $user_id, 'bws_perms', true );
			if ( is_array( $own ) ) {
				$perms = array_merge( $perms, array_intersect_key( $own, $perms ) );
			}
		}
		$perms['manager'] = false;
		return $perms;
	}

	public static function sanitize( $input ) {
		$out = array();
		foreach ( self::schema() as $k => $s ) {
			$v = isset( $input[ $k ] ) ? $input[ $k ] : null;
			if ( 'bool' === $s[1] ) {
				$out[ $k ] = $v ? 1 : 0;
			} elseif ( 'scope' === $s[1] ) {
				$out[ $k ] = in_array( $v, array_keys( $s[4] ), true ) ? $v : $s[2];
			} else {
				$out[ $k ] = max( 0, bws_parse_amount( $v ) );
			}
		}
		return $out;
	}

	/** Does the scope permission allow acting on this customer? */
	public static function scope_allows( $perm, $customer, $user_id = 0 ) {
		$user_id = $user_id ? $user_id : get_current_user_id();
		$p       = self::for_user( $user_id );
		$v       = isset( $p[ $perm ] ) ? $p[ $perm ] : 'none';
		if ( 'all' === $v ) {
			return true;
		}
		if ( 'own' === $v ) {
			return $customer && (int) $customer->visitor_id === (int) $user_id;
		}
		return false;
	}

	public static function can( $perm, $user_id = 0 ) {
		$p = self::for_user( $user_id );
		return ! empty( $p[ $perm ] ) && 'none' !== $p[ $perm ];
	}
}
