<?php
/**
 * Plugin Name:       ARIAGH.VISITOR — ویزیتور
 * Plugin URI:        https://ariagh.ir/visitor
 * Description:       سیستم کامل فروش عمده و ویزیتوری برای هر فروشگاه ووکامرسی: پنل ویزیتور با سطح دسترسی تک‌به‌تک، پنل خرید همکاران با کد اختصاصی، اعتبار خرید و دفتر حساب، قیمت عمده و حداقل سفارش، پشتیبانی از همه پنل‌های پیامکی ایران (متنی و الگو)، اسنپ‌پی، ویجت‌های المنتور و پنل مدیریت کامل.
 * Version:           2.3.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            ARIAGH
 * Author URI:        https://ariagh.ir
 * Text Domain:       ariagh-visitor
 * Domain Path:       /languages
 * License:           GPLv2 or later
 * WC requires at least: 7.0
 * WC tested up to:   9.9
 * Elementor tested up to: 3.30
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'BWS_VERSION' ) ) {
	return; // Another copy is already loaded.
}

define( 'BWS_VERSION', '2.3.1' );
define( 'BWS_DB_VERSION', '1.5.0' );
define( 'BWS_FILE', __FILE__ );
define( 'BWS_DIR', plugin_dir_path( __FILE__ ) );
define( 'BWS_URL', plugin_dir_url( __FILE__ ) );

require_once BWS_DIR . 'includes/class-events.php';
require_once BWS_DIR . 'includes/helpers.php';
require_once BWS_DIR . 'includes/class-perms.php';
require_once BWS_DIR . 'includes/class-icons.php';
require_once BWS_DIR . 'includes/class-install.php';
require_once BWS_DIR . 'includes/class-log.php';
require_once BWS_DIR . 'includes/class-customers.php';
require_once BWS_DIR . 'includes/class-ledger.php';
require_once BWS_DIR . 'includes/class-products.php';
require_once BWS_DIR . 'includes/class-orders.php';
require_once BWS_DIR . 'includes/class-stats.php';
require_once BWS_DIR . 'includes/class-visits.php';
require_once BWS_DIR . 'includes/returns/class-http-multipart.php';
require_once BWS_DIR . 'includes/returns/class-messenger.php';
require_once BWS_DIR . 'includes/returns/class-gdrive.php';
require_once BWS_DIR . 'includes/returns/class-bot.php';
require_once BWS_DIR . 'includes/returns/class-return-files.php';
require_once BWS_DIR . 'includes/returns/class-returns.php';
require_once BWS_DIR . 'includes/sms/class-sms-drivers.php';
require_once BWS_DIR . 'includes/class-sms.php';
require_once BWS_DIR . 'includes/class-auth.php';
require_once BWS_DIR . 'includes/class-rest.php';
require_once BWS_DIR . 'includes/class-print.php';
require_once BWS_DIR . 'includes/class-security.php';
require_once BWS_DIR . 'includes/class-frontend.php';
require_once BWS_DIR . 'includes/class-cron.php';
require_once BWS_DIR . 'includes/class-elementor.php';

register_activation_hook( __FILE__, array( 'BWS_Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'BWS_Cron', 'deactivate' ) );

// HPOS + cart/checkout blocks compatibility.
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
} );

// Payment gateway (SnappPay) is loaded only when WooCommerce is present.
add_action( 'plugins_loaded', function () {
	if ( class_exists( 'WC_Payment_Gateway' ) ) {
		require_once BWS_DIR . 'includes/gateways/class-snapppay-api.php';
		require_once BWS_DIR . 'includes/gateways/class-snapppay-gateway.php';
		add_filter( 'woocommerce_payment_gateways', function ( $g ) {
			$g[] = 'BWS_Gateway_SnappPay';
			return $g;
		} );
		BWS_Gateway_SnappPay::hooks();
	}
}, 11 );

add_action( 'plugins_loaded', function () {
	BWS_Install::maybe_upgrade();
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () {
			if ( current_user_can( 'activate_plugins' ) ) {
				echo '<div class="notice notice-error"><p><strong>ARIAGH.VISITOR (ویزیتور)</strong> برای کار به افزونه <strong>ووکامرس</strong> نیاز دارد. لطفاً ووکامرس را نصب و فعال کنید.</p></div>';
			}
		} );
	}
	BWS_Orders::init();
	BWS_Auth::init();
	BWS_REST::init();
	BWS_Print::init();
	BWS_Security::init();
	BWS_Frontend::init();
	BWS_Cron::init();
	BWS_Elementor::init();
	BWS_Returns::init();
	if ( is_admin() ) {
		require_once BWS_DIR . 'includes/admin/class-admin.php';
		require_once BWS_DIR . 'includes/admin/class-admin-sms.php';
		require_once BWS_DIR . 'includes/admin/class-admin-help.php';
		require_once BWS_DIR . 'includes/admin/class-admin-returns.php';
		BWS_Admin::init();
	}
} );

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift(
		$links,
		'<a href="' . esc_url( admin_url( 'admin.php?page=bws-settings' ) ) . '">تنظیمات</a>',
		'<a href="' . esc_url( admin_url( 'admin.php?page=bws-help' ) ) . '">راهنما</a>'
	);
	return $links;
} );
