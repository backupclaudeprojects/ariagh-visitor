( function () {
	var reg = window.wc && window.wc.wcBlocksRegistry;
	var settingsApi = window.wc && window.wc.wcSettings;
	if ( ! reg || ! window.wp || ! window.wp.element ) { return; }
	var el = window.wp.element.createElement;
	var data = ( settingsApi && settingsApi.getSetting ) ? settingsApi.getSetting( 'bws_snapppay_data', {} ) : {};
	var decode = ( window.wp.htmlEntities && window.wp.htmlEntities.decodeEntities ) || function ( s ) { return s; };
	var title = decode( data.title || 'خرید اقساطی با اسنپ‌پی' );
	var Content = function () {
		return el( 'div', null,
			data.description ? el( 'p', null, decode( data.description ) ) : null,
			data.offer ? el( 'p', null, el( 'strong', null, decode( data.offer ) ) ) : null
		);
	};
	var Label = function () {
		return el( 'span', { style: { display: 'inline-flex', alignItems: 'center', gap: '8px' } },
			data.icon ? el( 'img', { src: data.icon, alt: '', width: 24, height: 24 } ) : null, title );
	};
	reg.registerPaymentMethod( {
		name: 'bws_snapppay',
		label: el( Label ),
		content: el( Content ),
		edit: el( Content ),
		canMakePayment: function () { return true; },
		ariaLabel: title,
		supports: { features: data.supports || [ 'products' ] }
	} );
} )();
