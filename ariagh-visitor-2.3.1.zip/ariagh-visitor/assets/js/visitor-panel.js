/* ARIAGH.VISITOR – visitor / manager panel (also embedded in wp-admin for the owner).
 * Every button is shown only when the visitor has that permission; the server re-checks everything. */
(function (window, document) {
  'use strict';
  var U = window.BWSU, CFG = window.BWS;
  if (!U) return;
  var app, S;
  var TITLES = {
    dash: ['داشبورد', 'خلاصه فعالیت و فروش شما', 'dashboard'],
    'new': ['ثبت مشتری جدید', 'بعد از ثبت، کد اختصاصی تصادفی ساخته می‌شود؛ می‌توانید چاپ کنید و برای مشتری پیامک شود.', 'user-plus'],
    customers: ['مشتریان', 'جستجو با نام، موبایل، کد یا بخشی از آدرس', 'users'],
    follow: ['پیگیری‌ها', 'مشتریانی که موعد پیگیری‌شان امروز است یا گذشته', 'calendar'],
    orders: ['سفارش‌ها', 'سفارش‌های ثبت‌شده از پنل مشتری و ویزیتورها', 'package'],
    top: ['برترین‌ها', 'رتبه‌بندی ویزیتورها و مشتریان بر اساس مبلغ خرید', 'trophy'],
    sms: ['پیامک گروهی', 'برای هر مشتری پیامک جداگانه با نام و کد اختصاصی خودش ارسال می‌شود', 'send'],
    returns: ['مرجوعی‌ها', 'درخواست‌های مرجوعی کالا با عکس؛ بررسی، تأیید یا رد', 'return']
  };

  function P() { return S.me.perms; }
  function can(k) { var v = P()[k]; return !!v && v !== 'none'; }

  function start() {
    app = document.getElementById('bws-app');
    if (!app || app.getAttribute('data-booted')) return;
    app.setAttribute('data-booted', '1');
    S = {
      me: null, tab: 'dash', main: null, period: 'month',
      list: { search: '', mine: 0, debt: 0, page: 1, visitor: '', status: '', orderby: 'id', province: '' },
      olist: { search: '', mine: 0, page: 1, status: '' },
      rlist: { search: '', page: 1, status: '' }
    };
    app.innerHTML = '<div class="bws-loading"><span class="bws-spinner"></span> در حال بارگذاری…</div>';
    U.api('/staff/me').then(function (r) { S.me = r; U.currency = r.settings.currency; shell(); })
      .catch(function (e) { U.errorBox(app, e); });
  }

  function navItems() {
    var items = [{ key: 'dash', label: 'داشبورد', short: 'خانه', icon: 'dashboard', group: 'اصلی' }];
    if (can('customers_create')) items.push({ key: 'new', label: 'ثبت مشتری جدید', short: 'ثبت مشتری', icon: 'user-plus' });
    items.push({ key: 'customers', label: 'مشتریان', short: 'مشتریان', icon: 'users' });
    if (can('visits')) items.push({ key: 'follow', label: 'پیگیری‌ها', short: 'پیگیری', icon: 'calendar', count: S.me.followups.length || '' });
    items.push({ key: 'orders', label: 'سفارش‌ها', short: 'سفارش‌ها', icon: 'package' });
    if (can('returns_view')) items.push({ key: 'returns', label: 'مرجوعی‌ها', short: 'مرجوعی', icon: 'return', count: S.me.stats.returns_pending || '' });
    if (can('leaderboard')) items.push({ key: 'top', label: 'برترین‌ها', short: 'برترین‌ها', icon: 'trophy', group: 'گزارش و ابزار' });
    if (can('sms_bulk')) items.push({ key: 'sms', label: 'پیامک گروهی', short: 'پیامک', icon: 'send', group: can('leaderboard') ? '' : 'گزارش و ابزار' });
    return items;
  }

  function shell() {
    var m = S.me;
    if (CFG.inAdmin) {
      app.classList.add('bws-ui');
      S.main = app;
      U.qsa('[data-spa-tab]').forEach(function (a) {
        a.addEventListener('click', function (e) { e.preventDefault(); tab(a.dataset.spaTab); if (history.replaceState) history.replaceState({}, '', a.href.split('#')[0]); });
      });
    } else {
      var items = navItems();
      var mob = ['dash', 'customers', 'new', 'follow', 'orders', 'returns', 'top'].filter(function (k) { return items.some(function (i) { return i.key === k; }); }).slice(0, 5);
      var f = U.frame(app, items, {
        brandTitle: CFG.company,
        brandSub: P().manager ? 'پنل مدیریت فروش' : 'پنل ویزیتور',
        chips: '<span class="bws-chip is-info">' + U.ic('user', 15) + ' ' + U.esc(m.user.name) + '</span>' +
          (CFG.admin ? '<a class="bws-chip bws-hide-m" href="' + U.esc(CFG.admin) + '">' + U.ic('settings', 15) + ' پنل مدیر</a>' : '') +
          '<a class="bws-btn bws-btn-sm" href="' + U.esc(m.logout) + '">' + U.ic('logout', 15) + ' <span class="bws-hide-m">خروج</span></a>',
        mobile: mob,
        foot: 'مطالبات من: ' + U.esc(m.stats.outstanding)
      });
      S.main = f.main;
      U.qsa('[data-nav]', app).forEach(function (b) { b.onclick = function () { tab(b.dataset.nav); try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch (e) {} }; });
    }
    var hash = (window.location.hash || '').replace('#', '');
    if (/^c\d+$/.test(hash)) { tab('customers', true); customer(+hash.slice(1)); }
    else if (/^r\d+$/.test(hash) && can('returns_view')) { tab('returns'); openReturn(+hash.slice(1)); }
    else tab(CFG.startTab || S.tab);
  }

  function tab(t, silent) {
    if (!TITLES[t]) t = 'dash';
    if (t === 'new' && !can('customers_create')) t = 'dash';
    if (t === 'sms' && !can('sms_bulk')) t = 'dash';
    if (t === 'top' && !can('leaderboard')) t = 'dash';
    if (t === 'follow' && !can('visits')) t = 'dash';
    if (t === 'returns' && !can('returns_view')) t = 'dash';
    S.tab = t; U.setActive(t);
    var el = S.main; el.onclick = null;
    if (silent) return;
    var T = TITLES[t];
    el.innerHTML = U.head(T[0], t === 'dash' ? 'سلام ' + S.me.user.name + '؛ ' + T[1] : T[1], T[2], headActions(t)) + '<div data-body></div>';
    U.qsa('[data-go]', el).forEach(function (b) { b.onclick = function () { tab(b.dataset.go); }; });
    var exp = U.qs('[data-export]', el); if (exp) exp.onclick = function () { exportCsv(exp); };
    var body = U.qs('[data-body]', el);
    ({ dash: dash, 'new': newCustomer, customers: customers, follow: followups, orders: orders, top: top, sms: bulkSms, returns: returnsTab })[t](body);
  }

  function headActions(t) {
    var a = '';
    if ((t === 'customers' || t === 'dash') && can('customers_create')) a += '<button class="bws-btn bws-btn-primary" data-go="new">' + U.ic('user-plus', 16) + ' ثبت مشتری جدید</button>';
    if (t === 'customers' && (P().manager || can('export'))) a += '<button class="bws-btn" data-export>' + U.ic('download', 16) + ' خروجی Excel</button>';
    if (t === 'returns' && P().manager) a += '<button class="bws-btn" data-rexport>' + U.ic('download', 16) + ' خروجی Excel مرجوعی‌ها</button>';
    return a;
  }

  function exportCsv(btn) {
    U.busy(btn, true);
    U.api('/staff/export').then(function (r) {
      U.busy(btn, false);
      var blob = new Blob([r.csv], { type: 'text/csv;charset=utf-8' }), a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = r.filename; document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    }).catch(function (e) { U.busy(btn, false); U.toast(e.message, 'error'); });
  }

  function notice() {
    return S.me.notice ? '<div class="bws-alert bws-alert-info bws-notice">' + U.ic('bell', 18) + '<div>' + S.me.notice + '</div></div>' : '';
  }

  /* ---------------- Dashboard ---------------- */
  function targetCard() {
    var t = S.me.target;
    if (!t || (!t.amount && !t.commission)) return '';
    var body = '';
    if (t.amount) {
      body += '<div class="bws-target"><div class="bws-target-row"><span>فروش این ماه: <b>' + U.esc(t.sales_text) + '</b></span><span>هدف: <b>' + U.esc(t.amount_text) + '</b></span></div>' +
        '<div class="bws-bar-track"><span style="width:' + t.percent + '%"></span></div><div class="bws-muted">' + U.fa(t.percent) + '٪ از هدف ماهانه' + (t.percent >= 100 ? ' — عالی! هدف این ماه محقق شد 🎉' : '') + '</div></div>';
    }
    if (t.commission) body += '<div class="bws-kv" style="margin-top:10px"><div><span>پورسانت این ماه (' + U.fa(t.commission) + '٪)</span><b class="bws-green">' + U.esc(t.commission_text) + '</b></div></div>';
    return U.card('هدف فروش ماهانه', 'ماه جاری شمسی', 'target', body);
  }

  function followList(list, compact) {
    if (!list.length) return U.empty('پیگیری عقب‌افتاده‌ای ندارید.', 'check-circle');
    return '<div class="bws-clist">' + list.map(function (f) {
      return '<div class="bws-crow" data-cid="' + f.customer_id + '"><span class="bws-avatar' + (f.overdue ? ' is-red' : '') + '">' + U.ic('calendar', 16) + '</span><div class="bws-crow-main"><b>' + U.esc(f.customer) + '</b>' + (f.shop ? ' <small class="bws-muted">' + U.esc(f.shop) + '</small>' : '') +
        '<div class="bws-muted"><span>' + U.ic('clock', 13) + ' موعد: ' + U.esc(f.follow_up) + (f.overdue ? ' <b class="bws-red">(گذشته)</b>' : '') + '</span><span>' + U.esc(f.result_label) + '</span>' + (f.note ? '<span>' + U.esc(f.note.slice(0, 60)) + '</span>' : '') + (P().manager ? '<span>' + U.ic('user', 13) + ' ' + U.esc(f.visitor) + '</span>' : '') + '</div></div>' +
        '<div class="bws-crow-side"><a class="bws-btn bws-btn-sm" href="tel:' + U.esc(f.mobile) + '" data-stop>' + U.ic('phone', 14) + '</a>' + (compact ? '' : '<button class="bws-btn bws-btn-sm" data-done="' + f.id + '">' + U.ic('check', 14) + ' انجام شد</button>') + '</div></div>';
    }).join('') + '</div>';
  }
  function bindFollow(root, after) {
    U.qsa('[data-stop]', root).forEach(function (a) { a.onclick = function (e) { e.stopPropagation(); }; });
    U.qsa('[data-done]', root).forEach(function (b) {
      b.onclick = function (e) {
        e.stopPropagation(); U.busy(b, true);
        U.api('/staff/visits/' + b.dataset.done + '/done', { method: 'POST' }).then(function () { U.toast('ثبت شد'); if (after) after(); }).catch(function (er) { U.busy(b, false); U.toast(er.message, 'error'); });
      };
    });
    bindList(root);
  }

  function dash(el) {
    var s = S.me.stats, p = P();
    var rp = can('returns_view') && s.returns_pending ? '<div class="bws-alert bws-alert-warn bws-ret-alert">' + U.ic('return', 18) + '<div><b>' + U.fa(s.returns_pending) + ' درخواست مرجوعی</b> در انتظار بررسی است.</div><button class="bws-btn bws-btn-sm" data-go="returns">مشاهده</button></div>' : '';
    el.innerHTML = notice() + rp + '<div class="bws-stats">' +
      U.stat('users', 'violet', 'مشتریان ثبت‌شده توسط من', U.fa(s.customers), U.fa(s.debtors) + ' مشتری بدهکار') +
      U.stat('trending', 'green', 'فروش ۳۰ روز اخیر', s.sales_30, U.fa(s.orders_30) + ' سفارش · ' + U.fa(s.qty_30) + ' عدد') +
      U.stat('package', 'blue', 'کل سفارش‌ها', U.fa(s.orders_total), 'مجموع: ' + s.sales_total) +
      U.stat('wallet', 'amber', 'مطالبات مشتریان من', s.outstanding, can('visits') ? U.fa(s.visits_today) + ' ویزیت امروز' : 'اعتبار مصرف‌شده') + '</div>' +
      '<div class="bws-grid bws-grid-2-1"><div>' +
      U.card('جستجوی سریع مشتری', 'نام، موبایل، کد یا بخشی از آدرس را بنویسید', 'search', U.searchbox('مثلاً ۰۹۱۲… یا نارمک', '', 'bws-quick-search') + '<div class="bws-quick-results" style="margin-top:12px"></div>') +
      (can('visits') ? U.card('پیگیری‌های امروز', S.me.followups.length ? U.fa(S.me.followups.length) + ' مورد' : '', 'calendar', '<div data-follow>' + followList(S.me.followups.slice(0, 5), true) + '</div>' + (S.me.followups.length > 5 ? '<button class="bws-btn bws-btn-sm bws-btn-block" data-go="follow" style="margin-top:10px">همه پیگیری‌ها</button>' : '')) : '') +
      (can('leaderboard') ? U.card('مشتریان برتر من', 'بیشترین خرید در این ماه', 'crown', '<div data-mytop><div class="bws-skeleton"></div><div class="bws-skeleton"></div></div>') : '') +
      '</div><div>' + targetCard() +
      (can('leaderboard') ? U.card('رتبه من بین ویزیتورها', 'بر اساس مبلغ فروش این ماه', 'trophy', '<div data-myrank><div class="bws-skeleton"></div></div>') : '') +
      U.card('دسترسی سریع', '', 'zap', '<div class="bws-actions" style="margin:0;flex-direction:column">' +
        (can('customers_create') ? '<button class="bws-btn bws-btn-primary bws-btn-block" data-go="new">' + U.ic('user-plus', 16) + ' ثبت مشتری جدید</button>' : '') +
        '<button class="bws-btn bws-btn-block" data-go="customers">' + U.ic('users', 16) + ' لیست مشتریان</button>' +
        (can('sms_bulk') ? '<button class="bws-btn bws-btn-block" data-go="sms">' + U.ic('send', 16) + ' ارسال لینک ورود به همه</button>' : '') + '</div>') +
      '</div></div>';
    U.qsa('[data-go]', el).forEach(function (b) { b.onclick = function () { tab(b.dataset.go); }; });
    var fl = U.qs('[data-follow]', el); if (fl) bindFollow(fl);
    var res = U.qs('.bws-quick-results', el);
    U.qs('.bws-quick-search', el).addEventListener('input', U.debounce(function (e) {
      var q = e.target.value.trim(); if (q.length < 2) { res.innerHTML = ''; return; }
      U.api('/staff/customers', { query: { search: U.en(q) } }).then(function (r) { res.innerHTML = custList(r.customers); bindList(res); });
    }, 300));
    if (!can('leaderboard')) return;
    U.api('/staff/leaderboard', { query: { period: 'month' } }).then(function (r) {
      var mt = U.qs('[data-mytop]', el);
      var mine = p.manager ? r.customers.slice(0, 5) : r.my_customers;
      if (mt) { mt.innerHTML = U.lbList(mine, 'customer'); bindLb(mt); }
      var mr = U.qs('[data-myrank]', el);
      if (mr) {
        var me = r.me;
        mr.innerHTML = (me ? '<div class="bws-hero' + (me.rank === 1 ? '' : ' is-blue') + '"><span class="bws-hero-ic">' + U.ic(me.rank === 1 ? 'trophy' : 'medal', 28) + '</span><div><small>رتبه شما</small><b>' + U.fa(me.rank) + '</b><span>' + U.esc(me.sales_text) + ' فروش</span></div></div>'
          : (p.manager ? '' : '<div class="bws-alert bws-alert-info">' + U.ic('info', 17) + '<div>هنوز در این ماه فروشی ثبت نکرده‌اید.</div></div>')) +
          U.lbList(r.visitors.slice(0, 5), 'visitor', S.me.user.id) +
          '<button class="bws-btn bws-btn-sm bws-btn-block" data-go="top" style="margin-top:10px">' + U.ic('trophy', 15) + ' مشاهده همه برترین‌ها</button>';
        U.qs('[data-go]', mr).onclick = function () { tab('top'); };
      }
    }).catch(function () {});
  }
  function bindLb(root) { U.qsa('[data-cid]', root).forEach(function (li) { li.onclick = function () { tab('customers', true); customer(+li.dataset.cid); }; }); }

  /* ---------------- Follow-ups ---------------- */
  function followups(el) {
    U.loading(el);
    function load() {
      U.api('/staff/followups').then(function (r) {
        S.me.followups = r.followups;
        el.innerHTML = U.card('', '', '', followList(r.followups, false));
        bindFollow(el, load);
      }).catch(function (e) { U.errorBox(el, e); });
    }
    load();
  }

  /* ---------------- Leaderboard ---------------- */
  function top(el) {
    var p = P();
    el.innerHTML = '<div class="bws-section-head" style="margin-top:0"><div></div><div data-per></div></div><div data-lb></div>';
    var lb = U.qs('[data-lb]', el);
    function load() {
      U.loading(lb);
      U.api('/staff/leaderboard', { query: { period: S.period } }).then(function (r) {
        U.qs('[data-per]', el).innerHTML = U.seg(r.periods, r.period, 'data-period');
        U.qsa('[data-period]', el).forEach(function (b) { b.onclick = function () { S.period = b.dataset.period; load(); }; });
        var left = U.card('ویزیتورهای برتر', 'بر اساس مجموع مبلغ سفارش‌های مشتریان هر ویزیتور', 'trophy', (p.manager || can('see_others_stats') ? U.lbHero(r.visitors[0], 'visitor') : '') + U.lbList(r.visitors, 'visitor', S.me.user.id));
        var right = U.card(p.manager || p.customers_view === 'all' ? 'مشتریان برتر' : 'مشتریان برتر من', 'بیشترین مبلغ خرید', 'crown', U.lbHero(r.customers[0], 'customer') + U.lbList(r.customers, 'customer'));
        lb.innerHTML = '<div class="bws-grid bws-grid-2"><div>' + left + '</div><div>' + right + '</div></div>';
        bindLb(lb);
      }).catch(function (e) { U.errorBox(lb, e); });
    }
    load();
  }

  /* ---------------- Customer form ---------------- */
  function customerForm(c, opts) {
    c = c || {}; opts = opts || {};
    var p = P(), canCredit = p.manager || can('credit_set'), canStatus = !opts.isNew && (p.manager || can('customers_status'));
    var prov = S.me.provinces.map(function (x) { return '<option ' + (c.province === x ? 'selected' : '') + '>' + U.esc(x) + '</option>'; }).join('');
    var f = function (name, label, attrs, val) { return '<label class="bws-field"><span>' + label + '</span><input name="' + name + '" ' + (attrs || '') + ' value="' + U.esc(val != null ? val : (c[name] || '')) + '"></label>'; };
    var maxHint = !p.manager && canCredit ? ' — حداکثر ' + U.esc(p.credit_max > 0 ? U.money(p.credit_max) : 'اعتبار پیش‌فرض') : '';
    var mgr = '';
    if (canCredit || canStatus || p.manager) {
      mgr = '<div class="bws-mgr"><div class="bws-form-grid">' +
        (canCredit ? '<label class="bws-field"><span>سقف اعتبار (' + U.esc(U.currency) + ')' + (opts.isNew ? ' — خالی = پیش‌فرض' : '') + maxHint + '</span><input name="credit_limit" inputmode="numeric" dir="ltr" value="' + (c.credit ? Math.round(c.credit.limit) : '') + '"></label>' : '') +
        (p.manager ? '<label class="bws-field"><span>تخفیف اختصاصی این مشتری (٪) — خالی = تخفیف عمومی</span><input name="discount" inputmode="decimal" dir="ltr" value="' + (c.discount != null ? U.esc(c.discount) : '') + '"></label>' : '') +
        (p.manager ? '<label class="bws-field"><span>ویزیتور مسئول</span><select name="visitor_id"><option value="0">— مدیر / بدون ویزیتور —</option>' + S.me.visitors.map(function (v) { return '<option value="' + v.id + '" ' + (+c.visitor_id === v.id ? 'selected' : '') + '>' + U.esc(v.name) + '</option>'; }).join('') + '</select></label>' : '') +
        (canStatus ? '<label class="bws-field"><span>وضعیت</span><select name="status"><option value="active" ' + (c.status === 'active' ? 'selected' : '') + '>فعال</option><option value="inactive" ' + (c.status === 'inactive' ? 'selected' : '') + '>غیرفعال</option></select></label>' : '') +
        '</div></div>';
    }
    return '<form class="bws-form"><div class="bws-form-grid">' +
      f('first_name', 'نام *', 'required maxlength="100"') + f('last_name', 'نام خانوادگی *', 'required maxlength="100"') +
      f('mobile', 'شماره موبایل * (برای پیامک و ورود)', 'required inputmode="tel" dir="ltr" placeholder="09xxxxxxxxx" maxlength="14"') + f('shop_name', 'نام فروشگاه / شرکت', 'maxlength="190"') +
      f('phone', 'تلفن ثابت', 'inputmode="tel" dir="ltr" maxlength="30"') +
      '<label class="bws-field"><span>استان</span><select name="province"><option value="">انتخاب…</option>' + prov + '</select></label>' +
      f('city', 'شهر', 'maxlength="100"') + f('postal_code', 'کد پستی', 'inputmode="numeric" dir="ltr" maxlength="12"') +
      '</div><label class="bws-field"><span>آدرس کامل *</span><textarea name="address" rows="2" required maxlength="1000">' + U.esc(c.address || '') + '</textarea></label>' +
      '<div class="bws-form-grid">' + f('national_id', 'کد ملی / شناسه', 'inputmode="numeric" dir="ltr" maxlength="12"') +
      '<label class="bws-field"><span>یادداشت داخلی</span><input name="notes" maxlength="1000" value="' + U.esc(c.notes || '') + '"></label></div>' + mgr +
      (opts.isNew && can('location') ? '<label class="bws-switch"><input type="checkbox" name="use_location"><span></span> ثبت موقعیت فعلی من به‌عنوان موقعیت فروشگاه (GPS)</label>' : '') +
      (opts.isNew ? '<label class="bws-switch"><input type="checkbox" name="send_sms" checked><span></span> ارسال پیامک خوش‌آمد با کد اختصاصی و لینک ورود</label>' : '') +
      '<div class="bws-actions"><button class="bws-btn bws-btn-primary bws-btn-lg" type="submit">' + U.ic(opts.isNew ? 'key' : 'save', 18) + ' ' + (opts.isNew ? 'ثبت مشتری و صدور کد' : 'ذخیره تغییرات') + '</button>' + (opts.cancel ? '<button type="button" class="bws-btn bws-btn-lg" data-cancel>انصراف</button>' : '') + '</div></form>';
  }

  function geo() {
    return new Promise(function (res, rej) {
      if (!navigator.geolocation) { rej(new Error('مرورگر شما موقعیت‌یابی را پشتیبانی نمی‌کند.')); return; }
      navigator.geolocation.getCurrentPosition(function (p) { res({ lat: p.coords.latitude, lng: p.coords.longitude }); },
        function () { rej(new Error('دسترسی به موقعیت مکانی داده نشد (GPS را روشن کنید و اجازه دسترسی بدهید).')); },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 });
    });
  }

  function newCustomer(el) {
    el.innerHTML = U.card('اطلاعات مشتری', 'فیلدهای ستاره‌دار الزامی است', 'user', customerForm({}, { isNew: true }));
    var form = U.qs('form', el);
    form.onsubmit = function (e) {
      e.preventDefault(); var b = U.qs('[type=submit]', form); U.busy(b, true);
      var data = U.formData(form);
      var withLoc = data.use_location ? geo().then(function (g) { data.lat = g.lat; data.lng = g.lng; }, function (er) { U.toast(er.message, 'warn'); }) : Promise.resolve();
      delete data.use_location;
      withLoc.then(function () { return U.api('/staff/customers', { method: 'POST', body: data }); }).then(function (r) {
        created(el, r.customer, r.print);
      }).catch(function (er) {
        U.busy(b, false);
        var d = er.data && er.data.data;
        if (d && d.customer_id) {
          U.qs('[data-open]', U.modal('مشتری تکراری', '<div class="bws-alert bws-alert-warn">' + U.ic('alert', 18) + '<div>' + U.esc(er.message) + '</div></div><button class="bws-btn bws-btn-primary" data-open>' + U.ic('eye', 16) + ' مشاهده این مشتری</button>').el).onclick = function () {
            U.closeModals(); tab('customers', true); customer(d.customer_id);
          };
        } else U.toast(er.message, 'error');
      });
    };
  }

  function created(el, c, print) {
    S.me.stats.customers++;
    el.innerHTML = U.card('', '', '', '<div class="bws-created"><div class="bws-success">' + U.ic('check-circle', 24) + ' مشتری با موفقیت ثبت شد</div><h3>' + U.esc(c.full_name) + (c.shop_name ? ' — ' + U.esc(c.shop_name) : '') + '</h3>' +
      '<div class="bws-big-code">' + U.esc(c.code) + '</div><p class="bws-muted">این کد را به مشتری بدهید؛ با آن وارد پنل خرید می‌شود.</p>' +
      '<div class="bws-actions bws-center">' + (print ? '<a class="bws-btn bws-btn-primary" target="_blank" href="' + U.esc(print.thermal) + '">' + U.ic('printer', 16) + ' چاپ فیش ۸۰ میلی‌متری</a><a class="bws-btn" target="_blank" href="' + U.esc(print.a5) + '">' + U.ic('printer', 16) + ' چاپ کارت A5</a>' : '') +
      (can('sms_single') ? '<button class="bws-btn" data-sms>' + U.ic('send', 16) + ' ارسال مجدد پیامک کد</button>' : '') + '<button class="bws-btn" data-copy>' + U.ic('copy', 16) + ' کپی لینک ورود</button></div>' +
      '<div class="bws-actions bws-center">' + (can('orders_place') ? '<button class="bws-btn bws-btn-dark" data-order>' + U.ic('cart', 16) + ' ثبت سفارش برای این مشتری</button>' : '') + '<button class="bws-btn" data-open>' + U.ic('user', 16) + ' پرونده مشتری</button><button class="bws-btn" data-new>' + U.ic('plus', 16) + ' ثبت مشتری بعدی</button></div></div>');
    var sm = U.qs('[data-sms]', el); if (sm) sm.onclick = function (e) { sendSms(c.id, 'welcome', e.currentTarget); };
    U.qs('[data-copy]', el).onclick = function () { U.copy(c.link); };
    var od = U.qs('[data-order]', el); if (od) od.onclick = function () { tab('customers', true); placeOrder(c.id); };
    U.qs('[data-open]', el).onclick = function () { tab('customers', true); customer(c.id); };
    U.qs('[data-new]', el).onclick = function () { tab('new'); };
  }

  /* ---------------- Customers list ---------------- */
  function custList(list) {
    if (!list.length) return U.empty('مشتری‌ای یافت نشد.', 'users');
    return '<div class="bws-clist">' + list.map(function (c) {
      return '<div class="bws-crow" data-cid="' + c.id + '"><span class="bws-avatar">' + U.esc(U.initial(c.first_name || c.full_name)) + '</span><div class="bws-crow-main"><b>' + U.esc(c.full_name) + '</b>' + (c.shop_name ? ' <small class="bws-muted">' + U.esc(c.shop_name) + '</small>' : '') +
        (c.status !== 'active' ? ' <span class="bws-badge bws-st-inactive">غیرفعال</span>' : '') + (c.is_mine ? ' <span class="bws-badge bws-st-mine">مشتری من</span>' : '') + (c.overdue ? ' <span class="bws-badge bws-st-failed">سررسید گذشته</span>' : '') + (c.discount != null ? ' <span class="bws-badge">تخفیف ' + U.fa(c.discount) + '٪</span>' : '') +
        '<div class="bws-muted"><span>' + U.ic('phone', 13) + ' <span class="bws-ltr">' + U.esc(c.mobile) + '</span></span><span>' + U.ic('key', 13) + ' <b class="bws-ltr">' + U.esc(c.code) + '</b></span><span>' + U.ic('map-pin', 13) + ' ' + U.esc([c.city, (c.address || '').slice(0, 38)].filter(Boolean).join('، ')) + '</span><span>' + U.ic('user', 13) + ' ' + U.esc(c.visitor_name) + '</span></div></div>' +
        '<div class="bws-crow-side">' + (c.credit.debt > 0 ? '<b class="bws-red">بدهی ' + U.esc(c.credit.debt_text) + '</b>' : '<b class="bws-green">بدون بدهی</b>') +
        '<span class="bws-muted">مانده اعتبار: ' + U.esc(c.credit.available_text) + '</span></div></div>';
    }).join('') + '</div>';
  }
  function bindList(el) {
    U.qsa('.bws-crow', el).forEach(function (r) { r.onclick = function () { if (S.tab !== 'customers') tab('customers', true); customer(+r.dataset.cid); }; });
  }

  function customers(el) {
    var p = P(), L = S.list, all = p.manager || p.customers_view === 'all';
    el.innerHTML = '<div class="bws-filters">' + U.searchbox('جستجو: نام، موبایل، کد، آدرس، شهر…', L.search) +
      (all && S.me.visitors.length ? '<select data-f="visitor"><option value="">همه ویزیتورها</option><option value="0">بدون ویزیتور</option>' + S.me.visitors.map(function (v) { return '<option value="' + v.id + '" ' + (String(L.visitor) === String(v.id) ? 'selected' : '') + '>' + U.esc(v.name) + '</option>'; }).join('') + '</select>' : '') +
      '<select data-f="province"><option value="">همه استان‌ها</option>' + S.me.provinces.map(function (x) { return '<option ' + (L.province === x ? 'selected' : '') + '>' + U.esc(x) + '</option>'; }).join('') + '</select>' +
      (p.manager || can('customers_status') ? '<select data-f="status"><option value="">همه وضعیت‌ها</option><option value="active" ' + (L.status === 'active' ? 'selected' : '') + '>فعال</option><option value="inactive" ' + (L.status === 'inactive' ? 'selected' : '') + '>غیرفعال</option></select>' : '') +
      '<select data-f="orderby"><option value="id">جدیدترین</option><option value="balance" ' + (L.orderby === 'balance' ? 'selected' : '') + '>بیشترین بدهی</option><option value="last_order_at" ' + (L.orderby === 'last_order_at' ? 'selected' : '') + '>آخرین سفارش</option></select></div>' +
      '<div class="bws-filters">' + (all ? '<label class="bws-switch"><input type="checkbox" data-f="mine" ' + (L.mine ? 'checked' : '') + '><span></span> فقط مشتریان من</label>' : '') +
      '<label class="bws-switch"><input type="checkbox" data-f="debt" ' + (L.debt ? 'checked' : '') + '><span></span> فقط بدهکاران</label></div><div class="bws-list"></div>';
    var list = U.qs('.bws-list', el);
    function load() {
      U.loading(list);
      U.api('/staff/customers', { query: { search: U.en(L.search), mine: L.mine, debt: L.debt, page: L.page, visitor: L.visitor, status: L.status, orderby: L.orderby, province: L.province } }).then(function (r) {
        list.innerHTML = '<p class="bws-muted">' + U.fa(r.total) + ' مشتری</p>' + custList(r.customers) + pager(r.page, r.pages);
        bindList(list);
        U.qsa('[data-page]', list).forEach(function (b) { b.onclick = function () { L.page = +b.dataset.page; load(); }; });
      }).catch(function (e) { U.errorBox(list, e); });
    }
    U.qs('.bws-search', el).addEventListener('input', U.debounce(function (e) { L.search = e.target.value; L.page = 1; load(); }, 350));
    U.qsa('[data-f]', el).forEach(function (i) {
      i.onchange = function () { L[i.dataset.f] = i.type === 'checkbox' ? (i.checked ? 1 : 0) : i.value; L.page = 1; load(); };
    });
    load();
  }

  function pager(page, pages) {
    if (pages <= 1) return '';
    return '<div class="bws-pager">' + (page > 1 ? '<button class="bws-btn bws-btn-sm" data-page="' + (page - 1) + '">قبلی</button>' : '') +
      '<span>صفحه ' + U.fa(page) + ' از ' + U.fa(pages) + '</span>' + (page < pages ? '<button class="bws-btn bws-btn-sm" data-page="' + (page + 1) + '">بعدی</button>' : '') + '</div>';
  }

  /* ---------------- Customer detail ---------------- */
  function customer(id) {
    var el = S.main; el.onclick = null; U.loading(el);
    if (history.replaceState) history.replaceState({}, '', '#c' + id);
    U.api('/staff/customers/' + id).then(function (r) { renderCustomer(el, r); }).catch(function (e) { U.errorBox(el, e); });
  }

  function mapLink(c) {
    if (c.lat != null) return '<a target="_blank" rel="noopener" href="https://www.google.com/maps?q=' + c.lat + ',' + c.lng + '">' + U.ic('map-pin', 13) + ' موقعیت ثبت‌شده روی نقشه</a> · <a target="_blank" rel="noopener" href="https://nshn.ir/?lat=' + c.lat + '&lng=' + c.lng + '">نشان</a> · <a target="_blank" rel="noopener" href="https://balad.ir/location?latitude=' + c.lat + '&longitude=' + c.lng + '">بلد</a>';
    return '<a target="_blank" rel="noopener" href="https://www.google.com/maps/search/' + encodeURIComponent([c.city, c.address].join(' ')) + '">جستجوی آدرس روی نقشه</a>';
  }

  function renderCustomer(el, r) {
    var c = r.customer, p = P(), k = c.can || {};
    var addr = [c.province, c.city, c.address].filter(Boolean).join('، ');
    var subs = '<button class="is-active" data-st="orders">سفارش‌ها (' + U.fa(r.orders.length) + ')</button>' + (k.ledger ? '<button data-st="ledger">گردش حساب</button>' : '') + (k.visits ? '<button data-st="visits">ویزیت‌ها (' + U.fa(r.visits.length) + ')</button>' : '') + '<button data-st="sms">پیامک‌ها</button>' + (k.returns ? '<button data-st="returns">مرجوعی‌ها</button>' : '');
    el.innerHTML = '<div class="bws-page-head"><div><button class="bws-btn bws-btn-sm bws-btn-ghost" data-back>→ بازگشت به لیست</button></div><div class="bws-page-actions">' +
      (k.order && c.status === 'active' ? '<button class="bws-btn bws-btn-primary" data-a="order">' + U.ic('cart', 16) + ' ثبت سفارش</button>' : '') +
      (k.payment ? '<button class="bws-btn bws-btn-success" data-a="pay">' + U.ic('cash', 16) + ' ثبت پرداخت</button>' : '') +
      (k.visits ? '<button class="bws-btn" data-a="visit">' + U.ic('calendar', 16) + ' ثبت ویزیت</button>' : '') +
      (k.return_new && c.status === 'active' ? '<button class="bws-btn" data-a="ret">' + U.ic('return', 16) + ' ثبت مرجوعی</button>' : '') + '</div></div>' +
      '<div class="bws-grid bws-grid-2-1"><div>' +
      U.card('', '', '', '<div class="bws-cust-head"><div class="bws-cust-id"><span class="bws-avatar">' + U.esc(U.initial(c.first_name || c.full_name)) + '</span><div><h2>' + U.esc(c.full_name) + ' ' + U.statusBadge(c.status, c.status === 'active' ? 'فعال' : 'غیرفعال') + (c.overdue ? ' ' + U.statusBadge('failed', 'سررسید گذشته') : '') + '</h2>' +
        '<div class="bws-muted">' + (c.shop_name ? U.esc(c.shop_name) + ' · ' : '') + 'ویزیتور: ' + U.esc(c.visitor_name) + ' · ثبت: ' + U.esc(c.created_at) + (c.discount != null ? ' · تخفیف اختصاصی ' + U.fa(c.discount) + '٪' : '') + '</div></div></div><div class="bws-big-code sm">' + U.esc(c.code) + '</div></div>' +
        '<div class="bws-kv"><div><span>' + U.ic('phone', 13) + ' موبایل</span><a href="tel:' + U.esc(c.mobile) + '" class="bws-ltr">' + U.esc(c.mobile) + '</a></div>' + (c.phone ? '<div><span>' + U.ic('phone', 13) + ' تلفن</span><a href="tel:' + U.esc(c.phone) + '" class="bws-ltr">' + U.esc(c.phone) + '</a></div>' : '') +
        '<div style="grid-column:1/-1"><span>' + U.ic('map-pin', 13) + ' آدرس</span>' + U.esc(addr) + '<br><small>' + mapLink(c) + '</small></div>' +
        (c.postal_code ? '<div><span>کد پستی</span>' + U.esc(c.postal_code) + '</div>' : '') + '<div><span>آخرین ورود</span>' + U.esc(c.last_login) + '</div><div><span>آخرین سفارش</span>' + U.esc(c.last_order) + '</div>' + (c.notes ? '<div style="grid-column:1/-1"><span>یادداشت</span>' + U.esc(c.notes) + '</div>' : '') + '</div>' +
        '<div class="bws-actions" style="margin-bottom:0">' + (k.sms ? '<button class="bws-btn bws-btn-sm" data-a="sms">' + U.ic('send', 15) + ' پیامک</button>' : '') +
        (r.print ? '<a class="bws-btn bws-btn-sm" target="_blank" href="' + U.esc(r.print.thermal) + '">' + U.ic('printer', 15) + ' فیش ۸۰mm</a><a class="bws-btn bws-btn-sm" target="_blank" href="' + U.esc(r.print.a5) + '">' + U.ic('printer', 15) + ' کارت A5</a>' : '') +
        '<button class="bws-btn bws-btn-sm" data-a="copy">' + U.ic('link', 15) + ' کپی لینک ورود</button>' + (c.can_edit ? '<button class="bws-btn bws-btn-sm" data-a="edit">' + U.ic('edit', 15) + ' ویرایش</button>' : '') +
        (k.location ? '<button class="bws-btn bws-btn-sm" data-a="loc">' + U.ic('map-pin', 15) + ' ' + (c.lat != null ? 'به‌روزرسانی موقعیت' : 'ثبت موقعیت GPS') + '</button>' : '') +
        (k.code ? '<button class="bws-btn bws-btn-sm" data-a="code">' + U.ic('refresh', 15) + ' تغییر کد</button>' : '') +
        (p.manager ? '<button class="bws-btn bws-btn-sm" data-a="adjust">' + U.ic('edit', 15) + ' اصلاح حساب</button><button class="bws-btn bws-btn-sm bws-btn-danger" data-a="del">' + U.ic('trash', 15) + ' حذف</button>' : '') + '</div>') +
      '</div><div>' + U.creditCard(c.credit) + '</div></div>' +
      '<div class="bws-section-head"><div class="bws-seg">' + subs + '</div></div><div class="bws-subbody"></div>';
    var sub = U.qs('.bws-subbody', el);
    function visitsHtml() {
      if (!r.visits.length) return U.empty('ویزیتی ثبت نشده است.', 'calendar');
      return U.card('', '', '', '<div class="bws-table-wrap"><table class="bws-table stack"><thead><tr><th>تاریخ</th><th>نتیجه</th><th>توضیح</th><th>پیگیری بعدی</th><th>ویزیتور</th></tr></thead><tbody>' + r.visits.map(function (v) {
        return '<tr><td data-l="تاریخ">' + U.esc(v.date) + (v.map ? ' <a target="_blank" rel="noopener" href="' + U.esc(v.map) + '">' + U.ic('map-pin', 13) + '</a>' : '') + '</td><td data-l="نتیجه">' + U.esc(v.result_label) + '</td><td data-l="توضیح" class="bws-pre">' + U.esc(v.note) + '</td><td data-l="پیگیری">' + (v.follow_up ? U.esc(v.follow_up) + (v.follow_done ? ' ✓' : '') : '—') + '</td><td data-l="ویزیتور">' + U.esc(v.visitor) + '</td></tr>';
      }).join('') + '</tbody></table></div>', { cls: 'bws-card-flush' });
    }
    function subtab(t) {
      U.qsa('[data-st]', el).forEach(function (b) { b.classList.toggle('is-active', b.dataset.st === t); });
      if (t === 'orders') sub.innerHTML = U.orderCards(r.orders, {});
      if (t === 'ledger') sub.innerHTML = U.card('', '', '', U.ledgerTable(r.ledger), { cls: 'bws-card-flush' });
      if (t === 'visits') sub.innerHTML = visitsHtml();
      if (t === 'returns') { sub.innerHTML = '<div data-rl></div>'; returnsList(U.qs('[data-rl]', sub), { customer: c.id }); }
      if (t === 'sms') sub.innerHTML = r.sms.length ? U.card('', '', '', '<div class="bws-table-wrap"><table class="bws-table stack"><thead><tr><th>تاریخ</th><th>نوع</th><th>متن</th><th>وضعیت</th></tr></thead><tbody>' + r.sms.map(function (s) { return '<tr><td data-l="تاریخ">' + U.esc(s.date) + '</td><td data-l="نوع">' + U.esc(s.context) + '</td><td data-l="متن" class="bws-pre">' + U.esc(s.text) + '</td><td data-l="وضعیت">' + smsStatus(s.status) + '</td></tr>'; }).join('') + '</tbody></table></div>', { cls: 'bws-card-flush' }) : U.empty('پیامکی ارسال نشده است.', 'message');
    }
    U.qsa('[data-st]', el).forEach(function (b) { b.onclick = function () { subtab(b.dataset.st); }; });
    subtab('orders');
    sub.onclick = function (e) {
      var b = e.target.closest('[data-act]'); if (!b || !b.closest('[data-order]')) return;
      var oid = b.closest('[data-order]').dataset.order;
      if (b.dataset.act === 'detail') orderDetail(oid, c);
      if (b.dataset.act === 'cancel') cancelOrder(oid, function () { customer(c.id); });
    };
    U.qs('[data-back]', el).onclick = function () { if (history.replaceState) history.replaceState({}, '', '#'); tab('customers'); };
    U.qsa('[data-a]', el).forEach(function (b) {
      b.onclick = function () {
        var a = b.dataset.a;
        if (a === 'order') placeOrder(c.id);
        if (a === 'ret') newReturn(c.id, 0, function () { customer(c.id); });
        if (a === 'pay') payment(c, false);
        if (a === 'adjust') payment(c, true);
        if (a === 'sms') smsDialog(c);
        if (a === 'visit') visitDialog(c);
        if (a === 'copy') U.copy(c.link);
        if (a === 'edit') editCustomer(c);
        if (a === 'loc') {
          U.busy(b, true);
          geo().then(function (g) { return U.api('/staff/customers/' + c.id + '/location', { method: 'POST', body: g }); })
            .then(function () { U.toast('موقعیت فروشگاه ثبت شد'); customer(c.id); })
            .catch(function (e) { U.busy(b, false); U.toast(e.message, 'error'); });
        }
        if (a === 'code') U.confirm('کد جدید ساخته شود؟ کد قبلی دیگر کار نمی‌کند و کد جدید برای مشتری پیامک می‌شود.', function () {
          U.api('/staff/customers/' + c.id + '/code', { method: 'POST', body: { notify: 1 } }).then(function () { U.toast('کد جدید ساخته شد'); customer(c.id); }).catch(function (e) { U.toast(e.message, 'error'); });
        });
        if (a === 'del') U.confirm('مشتری «' + c.full_name + '» حذف شود؟ این کار قابل بازگشت نیست.', function () {
          U.api('/staff/customers/' + c.id + '/delete', { method: 'POST' }).then(function () { U.toast('حذف شد'); tab('customers'); }).catch(function (e) { U.toast(e.message, 'error'); });
        });
      };
    });
  }
  function smsStatus(s) {
    var m = { sent: ['ارسال شد', 'completed'], failed: ['ناموفق', 'failed'], test: ['حالت تست', 'pending'], disabled: ['پیامک غیرفعال', 'pending'] }[s] || [s, ''];
    return U.statusBadge(m[1], m[0]);
  }

  function visitDialog(c) {
    var res = S.me.results, opts = Object.keys(res).map(function (k) { return '<option value="' + k + '">' + U.esc(res[k]) + '</option>'; }).join('');
    var m = U.modal('ثبت ویزیت — ' + c.full_name, '<form><label class="bws-field"><span>نتیجه مراجعه</span><select name="result">' + opts + '</select></label>' +
      '<label class="bws-field"><span>توضیحات</span><textarea name="note" rows="3" maxlength="1000"></textarea></label>' +
      '<label class="bws-field"><span>تاریخ پیگیری بعدی (اختیاری) — مثل ۱۴۰۵/۰۸/۱۵</span><input name="follow_up" dir="ltr" placeholder="1405/08/15"></label>' +
      '<div class="bws-quick" style="position:static;margin:0 0 10px">' + [1, 3, 7, 14, 30].map(function (d) { return '<button type="button" data-days="' + d + '">' + U.fa(d) + ' روز بعد</button>'; }).join('') + '</div>' +
      (can('location') ? '<label class="bws-switch"><input type="checkbox" name="with_loc"><span></span> ثبت موقعیت فعلی من برای این ویزیت</label>' : '') +
      '<button class="bws-btn bws-btn-primary bws-btn-block" style="margin-top:12px">' + U.ic('save', 16) + ' ثبت ویزیت</button></form>');
    var f = U.qs('form', m.el);
    U.qsa('[data-days]', f).forEach(function (b) { b.onclick = function () { f.follow_up.value = '+' + b.dataset.days; U.qsa('[data-days]', f).forEach(function (x) { x.classList.toggle('is-active', x === b); }); }; });
    f.onsubmit = function (e) {
      e.preventDefault(); var b = U.qs('button:not([data-days])', f); U.busy(b, true);
      var d = U.formData(f), w = d.with_loc; delete d.with_loc;
      (w ? geo().then(function (g) { d.lat = g.lat; d.lng = g.lng; }, function (er) { U.toast(er.message, 'warn'); }) : Promise.resolve())
        .then(function () { return U.api('/staff/customers/' + c.id + '/visit', { method: 'POST', body: d }); })
        .then(function (r) { m.close(); U.toast(r.message); customer(c.id); })
        .catch(function (er) { U.busy(b, false); U.toast(er.message, 'error'); });
    };
  }

  function editCustomer(c) {
    var m = U.modal('ویرایش اطلاعات مشتری', customerForm(c, { cancel: true }), { wide: true });
    var form = U.qs('form', m.el);
    U.qs('[data-cancel]', m.el).onclick = m.close;
    form.onsubmit = function (e) {
      e.preventDefault(); var b = U.qs('[type=submit]', form); U.busy(b, true);
      U.api('/staff/customers/' + c.id, { method: 'POST', body: U.formData(form) }).then(function () { m.close(); U.toast('ذخیره شد'); customer(c.id); })
        .catch(function (er) { U.busy(b, false); U.toast(er.message, 'error'); });
    };
  }

  function payment(c, adjust) {
    var methods = Object.keys(S.me.methods).map(function (k) { return '<option value="' + k + '">' + U.esc(S.me.methods[k]) + '</option>'; }).join('');
    var html = adjust
      ? '<form><div class="bws-alert bws-alert-info">' + U.ic('info', 17) + '<div>عدد مثبت = افزایش بدهی، عدد منفی = کاهش بدهی (برای مانده اول دوره یا اصلاح اشتباه).</div></div><label class="bws-field"><span>مبلغ (' + U.esc(U.currency) + ')</span><input name="amount" dir="ltr" required></label><label class="bws-field"><span>شرح *</span><input name="note" required></label><input type="hidden" name="kind" value="adjust"><button class="bws-btn bws-btn-primary bws-btn-block">' + U.ic('save', 16) + ' ثبت اصلاحیه</button></form>'
      : '<form><div class="bws-kv"><div><span>بدهی فعلی</span><b class="bws-red">' + U.esc(c.credit.debt_text) + '</b></div><div><span>اعتبار فعلی</span><b class="bws-green">' + U.esc(c.credit.available_text) + '</b></div></div><label class="bws-field"><span>مبلغ دریافتی (' + U.esc(U.currency) + ')</span><input name="amount" inputmode="numeric" dir="ltr" required value="' + (c.credit.debt > 0 ? Math.round(c.credit.debt) : '') + '"></label>' +
        '<div class="bws-form-grid"><label class="bws-field"><span>روش پرداخت</span><select name="method">' + methods + '</select></label><label class="bws-field"><span>شماره پیگیری / چک</span><input name="reference" maxlength="190"></label></div>' +
        '<label class="bws-field"><span>توضیحات</span><input name="note" maxlength="500"></label><label class="bws-switch"><input type="checkbox" name="notify" checked><span></span> ارسال پیامک تأیید پرداخت به مشتری</label><input type="hidden" name="kind" value="payment">' +
        '<button class="bws-btn bws-btn-success bws-btn-lg bws-btn-block" style="margin-top:12px">' + U.ic('check-circle', 17) + ' ثبت پرداخت</button></form>';
    var m = U.modal(adjust ? 'اصلاح دستی حساب' : 'ثبت پرداخت / تسویه بدهی', html);
    var f = U.qs('form', m.el);
    f.onsubmit = function (e) {
      e.preventDefault(); var b = U.qs('button', f); U.busy(b, true);
      U.api('/staff/customers/' + c.id + '/payment', { method: 'POST', body: U.formData(f) }).then(function () { m.close(); U.toast('ثبت شد'); customer(c.id); })
        .catch(function (er) { U.busy(b, false); U.toast(er.message, 'error'); });
    };
  }

  function sendSms(id, kind, btn, text) {
    U.busy(btn, true);
    return U.api('/staff/customers/' + id + '/sms', { method: 'POST', body: { kind: kind, text: text || '' } }).then(function (r) { U.busy(btn, false); U.toast(r.message, r.result.sent ? 'ok' : 'error'); return r; })
      .catch(function (e) { U.busy(btn, false); U.toast(e.message, 'error'); });
  }

  function smsDialog(c) {
    var T = S.me.templates, k = c.can || {};
    var m = U.modal('ارسال پیامک به ' + c.full_name, '<div class="bws-actions" style="margin-top:0">' +
      '<button class="bws-btn" data-k="login_link">' + U.ic('link', 15) + ' ' + U.esc(T.login_link.label) + '</button><button class="bws-btn" data-k="welcome">' + U.ic('sparkles', 15) + ' ' + U.esc(T.welcome.label) + '</button><button class="bws-btn" data-k="reminder">' + U.ic('bell', 15) + ' ' + U.esc(T.reminder.label) + '</button></div>' +
      (k.sms_text ? '<label class="bws-field"><span>یا پیام دلخواه</span><textarea rows="4" name="text" maxlength="900"></textarea><small>متغیرها مثل {name} و {code} قابل استفاده‌اند.</small></label><button class="bws-btn bws-btn-primary" data-k="custom">' + U.ic('send', 15) + ' ارسال پیام دلخواه</button>' : ''));
    U.qsa('[data-k]', m.el).forEach(function (b) {
      b.onclick = function () { var ta = U.qs('textarea', m.el); sendSms(c.id, b.dataset.k, b, ta ? ta.value : '').then(function (r) { if (r && r.result.sent) m.close(); }); };
    });
  }

  function placeOrder(id) {
    var el = S.main; el.onclick = null; U.loading(el);
    U.api('/staff/customers/' + id).then(function (r) {
      var cust = r.customer;
      el.innerHTML = '<div class="bws-page-head"><div><h1>' + U.ic('cart', 22) + ' ثبت سفارش برای ' + U.esc(cust.full_name) + '</h1><p>' + (cust.shop_name ? U.esc(cust.shop_name) + ' · ' : '') + 'کد ' + U.esc(cust.code) + (cust.discount != null ? ' · تخفیف اختصاصی ' + U.fa(cust.discount) + '٪' : '') + '</p></div><div class="bws-page-actions"><button class="bws-btn" data-back>' + U.ic('user', 16) + ' بازگشت به پرونده</button></div></div>' +
        U.creditCard(cust.credit) + '<div class="bws-shop-host"></div>';
      U.qs('[data-back]', el).onclick = function () { customer(id); };
      U.Shop({
        el: U.qs('.bws-shop-host', el), credit: cust.credit, settings: S.me.settings, cart: cust.cart || {}, staff: true, customerId: id,
        saveCart: function (cart) { U.api('/staff/customers/' + id + '/cart', { method: 'POST', body: { items: cart } }).catch(function () {}); },
        quote: function (items) { return U.api('/staff/customers/' + id + '/quote', { method: 'POST', body: { items: items } }); },
        submit: function (items, method, note) { return U.api('/staff/customers/' + id + '/order', { method: 'POST', body: { items: items, excess_method: method, note: note } }); },
        onDone: function () { setTimeout(function () { U.closeModals(); customer(id); }, 1600); }
      });
    }).catch(function (e) { U.errorBox(el, e); });
  }

  /* ---------------- Orders ---------------- */
  function orders(el) {
    var p = P(), L = S.olist;
    el.innerHTML = '<div class="bws-filters">' + U.searchbox('جستجو: شماره سفارش، نام، موبایل، کد…', L.search) +
      '<select data-f="status"><option value="">همه وضعیت‌ها</option><option value="pending">در انتظار پرداخت</option><option value="processing">در حال انجام</option><option value="on-hold">در انتظار بررسی</option><option value="completed">تکمیل شده</option><option value="cancelled">لغو شده</option></select>' +
      (p.orders_view === 'all' ? '<label class="bws-switch"><input type="checkbox" data-f="mine" ' + (L.mine ? 'checked' : '') + '><span></span> فقط مشتریان من</label>' : '') + '</div><div class="bws-list"></div>';
    var list = U.qs('.bws-list', el);
    function load() {
      U.loading(list);
      U.api('/staff/orders', { query: { search: U.en(L.search), mine: L.mine, page: L.page, status: L.status } }).then(function (r) {
        list.innerHTML = '<p class="bws-muted">' + U.fa(r.total) + ' سفارش</p>' + U.orderCards(r.orders, { showCustomer: true }) + pager(L.page, r.pages);
        U.qsa('[data-page]', list).forEach(function (b) { b.onclick = function () { L.page = +b.dataset.page; load(); }; });
      }).catch(function (e) { U.errorBox(list, e); });
    }
    list.onclick = function (e) {
      var b = e.target.closest('[data-act]'); if (!b) return;
      var oid = b.closest('[data-order]').dataset.order;
      if (b.dataset.act === 'detail') orderDetail(oid);
      if (b.dataset.act === 'cancel') cancelOrder(oid, load);
    };
    U.qs('.bws-search', el).addEventListener('input', U.debounce(function (e) { L.search = e.target.value; L.page = 1; load(); }, 350));
    U.qsa('[data-f]', el).forEach(function (i) { i.onchange = function () { L[i.dataset.f] = i.type === 'checkbox' ? (i.checked ? 1 : 0) : i.value; L.page = 1; load(); }; });
    load();
  }

  function cancelOrder(id, after) {
    U.cancelOrder(id, true, function (reason, notify) {
      return U.api('/staff/orders/' + id + '/cancel', { method: 'POST', body: { reason: reason, notify: notify ? 1 : 0 } }).then(function (r) { U.closeModals(); if (after) after(); return r; });
    });
  }

  function orderDetail(id, cust) {
    var m = U.modal('سفارش #' + U.fa(id), '<div class="bws-loading"><span class="bws-spinner"></span></div>', { wide: true });
    U.api('/staff/orders/' + id).then(function (r) {
      var canRe = S.me.settings.allow_reorder && cust && cust.can && cust.can.order && cust.status === 'active';
      m.el.innerHTML = '<p style="margin-top:0"><b>' + U.esc(r.order.customer) + '</b> — کد <span class="bws-ltr">' + U.esc(r.order.code) + '</span></p>' + U.orderDetail(r.order, can('print') ? CFG.printOrder + '&order=' + id : '') +
        '<div class="bws-actions">' + (canRe ? '<button class="bws-btn bws-btn-primary" data-re>' + U.ic('refresh', 15) + ' تکرار این سفارش</button>' : '') +
        (r.order.can_cancel ? '<button class="bws-btn bws-btn-danger" data-cancel>' + U.ic('x-circle', 15) + ' لغو سفارش</button>' : '') +
        (cust && cust.can && cust.can.return_new && r.order.kind === 'order' && ['processing', 'completed', 'on-hold'].indexOf(r.order.status) > -1 ? '<button class="bws-btn" data-ret>' + U.ic('return', 15) + ' ثبت مرجوعی</button>' : '') +
        (P().manager ? '<a class="bws-btn bws-btn-sm" href="' + U.esc(CFG.adminOrder.replace('__ID__', id)) + '" target="_blank">' + U.ic('external', 15) + ' مدیریت در ووکامرس</a>' : '') + '</div>';
      var rt = U.qs('[data-ret]', m.el);
      if (rt) rt.onclick = function () { m.close(); newReturn(cust.id, +id, function () { customer(cust.id); }); };
      var cx = U.qs('[data-cancel]', m.el);
      if (cx) cx.onclick = function () { cancelOrder(id, function () { if (cust) customer(cust.id); else if (S.tab === 'orders') tab('orders'); }); };
      var re = U.qs('[data-re]', m.el);
      if (re) re.onclick = function () {
        U.busy(re, true);
        U.api('/staff/customers/' + cust.id + '/reorder', { method: 'POST', body: { order_id: id } }).then(function () { m.close(); placeOrder(cust.id); U.toast('اقلام سفارش در سبد قرار گرفت؛ تعدادها را بررسی و ثبت کنید.'); })
          .catch(function (e) { U.busy(re, false); U.toast(e.message, 'error'); });
      };
    }).catch(function (e) { U.errorBox(m.el, e); });
  }

  /* ---------------- Returns (مرجوعی) ---------------- */
  function setReturnsCount(n) {
    S.me.stats.returns_pending = n;
    U.qsa('[data-nav="returns"] .bws-count').forEach(function (e) { e.textContent = n ? U.fa(n) : ''; e.hidden = !n; });
    var b = U.qs('[data-nav="returns"]'); if (b && n && !U.qs('.bws-count', b)) b.insertAdjacentHTML('beforeend', '<em class="bws-count">' + U.fa(n) + '</em>');
    U.qsa('[data-returns-count]').forEach(function (e) { e.textContent = U.fa(n); e.hidden = !n; });
  }

  function returnsTab(el) {
    var p = P(), L = S.rlist;
    var st = { '': 'همه', pending: 'در انتظار بررسی', approved: 'تأیید شده', rejected: 'رد شده', cancelled: 'لغو شده' };
    el.innerHTML = (p.manager ? '<div data-rstats></div>' : '') + '<div class="bws-filters">' + U.searchbox('جستجو: کد مرجوعی، نام، موبایل، کد مشتری، شماره سفارش…', L.search) + U.seg(st, L.status, 'data-rs') + '</div><div class="bws-list"></div>';
    var list = U.qs('.bws-list', el);
    var ex = U.qs('[data-rexport]'); if (ex) ex.onclick = function () {
      U.busy(ex, true);
      U.api('/staff/returns/export').then(function (r) {
        U.busy(ex, false);
        var blob = new Blob([r.csv], { type: 'text/csv;charset=utf-8' }), a = document.createElement('a');
        a.href = URL.createObjectURL(blob); a.download = r.filename; document.body.appendChild(a); a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
      }).catch(function (e) { U.busy(ex, false); U.toast(e.message, 'error'); });
    };
    function load() { returnsList(list, { search: L.search, status: L.status, page: L.page, stats: U.qs('[data-rstats]', el), onPage: function (pg) { L.page = pg; load(); } }); }
    U.qs('.bws-search', el).addEventListener('input', U.debounce(function (e) { L.search = e.target.value; L.page = 1; load(); }, 350));
    U.qsa('[data-rs]', el).forEach(function (b) { b.onclick = function () { L.status = b.dataset.rs; L.page = 1; U.qsa('[data-rs]', el).forEach(function (x) { x.classList.toggle('is-active', x === b); }); load(); }; });
    load();
  }

  function returnsList(list, o) {
    U.loading(list);
    var reload = function () { returnsList(list, o); };
    U.api('/staff/returns', { query: { search: U.en(o.search || ''), status: o.status || '', page: o.page || 1, customer: o.customer || '' } }).then(function (r) {
      if (!o.customer) setReturnsCount(r.pending);
      if (o.stats && r.stats) {
        var c = r.stats.counts;
        o.stats.innerHTML = '<div class="bws-stats">' + U.stat('clock', 'amber', 'در انتظار بررسی', U.fa(c.pending)) + U.stat('check-circle', 'green', 'تأیید شده', U.fa(c.approved)) + U.stat('x-circle', 'red', 'رد شده', U.fa(c.rejected)) + U.stat('wallet', 'blue', 'برگشت به اعتبار (۹۰ روز)', r.stats.credit_90) + '</div>' +
          (r.stats.top_products.length ? U.card('بیشترین کالاهای مرجوعی (۹۰ روز)', 'برای پیگیری کیفیت و انبارداری', 'alert', '<div class="bws-table-wrap"><table class="bws-table"><thead><tr><th>کالا</th><th>تعداد</th><th>درخواست</th></tr></thead><tbody>' + r.stats.top_products.map(function (t) { return '<tr><td>' + U.esc(t.name) + '</td><td><b>' + U.fa(t.qty) + '</b></td><td>' + U.fa(t.requests) + '</td></tr>'; }).join('') + '</tbody></table></div>', { cls: 'bws-card-flush' }) : '');
      }
      list.innerHTML = (o.customer ? '' : '<p class="bws-muted">' + U.fa(r.total) + ' درخواست</p>') + U.returnCards(r.returns, { showCustomer: !o.customer, canDecide: true, emptyText: o.status === 'pending' ? 'درخواست در انتظار بررسی وجود ندارد.' : 'درخواست مرجوعی پیدا نشد.' }) + (o.onPage ? pager(o.page || 1, r.pages) : '');
      U.qsa('[data-page]', list).forEach(function (b) { b.onclick = function () { o.onPage(+b.dataset.page); }; });
      list.onclick = function (e) {
        var b = e.target.closest('[data-ract]'); if (!b) return;
        e.stopPropagation();
        openReturn(+b.closest('[data-ret]').dataset.ret, reload);
      };
    }).catch(function (e) { U.errorBox(list, e); });
  }

  function newReturn(cid, orderId, after) {
    var w = U.modal('ثبت مرجوعی', '<div class="bws-loading"><span class="bws-spinner"></span> در حال بارگذاری سفارش‌ها…</div>');
    U.api('/staff/customers/' + cid + '/returns').then(function (r) {
      w.close();
      U.returnForm({
        options: r.options, orderId: orderId, title: 'ثبت مرجوعی برای مشتری',
        submit: function (fd, prog) { return U.upload('/staff/customers/' + cid + '/returns', fd, prog); },
        onDone: function () { setReturnsCount((S.me.stats.returns_pending || 0) + 1); if (after) setTimeout(after, 300); }
      });
    }).catch(function (e) { U.errorBox(w.el, e); });
  }

  function openReturn(id, after) {
    var m = U.modal('مرجوعی', '<div class="bws-loading"><span class="bws-spinner"></span></div>', { wide: true, onClose: function () { if (history.replaceState && /^#r\d+$/.test(window.location.hash)) history.replaceState({}, '', window.location.href.split('#')[0]); } });
    U.api('/staff/returns/' + id).then(function (r) { renderReturn(m, r['return'], after); }).catch(function (e) { U.errorBox(m.el, e); });
  }

  function renderReturn(m, r, after) {
    var p = P();
    U.qs('.bws-modal-head h3', m.el.parentNode).textContent = 'مرجوعی ' + r.code + ' — ' + r.customer;
    var h = U.returnDetail(r, { staff: true });
    if (r.can_decide) h += decisionForm(r);
    else if (r.status === 'pending') h += '<div class="bws-alert bws-alert-info">' + U.ic('info', 18) + '<div>اجازه تأیید یا رد این درخواست را ندارید؛ مدیر بررسی می‌کند.</div></div>';
    var tools = '';
    tools += '<button type="button" class="bws-btn bws-btn-sm" data-rcust>' + U.ic('user', 15) + ' پرونده مشتری</button>';
    if (p.manager) {
      if (r.admin_order) tools += '<a class="bws-btn bws-btn-sm" target="_blank" href="' + U.esc(r.admin_order) + '">' + U.ic('external', 15) + ' سفارش #' + U.fa(r.order_id) + ' در ووکامرس</a>';
      if (r.replacement_order_id) tools += '<a class="bws-btn bws-btn-sm" target="_blank" href="' + U.esc(CFG.adminOrder.replace('__ID__', r.replacement_order_id)) + '">' + U.ic('package', 15) + ' سفارش جایگزین #' + U.fa(r.replacement_order_id) + '</a>';
      tools += '<button type="button" class="bws-btn bws-btn-sm" data-rresend>' + U.ic('send', 15) + ' ارسال دوباره به ربات‌ها</button>';
      if (r.can_delete) tools += '<button type="button" class="bws-btn bws-btn-sm bws-btn-danger" data-rdel>' + U.ic('trash', 15) + ' حذف درخواست</button>';
    }
    h += '<div class="bws-actions">' + tools + '</div>';
    if (p.manager && r.delivery) {
      var d = r.delivery, ev = { 'new': 'ثبت', decision: 'تصمیم', cancel: 'لغو' };
      h += '<details class="bws-delivery"><summary>' + U.ic('bot', 15) + ' وضعیت ارسال به ربات‌ها و ذخیره عکس‌ها</summary>' +
        '<p class="bws-muted">محل عکس‌ها: ' + (d.storage === 'gdrive' ? 'گوگل‌درایو — ' + ({ ok: 'منتقل شد', pending: 'در صف انتقال (هر ساعت دوباره تلاش می‌شود)', failed: 'ناموفق' }[d.files] || d.files) : 'هاست') + '</p>' +
        (d.bots.length ? '<ul>' + d.bots.map(function (b) { return '<li class="' + (b.ok ? 'bws-green' : 'bws-red') + '">' + (b.ok ? '✓' : '✗') + ' ' + U.esc(b.platform) + ' · ' + U.esc(ev[b.event] || b.event) + ' · <code dir="ltr">' + U.esc(b.chat) + '</code> — ' + U.esc(b.message) + '</li>'; }).join('') + '</ul>' : '<p class="bws-muted">ربات فعالی تنظیم نشده یا هنوز ارسالی انجام نشده است.</p>') + '</details>';
    }
    m.el.innerHTML = h;
    U.bindGallery(m.el, r.photos || []);
    var done = function (x) { U.toast(x.message || 'انجام شد'); if (after) after(); };
    U.qs('[data-rcust]', m.el).onclick = function () { m.close(); tab('customers', true); customer(r.customer_id); };
    var rs = U.qs('[data-rresend]', m.el);
    if (rs) rs.onclick = function () { U.busy(rs, true); U.api('/staff/returns/' + r.id + '/resend', { method: 'POST' }).then(function (x) { renderReturn(m, x['return'], after); U.toast(x.message); }).catch(function (e) { U.busy(rs, false); U.toast(e.message, 'error'); }); };
    var rd = U.qs('[data-rdel]', m.el);
    if (rd) rd.onclick = function () { U.confirm('درخواست ' + r.code + ' و عکس‌هایش برای همیشه حذف شود؟', function () { U.api('/staff/returns/' + r.id + '/delete', { method: 'POST' }).then(function (x) { m.close(); done(x); }).catch(function (e) { U.toast(e.message, 'error'); }); }); };
    if (r.can_decide) bindDecision(m, r, function (x) { renderReturn(m, x['return'], after); done(x); if (S.me.stats.returns_pending) setReturnsCount(S.me.stats.returns_pending - 1); });
  }

  function decisionForm(r) {
    var labels = { credit: ['برگشت مبلغ به اعتبار مشتری', 'در دفتر اعتبار ثبت و از بدهی کم می‌شود'], replacement: ['ارسال کالای جایگزین', 'سفارش رایگان با همین کالاها و کسر از انبار ساخته می‌شود'], manual: ['تسویه / پیگیری دستی', 'فقط ثبت تأیید؛ تسویه خارج از سیستم'] };
    var res = (r.resolutions || []).map(function (k, i) { return '<label class="bws-pick wide"><input type="radio" name="resolution" value="' + k + '"' + (i === 0 ? ' checked' : '') + '><span><b>' + U.esc(labels[k][0]) + '</b><small>' + U.esc(labels[k][1]) + '</small></span></label>'; }).join('');
    var rows = r.items.map(function (i) { return '<tr data-rid="' + i.id + '" data-unit="' + i.unit + '"><td>' + U.esc(i.name) + '</td><td>' + U.fa(i.qty) + '</td><td><input class="bws-num" name="aq" inputmode="numeric" value="' + i.qty + '" data-max="' + i.qty + '" style="max-width:80px"></td></tr>'; }).join('');
    return '<form class="bws-decide" novalidate><h4 class="bws-sub-title">' + U.ic('check-circle', 16) + ' بررسی و تصمیم</h4>' +
      '<div class="bws-seg bws-seg-lg"><button type="button" data-dec="approve" class="is-active">' + U.ic('check', 15) + ' تأیید</button><button type="button" data-dec="reject">' + U.ic('x', 15) + ' رد</button></div>' +
      '<div data-dbox="approve"><div class="bws-table-wrap"><table class="bws-table"><thead><tr><th>کالا</th><th>درخواستی</th><th>تعداد تأییدشده</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '<div class="bws-picks col">' + res + '</div>' +
      '<label class="bws-field" data-amt><span>مبلغ برگشتی (' + U.esc(U.currency || '') + ')</span><input name="amount" inputmode="numeric" dir="ltr"><small>به‌صورت خودکار از تعداد تأییدشده × فی خرید محاسبه می‌شود؛ قابل کاهش است.</small></label></div>' +
      '<label class="bws-field"><span data-note-l>توضیح برای مشتری (اختیاری)</span><textarea name="note" rows="2" maxlength="1000"></textarea></label>' +
      '<label class="bws-switch"><input type="checkbox" name="notify" checked><span></span> اطلاع نتیجه به مشتری با پیامک</label>' +
      '<div class="bws-actions"><button type="submit" class="bws-btn bws-btn-primary bws-btn-lg" data-submit>' + U.ic('check-circle', 17) + ' ثبت تأیید</button></div></form>';
  }

  function bindDecision(m, r, after) {
    var f = U.qs('.bws-decide', m.el); if (!f) return;
    var dec = 'approve', amt = U.qs('[name=amount]', f), touched = false;
    function calc() {
      var t = 0;
      U.qsa('tr[data-rid]', f).forEach(function (tr) { var i = U.qs('[name=aq]', tr); t += Math.min(+i.dataset.max, Math.max(0, parseInt(U.en(i.value), 10) || 0)) * (+tr.dataset.unit); });
      if (!touched) amt.value = U.num(t);
      return t;
    }
    function resMode() { var x = U.qs('[name=resolution]:checked', f); U.qs('[data-amt]', f).hidden = !x || x.value === 'replacement'; }
    U.qsa('[data-dec]', f).forEach(function (b) {
      b.onclick = function () {
        dec = b.dataset.dec; U.qsa('[data-dec]', f).forEach(function (x) { x.classList.toggle('is-active', x === b); });
        U.qs('[data-dbox="approve"]', f).hidden = dec !== 'approve';
        U.qs('[data-note-l]', f).textContent = dec === 'reject' ? 'دلیل رد (الزامی — برای مشتری پیامک می‌شود)' : 'توضیح برای مشتری (اختیاری)';
        var s = U.qs('[data-submit]', f); s.className = 'bws-btn bws-btn-lg ' + (dec === 'reject' ? 'bws-btn-danger' : 'bws-btn-primary'); s.innerHTML = U.ic(dec === 'reject' ? 'x-circle' : 'check-circle', 17) + (dec === 'reject' ? ' ثبت رد درخواست' : ' ثبت تأیید');
      };
    });
    U.qsa('[name=aq]', f).forEach(function (i) { i.oninput = calc; i.onchange = function () { var v = Math.min(+i.dataset.max, Math.max(0, parseInt(U.en(i.value), 10) || 0)); i.value = v; calc(); }; });
    U.qsa('[name=resolution]', f).forEach(function (x) { x.onchange = resMode; });
    amt.oninput = function () { touched = true; };
    calc(); resMode();
    f.onsubmit = function (e) {
      e.preventDefault();
      var note = U.qs('[name=note]', f).value.trim(), btn = U.qs('[data-submit]', f), items = {};
      if (dec === 'reject' && note.length < 3) { U.toast('دلیل رد را بنویسید.', 'error'); U.qs('[name=note]', f).focus(); return; }
      U.qsa('tr[data-rid]', f).forEach(function (tr) { items[tr.dataset.rid] = Math.max(0, parseInt(U.en(U.qs('[name=aq]', tr).value), 10) || 0); });
      var resn = U.qs('[name=resolution]:checked', f);
      if (dec === 'approve' && !Object.keys(items).some(function (k) { return items[k] > 0; })) { U.toast('حداقل یک عدد تأیید کنید یا درخواست را رد کنید.', 'error'); return; }
      var body = { decision: dec, note: note, notify: U.qs('[name=notify]', f).checked ? 1 : 0 };
      if (dec === 'approve') { body.items = items; body.resolution = resn ? resn.value : 'manual'; body.amount = U.en(amt.value).replace(/[^\d.]/g, ''); }
      var go = function () {
        U.busy(btn, true);
        U.api('/staff/returns/' + r.id + '/decide', { method: 'POST', body: body }).then(after).catch(function (er) { U.busy(btn, false); U.toast(er.message, 'error'); });
      };
      var msg = dec === 'reject' ? 'درخواست ' + r.code + ' رد شود؟' : (body.resolution === 'credit' ? 'مبلغ ' + amt.value + ' به اعتبار مشتری برگردد؟' : body.resolution === 'replacement' ? 'سفارش جایگزین رایگان ساخته و از انبار کسر شود؟' : 'درخواست تأیید شود؟');
      U.confirm(msg, go);
    };
  }

  /* ---------------- Bulk SMS ---------------- */
  function bulkSms(el) {
    var p = P(), T = S.me.templates, custom = can('sms_custom');
    var opts = (p.sms_bulk === 'all' ? '<option value="all">همه مشتریان فعال</option>' : '<option value="all">همه مشتریان من</option>') +
      '<option value="debtors">فقط بدهکاران</option><option value="no_order">مشتریانی که هنوز سفارش نداده‌اند</option><option value="inactive_30">بدون سفارش در ۳۰ روز اخیر</option><option value="inactive_60">بدون سفارش در ۶۰ روز اخیر</option>' +
      S.me.provinces.map(function (x) { return '<option value="province:' + U.esc(x) + '">استان ' + U.esc(x) + '</option>'; }).join('') +
      (p.sms_bulk === 'all' ? S.me.visitors.map(function (v) { return '<option value="visitor:' + v.id + '">مشتریان ویزیتور: ' + U.esc(v.name) + '</option>'; }).join('') : '') +
      (p.manager ? '<optgroup label="ارسال به ویزیتورها"><option value="visitors">همه ویزیتورهای فعال</option>' + S.me.visitors.filter(function (v) { return v.mobile; }).map(function (v) { return '<option value="visitor_user:' + v.id + '">ویزیتور: ' + U.esc(v.name) + '</option>'; }).join('') + '</optgroup>' : '');
    var tpl = Object.keys(T).map(function (k) { return '<option value="' + k + '">' + U.esc(T[k].label) + (T[k].pattern ? ' (الگو)' : '') + '</option>'; }).join('') + (custom ? '<option value="">متن دلخواه</option>' : '');
    el.innerHTML = '<div class="bws-grid bws-grid-2-1"><div>' + U.card('متن و گیرندگان', '', 'send',
      '<div class="bws-form-grid"><label class="bws-field"><span>گیرندگان</span><select name="filter">' + opts + '</select></label>' +
      '<label class="bws-field"><span>پیام</span><select name="tpl">' + tpl + '</select></label></div>' +
      '<div class="bws-alert bws-alert-info" data-pnote hidden>' + U.ic('info', 17) + '<div>این پیام با «الگو/پترن» پنل پیامک ارسال می‌شود (متن در پنل پیامک تأیید شده و این‌جا قابل ویرایش نیست).</div></div>' +
      '<label class="bws-field"><span>متن پیامک</span><textarea name="template" rows="7" maxlength="900" ' + (custom ? '' : 'readonly') + '>' + U.esc(T.login_link.text) + '</textarea><small data-cnt></small></label>' +
      '<div class="bws-actions"><button class="bws-btn" data-count>' + U.ic('users', 16) + ' تعداد گیرندگان</button><button class="bws-btn bws-btn-primary" data-send>' + U.ic('send', 16) + ' شروع ارسال</button></div>' +
      '<div class="bws-progress" hidden><div class="bws-bar-track"><span></span></div><div class="bws-progress-text"></div></div>') + '</div><div>' +
      U.card('متغیرها', 'در متن پیامک قرار دهید؛ برای هر مشتری جایگزین می‌شوند', 'info',
        '<div class="bws-vars-list">' + ['{name}', '{full_name}', '{shop}', '{code}', '{link}', '{panel_url}', '{credit_available}', '{debt}', '{company}', '{visitor_name}'].map(function (v) { return '<code>' + v + '</code>'; }).join('') + '</div><p class="bws-muted">{link} لینک مستقیم ورود است که کد مشتری داخلش قرار دارد. هر پیامک فارسی تا ۷۰ حرف یک پیامک حساب می‌شود و بعد از آن هر ۶۷ حرف یک پیامک.</p>') + '</div></div>';
    var sel = U.qs('[name=tpl]', el), ta = U.qs('[name=template]', el), fil = U.qs('[name=filter]', el), pn = U.qs('[data-pnote]', el), cnt = U.qs('[data-cnt]', el);
    function counter() { var n = ta.value.length, uni = /[^\x00-\x7F]/.test(ta.value), parts = n <= (uni ? 70 : 160) ? 1 : Math.ceil(n / (uni ? 67 : 153)); cnt.textContent = U.fa(n) + ' حرف · حدود ' + U.fa(parts) + ' پیامک برای هر نفر (قبل از جایگزینی متغیرها)'; }
    var vl = U.qs('.bws-vars-list', el), custVars = vl.innerHTML;
    var visVars = ['{name}', '{visitor_name}', '{username}', '{visitor_panel_url}', '{month_sales}', '{month_orders}', '{company}', '{date}'].map(function (v) { return '<code>' + v + '</code>'; }).join('');
    function toVisitors() { return /^visitor(s|_user:)/.test(fil.value); }
    function sync() {
      var vis = toVisitors();
      U.qsa('option', sel).forEach(function (o) { if (o.value) o.disabled = vis; });
      if (vis && sel.value) { sel.value = ''; ta.value = ''; }
      var t = T[sel.value]; if (sel.value && t) { ta.value = t.text || ''; pn.hidden = !t.pattern; ta.readOnly = !custom || !!t.pattern || !!sel.value; } else { ta.readOnly = false; pn.hidden = true; }
      vl.innerHTML = vis ? visVars : custVars; bindVars(); counter();
    }
    function bindVars() { if (custom || toVisitors()) U.qsa('.bws-vars-list code', el).forEach(function (c) { c.style.cursor = 'pointer'; c.onclick = function () { if (!ta.readOnly) { ta.value += c.textContent; ta.focus(); counter(); } }; }); }
    sel.onchange = sync; fil.onchange = sync; ta.oninput = counter; sync();
    function body(extra) { var b = { filter: fil.value, event: sel.value, template: sel.value ? '' : ta.value }; Object.keys(extra || {}).forEach(function (k) { b[k] = extra[k]; }); return b; }
    U.qs('[data-count]', el).onclick = function (e) {
      var b = e.currentTarget; U.busy(b, true);
      U.api('/staff/sms/bulk', { method: 'POST', body: body({ mode: 'count' }) }).then(function (r) { U.busy(b, false); U.toast(U.fa(r.total) + ' گیرنده'); }).catch(function (er) { U.busy(b, false); U.toast(er.message, 'error'); });
    };
    U.qs('[data-send]', el).onclick = function (e) {
      var b = e.currentTarget;
      U.confirm('پیامک برای همه گیرندگان انتخاب‌شده ارسال شود؟', function () {
        U.busy(b, true);
        var prog = U.qs('.bws-progress', el), bar = U.qs('.bws-bar-track span', prog), txt = U.qs('.bws-progress-text', prog), sent = 0, failed = 0;
        prog.hidden = false;
        (function step(offset) {
          U.api('/staff/sms/bulk', { method: 'POST', body: body({ offset: offset }) }).then(function (r) {
            sent += r.sent; failed += r.failed;
            bar.style.width = (r.total ? Math.round(r.next / r.total * 100) : 100) + '%';
            txt.textContent = U.fa(r.next) + ' از ' + U.fa(r.total) + ' — موفق: ' + U.fa(sent) + ' / ناموفق: ' + U.fa(failed);
            if (r.mode !== 'live' && offset === 0) U.toast(r.mode === 'test' ? 'پنل پیامک در حالت تست است؛ پیامک واقعی ارسال نمی‌شود.' : 'ارسال پیامک در تنظیمات غیرفعال است.', 'warn');
            if (r.done) { U.busy(b, false); U.toast('ارسال گروهی تمام شد'); } else step(r.next);
          }).catch(function (er) { U.busy(b, false); U.toast(er.message, 'error'); });
        })(0);
      });
    };
  }

  window.addEventListener('hashchange', function () {
    var h = (window.location.hash || '').replace('#', '');
    if (S && S.me && /^c\d+$/.test(h)) { tab('customers', true); customer(+h.slice(1)); }
    if (S && S.me && /^r\d+$/.test(h) && can('returns_view')) { if (S.tab !== 'returns') tab('returns'); openReturn(+h.slice(1)); }
  });

  window.BWSBoot = window.BWSBoot || {};
  window.BWSBoot.visitor = start;
  start();
})(window, document);
