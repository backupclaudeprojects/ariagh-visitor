/* ARIAGH.VISITOR – customer (wholesale buyer) panel */
(function (window, document) {
  'use strict';
  var U = window.BWSU, CFG = window.BWS;
  if (!U) return;
  var TK = 'bws_ct';
  var app, S;

  function brandImg() {
    if (CFG.logo && CFG.logoMode === 'company') return '<img class="bws-login-logo" src="' + U.esc(CFG.logo) + '" alt="">';
    return '<img class="bws-login-brand" src="' + U.esc(CFG.brandSvg) + '" alt="ARIAGH.VISITOR" width="210" height="34">';
  }

  function logout() { U.store.del(TK); U.token = null; S.me = null; S.frame = null; loginView(); }

  function loginShell(inner) {
    app.className = 'bws-app bws-ui bws-front bws-customer';
    app.innerHTML = '<div class="bws-login-wrap"><div class="bws-card bws-login">' + brandImg() + inner + '</div></div>';
  }
  function err(msg) { return msg ? '<div class="bws-alert bws-alert-error" role="alert">' + U.ic('alert', 18) + '<div>' + U.esc(msg) + '</div></div>' : ''; }

  function loginView(msg, prefill) {
    loginShell('<h2>پنل خرید همکاران</h2><p class="bws-muted">' + U.esc(CFG.company) + ' — برای ورود، کد اختصاصی خود را وارد کنید</p>' + err(msg) +
      '<form data-code><label class="bws-field"><span>کد اختصاصی</span><input name="code" class="bws-code-input" autocomplete="one-time-code" maxlength="32" ' + (CFG.codeType === 'numeric' ? 'inputmode="numeric"' : '') + ' required value="' + U.esc(prefill || '') + '"></label>' +
      '<button class="bws-btn bws-btn-primary bws-btn-lg bws-btn-block" type="submit">' + U.ic('lock', 18) + ' ورود به پنل</button></form>' +
      (CFG.otpLogin ? '<button type="button" class="bws-btn bws-btn-ghost bws-btn-block" data-mobile style="margin-top:8px">' + U.ic('phone', 16) + ' کدم را ندارم — ورود با شماره موبایل</button>' : '') +
      (CFG.phone ? '<p class="bws-muted" style="margin-top:14px">تماس با شرکت: <a href="tel:' + U.esc(CFG.phone) + '" class="bws-ltr">' + U.esc(CFG.phone) + '</a></p>' : ''));
    var f = U.qs('form', app);
    f.onsubmit = function (e) { e.preventDefault(); doLogin(U.en(f.code.value).trim(), U.qs('button', f)); };
    var mb = U.qs('[data-mobile]', app); if (mb) mb.onclick = function () { mobileView(); };
  }

  function mobileView(msg, prefill) {
    loginShell('<h2>ورود با شماره موبایل</h2><p class="bws-muted">شماره‌ای که ویزیتور برای شما ثبت کرده را وارد کنید تا کد تأیید پیامک شود.</p>' + err(msg) +
      '<form><label class="bws-field"><span>شماره موبایل</span><input name="mobile" inputmode="tel" dir="ltr" maxlength="14" placeholder="09xxxxxxxxx" required autocomplete="tel" value="' + U.esc(prefill || '') + '"></label>' +
      '<button class="bws-btn bws-btn-primary bws-btn-lg bws-btn-block" type="submit">' + U.ic('send', 18) + ' ارسال کد تأیید</button></form>' +
      '<button type="button" class="bws-btn bws-btn-ghost bws-btn-block" data-back style="margin-top:8px">ورود با کد اختصاصی</button>');
    var f = U.qs('form', app);
    U.qs('[data-back]', app).onclick = function () { loginView(); };
    f.onsubmit = function (e) {
      e.preventDefault(); var b = U.qs('button', f), mob = U.en(f.mobile.value).trim(); U.busy(b, true);
      U.api('/customer/otp/request', { method: 'POST', body: { mobile: mob } }).then(function (r) { otpView(r); })
        .catch(function (er) { mobileView(er.message, mob); });
    };
  }

  function otpView(t, msg) {
    loginShell('<h2>کد تأیید</h2><p class="bws-muted">کد ' + U.fa(t.length) + ' رقمی به شماره <b class="bws-ltr">' + U.esc(t.mobile) + '</b> پیامک شد (اعتبار: ' + U.fa(t.minutes) + ' دقیقه).</p>' + err(msg) +
      '<form><label class="bws-field"><span>کد تأیید</span><input name="otp" class="bws-code-input" inputmode="numeric" autocomplete="one-time-code" maxlength="8" required autofocus></label>' +
      '<button class="bws-btn bws-btn-primary bws-btn-lg bws-btn-block" type="submit">' + U.ic('check-circle', 18) + ' تأیید و ورود</button></form>' +
      '<button type="button" class="bws-btn bws-btn-ghost bws-btn-block" data-back style="margin-top:8px">بازگشت</button>');
    var f = U.qs('form', app);
    U.qs('[data-back]', app).onclick = function () { loginView(); };
    f.onsubmit = function (e) {
      e.preventDefault(); var b = U.qs('button', f); U.busy(b, true);
      U.api('/customer/otp/verify', { method: 'POST', body: { ticket: t.ticket, otp: U.en(f.otp.value).trim() } }).then(function (r) {
        U.token = r.token; U.store.set(TK, r.token); load();
      }).catch(function (er) { if (er.data && er.data.code === 'bws_otp_exp') loginView(er.message); else otpView(t, er.message); });
    };
  }

  function doLogin(code, btn) {
    U.busy(btn, true);
    return U.api('/customer/login', { method: 'POST', body: { code: code } }).then(function (r) {
      if (r.otp_required) { otpView(r); return; }
      U.token = r.token; U.store.set(TK, r.token); load();
    }).catch(function (e) { U.busy(btn, false); loginView(e.message, code); });
  }

  function load() {
    app.innerHTML = '<div class="bws-loading"><span class="bws-spinner"></span> در حال بارگذاری…</div>';
    U.api('/customer/me').then(function (r) { S.me = r; U.currency = r.settings.currency; shell(); })
      .catch(function (e) {
        if (e.status === 401 || e.status === 403) { U.store.del(TK); loginView('نشست شما منقضی شده؛ دوباره وارد شوید.'); }
        else { U.errorBox(app, e); }
      });
  }

  function refreshMe() {
    return U.api('/customer/me').then(function (r) { S.me = r; chips(); if (S.shop) S.shop.setCredit(r.customer.credit); });
  }

  function chips() {
    var c = S.me.customer;
    S.frame.top.innerHTML = '<span class="bws-chip is-info">' + U.ic('key', 15) + ' کد: <b>' + U.esc(c.code) + '</b></span>' +
      '<span class="bws-chip is-ok bws-hide-m">' + U.ic('wallet', 15) + ' اعتبار: ' + U.esc(c.credit.available_text) + '</span>' +
      '<button class="bws-btn bws-btn-sm" data-logout>' + U.ic('logout', 15) + ' <span class="bws-hide-m">خروج</span></button>';
    U.qs('[data-logout]', S.frame.top).onclick = function () { U.confirm('از پنل خارج می‌شوید؟', logout); };
  }

  function creditBlock() {
    var c = S.me.customer, s = S.me.settings;
    return U.creditCard(c.credit, (c.credit.debt > 0 && s.settle_online ? '<button class="bws-btn bws-btn-sm" data-settle>' + U.ic('wallet', 15) + ' پرداخت آنلاین بدهی</button>' : '') +
      (c.overdue ? '<div class="bws-alert bws-alert-warn" style="margin-top:10px">' + U.ic('clock', 17) + '<div>مهلت تسویه بخشی از بدهی شما گذشته است؛ لطفاً تسویه کنید.</div></div>' : '') +
      (s.settle_before && c.credit.debt > 0 ? '<div class="bws-alert bws-alert-warn" style="margin-top:10px">' + U.ic('alert', 17) + '<div>برای ثبت سفارش جدید ابتدا بدهی قبلی را تسویه کنید.</div></div>' : ''));
  }

  function notice() { return S.me.notice ? '<div class="bws-alert bws-alert-info bws-notice">' + U.ic('bell', 18) + '<div>' + S.me.notice + '</div></div>' : ''; }

  function shell() {
    var c = S.me.customer;
    var items = [
      { key: 'shop', label: 'ثبت سفارش', short: 'سفارش جدید', icon: 'cart', group: 'خرید' },
      { key: 'orders', label: 'سفارش‌های من', short: 'سفارش‌ها', icon: 'package' },
      { key: 'ledger', label: 'حساب و اعتبار', short: 'اعتبار', icon: 'wallet', group: 'حساب' }
    ];
    if (S.me.settings.returns) items.splice(2, 0, { key: 'returns', label: 'مرجوعی کالا', short: 'مرجوعی', icon: 'return' });
    if (CFG.about && CFG.about[1]) items.push({ key: 'about', label: CFG.about[0], short: CFG.about[0].length > 12 ? 'درباره ما' : CFG.about[0], icon: 'info', href: CFG.about[1], group: 'بیشتر' });
    S.frame = U.frame(app, items, { brandTitle: CFG.company, brandSub: 'پنل خرید همکاران', foot: 'سلام ' + U.esc(c.full_name) + (c.shop_name ? '<br>' + U.esc(c.shop_name) : '') + (c.visitor_name && c.visitor_name !== '—' ? '<br><small>ویزیتور شما: ' + U.esc(c.visitor_name) + '</small>' : '') });
    app.classList.add('bws-customer');
    chips();
    U.qsa('[data-nav]', app).forEach(function (b) { b.onclick = function () { tab(b.dataset.nav); try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch (e) {} }; });
    tab(S.tab);
  }

  function bindSettle(root) { U.qsa('[data-settle]', root).forEach(function (b) { b.onclick = settle; }); }

  function tab(t) {
    S.tab = t; U.setActive(t);
    var main = S.frame.main, c = S.me.customer;
    main.onclick = null;
    if (t === 'shop') {
      main.innerHTML = U.head('سلام ' + (c.first_name || c.full_name) + '، خوش آمدید', 'محصولات را با قیمت همکاری انتخاب کنید و سفارش خود را ثبت کنید.', 'cart') + notice() + creditBlock() + '<div data-shop></div>';
      bindSettle(main);
      S.shop = U.Shop({
        el: U.qs('[data-shop]', main), credit: c.credit, settings: S.me.settings, cart: S.me.cart,
        saveCart: function (cart) { U.api('/customer/cart', { method: 'POST', body: { items: cart } }).catch(function () {}); },
        quote: function (items) { return U.api('/customer/quote', { method: 'POST', body: { items: items } }); },
        submit: function (items, method, note) { return U.api('/customer/order', { method: 'POST', body: { items: items, excess_method: method, note: note } }); },
        onDone: function () { S.me.cart = {}; refreshMe().then(function () { if (S.tab === 'shop') tab('shop'); }); }
      });
    } else if (t === 'orders') {
      main.innerHTML = U.head('سفارش‌های من', 'وضعیت، جزئیات و فاکتور سفارش‌های شما', 'package') + '<div data-list></div>';
      var list = U.qs('[data-list]', main); U.loading(list);
      U.api('/customer/orders').then(function (r) {
        list.innerHTML = U.orderCards(r.orders, { canPay: true, canCancel: true });
        list.onclick = function (e) {
          var b = e.target.closest('[data-act]'); if (!b) return;
          var id = b.closest('[data-order]').dataset.order;
          if (b.dataset.act === 'detail') orderDetail(id);
          if (b.dataset.act === 'cancel') U.cancelOrder(id, false, function (reason) {
            return U.api('/customer/orders/' + id + '/cancel', { method: 'POST', body: { reason: reason } }).then(function (r) { refreshMe(); tab('orders'); return r; });
          });
        };
      }).catch(function (e) { U.errorBox(list, e); });
    } else if (t === 'returns') {
      returnsTab(main);
    } else if (t === 'ledger') {
      main.innerHTML = U.head('حساب و اعتبار', 'هر خرید از اعتبار به بدهی اضافه و هر پرداخت از آن کم می‌شود. بعد از تسویه، اعتبار دوباره قابل استفاده است.', 'wallet') + creditBlock() + '<div data-led></div>';
      bindSettle(main);
      var led = U.qs('[data-led]', main); U.loading(led);
      U.api('/customer/ledger').then(function (r) {
        led.innerHTML = U.card('گردش حساب', 'همه خریدها و پرداخت‌های اعتباری', 'receipt', U.ledgerTable(r.entries));
      }).catch(function (e) { U.errorBox(led, e); });
    }
  }

  function orderDetail(id) {
    var m = U.modal('سفارش #' + U.fa(id), '<div class="bws-loading"><span class="bws-spinner"></span></div>', { wide: true });
    U.api('/customer/orders/' + id).then(function (r) {
      var retOk = S.me.settings.returns && r.order.kind === 'order' && ['processing', 'completed', 'on-hold'].indexOf(r.order.status) > -1;
      m.el.innerHTML = U.orderDetail(r.order, CFG.printUrl + '&order=' + id + '&t=' + encodeURIComponent(U.token)) +
        '<div class="bws-actions">' + (S.me.settings.allow_reorder && r.order.kind === 'order' ? '<button class="bws-btn bws-btn-primary" data-re>' + U.ic('refresh', 16) + ' تکرار این سفارش</button>' : '') +
        (retOk ? '<button class="bws-btn" data-ret>' + U.ic('return', 16) + ' ثبت مرجوعی (کالای معیوب)</button>' : '') + '</div>';
      var rb = U.qs('[data-ret]', m.el);
      if (rb) rb.onclick = function () { m.close(); newReturn(+id); };
      var re = U.qs('[data-re]', m.el);
      if (re) re.onclick = function () {
        U.busy(re, true);
        U.api('/customer/orders/' + id + '/reorder', { method: 'POST' }).then(function (x) {
          S.me.cart = x.cart; m.close(); tab('shop'); U.toast('اقلام این سفارش در سبد قرار گرفت؛ بررسی و ثبت کنید.');
        }).catch(function (e) { U.busy(re, false); U.toast(e.message, 'error'); });
      };
    }).catch(function (e) { U.errorBox(m.el, e); });
  }

  /* ---------------- Returns (مرجوعی) ---------------- */
  function returnsTab(main) {
    main.innerHTML = U.head('مرجوعی کالا', 'برای کالای معیوب (مثل کپک‌زدگی) از روی سفارش، درخواست مرجوعی با عکس ثبت کنید و نتیجه را پیگیری کنید.', 'return',
      '<button class="bws-btn bws-btn-primary" data-new>' + U.ic('plus', 16) + ' ثبت مرجوعی جدید</button>') + '<div data-list></div>';
    var list = U.qs('[data-list]', main); U.loading(list);
    U.qs('[data-new]', main).onclick = function () { newReturn(0); };
    U.api('/customer/returns').then(function (r) {
      S.retOptions = r.options; S.returns = r.returns;
      list.innerHTML = (r.returns.length ? '' : '<div class="bws-alert bws-alert-info">' + U.ic('info', 18) + '<div>برای ثبت مرجوعی: سفارش، کالا و تعداد معیوب، دلیل، توضیحات و حداقل ' + U.fa(r.options.min_photos || 1) + ' عکس لازم است.' + (r.options.days ? ' مهلت ثبت: ' + U.fa(r.options.days) + ' روز بعد از سفارش.' : '') + '</div></div>') +
        U.returnCards(r.returns, { canCancel: true, emptyText: 'هنوز درخواست مرجوعی ثبت نکرده‌اید.' });
      list.onclick = function (e) {
        var b = e.target.closest('[data-ract]'); if (!b) return;
        var id = +b.closest('[data-ret]').dataset.ret, it = S.returns.filter(function (x) { return x.id === id; })[0];
        if (b.dataset.ract === 'detail') returnDetail(it);
        if (b.dataset.ract === 'cancel') U.confirm('درخواست مرجوعی ' + it.code + ' لغو شود؟', function () {
          U.api('/customer/returns/' + id + '/cancel', { method: 'POST' }).then(function (x) { U.toast(x.message); if (S.tab === 'returns') tab('returns'); }).catch(function (er) { U.toast(er.message, 'error'); });
        });
      };
    }).catch(function (e) { U.errorBox(list, e); });
  }

  function returnDetail(r) {
    var m = U.modal('مرجوعی ' + r.code, U.returnDetail(r, {}), { wide: true });
    U.bindGallery(m.el, r.photos || []);
  }

  function newReturn(orderId) {
    var go = function (o) {
      U.returnForm({
        options: o, orderId: orderId,
        submit: function (fd, prog) { return U.upload('/customer/returns', fd, prog); },
        onDone: function () { S.retOptions = null; if (S.tab === 'returns') tab('returns'); }
      });
    };
    if (S.retOptions) { go(S.retOptions); return; }
    var w = U.modal('ثبت مرجوعی', '<div class="bws-loading"><span class="bws-spinner"></span> در حال بارگذاری سفارش‌ها…</div>');
    U.api('/customer/returns').then(function (r) { S.retOptions = r.options; w.close(); go(r.options); }).catch(function (e) { U.errorBox(w.el, e); });
  }

  function settle() {
    var c = S.me.customer;
    var m = U.modal('پرداخت آنلاین بدهی اعتبار', '<form><div class="bws-kv"><div><span>بدهی فعلی</span><b class="bws-red">' + U.esc(c.credit.debt_text) + '</b></div><div><span>بعد از پرداخت کامل</span><b class="bws-green">' + U.esc(c.credit.limit_text) + ' اعتبار</b></div></div>' +
      '<label class="bws-field"><span>مبلغ پرداخت (' + U.esc(U.currency) + ')</span><input name="amount" inputmode="numeric" dir="ltr" value="' + Math.round(c.credit.debt) + '"><small>می‌توانید کل یا بخشی از بدهی را پرداخت کنید.' + (S.me.settings.snapppay ? ' امکان پرداخت اقساطی با اسنپ‌پی هم در صفحه پرداخت وجود دارد.' : '') + '</small></label>' +
      '<button class="bws-btn bws-btn-primary bws-btn-lg bws-btn-block">' + U.ic('wallet', 18) + ' انتقال به صفحه پرداخت</button></form>');
    var f = U.qs('form', m.el);
    f.onsubmit = function (e) {
      e.preventDefault(); var b = U.qs('button', f); U.busy(b, true);
      U.api('/customer/settle', { method: 'POST', body: { amount: U.en(f.amount.value) } }).then(function (r) { window.location.href = r.pay_url; })
        .catch(function (er) { U.busy(b, false); U.toast(er.message, 'error'); });
    };
  }

  function start() {
    app = document.getElementById('bws-app');
    if (!app || app.getAttribute('data-booted')) return;
    app.setAttribute('data-booted', '1');
    S = { me: null, tab: 'shop', shop: null, frame: null };
    // Direct link ?code=XXXX logs in automatically (the code is removed from the address bar).
    var params = new URLSearchParams(window.location.search);
    var code = params.get('code');
    if (code) {
      params.delete('code');
      window.history.replaceState({}, '', window.location.pathname + (params.toString() ? '?' + params.toString() : '') + window.location.hash);
      loginView('', code);
      doLogin(U.en(code).trim(), U.qs('button', app));
    } else if ((U.token = U.store.get(TK))) {
      load();
    } else {
      loginView();
    }
  }

  window.BWSBoot = window.BWSBoot || {};
  window.BWSBoot.customer = start;
  start();
})(window, document);
