/* ARIAGH.VISITOR – wp-admin helpers */
(function () {
  'use strict';
  var A = window.BWSA || {};
  function api(path, body, method) {
    return fetch(A.rest + path, {
      method: method || 'POST', credentials: 'same-origin', cache: 'no-store',
      headers: { 'X-WP-Nonce': A.nonce, 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined
    }).then(function (r) { return r.json().then(function (j) { if (!r.ok || j.ok === false) throw new Error(j.message || 'خطا'); return j; }); });
  }
  function toast(msg, err) {
    var box = document.querySelector('.bws-toasts');
    if (!box) { box = document.createElement('div'); box.className = 'bws-toasts'; document.body.appendChild(box); }
    var t = document.createElement('div'); t.className = 'bws-toast ' + (err ? 'bws-toast-error' : ''); t.textContent = msg; box.appendChild(t);
    setTimeout(function () { t.classList.add('out'); setTimeout(function () { t.remove(); }, 400); }, err ? 6000 : 3000);
  }
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function fa(s) { return String(s).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; }); }
  function debounce(fn, ms) { var t; return function () { var a = arguments; clearTimeout(t); t = setTimeout(function () { fn.apply(null, a); }, ms); }; }

  // Product sync.
  var sync = $('#bws-sync');
  if (sync) sync.addEventListener('click', function () {
    sync.disabled = true; sync.textContent = 'در حال بارگذاری...';
    api('/admin/products/sync').then(function (r) { toast(r.message); setTimeout(function () { location.reload(); }, 1200); })
      .catch(function (e) { toast(e.message, true); sync.disabled = false; sync.textContent = 'بارگذاری مجدد'; });
  });

  // Product row autosave.
  $$('.bws-ptable tr[data-pid]').forEach(function (tr) {
    $$('[data-k]', tr).forEach(function (inp) {
      inp.addEventListener('change', function () {
        var body = {}; body[inp.dataset.k] = inp.type === 'checkbox' ? (inp.checked ? 1 : 0) : inp.value;
        tr.classList.add('bws-saving');
        api('/admin/products/' + tr.dataset.pid, body).then(function (r) {
          tr.classList.remove('bws-saving'); tr.classList.add('bws-saved');
          var w = $('.bws-wprice', tr); if (w && r.wholesale_text) w.innerHTML = '<b style="color:var(--bws-primary)">' + esc(r.wholesale_text) + '</b>';
          setTimeout(function () { tr.classList.remove('bws-saved'); }, 1200);
        }).catch(function (e) { tr.classList.remove('bws-saving'); toast(e.message, true); });
      });
    });
  });
  var ps = $('#bws-psearch');
  if (ps) ps.addEventListener('input', function () {
    var q = ps.value.trim().toLowerCase();
    $$('.bws-ptable tr[data-pid]').forEach(function (tr) { tr.style.display = !q || tr.dataset.name.indexOf(q) > -1 ? '' : 'none'; });
  });

  // SMS provider switch + search.
  var prov = $('#bws-provider');
  if (prov) {
    prov.addEventListener('change', function () {
      $$('.bws-driver').forEach(function (d) { d.hidden = d.dataset.driver !== prov.value; });
    });
    var psr = $('#bws-provider-search');
    if (psr) psr.addEventListener('input', function () {
      var q = psr.value.trim().toLowerCase(), first = null;
      $$('option', prov).forEach(function (o) {
        var ok = !q || (o.dataset.search || '').indexOf(q) > -1;
        o.hidden = !ok; o.disabled = !ok && o.value !== prov.value;
        if (ok && !first) first = o;
      });
      if (q && first && first.value !== prov.value) { prov.value = first.value; prov.dispatchEvent(new Event('change')); }
    });
  }
  var cr = $('#bws-sms-credit');
  if (cr) cr.addEventListener('click', function () {
    var out = $('#bws-sms-credit-out'); out.textContent = '...';
    fetch(A.rest + '/admin/sms/credit?_=' + Date.now(), { credentials: 'same-origin', cache: 'no-store', headers: { 'X-WP-Nonce': A.nonce } }).then(function (r) { return r.json(); })
      .then(function (j) { out.textContent = j.ok ? j.credit : (j.message || 'خطا'); });
  });
  var tb = $('#bws-sms-test');
  if (tb) tb.addEventListener('click', function () {
    var out = $('#bws-sms-test-out'); out.hidden = false; out.textContent = 'در حال ارسال...';
    var ev = $('#bws-test-event');
    api('/admin/sms/test', { mobile: $('#bws-test-mobile').value, event: ev ? ev.value : '' }).then(function (r) {
      var m = { live: '', test: '\n(حالت تست روشن است؛ پیامک واقعی ارسال نشد)', disabled: '\n(ارسال پیامک در تنظیمات خاموش است)' }[r.mode] || '';
      out.textContent = (r.result.sent ? '✓ ارسال شد' : '✗ ناموفق') + m + '\nپاسخ سامانه: ' + (r.response || '');
    }).catch(function (e) { out.textContent = e.message; });
  });

  // Template editor: mode switch, live preview, counters & warnings.
  $$('.bws-tpl-card').forEach(function (card) {
    var ev = card.dataset.event, ta = $('[data-tpl]', card), pa = $('[data-params]', card);
    var pat = $('.bws-tpl-pattern', card), meta = $('.bws-tpl-meta', card), out = $('.bws-tpl-out', card), warn = $('.bws-tpl-warn', card);
    function mode() { var r = $('input[type=radio]:checked', card); return r ? r.value : 'text'; }
    $$('input[type=radio]', card).forEach(function (r) { r.addEventListener('change', function () { pat.hidden = mode() !== 'pattern'; preview(); }); });
    var preview = debounce(function () {
      api('/admin/sms/preview', { event: ev, text: ta.value, params: mode() === 'pattern' ? pa.value : '' }).then(function (r) {
        meta.textContent = fa(r.chars) + ' حرف · ' + fa(r.parts) + ' پیامک' + (r.unicode ? ' (فارسی)' : '') + ' — پیش‌نمایش با مقادیر نمونه:';
        out.textContent = r.text;
        var p = r.params || {}, keys = Object.keys(p);
        var h = keys.length ? '<div class="bws-tpl-params"><b>پارامترهای ارسالی الگو:</b> ' + keys.map(function (k) { return '<code dir="ltr">' + esc(k) + ' = ' + esc(p[k]) + '</code>'; }).join(' ') + '</div>' : '';
        warn.innerHTML = h + (r.warnings || []).map(function (w) { return '<div class="bws-alert bws-alert-warn">' + esc(w) + '</div>'; }).join('');
      }).catch(function () {});
    }, 400);
    ta.addEventListener('input', preview);
    if (pa) pa.addEventListener('input', preview);
    preview();
  });

  // Returns & bots settings.
  var rf = $('#bws-returns-form');
  if (rf) {
    var dirty = false;
    rf.addEventListener('input', function () { dirty = true; });
    rf.addEventListener('submit', function () { dirty = false; });
    function needSave() { if (dirty) { toast('ابتدا تنظیمات را ذخیره کنید؛ آزمایش با تنظیمات ذخیره‌شده انجام می‌شود.', true); return true; } return false; }
    $$('[data-toggle-storage]').forEach(function (r) { r.addEventListener('change', function () { $$('[data-storage-drive]').forEach(function (b) { b.hidden = r.value === 'host'; }); }); });
    $$('[data-toggle-gmode]').forEach(function (r) { r.addEventListener('change', function () { $$('[data-gmode-box]').forEach(function (b) { b.hidden = b.dataset.gmodeBox !== r.value; }); }); });
    $$('[data-need-saved]').forEach(function (a) { a.addEventListener('click', function (e) { if (needSave()) e.preventDefault(); }); });
    $$('[data-secret]').forEach(function (i) { i.addEventListener('focus', function () { if (i.value === '••••••••') i.select(); }); });
    function out(el, html, err) { el.hidden = false; el.className = 'bws-test-out' + (err ? ' is-error' : ' is-ok'); el.innerHTML = html; }
    var dt = $('#bws-drive-test');
    if (dt) dt.addEventListener('click', function () {
      if (needSave()) return;
      var o = $('#bws-drive-out'); out(o, 'در حال بررسی...'); dt.disabled = true;
      api('/admin/returns/drive-test').then(function (r) {
        out(o, '✓ ' + esc(r.message) + (r.link ? ' — <a href="' + esc(r.link) + '" target="_blank" rel="noopener">باز کردن پوشه</a>' : ''));
      }).catch(function (e) { out(o, '✗ ' + esc(e.message), true); }).then(function () { dt.disabled = false; });
    });
    $$('[data-bot-test]').forEach(function (b) {
      b.addEventListener('click', function () {
        if (needSave()) return;
        var p = b.dataset.botTest, o = $('[data-bot-out="' + p + '"]'); out(o, 'در حال ارسال...'); b.disabled = true;
        api('/admin/returns/bot-test', { platform: p }).then(function (r) {
          var rows = Object.keys(r.results || {}).map(function (k) { var ok = r.results[k] === 'ارسال شد'; return '<div class="' + (ok ? 'bws-green' : 'bws-red') + '"><code dir="ltr">' + esc(k) + '</code> ' + (ok ? '✓ ' : '✗ ') + esc(r.results[k]) + '</div>'; }).join('');
          out(o, '<b>ربات <span dir="ltr">' + esc(r.bot) + '</span> متصل است.</b>' + rows);
        }).catch(function (e) { out(o, '✗ ' + esc(e.message), true); }).then(function () { b.disabled = false; });
      });
    });
    // Recipients repeater.
    var rcps = $('[data-rcps]'), rtpl = $('#bws-rcp-tpl'), rIdx = rcps ? $$('[data-rcp]', rcps).length + 100 : 0;
    function syncRcp(row) {
      var u = $('[data-rcp-user]', row), sc = $('[data-rcp-scope]', row), dec = $('[name$="[decide]"]', row), opt = u.options[u.selectedIndex];
      var visitor = u.value !== '0' && !(opt && opt.dataset.manager);
      sc.disabled = !visitor; if (!visitor) sc.value = 'all';
      dec.disabled = u.value === '0'; if (dec.disabled) dec.checked = false;
      row.classList.toggle('is-off', !$('[name$="[on]"]', row).checked);
    }
    function addRcp(vals) {
      var html = rtpl.innerHTML.replace(/__i__/g, String(rIdx++)), w = document.createElement('div'); w.innerHTML = html.trim();
      var row = w.firstChild; rcps.appendChild(row);
      if (vals) { if (vals.p) $('[name$="[p]"]', row).value = vals.p; if (vals.chat) $('[name$="[chat]"]', row).value = vals.chat; if (vals.name) $('[name$="[name]"]', row).value = vals.name; }
      bindRcp(row); dirty = true; return row;
    }
    function bindRcp(row) {
      $('[data-rcp-del]', row).onclick = function () { if (confirm('این گیرنده حذف شود؟ (بعد از ذخیره اعمال می‌شود)')) { row.remove(); dirty = true; } };
      $$('select,input', row).forEach(function (i) { i.addEventListener('change', function () { syncRcp(row); }); });
      syncRcp(row);
    }
    if (rcps) {
      $$('[data-rcp]', rcps).forEach(bindRcp);
      var ab = $('[data-rcp-add]'); if (ab) ab.onclick = function () { var row = addRcp(); $('[name$="[chat]"]', row).focus(); };
    }
    $$('[data-bot-chats]').forEach(function (b) {
      b.addEventListener('click', function () {
        if (needSave()) return;
        var p = b.dataset.botChats, o = $('[data-bot-out="' + p + '"]'); out(o, 'در حال دریافت...'); b.disabled = true;
        api('/admin/returns/bot-chats', { platform: p }).then(function (r) {
          if (!r.chats.length) { out(o, 'هیچ پیامی پیدا نشد. از گیرنده بخواهید ربات را باز کند، Start بزند و یک پیام بفرستد؛ سپس دوباره بزنید.', true); return; }
          var types = { 'private': 'کاربر', group: 'گروه', supergroup: 'گروه', channel: 'کانال' };
          var have = rcps ? $$('[data-rcp]', rcps).map(function (row) { return $('[name$="[p]"]', row).value + '|' + $('[name$="[chat]"]', row).value.trim(); }) : [];
          out(o, '<b>برای افزودن به «گیرندگان ربات» روی هر مورد بزنید:</b><br>' + r.chats.map(function (c) {
            var exists = have.indexOf(p + '|' + c.id) > -1;
            return '<button type="button" class="bws-btn bws-btn-sm bws-chat-add" data-id="' + esc(c.id) + '" data-name="' + esc(c.name || c.username || '') + '"' + (exists ? ' disabled' : '') + '>' + (exists ? '✓ ' : '+ ') + esc(c.name || '—') + (c.username ? ' <span dir="ltr">@' + esc(c.username) + '</span>' : '') + ' · ' + esc(types[c.type] || c.type) + ' · <code dir="ltr">' + esc(c.id) + '</code></button>';
          }).join(' ') + '<small class="bws-muted" style="display:block;margin-top:6px">بعد از افزودن، کاربر/محدوده هر گیرنده را تعیین و تنظیمات را ذخیره کنید.</small>');
          $$('.bws-chat-add', o).forEach(function (btn) {
            btn.addEventListener('click', function () {
              var row = addRcp({ p: p, chat: btn.dataset.id, name: btn.dataset.name });
              btn.disabled = true; btn.textContent = '✓ اضافه شد'; row.scrollIntoView({ behavior: 'smooth', block: 'center' });
            });
          });
        }).catch(function (e) { out(o, '✗ ' + esc(e.message), true); }).then(function () { b.disabled = false; });
      });
    });
    var bm = $('#bws-bot-mode');
    if (bm) bm.addEventListener('click', function () {
      if (needSave()) return;
      var o = $('#bws-bot-mode-out'); out(o, 'در حال اعمال...'); bm.disabled = true;
      api('/admin/returns/bot-mode').then(function (r) {
        out(o, Object.keys(r.results).map(function (k) { return '<div><b>' + esc(k) + ':</b> ' + esc(r.results[k]) + '</div>'; }).join(''));
      }).catch(function (e) { out(o, '✗ ' + esc(e.message), true); }).then(function () { bm.disabled = false; });
    });
    var dv = $('#bws-drive-verify');
    if (dv) dv.addEventListener('click', function () {
      if (needSave()) return;
      var o = $('#bws-drive-out'); out(o, 'در حال بررسی فایل‌های گوگل‌درایو...'); dv.disabled = true;
      api('/admin/returns/drive-verify').then(function (r) { out(o, esc(r.message), r.result.bad > r.result.fixed); })
        .catch(function (e) { out(o, '✗ ' + esc(e.message), true); }).then(function () { dv.disabled = false; });
    });
    // Template preview / reset.
    $$('.bws-tpl-bot').forEach(function (box) {
      var ta = $('textarea', box), po = $('.bws-tpl-prev-out', box);
      $$('[data-tpl-prev]', box).forEach(function (b) {
        b.addEventListener('click', function () {
          po.hidden = false; po.textContent = '...';
          api('/admin/returns/bot-preview', { key: box.dataset.tplKey, tpl: ta.value, platform: b.dataset.tplPrev }).then(function (r) {
            po.textContent = r.text + (r.limit ? '\n\n— ' + fa(r.length) + ' از ' + fa(r.limit) + ' حرف' + (r.over ? ' (بیشتر از حد؛ فیلدهای طولانی خودکار کوتاه می‌شوند)' : '') : '');
            po.classList.toggle('is-over', !!r.over);
          }).catch(function (e) { po.textContent = e.message; });
        });
      });
      $('[data-tpl-reset]', box).addEventListener('click', function () { ta.value = ta.dataset.default; dirty = true; });
    });
    // Host photo clean-up.
    $$('[data-cl]').forEach(function (b) {
      b.addEventListener('click', function () {
        var o = $('#bws-cl-out'), run = b.dataset.cl === 'run';
        var body = { mode: b.dataset.cl, days: $('[data-cl-days]').value, backed: $('[data-cl-backed]').checked ? 1 : 0, statuses: $$('[data-cl-st]:checked').map(function (x) { return x.value; }) };
        if (!body.statuses.length) { out(o, 'حداقل یک وضعیت را انتخاب کنید.', true); return; }
        if (run && !confirm('عکس‌های انتخاب‌شده از هاست برای همیشه حذف شوند؟ (اطلاعات درخواست‌ها و نسخه گوگل‌درایو باقی می‌ماند)')) return;
        out(o, run ? 'در حال حذف...' : 'در حال بررسی...'); b.disabled = true;
        api('/admin/returns/cleanup', body).then(function (r) {
          out(o, esc(r.message)); var u = $('[data-usage]'); if (u && r.usage) u.textContent = fa(r.usage.files) + ' عکس — ' + r.usage.size;
        }).catch(function (e) { out(o, '✗ ' + esc(e.message), true); }).then(function () { b.disabled = false; });
      });
    });
  }
  $$('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      var i = $(b.dataset.copy); if (!i) return;
      var done = function () { toast('کپی شد'); };
      if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(i.value).then(done, function () { i.select(); document.execCommand('copy'); done(); });
      else { i.select(); document.execCommand('copy'); done(); }
    });
  });

  // Visitor permission mode.
  $$('.bws-perm-mode input').forEach(function (r) {
    r.addEventListener('change', function () { var c = $('.bws-perm-custom'); if (c) c.hidden = r.value !== 'custom' || !r.checked; });
  });
})();

/* Insert SMS template variables into the last focused field (inside the same template card when possible). */
(function () {
  'use strict';
  var last = null;
  document.addEventListener('focusin', function (e) { if (e.target.tagName === 'TEXTAREA' || (e.target.tagName === 'INPUT' && e.target.type === 'text')) last = e.target; });
  document.addEventListener('click', function (e) {
    var v = e.target.closest && e.target.closest('[data-var]');
    if (!v) return;
    var card = v.closest('.bws-tpl-card');
    var target = last && card && card.contains(last) ? last : (card ? card.querySelector('[data-tpl]') : last);
    if (!target) return;
    var s = typeof target.selectionStart === 'number' ? target.selectionStart : target.value.length;
    target.value = target.value.slice(0, s) + v.textContent + target.value.slice(s);
    target.focus();
    target.dispatchEvent(new Event('input'));
  });
})();
