/* ARIAGH.VISITOR – shared front-end core: API, UI helpers, components and the wholesale shop. */
(function (window, document) {
  'use strict';
  var CFG = window.BWS || {};
  var U = { cfg: CFG };

  /* ---------------- helpers ---------------- */
  U.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  U.fa = function (s) { return String(s == null ? '' : s).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; }); };
  U.en = function (s) {
    return String(s == null ? '' : s).replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); })
      .replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
  };
  U.num = function (n) { return Math.round(Number(n) || 0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); };
  U.money = function (n, cur) { return U.num(n) + ' ' + (cur || U.currency || 'تومان'); };
  U.qs = function (sel, root) { return (root || document).querySelector(sel); };
  U.qsa = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  U.debounce = function (fn, ms) { var t; return function () { var a = arguments, s = this; clearTimeout(t); t = setTimeout(function () { fn.apply(s, a); }, ms || 300); }; };
  U.initial = function (name) { name = String(name || '').trim(); return name ? name.charAt(0) : '؟'; };
  U.store = {
    get: function (k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { window.localStorage.setItem(k, v); } catch (e) {} },
    del: function (k) { try { window.localStorage.removeItem(k); } catch (e) {} }
  };
  U.formData = function (form) {
    var o = {};
    U.qsa('input,select,textarea', form).forEach(function (el) {
      if (!el.name) return;
      if (el.type === 'checkbox') { o[el.name] = el.checked ? 1 : 0; return; }
      if (el.type === 'radio') { if (el.checked) o[el.name] = el.value; return; }
      o[el.name] = U.en(el.value);
    });
    return o;
  };
  U.copy = function (text) {
    if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(text).then(function () { U.toast('کپی شد'); }); return; }
    var ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); U.toast('کپی شد'); } catch (e) {} document.body.removeChild(ta);
  };

  /* ---------------- icons ---------------- */
  U.ic = function (name, size, cls) {
    var p = (CFG.icons || {})[name] || (CFG.icons || {}).info || '';
    size = size || 18;
    return '<svg class="bws-ic ' + (cls || '') + '" width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>';
  };

  /* ---------------- API ---------------- */
  U.token = null;
  U.api = function (path, opts) {
    opts = opts || {};
    var headers = { 'Accept': 'application/json' };
    if (CFG.nonce) headers['X-WP-Nonce'] = CFG.nonce;
    if (U.token) headers['X-BWS-Token'] = U.token;
    var url = CFG.rest.replace(/\/$/, '') + path;
    var init = { method: opts.method || 'GET', headers: headers, credentials: 'same-origin', cache: 'no-store' };
    var query = {};
    Object.keys(opts.query || {}).forEach(function (k) { query[k] = opts.query[k]; });
    // Never let a browser, page-cache plugin or CDN (LiteSpeed, ArvanCloud, Cloudflare…) serve a stale answer.
    if (init.method === 'GET') query._ = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    var q = Object.keys(query).filter(function (k) { return query[k] !== '' && query[k] != null; })
      .map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(query[k]); }).join('&');
    if (q) url += (url.indexOf('?') > -1 ? '&' : '?') + q;
    if (opts.body) { headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.body); }
    return fetch(url, init).then(function (r) {
      return r.json().catch(function () { return { ok: false, message: 'پاسخ نامعتبر از سرور (' + r.status + ')' }; }).then(function (j) {
        if (!r.ok || j.ok === false) {
          var err = new Error((j && j.message) || 'خطا در ارتباط با سرور');
          err.data = j; err.status = r.status; throw err;
        }
        return j;
      });
    }, function () { throw new Error('اتصال اینترنت را بررسی کنید.'); });
  };

  /* ---------------- UI primitives ---------------- */
  U.toast = function (msg, type) {
    var box = U.qs('.bws-toasts');
    if (!box) { box = document.createElement('div'); box.className = 'bws-toasts'; document.body.appendChild(box); }
    var t = document.createElement('div');
    t.className = 'bws-toast bws-toast-' + (type || 'ok');
    t.textContent = msg; box.appendChild(t);
    setTimeout(function () { t.classList.add('out'); setTimeout(function () { t.remove(); }, 400); }, type === 'error' ? 6000 : 3000);
  };
  U.modal = function (title, html, opts) {
    opts = opts || {};
    var wrap = document.createElement('div');
    wrap.className = 'bws-modal-wrap'; wrap.setAttribute('dir', 'rtl');
    wrap.innerHTML = '<div class="bws-modal ' + (opts.wide ? 'wide' : '') + '" role="dialog" aria-modal="true"><div class="bws-modal-head"><h3>' + U.esc(title) +
      '</h3><button type="button" class="bws-x" aria-label="بستن">' + U.ic('x', 18) + '</button></div><div class="bws-modal-body">' + html + '</div></div>';
    document.body.appendChild(wrap);
    document.body.classList.add('bws-noscroll');
    var close = function () { wrap.remove(); if (!U.qs('.bws-modal-wrap')) document.body.classList.remove('bws-noscroll'); if (opts.onClose) opts.onClose(); };
    U.qs('.bws-x', wrap).onclick = close;
    wrap.addEventListener('click', function (e) { if (e.target === wrap) close(); });
    return { el: U.qs('.bws-modal-body', wrap), close: close };
  };
  U.closeModals = function () { U.qsa('.bws-modal-wrap').forEach(function (w) { w.remove(); }); document.body.classList.remove('bws-noscroll'); };
  U.confirm = function (msg, cb) {
    var m = U.modal('تأیید', '<p style="margin:0 0 6px">' + U.esc(msg) + '</p><div class="bws-actions"><button class="bws-btn bws-btn-primary" data-y>' + U.ic('check', 16) + ' بله</button><button class="bws-btn" data-n>انصراف</button></div>');
    U.qs('[data-y]', m.el).onclick = function () { m.close(); cb(); };
    U.qs('[data-n]', m.el).onclick = m.close;
  };
  U.busy = function (btn, on) {
    if (!btn) return;
    if (on) { btn.dataset.txt = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<span class="bws-spinner"></span>'; }
    else { btn.disabled = false; if (btn.dataset.txt) btn.innerHTML = btn.dataset.txt; }
  };
  U.loading = function (el) { el.innerHTML = '<div class="bws-card"><div class="bws-card-body"><div class="bws-skeleton" style="width:40%"></div><div class="bws-skeleton"></div><div class="bws-skeleton" style="width:70%"></div></div></div>'; };
  U.errorBox = function (el, e) { el.innerHTML = '<div class="bws-alert bws-alert-error">' + U.ic('alert', 18) + '<div>' + U.esc(e.message) + '</div></div>'; };
  U.empty = function (text, icon) { return '<div class="bws-empty">' + U.ic(icon || 'inbox', 30) + U.esc(text) + '</div>'; };

  U.head = function (title, desc, icon, actions) {
    return '<div class="bws-page-head"><div><h1>' + (icon ? U.ic(icon, 22) : '') + U.esc(title) + '</h1>' + (desc ? '<p>' + U.esc(desc) + '</p>' : '') + '</div>' +
      (actions ? '<div class="bws-page-actions">' + actions + '</div>' : '') + '</div>';
  };
  U.card = function (title, desc, icon, body, opts) {
    opts = opts || {};
    return '<section class="bws-card ' + (opts.cls || '') + '"' + (opts.attr || '') + '>' + (title ? '<div class="bws-card-head"><div class="bws-card-title">' + (icon ? '<span class="bws-card-ic">' + U.ic(icon, 18) + '</span>' : '') +
      '<div><h2>' + U.esc(title) + '</h2>' + (desc ? '<p>' + U.esc(desc) + '</p>' : '') + '</div></div>' + (opts.side || '') + '</div>' : '') +
      '<div class="bws-card-body">' + body + '</div></section>';
  };
  U.stat = function (icon, color, label, value, sub, href) {
    var tag = href ? 'a' : 'div';
    return '<' + tag + ' class="bws-stat"' + (href ? ' href="' + U.esc(href) + '"' : '') + '><span class="bws-stat-ic is-' + color + '">' + U.ic(icon, 20) + '</span><div><small>' + U.esc(label) + '</small><strong>' + U.esc(value) + '</strong>' + (sub ? '<em>' + U.esc(sub) + '</em>' : '') + '</div></' + tag + '>';
  };
  U.searchbox = function (placeholder, value, cls) {
    return '<div class="bws-searchbox">' + U.ic('search', 17) + '<input type="search" class="bws-search ' + (cls || '') + '" placeholder="' + U.esc(placeholder) + '" value="' + U.esc(value || '') + '"></div>';
  };
  U.seg = function (items, active, attr) {
    return '<div class="bws-seg">' + Object.keys(items).map(function (k) { return '<button type="button" ' + attr + '="' + U.esc(k) + '" class="' + (String(k) === String(active) ? 'is-active' : '') + '">' + U.esc(items[k]) + '</button>'; }).join('') + '</div>';
  };

  U.creditCard = function (cr, extra) {
    var pct = cr.percent_used || 0;
    return '<div class="bws-credit">' +
      '<div class="bws-credit-row"><div><small>' + U.ic('wallet', 14) + ' سقف اعتبار خرید</small><strong>' + U.esc(cr.limit_text) + '</strong></div>' +
      '<div><small>استفاده‌شده (قابل تسویه)</small><strong class="bws-red">' + U.esc(cr.debt_text) + '</strong></div>' +
      '<div><small>اعتبار قابل استفاده</small><strong class="bws-green">' + U.esc(cr.available_text) + '</strong></div></div>' +
      '<div class="bws-bar-track"><span style="width:' + pct + '%"></span></div>' +
      (cr.credit_text ? '<div class="bws-muted" style="position:relative;z-index:1;margin-top:6px">بستانکار: ' + U.esc(cr.credit_text) + '</div>' : '') + (extra || '') + '</div>';
  };
  U.statusBadge = function (status, label) { return '<span class="bws-badge bws-st-' + U.esc(status) + '">' + U.esc(label) + '</span>'; };

  U.ledgerTable = function (entries) {
    if (!entries || !entries.length) return U.empty('گردش حسابی ثبت نشده است.', 'receipt');
    return '<div class="bws-table-wrap"><table class="bws-table stack"><thead><tr><th>تاریخ</th><th>شرح</th><th>بدهکار</th><th>بستانکار</th><th>مانده</th><th>ثبت توسط</th></tr></thead><tbody>' +
      entries.map(function (e) {
        var desc = '<b>' + U.esc(e.type_label) + '</b>' + (e.order_id ? ' — سفارش #' + U.fa(e.order_id) : '') + (e.method ? ' <span class="bws-badge">' + U.esc(e.method) + '</span>' : '') + (e.reference ? '<br><small class="bws-muted">پیگیری: ' + U.esc(e.reference) + '</small>' : '') + (e.note && !e.order_id ? '<br><small class="bws-muted">' + U.esc(e.note) + '</small>' : '');
        return '<tr><td data-l="تاریخ">' + U.esc(e.date) + '</td><td data-l="شرح">' + desc + '</td><td data-l="بدهکار" class="bws-red">' + (e.direction === 'debit' ? U.esc(e.amount_text) : '') +
          '</td><td data-l="بستانکار" class="bws-green">' + (e.direction === 'credit' ? U.esc(e.amount_text) : '') + '</td><td data-l="مانده"><b>' + U.esc(e.balance_text) + '</b></td><td data-l="ثبت توسط">' + U.esc(e.by) + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  };
  U.orderCards = function (orders, opts) {
    opts = opts || {};
    if (!orders || !orders.length) return U.empty('سفارشی ثبت نشده است.', 'package');
    return '<div class="bws-orders">' + orders.map(function (o) {
      return '<div class="bws-order" data-order="' + o.order_id + '"><div class="bws-order-top"><strong>' + U.ic(o.kind === 'settlement' ? 'wallet' : 'package', 17) + (o.kind === 'settlement' ? 'تسویه' : 'سفارش') + ' #' + U.fa(o.order_id) + '</strong>' + U.statusBadge(o.status, o.status_label) + '</div>' +
        (opts.showCustomer ? '<div style="margin-top:4px"><b>' + U.esc(o.customer) + '</b> <small class="bws-muted bws-ltr">' + U.esc(o.code) + '</small></div>' : '') +
        '<div class="bws-order-meta"><span>' + U.ic('calendar', 14) + ' ' + U.esc(o.date) + '</span>' + (o.qty ? '<span>' + U.fa(o.qty) + ' عدد</span>' : '') + '<span><b>' + U.esc(o.total_text) + '</b></span></div>' +
        (o.kind === 'order' ? '<div class="bws-order-meta bws-muted"><span>از اعتبار: ' + U.esc(o.credit_text) + '</span>' + (o.excess > 0 ? '<span>مازاد: ' + U.esc(o.excess_text) + ' (' + (o.excess_method === 'online' ? 'آنلاین' : 'حضوری') + ')</span>' : '') + '<span>ثبت: ' + U.esc(o.placed_by) + '</span></div>' : '') +
        '<div class="bws-order-actions">' + (o.kind === 'order' ? '<button class="bws-btn bws-btn-sm" data-act="detail">' + U.ic('eye', 15) + ' جزئیات</button>' : '') +
        (o.pay_url && opts.canPay ? '<a class="bws-btn bws-btn-sm bws-btn-primary" href="' + U.esc(o.pay_url) + '">' + U.ic('wallet', 15) + ' پرداخت</a>' : '') +
        (o.can_cancel && opts.canCancel !== false ? '<button class="bws-btn bws-btn-sm bws-btn-danger" data-act="cancel">' + U.ic('x', 15) + ' لغو سفارش</button>' : '') +
        '</div></div>';
    }).join('') + '</div>';
  };
  U.orderDetail = function (o, printBase) {
    var rows = (o.items || []).map(function (i) { return '<tr><td>' + U.esc(i.name) + '</td><td>' + U.fa(i.qty) + '</td><td>' + U.esc(i.unit_text) + '</td><td><b>' + U.esc(i.total_text) + '</b></td></tr>'; }).join('');
    return '<div class="bws-kv"><div><span>وضعیت</span>' + U.statusBadge(o.status, o.status_label) + '</div><div><span>تاریخ</span>' + U.esc(o.date) + '</div><div><span>ثبت توسط</span>' + U.esc(o.placed_by) + '</div></div>' +
      '<div class="bws-table-wrap"><table class="bws-table"><thead><tr><th>کالا</th><th>تعداد</th><th>فی</th><th>جمع</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '<div class="bws-kv"><div><span>جمع به قیمت مصرف‌کننده</span><s>' + U.esc(o.retail_text) + '</s></div><div><span>جمع عمده</span><b>' + U.esc(o.total_text) + '</b></div><div><span>از اعتبار</span>' + U.esc(o.credit_text) + '</div><div><span>پرداخت مستقیم</span>' + U.esc(o.excess_text) + '</div></div>' +
      (o.note ? '<p class="bws-muted">توضیحات: ' + U.esc(o.note) + '</p>' : '') +
      (printBase ? '<div class="bws-actions"><a class="bws-btn" target="_blank" href="' + U.esc(printBase + '&format=80') + '">' + U.ic('printer', 16) + ' فیش ۸۰ میلی‌متری</a><a class="bws-btn" target="_blank" href="' + U.esc(printBase + '&format=a5') + '">' + U.ic('printer', 16) + ' فاکتور A5</a></div>' : '');
  };

  /** Cancel dialog: asks for confirmation and an optional reason, then calls send(reason, notify). */
  U.cancelOrder = function (id, staff, send) {
    var m = U.modal('لغو سفارش #' + U.fa(id), '<div class="bws-alert bws-alert-warn">' + U.ic('alert', 18) + '<div>با لغو سفارش، مبلغ کسرشده از اعتبار به حساب مشتری برمی‌گردد و موجودی کالاها به انبار برمی‌گردد. این کار قابل بازگشت نیست.</div></div>' +
      '<label class="bws-field"><span>دلیل لغو (اختیاری)</span><textarea name="reason" rows="2" maxlength="500"></textarea></label>' +
      (staff ? '<label class="bws-switch"><input type="checkbox" name="notify"><span></span> اطلاع به مشتری با پیامک</label>' : '') +
      '<div class="bws-actions"><button class="bws-btn bws-btn-danger bws-btn-lg" data-y>' + U.ic('x-circle', 17) + ' بله، سفارش لغو شود</button><button class="bws-btn bws-btn-lg" data-n>انصراف</button></div>');
    U.qs('[data-n]', m.el).onclick = m.close;
    U.qs('[data-y]', m.el).onclick = function (e) {
      var b = e.currentTarget, n = U.qs('[name=notify]', m.el); U.busy(b, true);
      send(U.qs('[name=reason]', m.el).value, n ? n.checked : false).then(function (r) { m.close(); U.toast(r.message || 'سفارش لغو شد'); })
        .catch(function (er) { U.busy(b, false); U.toast(er.message, 'error'); });
    };
  };

  /* ---------------- Upload (multipart, with progress) ---------------- */
  U.upload = function (path, fd, onProgress) {
    return new Promise(function (resolve, reject) {
      var x = new XMLHttpRequest();
      x.open('POST', CFG.rest.replace(/\/$/, '') + path, true);
      x.withCredentials = true;
      x.timeout = 300000;
      x.setRequestHeader('Accept', 'application/json');
      if (CFG.nonce) x.setRequestHeader('X-WP-Nonce', CFG.nonce);
      if (U.token) x.setRequestHeader('X-BWS-Token', U.token);
      if (x.upload && onProgress) x.upload.onprogress = function (e) { if (e.lengthComputable) onProgress(Math.min(99, Math.round(e.loaded / e.total * 100))); };
      x.onload = function () {
        var j;
        try { j = JSON.parse(x.responseText); } catch (e) {
          j = { ok: false, message: x.status === 413 ? 'حجم عکس‌ها از حد مجاز سرور بیشتر است؛ تعداد عکس‌ها را کمتر کنید.' : 'پاسخ نامعتبر از سرور (' + x.status + ')' };
        }
        if (x.status >= 200 && x.status < 300 && j && j.ok !== false) { if (onProgress) onProgress(100); resolve(j); return; }
        var er = new Error((j && j.message) || 'خطا در ارسال'); er.data = j; er.status = x.status; reject(er);
      };
      x.onerror = function () { reject(new Error('اتصال اینترنت را بررسی کنید.')); };
      x.ontimeout = function () { reject(new Error('ارسال بیش از حد طول کشید؛ اتصال را بررسی و دوباره تلاش کنید.')); };
      x.send(fd);
    });
  };

  /** Resize/re-encode a photo in the browser (max side, JPEG) so uploads on mobile data are fast. Resolves { blob, name }. */
  U.compressImage = function (file, max, quality) {
    max = max || 1600; quality = quality || 0.85;
    var base = String(file.name || 'photo').replace(/\.[^.]+$/, '') || 'photo';
    return new Promise(function (resolve) {
      var keep = function () { resolve({ blob: file, name: file.name || base + '.jpg' }); };
      if (!/^image\//i.test(file.type || '') || /gif$/i.test(file.type) || !window.URL || !document.createElement('canvas').toBlob) { keep(); return; }
      var url = URL.createObjectURL(file), img = new Image();
      img.onload = function () {
        try {
          var w = img.naturalWidth, h = img.naturalHeight, sc = Math.min(1, max / Math.max(w, h));
          if (sc === 1 && /jpe?g$/i.test(file.type) && file.size < 900 * 1024) { URL.revokeObjectURL(url); keep(); return; }
          var c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * sc)); c.height = Math.max(1, Math.round(h * sc));
          var ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); ctx.drawImage(img, 0, 0, c.width, c.height);
          c.toBlob(function (b) {
            URL.revokeObjectURL(url);
            if (b && (b.size < file.size || !/^image\/(jpeg|png|webp)$/i.test(file.type))) resolve({ blob: b, name: base + '.jpg' }); else keep();
          }, 'image/jpeg', quality);
        } catch (e) { URL.revokeObjectURL(url); keep(); }
      };
      img.onerror = function () { URL.revokeObjectURL(url); keep(); };
      img.src = url;
    });
  };

  /* ---------------- Returns (مرجوعی) ---------------- */
  U.retStatus = { pending: 'در انتظار بررسی', approved: 'تأیید شد', rejected: 'رد شد', cancelled: 'لغو شده' };

  U.returnCards = function (list, opts) {
    opts = opts || {};
    if (!list || !list.length) return U.empty(opts.emptyText || 'درخواست مرجوعی ثبت نشده است.', 'return');
    return '<div class="bws-orders bws-returns">' + list.map(function (r) {
      return '<div class="bws-order bws-ret is-' + U.esc(r.status) + '" data-ret="' + r.id + '">' +
        '<div class="bws-order-top"><strong>' + U.ic('return', 17) + 'مرجوعی <span class="bws-ltr">' + U.esc(r.code) + '</span></strong>' + U.statusBadge(r.status, r.status_label) + '</div>' +
        (opts.showCustomer ? '<div style="margin-top:4px"><b>' + U.esc(r.customer) + '</b>' + (r.shop ? ' · ' + U.esc(r.shop) : '') + ' <small class="bws-muted bws-ltr">' + U.esc(r.customer_code) + '</small></div>' : '') +
        '<div class="bws-order-meta"><span>' + U.ic('calendar', 14) + ' ' + U.esc(r.date) + '</span><span>سفارش #' + U.fa(r.order_id) + '</span><span>' + U.ic('camera', 14) + ' ' + U.fa(r.photos_count) + ' عکس</span><span><b>' + U.esc(r.amount_text) + '</b></span></div>' +
        '<div class="bws-ret-items">' + U.ic('package', 14) + ' ' + U.esc(r.items_text) + '</div>' +
        '<div class="bws-order-meta bws-muted"><span>دلیل: ' + U.esc(r.reason) + '</span>' + (opts.showCustomer ? '<span>ویزیتور: ' + U.esc(r.visitor) + '</span><span>ثبت: ' + U.esc(r.by) + '</span>' : '') + '</div>' +
        (r.status === 'approved' && r.result_text ? '<div class="bws-ret-result is-ok">' + U.ic('check-circle', 16) + '<span>' + U.esc(r.result_text) + '</span></div>' : '') +
        (r.status === 'rejected' && r.decision_note ? '<div class="bws-ret-result is-bad">' + U.ic('x-circle', 16) + '<span>دلیل رد: ' + U.esc(r.decision_note) + '</span></div>' : '') +
        '<div class="bws-order-actions"><button type="button" class="bws-btn bws-btn-sm" data-ract="detail">' + U.ic('eye', 15) + ' جزئیات و عکس‌ها</button>' +
        (opts.canDecide && r.can_decide ? '<button type="button" class="bws-btn bws-btn-sm bws-btn-primary" data-ract="detail">' + U.ic('check-circle', 15) + ' بررسی و تأیید / رد</button>' : '') +
        (opts.canCancel && r.status === 'pending' ? '<button type="button" class="bws-btn bws-btn-sm bws-btn-danger" data-ract="cancel">' + U.ic('x', 15) + ' لغو درخواست</button>' : '') +
        '</div></div>';
    }).join('') + '</div>';
  };

  U.gallery = function (photos) {
    if (!photos || !photos.length) return '<p class="bws-muted">عکسی وجود ندارد.</p>';
    return '<div class="bws-gallery">' + photos.map(function (p, i) {
      if (p.storage === 'deleted') {
        return '<span class="bws-ph is-deleted" title="عکس برای آزادسازی فضای هاست حذف شده است"><span class="bws-ph-ic">' + U.ic('trash', 22) + '</span><em>حذف‌شده از هاست</em></span>';
      }
      if (p.storage === 'gdrive') {
        return '<a class="bws-ph" href="' + U.esc(p.url) + '" target="_blank" rel="noopener noreferrer" title="باز کردن در گوگل‌درایو">' +
          (p.thumb ? '<img loading="lazy" src="' + U.esc(p.thumb) + '" alt="عکس ' + U.fa(i + 1) + '" referrerpolicy="no-referrer">' : '') +
          '<span class="bws-ph-ic">' + U.ic('image', 26) + '</span><em>' + U.ic('external', 12) + ' گوگل‌درایو</em></a>';
      }
      return '<span class="bws-ph-wrap"><a class="bws-ph" href="' + U.esc(p.url) + '" data-lb="' + i + '" title="بزرگ‌نمایی"><img loading="lazy" src="' + U.esc(p.thumb) + '" alt="عکس ' + U.fa(i + 1) + '"><span class="bws-ph-ic">' + U.ic('image', 26) + '</span>' + (p.pending ? '<em>در صف انتقال به درایو</em>' : '') + '</a>' +
        (p.drive ? '<a class="bws-ph-drive" href="' + U.esc(p.drive) + '" target="_blank" rel="noopener noreferrer" title="نسخه گوگل‌درایو">' + U.ic('cloud', 13) + '</a>' : '') + '</span>';
    }).join('') + '</div>';
  };

  /** Host photos open in an in-panel viewer; Drive photos open on Google Drive (plain links). */
  U.bindGallery = function (root, photos) {
    root.addEventListener('error', function (e) { if (e.target && e.target.tagName === 'IMG' && e.target.closest('.bws-ph')) e.target.closest('.bws-ph').classList.add('no-img'); }, true);
    U.qsa('[data-lb]', root).forEach(function (a) {
      a.addEventListener('click', function (e) {
        e.preventDefault();
        var list = photos.filter(function (p) { return p.storage !== 'gdrive'; }), i = list.indexOf(photos[+a.dataset.lb]);
        var m = U.modal('', '<div class="bws-lightbox"><img alt=""><div class="bws-lb-bar"><button type="button" class="bws-btn bws-btn-sm" data-n="-1">→ قبلی</button><span></span><a class="bws-btn bws-btn-sm" target="_blank" rel="noopener">' + U.ic('external', 14) + ' اندازه اصلی</a><button type="button" class="bws-btn bws-btn-sm" data-n="1">بعدی ←</button></div></div>', { wide: true, onClose: function () { document.removeEventListener('keydown', key); } });
        function show(k) {
          i = (k + list.length) % list.length;
          U.qs('img', m.el).src = list[i].url; U.qs('.bws-lb-bar a', m.el).href = list[i].url;
          U.qs('.bws-lb-bar span', m.el).textContent = U.fa(i + 1) + ' از ' + U.fa(list.length);
          U.qsa('[data-n]', m.el).forEach(function (b) { b.hidden = list.length < 2; });
        }
        function key(ev) { if (ev.key === 'ArrowLeft') show(i + 1); if (ev.key === 'ArrowRight') show(i - 1); if (ev.key === 'Escape') m.close(); }
        U.qsa('[data-n]', m.el).forEach(function (b) { b.onclick = function () { show(i + +b.dataset.n); }; });
        document.addEventListener('keydown', key);
        show(i < 0 ? 0 : i);
      });
    });
  };

  U.returnDetail = function (r, opts) {
    opts = opts || {};
    var appr = r.status === 'approved';
    var rows = (r.items || []).map(function (i) {
      return '<tr><td>' + U.esc(i.name) + '</td><td>' + U.fa(i.qty) + '</td>' + (appr ? '<td><b>' + U.fa(i.approved_qty) + '</b></td>' : '') + '<td>' + U.esc(i.unit_text) + '</td><td>' + U.esc(i.total_text) + '</td></tr>';
    }).join('');
    var h = '<div class="bws-kv"><div><span>وضعیت</span>' + U.statusBadge(r.status, r.status_label) + '</div><div><span>کد پیگیری</span><b class="bws-ltr">' + U.esc(r.code) + '</b></div><div><span>تاریخ ثبت</span>' + U.esc(r.date) + '</div><div><span>سفارش</span>#' + U.fa(r.order_id) + '</div>' +
      (opts.staff ? '<div><span>مشتری</span><b>' + U.esc(r.customer) + '</b>' + (r.shop ? ' · ' + U.esc(r.shop) : '') + ' <small class="bws-ltr">' + U.esc(r.customer_code) + '</small></div>' + (r.mobile ? '<div><span>موبایل</span><a class="bws-ltr" href="tel:' + U.esc(r.mobile) + '">' + U.esc(r.mobile) + '</a></div>' : '') + '<div><span>ویزیتور</span>' + U.esc(r.visitor) + '</div><div><span>ثبت توسط</span>' + U.esc(r.by) + '</div>' : '') + '</div>' +
      '<div class="bws-table-wrap"><table class="bws-table"><thead><tr><th>کالا</th><th>تعداد معیوب</th>' + (appr ? '<th>تأییدشده</th>' : '') + '<th>فی</th><th>ارزش</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '<div class="bws-ret-box"><div><span>دلیل مرجوعی</span><b>' + U.esc(r.reason) + '</b></div>' + (r.description ? '<div><span>توضیحات</span><p class="bws-pre">' + U.esc(r.description) + '</p></div>' : '') + '<div><span>ارزش اقلام</span><b>' + U.esc(r.amount_text) + '</b></div></div>' +
      '<h4 class="bws-sub-title">' + U.ic('camera', 16) + ' عکس‌های ارسالی (' + U.fa((r.photos || []).length) + ')</h4>' + U.gallery(r.photos);
    if (r.status === 'approved' || r.status === 'rejected') {
      h += '<div class="bws-ret-result ' + (appr ? 'is-ok' : 'is-bad') + '">' + U.ic(appr ? 'check-circle' : 'x-circle', 18) + '<div><b>' + (appr ? 'تأیید شد — ' + U.esc(r.resolution_label) : 'رد شد') + '</b>' +
        (appr && r.result_text ? '<div>' + U.esc(r.result_text) + '</div>' : '') + (r.decision_note ? '<div>' + (appr ? 'توضیح: ' : 'دلیل: ') + U.esc(r.decision_note) + '</div>' : '') +
        (r.decided_at ? '<small class="bws-muted">' + (opts.staff && r.decided_by ? U.esc(r.decided_by) + ' — ' : '') + U.esc(r.decided_at) + '</small>' : '') + '</div></div>';
    }
    return h;
  };

  /**
   * Return request form (modal). opts: { options, orderId, title, submit(FormData, onProgress) -> Promise, onDone(res) }
   */
  U.returnForm = function (opts) {
    var o = opts.options || {}, orders = o.orders || [], photos = [];
    if (!o.enabled) { U.modal('ثبت مرجوعی', U.empty('ثبت مرجوعی در حال حاضر غیرفعال است.', 'return')); return; }
    if (!orders.length) {
      U.modal('ثبت مرجوعی', U.empty('سفارشی قابل مرجوعی پیدا نشد.', 'return') + '<p class="bws-muted" style="text-align:center">' + (o.days ? 'فقط سفارش‌های ' + U.fa(o.days) + ' روز اخیر که تحویل/پردازش شده‌اند' : 'فقط سفارش‌های تحویل/پردازش‌شده') + ' و اقلامی که قبلاً مرجوع نشده‌اند قابل ثبت هستند.</p>');
      return;
    }
    var pre = opts.orderId ? orders.filter(function (x) { return +x.order_id === +opts.orderId; })[0] : null;
    if (opts.orderId && !pre) U.toast('سفارش #' + U.fa(opts.orderId) + ' قابل مرجوعی نیست (مهلت گذشته، وضعیت مجاز نیست یا قبلاً مرجوع شده)؛ سفارش دیگری انتخاب کنید.', 'warn');
    var cur = pre || (orders.length === 1 ? orders[0] : null), qty = {};
    var oOpts = '<option value="">— سفارش را انتخاب کنید —</option>' + orders.map(function (x) { return '<option value="' + x.order_id + '"' + (cur && cur.order_id === x.order_id ? ' selected' : '') + '>سفارش #' + U.fa(x.order_id) + ' — ' + U.esc(x.date) + ' — ' + U.esc(x.total_text) + ' (' + U.fa(x.items.length) + ' قلم)</option>'; }).join('');
    var reasons = (o.reasons || []).map(function (rs) { return '<label class="bws-pick"><input type="radio" name="reason" value="' + U.esc(rs) + '"><span>' + U.ic('alert', 15) + U.esc(rs) + '</span></label>'; }).join('');
    var m = U.modal(opts.title || 'ثبت درخواست مرجوعی کالا', '<form class="bws-rform" novalidate>' +
      '<div class="bws-rstep"><h4><i>۱</i> سفارش</h4><select name="order_id">' + oOpts + '</select><div class="bws-ferr" data-e="order"></div></div>' +
      '<div class="bws-rstep"><h4><i>۲</i> کالاهای معیوب و تعداد</h4><div data-items></div><div class="bws-ferr" data-e="items"></div></div>' +
      '<div class="bws-rstep"><h4><i>۳</i> دلیل مرجوعی <b class="bws-red">*</b></h4><div class="bws-picks">' + reasons + '</div><div class="bws-ferr" data-e="reason"></div></div>' +
      '<div class="bws-rstep"><h4><i>۴</i> توضیحات' + (o.desc_required ? ' <b class="bws-red">*</b>' : '') + '</h4><textarea name="description" rows="3" maxlength="2000" placeholder="نوع مشکل (مثلاً کپک روی سطح محصول)، تعداد معیوب، تاریخ تولید/انقضای روی بسته و هر جزئیات دیگر…"></textarea><small class="bws-muted" data-cnt></small><div class="bws-ferr" data-e="desc"></div></div>' +
      '<div class="bws-rstep"><h4><i>۵</i> عکس‌ها ' + (o.min_photos ? '<b class="bws-red">*</b>' : '') + '</h4><p class="bws-muted" style="margin:0 0 8px">' + (o.min_photos ? 'حداقل ' + U.fa(o.min_photos) + ' و ' : '') + 'حداکثر ' + U.fa(o.max_photos) + ' عکس واضح از محصول معیوب، برچسب تاریخ و بسته‌بندی.</p>' +
      '<div class="bws-photos"><label class="bws-ph-add">' + U.ic('image', 24) + '<span>انتخاب از گالری</span><input type="file" accept="image/*" multiple hidden data-pick></label><label class="bws-ph-add">' + U.ic('camera', 24) + '<span>گرفتن عکس</span><input type="file" accept="image/*" capture="environment" hidden data-pick></label></div><div class="bws-ferr" data-e="photos"></div></div>' +
      '<div class="bws-ret-sum" data-sum></div>' +
      '<div class="bws-progress" hidden><div class="bws-bar-track"><span></span></div><div class="bws-progress-text"></div></div>' +
      '<div class="bws-actions"><button type="submit" class="bws-btn bws-btn-primary bws-btn-lg">' + U.ic('send', 18) + ' ثبت درخواست مرجوعی</button><button type="button" class="bws-btn bws-btn-lg" data-n>انصراف</button></div></form>',
      { wide: true, onClose: function () { photos.forEach(function (p) { URL.revokeObjectURL(p.url); }); } });
    var f = U.qs('form', m.el), itemsEl = U.qs('[data-items]', f), phEl = U.qs('.bws-photos', f), sumEl = U.qs('[data-sum]', f), ta = U.qs('textarea', f);
    U.qs('[data-n]', f).onclick = m.close;
    function errs(k, msg) { var e = U.qs('[data-e="' + k + '"]', f); if (e) { e.textContent = msg || ''; e.hidden = !msg; } return !msg; }
    U.qsa('.bws-ferr', f).forEach(function (e) { e.hidden = true; });
    function sum() {
      if (!cur) { sumEl.innerHTML = ''; return; }
      var n = 0, v = 0;
      cur.items.forEach(function (it) { var q = qty[it.item_id] || 0; n += q; v += q * it.unit; });
      sumEl.innerHTML = n ? U.ic('return', 16) + ' <span>' + U.fa(n) + ' عدد — ارزش تقریبی <b>' + U.money(v) + '</b></span>' : '';
    }
    function renderItems() {
      qty = {};
      if (!cur) { itemsEl.innerHTML = '<p class="bws-muted">ابتدا سفارش را انتخاب کنید.</p>'; sum(); return; }
      itemsEl.innerHTML = '<div class="bws-ritems">' + cur.items.map(function (it) {
        return '<div class="bws-ritem" data-iid="' + it.item_id + '">' + (it.image ? '<img src="' + U.esc(it.image) + '" alt="" loading="lazy">' : '<span class="bws-ritem-ic">' + U.ic('package', 20) + '</span>') +
          '<div class="bws-ritem-info"><b>' + U.esc(it.name) + '</b><small>خرید: ' + U.fa(it.qty) + ' عدد · قابل مرجوعی: ' + U.fa(it.max) + ' عدد · فی ' + U.esc(it.unit_text) + '</small></div>' +
          '<div class="bws-qty"><button type="button" class="bws-step" data-d="1" aria-label="افزایش">+</button><input class="bws-qty-in" inputmode="numeric" placeholder="۰" aria-label="تعداد معیوب"><button type="button" class="bws-step" data-d="-1" aria-label="کاهش">−</button>' +
          '<div class="bws-quick"><button type="button" data-all>همه (' + U.fa(it.max) + ')</button></div></div></div>';
      }).join('') + '</div>';
      sum();
    }
    function setQty(row, q) {
      var it = cur.items.filter(function (x) { return x.item_id === +row.dataset.iid; })[0];
      q = Math.max(0, parseInt(U.en(q), 10) || 0);
      if (q > it.max) { q = it.max; U.toast('حداکثر ' + U.fa(it.max) + ' عدد از این کالا قابل مرجوعی است.', 'warn'); }
      if (q) qty[it.item_id] = q; else delete qty[it.item_id];
      U.qs('.bws-qty-in', row).value = q ? U.fa(q) : '';
      row.classList.toggle('in-cart', q > 0); errs('items', ''); sum();
    }
    itemsEl.addEventListener('click', function (e) {
      var b = e.target.closest('button'), row = e.target.closest('.bws-ritem'); if (!b || !row) return;
      var id = +row.dataset.iid, it = cur.items.filter(function (x) { return x.item_id === id; })[0];
      if (b.dataset.d) setQty(row, (qty[id] || 0) + (+b.dataset.d));
      if (b.hasAttribute('data-all')) setQty(row, it.max);
    });
    itemsEl.addEventListener('change', function (e) { if (e.target.classList.contains('bws-qty-in')) setQty(e.target.closest('.bws-ritem'), e.target.value); });
    U.qs('[name=order_id]', f).onchange = function (e) { cur = orders.filter(function (x) { return String(x.order_id) === e.target.value; })[0] || null; errs('order', ''); renderItems(); };
    U.qsa('[name=reason]', f).forEach(function (r) { r.onchange = function () { errs('reason', ''); }; });
    ta.oninput = function () { U.qs('[data-cnt]', f).textContent = U.fa(ta.value.length) + ' / ۲۰۰۰'; errs('desc', ''); };
    function renderPhotos() {
      U.qsa('.bws-ph-item', phEl).forEach(function (x) { x.remove(); });
      var first = phEl.firstChild;
      photos.forEach(function (p, i) {
        var d = document.createElement('div'); d.className = 'bws-ph-item';
        d.innerHTML = '<img src="' + p.url + '" alt=""><button type="button" class="bws-ph-del" data-i="' + i + '" aria-label="حذف عکس">' + U.ic('x', 14) + '</button>' + (p.busy ? '<span class="bws-spinner"></span>' : '');
        phEl.insertBefore(d, first);
      });
      U.qsa('.bws-ph-add', phEl).forEach(function (a) { a.hidden = photos.length >= o.max_photos; });
    }
    phEl.addEventListener('click', function (e) {
      var b = e.target.closest('.bws-ph-del'); if (!b) return;
      var p = photos.splice(+b.dataset.i, 1)[0]; if (p) URL.revokeObjectURL(p.url); renderPhotos();
    });
    U.qsa('[data-pick]', f).forEach(function (inp) {
      inp.onchange = function () {
        var files = Array.prototype.slice.call(inp.files || []); inp.value = '';
        var room = o.max_photos - photos.length;
        if (files.length > room) U.toast('حداکثر ' + U.fa(o.max_photos) + ' عکس؛ ' + U.fa(files.length - room) + ' عکس اضافه نشد.', 'warn');
        files.slice(0, Math.max(0, room)).forEach(function (file) {
          if (!/^image\//i.test(file.type || '') && !/\.(jpe?g|png|webp|gif|heic|heif)$/i.test(file.name || '')) { U.toast('«' + file.name + '» عکس نیست.', 'error'); return; }
          var p = { url: URL.createObjectURL(file), busy: true, blob: null, name: '' };
          photos.push(p); renderPhotos();
          U.compressImage(file).then(function (c) {
            p.busy = false; p.blob = c.blob; p.name = c.name;
            if (c.blob.size > o.max_mb * 1048576) { photos.splice(photos.indexOf(p), 1); URL.revokeObjectURL(p.url); U.toast('حجم عکس «' + file.name + '» بیشتر از ' + U.fa(o.max_mb) + ' مگابایت است.', 'error'); }
            renderPhotos(); errs('photos', '');
          });
        });
      };
    });
    renderItems(); renderPhotos();
    f.onsubmit = function (e) {
      e.preventDefault();
      var reason = U.qs('[name=reason]:checked', f), desc = ta.value.trim(), lines = Object.keys(qty).map(function (k) { return { item_id: +k, qty: qty[k] }; }), ok = true;
      ok = errs('order', cur ? '' : 'سفارش را انتخاب کنید.') && ok;
      ok = errs('items', cur && !lines.length ? 'حداقل یک کالا و تعداد معیوب آن را مشخص کنید.' : '') && ok;
      ok = errs('reason', reason ? '' : 'انتخاب دلیل مرجوعی الزامی است.') && ok;
      ok = errs('desc', o.desc_required && desc.length < 5 ? 'توضیحات مشکل (نوع مشکل، تعداد معیوب و جزئیات) را بنویسید.' : '') && ok;
      ok = errs('photos', photos.length < (o.min_photos || 0) ? 'ارسال حداقل ' + U.fa(o.min_photos) + ' عکس الزامی است.' : (photos.some(function (p) { return p.busy; }) ? 'چند لحظه صبر کنید تا آماده‌سازی عکس‌ها تمام شود.' : '')) && ok;
      if (!ok) { var fe = U.qsa('.bws-ferr', f).filter(function (x) { return !x.hidden; })[0]; if (fe && fe.scrollIntoView) fe.scrollIntoView({ block: 'center', behavior: 'smooth' }); return; }
      var fd = new FormData();
      fd.append('order_id', cur.order_id); fd.append('reason', reason.value); fd.append('description', desc); fd.append('items', JSON.stringify(lines));
      photos.forEach(function (p, i) { fd.append('photos[]', p.blob, p.name || ('photo-' + (i + 1) + '.jpg')); });
      var btn = U.qs('[type=submit]', f), prog = U.qs('.bws-progress', f), bar = U.qs('.bws-bar-track span', prog), txt = U.qs('.bws-progress-text', prog);
      U.busy(btn, true); prog.hidden = false;
      opts.submit(fd, function (pc) { bar.style.width = pc + '%'; txt.textContent = pc < 100 ? 'در حال ارسال عکس‌ها… ' + U.fa(pc) + '٪' : 'در حال ثبت…'; }).then(function (res) {
        m.el.innerHTML = '<div class="bws-created"><div class="bws-success">' + U.ic('check-circle', 22) + ' ' + U.esc(res.message) + '</div><div class="bws-big-code sm bws-ltr" style="margin:14px auto">' + U.esc(res['return'].code) + '</div><p class="bws-muted">وضعیت: در انتظار بررسی — نتیجه از طریق پیامک و همین پنل اطلاع داده می‌شود.</p><button type="button" class="bws-btn bws-btn-primary" data-ok>' + U.ic('check', 16) + ' متوجه شدم</button></div>';
        U.qs('[data-ok]', m.el).onclick = m.close;
        if (opts.onDone) opts.onDone(res);
      }).catch(function (er) { U.busy(btn, false); prog.hidden = true; bar.style.width = '0'; U.toast(er.message, 'error'); });
    };
    return m;
  };

  /* ---------------- Leaderboard ---------------- */
  U.lbList = function (rows, kind, meId) {
    if (!rows || !rows.length) return U.empty('در این بازه فروشی ثبت نشده است.', 'trophy');
    var max = rows[0].sales || 1;
    return '<ol class="bws-lb">' + rows.map(function (r) {
      var sub = kind === 'visitor'
        ? U.fa(r.orders) + ' سفارش · ' + U.fa(r.buyers) + ' مشتری خریدار · ' + U.fa(r.new_customers) + ' مشتری جدید'
        : (r.shop ? U.esc(r.shop) + ' · ' : '') + U.fa(r.orders) + ' سفارش · ' + U.fa(r.qty) + ' عدد' + (r.visitor ? ' · ' + U.esc(r.visitor) : '');
      return '<li class="' + (meId && r.id === meId ? 'is-me' : '') + '"' + (kind === 'customer' ? ' data-cid="' + r.id + '" style="cursor:pointer"' : '') + '><span class="bws-rank r' + r.rank + '">' + U.fa(r.rank) + '</span>' +
        '<div class="bws-lb-main"><b>' + U.esc(r.name) + (meId && r.id === meId ? ' (شما)' : '') + '</b><small>' + sub + '</small><div class="bws-lb-bar"><i style="width:' + Math.max(4, Math.round(r.sales / max * 100)) + '%"></i></div></div>' +
        '<div class="bws-lb-val"><b>' + U.esc(r.sales_text) + '</b>' + (r.debt_text ? '<small class="bws-red">بدهی ' + U.esc(r.debt_text) + '</small>' : '') + '</div></li>';
    }).join('') + '</ol>';
  };
  U.lbHero = function (r, kind) {
    if (!r) return '';
    return '<div class="bws-hero ' + (kind === 'customer' ? 'is-blue' : '') + '"><span class="bws-hero-ic">' + U.ic(kind === 'customer' ? 'crown' : 'trophy', 28) + '</span>' +
      '<div><small>' + (kind === 'customer' ? 'مشتری برتر' : 'ویزیتور برتر') + '</small><b>' + U.esc(r.name) + '</b><span>' +
      (kind === 'customer' ? (r.shop ? U.esc(r.shop) + ' · ' : '') + U.fa(r.orders) + ' سفارش' : U.fa(r.orders) + ' سفارش · ' + U.fa(r.new_customers) + ' مشتری جدید') + '</span></div>' +
      '<div class="bws-hero-val"><small>مجموع خرید</small><strong>' + U.esc(r.sales_text) + '</strong></div></div>';
  };

  /* ---------------- Shop component ---------------- */
  /**
   * opts: { el, credit, settings, cart, saveCart(cart), quote(items), submit(items, method, note), onDone(res), staff }
   */
  U.Shop = function (opts) {
    var S = { products: [], cart: {}, q: '', cat: '' };
    var st = opts.settings || {};
    U.currency = st.currency || U.currency;
    Object.keys(opts.cart || {}).forEach(function (k) { S.cart[k] = +opts.cart[k]; });
    var el = opts.el;
    var save = U.debounce(function () { if (opts.saveCart) opts.saveCart(S.cart); }, 700);

    function count() { return Object.keys(S.cart).reduce(function (a, k) { return a + (S.cart[k] || 0); }, 0); }
    function lines() { return Object.keys(S.cart).filter(function (k) { return S.cart[k] > 0; }).length; }
    function total() { return S.products.reduce(function (a, p) { return a + (S.cart[p.id] || 0) * p.price; }, 0); }
    function retailTotal() { return S.products.reduce(function (a, p) { return a + (S.cart[p.id] || 0) * p.retail; }, 0); }
    function setQty(id, q) {
      q = Math.max(0, parseInt(U.en(q), 10) || 0);
      var p = S.products.filter(function (x) { return x.id === id; })[0];
      if (p && p.stock !== null && !p.backorders && q > p.stock) { q = p.stock; U.toast('موجودی این محصول ' + U.fa(p.stock) + ' عدد است', 'warn'); }
      if (q) S.cart[id] = q; else delete S.cart[id];
      var row = U.qs('[data-pid="' + id + '"]', el);
      if (row) { U.qs('input.bws-qty-in', row).value = q || ''; row.classList.toggle('in-cart', q > 0); }
      bar(); save();
    }
    function cats() {
      var set = {};
      S.products.forEach(function (p) { (p.categories || []).forEach(function (c) { set[c] = 1; }); });
      return Object.keys(set);
    }
    function productHtml(p) {
      var q = S.cart[p.id] || 0;
      return '<div class="bws-prod ' + (q ? 'in-cart ' : '') + (p.in_stock ? '' : 'oos') + '" data-pid="' + p.id + '" data-name="' + U.esc((p.name + ' ' + p.sku).toLowerCase()) + '" data-cats="' + U.esc((p.categories || []).join('|')) + '">' +
        '<div class="bws-prod-img"><img loading="lazy" src="' + U.esc(p.image) + '" alt="" data-zoom="' + U.esc(p.image_large) + '">' + (p.discount > 0 ? '<span class="bws-off">٪' + U.fa(p.discount) + '</span>' : '') + '</div>' +
        '<div class="bws-prod-info"><h4>' + U.esc(p.name) + '</h4>' +
        (p.desc ? '<div class="bws-prod-desc">' + p.desc + '</div><button type="button" class="bws-more">توضیحات بیشتر</button>' : '') +
        '<div class="bws-prices">' + (st.show_retail ? '<div class="bws-retail">' + U.esc(st.retail_label) + ' <s>' + U.esc(p.retail_text) + '</s></div>' : '') +
        '<div class="bws-wholesale"><span>' + U.esc(st.wholesale_label) + '</span><b>' + U.esc(p.price_text) + '</b></div></div>' +
        (p.in_stock ? '' : '<div class="bws-oos-label">ناموجود</div>') + '</div>' +
        (p.in_stock ? '<div class="bws-qty"><button type="button" class="bws-step" data-d="1" aria-label="افزایش">+</button><input class="bws-qty-in" inputmode="numeric" value="' + (q || '') + '" placeholder="۰" aria-label="تعداد"><button type="button" class="bws-step" data-d="-1" aria-label="کاهش">−</button>' +
        '<div class="bws-quick"><button type="button" data-add="5">+۵</button><button type="button" data-add="10">+۱۰</button><button type="button" data-add="20">+۲۰</button></div></div>' : '') + '</div>';
    }
    function bar() {
      var c = count(), min = st.min_qty || 0, t = total();
      var b = U.qs('.bws-cartbar', el);
      if (!b) return;
      var pct = min ? Math.min(100, Math.round(c / min * 100)) : 100;
      var avail = opts.credit ? opts.credit.available : 0;
      U.qs('.bws-cb-count', b).textContent = U.fa(c) + (min ? ' از حداقل ' + U.fa(min) : '') + ' عدد';
      U.qs('.bws-cb-total', b).textContent = U.money(t);
      U.qs('.bws-cb-ic em', b).textContent = U.fa(lines());
      U.qs('.bws-cb-bar span', b).style.width = pct + '%';
      U.qs('.bws-cb-bar', b).classList.toggle('done', c >= min);
      var hint = U.qs('.bws-cb-hint', b);
      if (c < min) hint.textContent = U.fa(min - c) + ' عدد دیگر تا حداقل سفارش';
      else if (st.min_amount && t < st.min_amount) hint.textContent = U.money(st.min_amount - t) + ' دیگر تا حداقل مبلغ سفارش';
      else if (opts.credit && t > avail) hint.textContent = 'مازاد بر اعتبار: ' + U.money(t - avail);
      else hint.textContent = 'صرفه‌جویی شما: ' + U.money(retailTotal() - t);
      U.qs('.bws-cb-go', b).disabled = c < min || c === 0 || (st.min_amount && t < st.min_amount);
      b.classList.toggle('empty', c === 0);
    }
    function filter() {
      var q = S.q.toLowerCase().trim(), cat = S.cat, shown = 0;
      U.qsa('.bws-prod', el).forEach(function (r) {
        var ok = (!q || r.dataset.name.indexOf(q) > -1) && (!cat || ('|' + r.dataset.cats + '|').indexOf('|' + cat + '|') > -1);
        r.style.display = ok ? '' : 'none'; if (ok) shown++;
      });
    }
    function render() {
      var cl = cats();
      el.innerHTML = '<div class="bws-shop-tools">' + U.searchbox('جستجوی محصول…') +
        (cl.length ? '<select class="bws-cat"><option value="">همه دسته‌ها</option>' + cl.map(function (c) { return '<option>' + U.esc(c) + '</option>'; }).join('') + '</select>' : '') + '</div>' +
        '<div class="bws-rules">' + U.ic('info', 17) + '<span>' + (st.min_qty ? 'حداقل سفارش <b>' + U.fa(st.min_qty) + ' عدد</b> است — از هر نوع محصولی که بخواهید' : 'سفارش از هر تعداد') + (st.max_qty ? ' (حداکثر ' + U.fa(st.max_qty) + ' عدد)' : '') + (st.min_amount_text ? ' — حداقل مبلغ سفارش: <b>' + U.esc(st.min_amount_text) + '</b>' : '') + '.</span></div>' +
        '<div class="bws-prods">' + (S.products.length ? S.products.map(productHtml).join('') : U.empty('محصولی برای فروش عمده فعال نشده است.', 'package')) + '</div>' +
        '<div class="bws-cartbar empty"><span class="bws-cb-ic">' + U.ic('cart', 22) + '<em>۰</em></span><div class="bws-cb-info"><div class="bws-cb-line"><b class="bws-cb-total"></b><span class="bws-cb-count"></span></div><div class="bws-cb-bar"><span></span></div><small class="bws-cb-hint"></small></div>' +
        '<div class="bws-cb-btns"><button type="button" class="bws-btn bws-icon-btn bws-cb-clear" title="خالی کردن سبد">' + U.ic('trash', 17) + '</button><button type="button" class="bws-btn bws-btn-primary bws-cb-go">' + U.ic('bag', 17) + ' ثبت سفارش</button></div></div>';
      bar();
      U.qs('.bws-search', el).addEventListener('input', U.debounce(function (e) { S.q = e.target.value; filter(); }, 150));
      var catSel = U.qs('.bws-cat', el); if (catSel) catSel.addEventListener('change', function (e) { S.cat = e.target.value; filter(); });
      el.onclick = function (e) {
        var t = e.target.closest('button,img') || e.target;
        var row = t.closest ? t.closest('.bws-prod') : null;
        if (t.classList.contains('bws-step') && row) { var id = +row.dataset.pid; setQty(id, (S.cart[id] || 0) + (+t.dataset.d)); }
        else if (t.dataset.add && row) { var id2 = +row.dataset.pid; setQty(id2, (S.cart[id2] || 0) + (+t.dataset.add)); }
        else if (t.classList.contains('bws-more')) { row.classList.toggle('open'); t.textContent = row.classList.contains('open') ? 'بستن توضیحات' : 'توضیحات بیشتر'; }
        else if (t.dataset.zoom) { U.modal('', '<img class="bws-zoom" src="' + U.esc(t.dataset.zoom) + '" alt="">'); }
        else if (t.classList.contains('bws-cb-go')) { checkout(); }
        else if (t.classList.contains('bws-cb-clear')) { U.confirm('سبد خرید خالی شود؟', function () { Object.keys(S.cart).forEach(function (k) { setQty(+k, 0); }); }); }
      };
      el.onchange = function (e) {
        if (e.target.classList.contains('bws-qty-in')) { setQty(+e.target.closest('.bws-prod').dataset.pid, e.target.value); }
      };
    }
    function checkout() {
      var items = {};
      Object.keys(S.cart).forEach(function (k) { items[k] = S.cart[k]; });
      var m = U.modal('سبد خرید عمده', '<div class="bws-loading"><span class="bws-spinner"></span> در حال محاسبه…</div>', { wide: true });
      opts.quote(items).then(function (r) {
        var q = r.quote, methods = '';
        if (q.excess > 0) {
          var on = st.excess_online, off = st.excess_offline;
          methods = '<div class="bws-alert bws-alert-warn">' + U.ic('alert', 18) + '<div>مبلغ سفارش از اعتبار بیشتر است. <b>' + U.esc(q.credit_used_text) + '</b> از اعتبار کسر می‌شود و <b>' + U.esc(q.excess_text) + '</b> باید مستقیم پرداخت شود.</div></div>' +
            '<div class="bws-methods">' + (on ? '<label class="bws-radio"><input type="radio" name="excess_method" value="online" checked> ' + U.ic('wallet', 17) + ' پرداخت آنلاین مبلغ مازاد (درگاه بانکی' + (st.snapppay ? ' یا اقساطی با اسنپ‌پی' : '') + ')' + (opts.staff ? ' — لینک پرداخت برای مشتری پیامک می‌شود' : '') + '</label>' : '') +
            (off ? '<label class="bws-radio"><input type="radio" name="excess_method" value="offline" ' + (on ? '' : 'checked') + '> ' + U.ic('cash', 17) + ' پرداخت حضوری / نقدی به ویزیتور (به بدهی اضافه می‌شود)</label>' : '') + '</div>';
        }
        var rows = q.lines.map(function (l) { return '<tr><td>' + U.esc(l.name) + '</td><td>' + U.fa(l.qty) + '</td><td><b>' + U.esc(l.total_text) + '</b></td></tr>'; }).join('');
        m.el.innerHTML = '<div class="bws-table-wrap"><table class="bws-table"><thead><tr><th>محصول</th><th>تعداد</th><th>جمع</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
          '<div class="bws-kv"><div><span>تعداد کل</span><b>' + U.fa(q.qty) + ' عدد</b></div><div><span>جمع به قیمت مصرف‌کننده</span><s>' + U.esc(q.retail_text) + '</s></div><div><span>جمع به قیمت عمده</span><b>' + U.esc(q.total_text) + '</b></div>' +
          '<div><span>صرفه‌جویی</span><b class="bws-green">' + U.esc(q.saving_text) + '</b></div><div><span>کسر از اعتبار</span><b>' + U.esc(q.credit_used_text) + '</b></div><div><span>پرداخت مستقیم</span><b class="bws-red">' + U.esc(q.excess_text) + '</b></div><div><span>اعتبار باقیمانده بعد از سفارش</span><b class="bws-green">' + U.esc(q.available_after) + '</b></div></div>' +
          methods + (st.allow_note || opts.staff ? '<label class="bws-field"><span>توضیحات سفارش (اختیاری)</span><textarea name="note" rows="2"></textarea></label>' : '') +
          '<div class="bws-actions"><button class="bws-btn bws-btn-primary bws-btn-lg" data-submit>' + U.ic('check-circle', 18) + ' ثبت نهایی سفارش</button><button class="bws-btn bws-btn-lg" data-back>ادامه خرید</button></div>';
        U.qs('[data-back]', m.el).onclick = m.close;
        U.qs('[data-submit]', m.el).onclick = function (e) {
          var btn = e.currentTarget, meth = U.qs('input[name=excess_method]:checked', m.el), note = U.qs('textarea[name=note]', m.el);
          U.busy(btn, true);
          opts.submit(items, meth ? meth.value : '', note ? note.value : '').then(function (res) {
            S.cart = {}; m.close();
            if (res.pay_url && !opts.staff) {
              U.modal('پرداخت مبلغ مازاد', '<p>' + U.esc(res.message) + '</p><a class="bws-btn bws-btn-primary bws-btn-block" href="' + U.esc(res.pay_url) + '">' + U.ic('wallet', 17) + ' رفتن به درگاه پرداخت</a>');
              setTimeout(function () { window.location.href = res.pay_url; }, 1800);
            } else {
              U.modal('سفارش ثبت شد', '<div class="bws-created"><div class="bws-success">' + U.ic('check-circle', 22) + ' ' + U.esc(res.message) + '</div><div class="bws-big-code sm" style="margin:14px auto">#' + U.esc(res.order_id) + '</div></div>');
            }
            if (opts.onDone) opts.onDone(res);
          }).catch(function (err) { U.busy(btn, false); U.toast(err.message, 'error'); });
        };
      }).catch(function (err) { m.close(); U.toast(err.message, 'error'); });
    }

    el.innerHTML = '<div class="bws-loading"><span class="bws-spinner"></span> بارگذاری محصولات…</div>';
    U.api('/catalog', { query: opts.customerId ? { customer: opts.customerId } : null }).then(function (r) {
      S.products = r.products || []; st = Object.assign({}, r.settings, st); U.currency = st.currency;
      var ids = {}; S.products.forEach(function (p) { ids[p.id] = 1; });
      Object.keys(S.cart).forEach(function (k) { if (!ids[k]) delete S.cart[k]; });
      render();
    }).catch(function (e) { U.errorBox(el, e); });

    return { setCredit: function (c) { opts.credit = c; bar(); } };
  };

  /* ---------------- App frame (top bar + side nav + bottom nav) ---------------- */
  /**
   * items: [{ key, label, icon, group }] ; opts: { brandTitle, brandSub, chips, mobile: [keys] }
   */
  U.frame = function (root, items, opts) {
    var group = '';
    var nav = items.map(function (it) {
      var g = '';
      if (it.group && it.group !== group) { group = it.group; g = '<div class="bws-nav-group">' + U.esc(group) + '</div>'; }
      if (it.href) return g + '<a class="bws-nav-link" href="' + U.esc(it.href) + '">' + U.ic(it.icon, 18) + '<span>' + U.esc(it.label) + '</span></a>';
      return g + '<button type="button" data-nav="' + it.key + '">' + U.ic(it.icon, 18) + '<span>' + U.esc(it.label) + '</span>' + (it.count ? '<em class="bws-count">' + U.esc(it.count) + '</em>' : '') + '</button>';
    }).join('');
    var mob = (opts.mobile || items.map(function (i) { return i.key; })).map(function (k) {
      var it = items.filter(function (x) { return x.key === k; })[0];
      if (it && it.href) return '<a class="bws-nav-link" href="' + U.esc(it.href) + '">' + U.ic(it.icon, 21) + '<span>' + U.esc(it.short || it.label) + '</span></a>';
      return it ? '<button type="button" data-nav="' + it.key + '">' + U.ic(it.icon, 21) + '<span>' + U.esc(it.short || it.label) + '</span></button>' : '';
    }).join('');
    var brand = (CFG.logo && CFG.logoMode === 'company') ? '<img src="' + U.esc(CFG.logo) + '" alt="">' : (CFG.markSvg ? '<img class="bws-mark" src="' + U.esc(CFG.markSvg) + '" alt="" width="38" height="38">' : '<span class="bws-logo">' + U.ic('store', 22) + '</span>');
    root.classList.add('bws-ui', 'bws-front');
    root.innerHTML = '<header class="bws-top"><div class="bws-brand">' + brand + '<div><strong>' + U.esc(opts.brandTitle) + '</strong><small>' + U.esc(opts.brandSub || '') + '</small></div></div>' +
      '<div class="bws-top-status">' + (opts.chips || '') + '</div></header>' +
      '<div class="bws-shell"><nav class="bws-nav" aria-label="بخش‌ها">' + nav + (opts.foot ? '<div class="bws-nav-foot">' + opts.foot + '</div>' : '') + '</nav><main class="bws-main"></main></div>' +
      '<nav class="bws-bnav">' + mob + '</nav>';
    return { main: U.qs('.bws-main', root), top: U.qs('.bws-top-status', root) };
  };
  U.setActive = function (key) {
    U.qsa('[data-nav],[data-spa-tab]').forEach(function (b) { b.classList.toggle('is-active', (b.dataset.nav || b.dataset.spaTab) === key); });
  };

  window.BWSU = U;
})(window, document);
