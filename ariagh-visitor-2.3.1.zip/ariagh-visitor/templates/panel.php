<?php
/**
 * Full-screen app template for the panels (no theme header/footer).
 * Used when Settings → Appearance → Display mode = "Full-screen app".
 */
defined( 'ABSPATH' ) || exit;
$bws_color = sanitize_hex_color( bws_opt( 'ui_primary', '#1D4ED8' ) );
?><!doctype html>
<html <?php language_attributes(); ?> dir="rtl">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
	<meta name="theme-color" content="<?php echo esc_attr( $bws_color ? $bws_color : '#1D4ED8' ); ?>">
	<meta name="mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'bws-standalone' ); ?>>
<?php
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
}
while ( have_posts() ) {
	the_post();
	the_content();
}
wp_footer();
?>
</body>
</html>
